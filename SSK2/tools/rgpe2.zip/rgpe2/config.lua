-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2016 (All Rights Reserved)
-- =============================================================
-- Roaming Gamer Particle Editor 2 (a free SSK2 co-product)
-- =============================================================
-- See README.md for full license details.
-- =============================================================
--   Last Updated: 15 DEC 2016
-- =============================================================
application = {
	content = {
		
		width 	= 720, 
		height 	= 1280,
		scale 	= "letterbox",
		fps 	= 60,
	},
}

