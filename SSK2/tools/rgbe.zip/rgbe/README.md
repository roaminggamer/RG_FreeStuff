#Roaming Gamer Button (Presets) Editor - (a free SSK2 PRO co-product)

# LICENSE
Copyright (C) Roaming Gamer, LLC. 2016
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0)

This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

**This product requires a licensed copy of [SSK2 PRO](https://roaminggamer.github.io/RGDocs/pages/SSK2/) to run.**

**While you may distribute the Generic (Tool) Framework code, be aware YOU MUST NOT distribute SSK2 along with it.**


## ADDITIONAL LICENSE NOTES
Many hours of genuine hard work have gone into this project.  

Please do not sell this code.  

If you want to modify it and improve it, then distribute those improvements: **Awesome!**

Thanks for you support.


# ABOUT THIS TOOL
+ This is my attempt to create a starter frame from which to make other tools.
+ It requires requires [SSK2 PRO](https://roaminggamer.github.io/RGDocs/pages/SSK2/) `2016.005` or later to run.
+ Written by Ed Maurina (aka [The Roaming Gamer](http://roaminggamer.com/)).


# SUPPORT
+ No docs as of yet.  Sorry, but this is a Work In Progress
+ Please do not e-mail me directly.  Use the Corona SDK forums.
