-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
_G.fontN = "Roboto-Thin.ttf"
_G.fontB = "Lato-Black.ttf"
-- =============================================================

-- *************************************************************
-- GLOBALS * GLOBALS * GLOBALS * GLOBALS * GLOBALS * GLOBALS * 
-- *************************************************************
require "easy.globals"


-- *************************************************************
-- STANDARD REQUIRES * STANDARD REQUIRES * STANDARD REQUIRES  
-- *************************************************************
local common    = require "scripts.common"
local utils     = require "easy.utils"
local soundMgr  = require "easy.soundMgr"
local persist   = require "easy.persist"


-- *************************************************************
-- BUTTON PRESETS * BUTTON PRESETS * BUTTON PRESETS * BUTTON PRESETS 
-- *************************************************************
require "presets.presets"


-- *************************************************************
-- SOUND MANGAGER * SOUND MANGAGER * SOUND MANGAGER * SOUND MANGAGER 
-- *************************************************************
soundMgr.addEffect( "click", "sounds/sfx/click.wav")


-- *************************************************************
-- PERSISTENT SETTINGS * PERSISTENT SETTINGS * PERSISTENT SETTINGS
-- *************************************************************
persist.setDefault( "settings.json", "sound_enabled", true )
