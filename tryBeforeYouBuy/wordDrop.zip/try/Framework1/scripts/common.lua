-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- common.lua - Common Scratch Pad
-- =============================================================
local common = {}

--
-- Capture safe insets once and use them as needed elswewhere
common.topInset, common.leftInset, 
common.bottomInset, common.rightInset = display.getSafeAreaInsets()

return common
