-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
_G.fontN = "Roboto-Thin.ttf"
_G.fontB = "Lato-Black.ttf"
-- =============================================================
require "easy.globals"
local letterselector = require "scripts.letterselector"
local utils 			= require "easy.utils"
local worddrop 		= require "easy.worddrop"
local physics  		= require "physics"

physics.start()
physics.setGravity(0,30)

local group = display.newGroup()

local curScore = 0
local scoreLabel = display.newText( curScore, centerX, top + 40, fontN, 44 )
local lastWordLabel  = display.newText( "Word Drop", centerX, bottom - 40, fontN, 44 ) 


--
-- Replace default 'getRandomLeter()' function with custom function
--
-- Not required.  
--
-- The module comes with a basic letter selector, but
-- you can replaec it wit your own.
-- 
letterselector.randomizeDieOrder( 1000 )
function worddrop.getRandomLetter()
	return string.upper(letterselector.getRandomLetter())
end

--
-- Replace default 'getLetterValue()' function with custom function.
--
-- Not required.  
--
-- This example is dumb, but hey this is just a demo.
--
function worddrop.getLetterValue( letter )
   return string.find( "ABCDEFGHIJKLMNOPQRSTUVWXYZ", letter )
end

--
-- Replace default 'getLetterValue()' function with custom function.
--
-- Not required.  
--
-- This example is dumb, but hey this is just a demo.
--
local words = utils.load( "data/enable1.json", system.ResourceDirectory )
function worddrop.testWord( word )
   word = string.lower( word )
   if( words[word] ) then 
   	return true, string.upper(word)
   end

   word = word:reverse()
   if( words[word] ) then 
   	return true, string.upper(word)
   end
   return false, word:reverse()
end

local function scoreListener( value )
	curScore = curScore + value
	scoreLabel.text = curScore
end


local function wordListener( word )
	lastWordLabel.text = word
end
                          
local board = worddrop.new( group, centerX, centerY, 
	                        { cols = 7, rows = 9,
	                          size = 80, tween = 4, cellColor = {1,1,1},
	                          outlineSize = 90, outlineColor = { 1,0,0 },
	                          backColor = { 0.125, 0.125, 0.125 }, 
	                          extraHeight = 20, 
	                          extraWidth = 20,
	                          letterOX = 1, --letterOY = 1,
	                          font = "Lato-Black.ttf", fontSize = 46,
	                          scoreFont = "Lato-Black.ttf", scoreSize = 32,
	                          kickMag = 0.15, spinMag = 360 * 3, 
	                          fontColor = {0,0,0},
	                          wordListener = wordListener,
	                          scoreListener = scoreListener  } )

