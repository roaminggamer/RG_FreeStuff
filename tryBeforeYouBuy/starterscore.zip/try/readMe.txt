-- =============================================================
-- Starters Core - 'Documentation'
-- =============================================================
This is a 'try before you buy' template.  Feel free to use it and 
make games with it, but if you want to distribute them please buy it.

Thanks,
Roaming Gamer


-- =============================================================
-- Need Help?
-- =============================================================
Aside from fixing bugs and releasing update to the module(s),
support is not provided. 

That said, if you need help making your game, I am available and 
you can pay me to help.

Send me an email titled 'Paid Help - Starters Core' at roaminggamer@gmail.com

I'll get back to you promptly.


-- =============================================================
-- What Comes In This Template
-- =============================================================
+ easy       - Starters core modules.
+ Framework1 - Basic Framework: No Ads and No IAP. (Includes: Splash Scene, Home Scene (Main Menu), and Play Scene, and basic game module.)
+ Framework2 - Framework1 + Banner Ads and 'No Ads' IAP.
+ Framework3 - Framework1 + Banner Ads, Interstitial on nth 'death', Rewarded Ad to 'continue game' after death, and 'No Ads' IAP to turn off Banners and Interstitials.
+ readMe.txt    - This file.

-- =============================================================
-- Docs
-- =============================================================
The docs are online here:

https://roaminggamer.github.io/RGDocs/pages/Try/starterscore

