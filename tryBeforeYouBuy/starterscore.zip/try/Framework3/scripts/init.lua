-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
_G.fontN = "Roboto-Thin.ttf"
_G.fontB = "Lato-Black.ttf"
-- =============================================================

-- *************************************************************
-- GLOBALS * GLOBALS * GLOBALS * GLOBALS * GLOBALS * GLOBALS * 
-- *************************************************************
require "easy.globals"


-- *************************************************************
-- STANDARD REQUIRES * STANDARD REQUIRES * STANDARD REQUIRES  
-- *************************************************************
local common    = require "scripts.common"
local utils     = require "easy.utils"
local soundMgr  = require "easy.soundMgr"
local persist   = require "easy.persist"


-- *************************************************************
-- BUTTON PRESETS * BUTTON PRESETS * BUTTON PRESETS * BUTTON PRESETS 
-- *************************************************************
require "presets.presets"


-- *************************************************************
-- SOUND MANGAGER * SOUND MANGAGER * SOUND MANGAGER * SOUND MANGAGER 
-- *************************************************************
soundMgr.addEffect( "click", "sounds/sfx/click.wav")


-- *************************************************************
-- PERSISTENT SETTINGS * PERSISTENT SETTINGS * PERSISTENT SETTINGS
-- *************************************************************
persist.setDefault( "settings.json", "sound_enabled", true )
persist.setDefault( "settings.json", "ads_enabled", true )
persist.setDefault( "settings.json", "request_gdpr_consent", false )
--persist.setDefault( "settings.json", "has_gdpr_consent", false )


-- *************************************************************
-- ADS * ADS * ADS * ADS * ADS * ADS * ADS * ADS * ADS * ADS 
-- *************************************************************
local providerName = "Appodeal" -- AppLovin Appodeal
local adParams
--
if( providerName == "AppLovin" ) then
   _G.adsHelper = require( "easy.ads.applovinAds" )
   adParams = {
      testMode       = true, -- Set to false before building for release
      verbose        = false, -- Set to 'true' for detailed messages from event listener
      verboseLogging = false, -- Set to 'true' for detailed output from provider plugin
      initDelay      = 30, -- Short delay before init allows main to finish first.
      androidID      = "ANDROID_ID_HERE", -- Supply Android ad ID or comment out
      iosID          = "IOS_ID_HERE", -- Supply iOS ad ID or comment out
      enableFakeAds  = true, -- Set to 'true' to enable fake ads in simulator      
   }

elseif( providerName == "Appodeal" ) then
   _G.adsHelper = require( "easy.ads.appodealAds" ) -- APPODEAL
   adParams = {      
      testMode          = true, -- Set to false before building for release
      verbose           = false, -- Set to 'true' for detailed messages from event listener
      initDelay         = 30, -- Short delay before init allows main to finish first.
      androidID         = "ANDROID_ID_HERE", -- Supply Android ad ID or comment out
      iosID             = "IOS_ID_HERE", -- Supply iOS ad ID or comment out
      supportedAdTypes  = { "banner", "interstitial", "rewardedVideo" },
      isCOPPACompliant  = false, -- Set to 'true' if your game is COPPA compliant
      enableFakeAds     = true, -- Set to 'true' to enable fake ads in simulator
      
      -- Comment out this line if you are not explicity setting GDPR settings
      hasGDPRConsent    = persist.get( "settings.json", "has_gdpr_consent" ),

      -- ONLY ONE OF THESE CAN BE ENABLED:
      --
      -- Uncomment this line if you want to immediately show a banner ad after init
      --bannerAfterInit         = { position = "bottom", placement = nil }, -- bottom top
      -- Uncomment this line if you want to immediately show a interstitial ad after init
      --interstitialAfterInit   = { placement = nil },
   }

end
--

--
-- Handle the four (4) possible GDPR cases...
-- 
-- CASE 1: Ads have been disabled, so just initialize the helper as it won't matter anyways
if( persist.get( "settings.json", "ads_enabled" ) == false ) then
   adsHelper.prepare( true, adParams )

-- CASE 2:  Already has consent, so initialize.
elseif( persist.get( "settings.json", "has_gdpr_consent" ) == true ) then
   adsHelper.prepare( true, adParams )

-- CASE 3:  Doesn't have permission yet, but you want to ask
elseif( persist.get( "settings.json", "request_gdpr_consent" ) == true ) then

   -- Make the splash screen wait if while the user reads the dialog.
   common.gdpr_dialog_is_showing = true

   --
   local function onYes()
      persist.set( "settings.json", "has_gdpr_consent", true ) 
      adsHelper.prepare( true, adParams )
      common.gdpr_dialog_is_showing = false
   end
   local function onNo()
      persist.set( "settings.json", "has_gdpr_consent", false ) 
      adsHelper.prepare( true, adParams )
      common.gdpr_dialog_is_showing = false
   end
   local function onDoNotAskAgain()
      persist.set( "settings.json", "has_gdpr_consent", false ) 
      persist.set( "settings.json", "request_gdpr_consent", false ) 
      adsHelper.prepare( true, adParams )
      common.gdpr_dialog_is_showing = false
   end
   local function onAskMeLater()
      adsHelper.prepare( true, adParams )
      common.gdpr_dialog_is_showing = false
   end
   
   --   
   -- Tip: You should carefully review this statement and if you have a lawyer available to you,
   -- I strongly suggest you get a second opinion on the verbiage below.
   --
   utils.easyAlert( "Personalized Ad Experience",
                      providerName .. " personalizes your advertising experience.\n\n" .. 
                      providerName .. " and its partners may collect and process personal data such as " ..
                      "device identifiers, location data, and other demographic and interest data to provide an advertising " ..
                      "experience tailored to you.\n\n" ..
                      "By agreeing to this, you are confirming you are over the age of 16 and that you would like a personalized experience.", 
                      {
                        {"Ask Me Later", onAskMeLater },
                        {"Don't Ask Again", onDoNotAskAgain },
                        {"I Do Not Consent", onNo },
                        {"I Consent", onYes },
                     } )

-- CASE 4:You don't have permission and you don't want to ask, or the user
-- said do not ask me again...
else 
   adsHelper.prepare( true, adParams )
end


-- *************************************************************
-- IAP * IAP * IAP * IAP * IAP * IAP * IAP * IAP * IAP * IAP 
-- *************************************************************
_G.easyIAP = require "easy.iap.easyIAP"

local ids = { android = {}, ios = {} }

-- Set IDs for 'No Ads' iap
ids.android.noads       = "com.yourcompany.appname.noads" -- replace with your Android IAP ID
ids.ios.noads           = "com.yourcompany.appname.noads" -- replace with your iOS IAP ID
--

local os = utils.os()
if( os == "android" or os == "ios" ) then
   easyIAP.addItem( "noads", ids[os].noads, "non-consumable"  )
end
--
easyIAP.init( 
   {
      salt               = "TypeSomeRandomStringHere",
      testMode           = true,
      doNotLoadInventory = false,
   } )
