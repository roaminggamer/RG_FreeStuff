-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================

require "scripts.init"

--
-- Load First Scene (or go directly to a scene while debugging/modifying/editing the game)
--
local composer = require "composer"
composer.gotoScene( "scenes.splash" )
--composer.gotoScene( "scenes.home" )
--composer.gotoScene( "scenes.play" )
