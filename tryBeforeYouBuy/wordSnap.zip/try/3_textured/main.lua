-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
local utils = require "easy.utils"
local wordSnap = require "easy.wordSnap"

local group = display.newGroup()
local back = display.newRect( group, centerX, centerY, fullw, fullh )
back:setFillColor(unpack(utils.hexcolor("#128223")))

local params = 
{
	tileImage 	= "images/letterTile.png",
	landImage 	= "images/landTile.png",
	letterFont 	= "Lato-Black.ttf",
	letterSize 	= 40,
	letterColor = utils.hexcolor("#5a85ec")
}

wordSnap.setTileDimensions(60,60)
wordSnap.createViewer( group, centerX, centerY, "level_1_1.json", params)

