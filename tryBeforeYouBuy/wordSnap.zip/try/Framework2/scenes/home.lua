-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"
local utils          = require "easy.utils"
local buttonMaker    = require "easy.buttonMaker"
local persist        = require "easy.persist"
local soundMgr       = require "easy.soundMgr"
local persist        = require "easy.persist"

-- =============================================================
-- =============================================================
-- Localizations
-- =============================================================
local getTimer=system.getTimer;local mRand=math.random
local newCircle=display.newCircle;local newRect=display.newRect
local newImageRect=display.newImageRect;local newSprite=display.newSprite
local newText=display.newText

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onPlay
local onSound

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local content

----------------------------------------------------------------------
-- Scene Methods
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view
end

function scene:willShow( event )
   local sceneGroup = self.view

   display.remove( content )
   content = display.newGroup()
   sceneGroup:insert( content )

   local back = newImageRect( content, "images/protoBackX.png", 720, 1386 )
   back.x = centerX
   back.y = centerY

   local label = newText( content, "Home", centerX, top + common.topInset + 40, fontB, 64 )

   local playB = buttonMaker.easyPush( { parent = content, preset = "play", x = centerX, y = centerY, listener = onPlay } )

   if( persist.get( "settings.json", "ads_enabled") ) then

      local noAdsB
      local onRestore

      local function onSuccess()
         persist.set( "settings.json", "ads_enabled", false )
         _G.adsHelper.hideBanner()
         --_G.adsHelper.disableModule( true )
         noAdsB.isVisible = false
         restoreB.isVisible = false
      end

      local function buyNoAds()
         if( persist.get( "settings.json", "sound_enabled" ) ) then
            soundMgr.playEffect( "click" )
         end
         _G.easyIAP.buy_noads(onSuccess)
      end

      local function restoreIAP()
         if( persist.get( "settings.json", "sound_enabled" ) ) then
            soundMgr.playEffect( "click" )
         end
         _G.easyIAP.restore(onSuccess)
      end

      noAdsB = buttonMaker.easyPush( { parent = content, preset = "noads", x = right - 80, y = bottom - 140, listener = buyNoAds } )
      restoreB = buttonMaker.easyPush( { parent = content, labelText = "Restore IAP", fontSize = 22, width = 140, height = 60, x = left + 80, y = bottom - 140, listener = restoreIAP } )

   end

   if( persist.get( "settings.json", "ads_enabled") ) then
      _G.adsHelper.showBanner( "bottom" )
   end

   local soundB = buttonMaker.easyToggle( { parent = content, preset = "sound", 
                                            x = right - common.rightInset - 50, 
                                            y = top + common.topInset + 50, listener = onSound } )
   if( persist.get( "settings.json", "sound_enabled" ) ) then
      soundB:toggle()
   end
   
end

function scene:didShow( event )
   local sceneGroup = self.view
end

function scene:willHide( event )
   local sceneGroup = self.view
end

function scene:didHide( event )
   local sceneGroup = self.view
   display.remove( content )
   content = nil
end

function scene:destroy( event )
   local sceneGroup = self.view
   display.remove( content )
   content = nil
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onPlay = function( self, event )
   if( persist.get( "settings.json", "sound_enabled" ) ) then
      soundMgr.playEffect( "click" )
   end
   local params = {}
   composer.gotoScene( "scenes.play", { time = 500, effect = "crossFade", params = params } )
end

onSound = function( self, event )
   utils.dump(self)
   persist.set( "settings.json", "sound_enabled", self.isToggled ) 
   if( persist.get( "settings.json", "sound_enabled" ) ) then
      soundMgr.playEffect( "click" )
   end
end

---------------------------------------------------------------------------------
-- Custom Dispatch Parser -- DO NOT EDIT THIS
---------------------------------------------------------------------------------
function scene.commonHandler( event )
   local willDid  = event.phase
   local name     = willDid and willDid .. event.name:gsub("^%l", string.upper) or event.name
   if( scene[name] ) then scene[name](scene,event) end
end
scene:addEventListener( "create",   scene.commonHandler )
scene:addEventListener( "show",     scene.commonHandler )
scene:addEventListener( "hide",     scene.commonHandler )
scene:addEventListener( "destroy",  scene.commonHandler )
return scene
