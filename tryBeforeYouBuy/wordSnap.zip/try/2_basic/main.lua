-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
local utils = require "easy.utils"
local wordSnap = require "easy.wordSnap"

local group = display.newGroup()
local back = display.newRect( group, centerX, centerY, fullw, fullh )
back:setFillColor(unpack(utils.hexcolor("#128223")))

local params = 
{
	tileColor   		= utils.hexcolor("#e96a5d"),
	tileStroke 			= utils.hexcolor("FFFFFF"),
	tileStrokeWidth	= 2,

	landColor   		= utils.hexcolor("#1b3679"),
	landStroke 			= utils.hexcolor("#edff47"),
	landStrokeWidth	= 2,
}

wordSnap.setTileDimensions(60,60)
wordSnap.createViewer( group, centerX, centerY, "level_1_1.json", params)

