-- =============================================================
-- Word Search - 'Documentation'
-- =============================================================
This is a 'try before you buy' template.  Feel free to use it and 
make games with it, but if you want to distribute them please buy it.

Thanks,
Roaming Gamer

-- =============================================================
-- Need Help?
-- =============================================================
Aside from fixing bugs and releasing update to the module(s),
support is not provided. 

That said, if you need help making your game, I am available and 
you can pay me to help.

Send me an email titled 'Paid Help - Word Search' at roaminggamer@gmail.com

I'll get back to you promptly.


-- =============================================================
-- What Comes In This Template
-- =============================================================
+ 1_edit        - Example of editor and viewer with two puzzles.
+ 2_basic       - Basic game using module and containing two puzzles.
+ easy          - The modules used to make the editor, viewer, and game.
+ readMe.txt    - This file.
+ template      - Basic starter project for editing making your games.

-- =============================================================
-- Basic Usage
-- =============================================================
There are two (2) examples and a template.  You can work it out. :)


-- =============================================================
-- Editor (easy.wordSearch)
-- =============================================================

--
-- Initialize helpers
local utils = require "easy.utils"
require "presets.presets" -- For button maker

-- Require It:
local wordSearch = require "easy.wordSearch"	

-- Set the size of tiles:
wordSearch.setTileSize(36) 

-- Set font used by the module for letters:
wordSearch.setFont( "editor.ttf"  ) 

-- Create the editor:
wordSearch.createEditor()


-- =============================================================
-- Viewer  (easy.wordSearch)
-- =============================================================

--
-- Initialize helpers
require "easy.globals"
local utils = require "easy.utils"
require "presets.presets" -- For button maker

-- Require It:
local wordSearch = require "easy.wordSearch"	

-- Set the size of tiles:
wordSearch.setTileSize(36) 

-- (Optionally) change the line width for selecting letters.
wordSearch.setLineWidth( 36 ) 

-- (Optionally) provide your own color codes for 'lines'
local colorCodes = { "#7ec696", "#e9c9bc", "#aaf2e7", "#df93ed", "#dbc1a6", 
                "#7f89ad", "#9194ff", "#7fafc5", "#93d3b8", "#aa84cd", 
                "#e1e5c2", "#e1e5c2", "#f9f7c4", "#92ba9f", "#ec99e1", 
                "#af89d6", "#a3a1c9", "#afdece", }
wordSearch.setColors( colorCodes )

-- Write a listener
--
local function onPuzzleEvent( event )
	if( event.phase == "foundWord" ) then
		print( "Found: ", event.word )
	
	elseif( event.phase == "puzzleComplete" ) then
		print( "Puzzle Solved" )
	end
end

-- Optionally define some parameters (more on this later)
local params = 
{
	tileImg 				= "images/fillW.png",
	letterFontSize 	= 25,
	letterColor 		= {0,0,0},
	letterFont 			= "Roboto-Thin.ttf", -- overrides prior call to setFont()
	listener  			= onPuzzleEvent,
}

-- Create a viewer
-- group - Display group to put viewer in
-- x, y - Next two args are x,y position of board center.
-- levelName - Name of level to load, including the .json extension.
-- params - Optional parameters.
--
local viewer = wordSearch.createPuzzleViewer( group, tray.x, tray.y, "puzzle_001.json", params )

-- =============================================================
-- Viewer Parameters (in no particular order)
-- =============================================================
+ listener 		- Function to call when word is found and/or puzzleis solved.
+ tileImg 		- Image to use for drawing tiles. Default is "images/fillW.png"
+ letterFont - Font to use for letters if you're not supplying letter tiles.
+ letterSize - Size of letters (only for non-letter tile case).
+ letterColor - Color of letters (only for non-letter tile case).


-- =============================================================
-- wordSearch.getPuzzle( puzzleName )
-- =============================================================
This function returns a table with these named fields:
+        rows - Number of rows in puzzle.
+        cols - Number of colums in puzzle.
+      inCols - Words in columns.
+      inRows - Words in rows.
+ inDiagonals - Words in diagonals.
+   difficult - Rated dificulty of puzzle from 1 .. 10.
+   rawPuzzle - Raw puzzle (rows of letters separated by "\n").
+     rawList - Raw list of words in puzzle, separated by "\n".


-- =============================================================
-- Utility Functions (easy.utils)
-- =============================================================
There are a number of utility functions in this module and they are all 
(for the most part) documented internally, so take a look a the file.

Online docs are coming soon for this module.

-- =============================================================
-- Button Maker Functions (easy.buttonMaker)
-- =============================================================
This kit comes with a set of button makers for:
- Push buttons
- Toggle buttons
- Radio buttons

Online docs are coming soon for this module.

-- =============================================================
-- Sound Manager (easy.soundMgr)
-- =============================================================
This kit comes with a starter sound manager you can tweak as needed.

It handles basic sound management and playing.

Online docs are coming soon for this module.

-- =============================================================
-- Files Lib (easy.files)
-- =============================================================
This kit comes with an advanced file system library.

It is used by the editor, but you can dig into it if you want.

