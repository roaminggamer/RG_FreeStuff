-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
local mode = "edit" -- edit view

if( mode == "edit" ) then
	local utils = require "easy.utils"
	require "presets.presets" -- For button maker
	local wordSearch = require "easy.wordSearch"
	wordSearch.setFont( "editor.ttf" )
	wordSearch.setTileSize(34)
	wordSearch.createEditor()

else
	require "easy.globals"
	local utils = require "easy.utils"
	require "presets.presets" -- For button maker
	local wordSearch = require "easy.wordSearch"

	-- 
	local tileSize 		= 60
	local info 				= wordSearch.getPuzzle( "puzzle_001.json" )
	local puzzleWidth 	= info.cols * tileSize
	local puzzleHeight 	= info.rows * tileSize
	--
	local x = centerX - puzzleWidth/2
	local y = centerY - puzzleHeight/2
	--	
	wordSearch.setTileSize( tileSize )

	local params =
	{ 
		tileImg 				= "images/fillW.png",
		letterColor 		= { 0, 0, 0 },
		letterSize 			= 25,
		letterFont 			= "Roboto-Thin.ttf" }

	wordSearch.createPuzzleViewer( nil, x, y, "puzzle_001.json", params )
end


