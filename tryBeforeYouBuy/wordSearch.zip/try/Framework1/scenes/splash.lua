-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"
local utils          = require "easy.utils"
local buttonMaker    = require "easy.buttonMaker"
local soundMgr       = require "easy.soundMgr"
local persist        = require "easy.persist"

-- =============================================================
-- =============================================================
-- Localizations
-- =============================================================
local getTimer=system.getTimer;local mRand=math.random
local newCircle=display.newCircle;local newRect=display.newRect
local newImageRect=display.newImageRect;local newSprite=display.newSprite
local newText=display.newText

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onHome

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------


----------------------------------------------------------------------
-- Scene Methods
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view

   local back = newImageRect( sceneGroup, "images/protoBackX.png", 720, 1386 )
   back.x = centerX
   back.y = centerY
   local label = newText( sceneGroup, "Splash", centerX, centerY, fontB, 64 )

   timer.performWithDelay( 3000, onHome )
end

function scene:willShow( event )
   local sceneGroup = self.view
end

function scene:didShow( event )
   local sceneGroup = self.view
end

function scene:willHide( event )
   local sceneGroup = self.view
end

function scene:didHide( event )
   local sceneGroup = self.view
end

function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onHome = function( event )

   -- Defer if we are showing the GDPR request dialog
   if( common.gdpr_dialog_is_showing ) then
      timer.performWithDelay( 500, onHome )
      return
   end

   local params = {}
   composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade", params = params } )
end

---------------------------------------------------------------------------------
-- Custom Dispatch Parser -- DO NOT EDIT THIS
---------------------------------------------------------------------------------
function scene.commonHandler( event )
   local willDid  = event.phase
   local name     = willDid and willDid .. event.name:gsub("^%l", string.upper) or event.name
   if( scene[name] ) then scene[name](scene,event) end
end
scene:addEventListener( "create",   scene.commonHandler )
scene:addEventListener( "show",     scene.commonHandler )
scene:addEventListener( "hide",     scene.commonHandler )
scene:addEventListener( "destroy",  scene.commonHandler )
return scene
