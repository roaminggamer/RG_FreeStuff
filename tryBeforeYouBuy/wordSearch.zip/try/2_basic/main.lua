-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
require "easy.globals"
local utils = require "easy.utils"
require "presets.presets" -- For button maker
local buttonMaker = require "easy.buttonMaker"

local wordSearch = require "easy.wordSearch"

local group
local puzzleNum = 0
local function run()	

	puzzleNum = puzzleNum + 1
	puzzleNum = (puzzleNum > 2) and 1 or puzzleNum

	display.remove(group)
	group = display.newGroup()

	--
	-- Draw a background
	--		
	local back = display.newRect( group, centerX, centerY, fullw, fullh )	

	--
	-- Draw a win label
	--
	local winLabel = display.newText( group, "Puzzle Complete", centerX, bottom - 40, "Lato-Black.ttf", 60 )
	winLabel:setFillColor(1,1,1)
	winLabel.isVisible = false

	--
	-- Add a button to 're-run' this example
	--
	local button = buttonMaker.easyPush( { parent = group, x = right - 55, y = top + 20,  fontSize = 20,
	                     width = 100, height = 30, labelText = "Next", listener = run } )	
	button.isVisible = false

	--
	-- Add a button to 're-run' this example
	--
	local button = buttonMaker.easyPush( { parent = group, x = right - 55, y = top + 20,  fontSize = 20,
	                     width = 100, height = 30, labelText = "Next", listener = run } )	
	button.isVisible = false

	-- 
	local puzzleName 		= string.format( "puzzle_%0.3d.json", puzzleNum )
	local tileSize 		= 50
	local info 				= wordSearch.getPuzzle( puzzleName )
	--utils.dump(info,"info")
	--
	local puzzleWidth 	= info.cols * tileSize
	local puzzleHeight 	= info.rows * tileSize
	--
	local puzzleX = centerX - puzzleWidth/2 - 180
	local puzzleY = centerY - puzzleHeight/2 - 10
	
	--
	--	Draw word list
	--
	local wordList = info.rawList
	wordList = utils.split(wordList,"\n")
	--utils.dump(wordList, "wordList")
	local wordLabels = {}
	--
	local x = puzzleX + puzzleWidth + 21
	local y = puzzleY
	local tray = display.newRect( group, x, y, 350, puzzleHeight )
	tray:setStrokeColor(unpack(utils.hexcolor("#128223")))
	tray.strokeWidth = 5
	tray.anchorX = 0
	tray.anchorY = 0
	--
	local tmp = display.newText( group, "Difficulty: " .. tostring(utils.round(info.difficulty,2)), centerX, top + 30, "Lato-Black.ttf", 25 )	
	tmp:setFillColor(unpack(utils.hexcolor("#128223")))
	--
	x = x + 350/2
	y = y + 40
	--
	for i = 1, #wordList do
		local word = wordList[i]
		local tmp = display.newText( group, word, x, y, "Roboto-Thin.ttf", 20 )
		tmp:setFillColor(0,0,0)
		wordLabels[word] = tmp
		tmp.line = display.newLine( x - 10 - tmp.contentWidth/2, y, x + tmp.contentWidth/2 + 10, y )
		tmp.line.strokeWidth = 2
		tmp.line:setStrokeColor(0,0,0)
		tmp.line.isVisible = false
		y = y + 40
	end
	--
	-- Listener for puzzle
	--
	local function onPuzzleEvent( event )
		if( event.phase == "foundWord" ) then
			print(event.word)
			print(wordLabels[event.word])
			wordLabels[event.word].line.isVisible = true
		
		elseif( event.phase == "puzzleComplete" ) then
			winLabel.isVisible = true
			button.isVisible = true
		end
	end

	--
	-- Draw current puzzle
	--
	wordSearch.setTileSize( tileSize )	

	local colorCodes = { "#7ec696", "#e9c9bc", "#aaf2e7", "#df93ed", "#dbc1a6", 
								"#7f89ad", "#9194ff", "#7fafc5", "#93d3b8", "#aa84cd", 
								"#e1e5c2", "#e1e5c2", "#f9f7c4", "#92ba9f", "#ec99e1", 
								"#af89d6", "#a3a1c9", "#afdece", }
	wordSearch.setColors( colorCodes )	

	local params =
	{ 
		tileImg 				= "images/fillT.png",
		letterColor 		= { 0, 0, 0 },
		--letterSize 			= 25,
		letterFont 			= "Lato-Black.ttf",
		listener 			= onPuzzleEvent 
	}	

	wordSearch.setLineWidth( 36 )
	
	wordSearch.createPuzzleViewer( group, puzzleX, puzzleY, puzzleName, params )
end

run()