-- Example for this question: http://forums.coronalabs.com/topic/48914-how-to-deal-with-arrays-of-a-lot-of-spawned-objects/#entry253053
-- and for Bud's private question.


-- Run one or the other, but not both:

require "integerIndexed"
--require "objectIndexed"