
-- Only require one at a time to test them.

require ("ex1_timer")
--require ("ex2_transition_onComplete")
--require ("ex3_touch")

