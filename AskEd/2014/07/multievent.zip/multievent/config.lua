
application =
{

    content =
    {
        fps = 30,
        width = 720,
        height = 1280,
        scale = "zoomEven",
        xAlign = "center",
        yAlign = "center",
    }
}

