local composer = require( "composer" )
display.setDefault("background", 1, 1, 1, 1);
display.setStatusBar( display.HiddenStatusBar )
composer.gotoScene("FirstScene")
