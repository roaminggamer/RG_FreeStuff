local composer = require( "composer" )
local scene = composer.newScene()
local getTimer = system.getTimer

local otherSceneButton
local function gotoOtherScene( self, event )
    composer.gotoScene("OtherScene")
    return true
end

---------------------------------------------------------------------------------
-- "scene:create()"
function scene:create( event )
    local sceneGroup = self.view
    print("[FirstScene] Create ", getTimer())
    otherSceneButton = display.newText("OtherScene", 200,200, native.systemFont, 60)
    otherSceneButton:setFillColor( 0, 0.5, 1 )
    sceneGroup:insert(otherSceneButton)
    otherSceneButton.tap = gotoOtherScene
    otherSceneButton:addEventListener( "tap" )
end

-- "scene:show()"
function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        print("[FirstScene] show(will) ", getTimer())
    elseif ( phase == "did" ) then
        print("[FirstScene] show(did) ", getTimer())
    end
end

-- "scene:hide()"
function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
        print("[FirstScene] hide(will) ", getTimer())
    elseif ( phase == "did" ) then
        print("[FirstScene] hide(did) ", getTimer())
    end
end

function scene:destroy( event )
    local sceneGroup = self.view
    otherSceneButton = nil
    print("[FirstScene] destroy ", getTimer())
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

---------------------------------------------------------------------------------

return scene