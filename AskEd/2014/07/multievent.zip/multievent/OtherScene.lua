local composer = require( "composer" )
local scene = composer.newScene()
local getTimer = system.getTimer

local firstSceneButton
local function gotoFirstScene( self, event )
    composer.gotoScene("FirstScene")
    return true
end

function scene:create( event )
    local sceneGroup = self.view
    print("[OtherScene] Create ", getTimer())
    firstSceneButton = display.newText("FirstScene", 200,200, native.systemFont, 60)
    firstSceneButton:setFillColor( 0, 0.5, 1 )
    sceneGroup:insert(firstSceneButton)
    firstSceneButton.tap = gotoFirstScene
    firstSceneButton:addEventListener( "tap" )
end

function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
        print("[OtherScene] show(will) ", getTimer())
    elseif ( phase == "did" ) then
        print("[OtherScene] show(did) ", getTimer())
    end
end

function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
        print("[OtherScene] hide(will) ", getTimer())
    elseif ( phase == "did" ) then
        print("[OtherScene] hide(did) ", getTimer())
    end
end

-- "scene:destroy()"
function scene:destroy( event )
    local sceneGroup = self.view
    firstSceneButton = nil
    print("[OtherScene] destroy ", getTimer())
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

---------------------------------------------------------------------------------

return scene