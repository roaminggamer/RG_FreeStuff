
require "perf1" -- Auto localized vs. 'remove' Math Square Root

require "perf2" -- Auto localized vs. Normal localized Math Square Root


-- require "example_old" -- Does nothing, just an example of the old way I did things

-- require "example_new" -- Does nothing, just an example of the new way I did things