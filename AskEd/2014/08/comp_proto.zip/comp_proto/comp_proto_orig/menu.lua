_H = display.viewableContentHeight;
_W = display.viewableContentWidth;

local widget = require ("widget");

local composer = require ("composer");
local scene = composer.newScene();

local memTimer, AboutButton, CaseStudyButton, ReadButton

local function onAboutSceneTouch(self, event)
		if event.phase == "began" then
			composer.gotoScene("about", "fade",400)
			return true;
		end
end

local function onReadSceneTouch(self, event)
		if event.phase == "began" then
			composer.gotoScene("scene2", "fade", 400)
			return true;
		end
end

local function onCaseStudySceneTouch(self, event)
		if event.phase == "began" then
			composer.gotoScene("caseStudy", "fade", 400)
			return true;
		end
end

function scene:create(event)
	local sceneGroup = self.view
	
	AboutButton = display.newImage("AboutBigButton.png");
	AboutButton.x = _W - 400;
	AboutButton.y = _H - 240;
	AboutButton.xScale = 1.5;
	AboutButton.yScale = 1.5;
	sceneGroup:insert(AboutButton)
	
	
	ReadButton = display.newImage("ReadBigButton.png")
	ReadButton.x = _W - 152;
	ReadButton.y = _H - 240;
	ReadButton.xScale = 1.6;
	ReadButton.yScale = 1.5;
	sceneGroup:insert(ReadButton)
	

	CaseStudyButton = display.newImage("CaseStudyBigButton.png");
	CaseStudyButton.x = _W + 90;
	CaseStudyButton.y = _H - 240;
	CaseStudyButton.xScale = 1.5;
	CaseStudyButton.yScale = 1.5;
	sceneGroup:insert(CaseStudyButton)
	
	AboutButton.touch = onAboutSceneTouch
	ReadButton.touch = onReadScenetouch
	CaseStudyButton.touch = onCaseStudySceneTouch

end

function scene:show(event)
	local phase = event.phase
		if "did" == phase then
			composer.removeScene("titlePage")
			local showMem = function()
			AboutButton:addEventListener("touch", AboutButton);
			ReadButton:addEventListener("touch", ReadButton);
			CaseStudyButton:addEventListener("touch", CaseStudyButton);
		end
		memTimer = timer.performWithDelay(1000, showMem,1)
	end
end

function scene:hide(event)
	local phase = event.phase
		if "will" == phase then
			AboutButton:removeEventListener("touch", AboutButton);
			ReadButton:removeEventListener("touch", ReadButton);
			CaseStudyButton:removeEventListener("touch", CaseStudyButton);
			timer.cancel(memTimer); memTimer = nil;
		end
end

function scene:destroy(event)
	composer.removeScene(titlePage)
end	

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene
			