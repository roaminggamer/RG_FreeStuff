
display.setStatusBar(display.HiddenStatusBar);

local composer = require "composer"

local widget = require "widget"

composer.gotoScene( "menu", "fade", 400 )




