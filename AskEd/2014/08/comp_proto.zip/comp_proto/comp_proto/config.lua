application = 	{
					content = {
								graphicsCompatibility = 1,
								width = 480,
								height = 320,
								scale = "letterBox",
								xAlign = "center",
								yAlign = "center",
									imageSuffix = {
													["@2x"] = 2;
												  },
							  },
				}