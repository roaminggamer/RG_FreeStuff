-- EFM No need to add semi-colons to the end of lines.  Its just extra typing. 
--

_H = display.viewableContentHeight;
_W = display.viewableContentWidth;

local widget = require ("widget");

local composer = require ("composer");
local scene = composer.newScene();

local memTimer -- EFM don't need locals now to hold button refernces

-- EFM it is simpler to have ONE listner
local function onTouch(self, event)
	if event.phase == "ended" then -- ended is better than began
		local options = { effect = "fade", time = 400, params = { buttonName = self.buttonName } }
		composer.gotoScene( self.toScene , options )		
	end
	return true;
end


function scene:create(event)
	local sceneGroup = self.view
	
	local AboutButton = display.newImage("AboutBigButton.png");
	AboutButton.x = _W - 400;
	AboutButton.y = _H - 240;
	AboutButton.xScale = 1.5;
	AboutButton.yScale = 1.5;
	sceneGroup:insert(AboutButton)
	
	
	local ReadButton = display.newImage("ReadBigButton.png")
	ReadButton.x = _W - 152;
	ReadButton.y = _H - 240;
	ReadButton.xScale = 1.6;
	ReadButton.yScale = 1.5;
	sceneGroup:insert(ReadButton)
	

	local CaseStudyButton = display.newImage("CaseStudyBigButton.png");
	CaseStudyButton.x = _W + 90;
	CaseStudyButton.y = _H - 240;
	CaseStudyButton.xScale = 1.5;
	CaseStudyButton.yScale = 1.5;
	sceneGroup:insert(CaseStudyButton)
	
	AboutButton.touch = onTouch --EFM 
	ReadButton.touch = onTouch --EFM
	CaseStudyButton.touch = onTouch --EFM

	AboutButton.toScene 		= "efm" --EFM change to match your needs
	ReadButton.toScene 			= "efm" --EFM change to match your needs
	CaseStudyButton.toScene 	= "efm" --EFM change to match your needs

	AboutButton.buttonName 		= "About" --EFM just for this example
	ReadButton.buttonName 		= "Read" --EFM just for this example
	CaseStudyButton.buttonName 	= "Case Study" --EFM just for this example

	AboutButton:addEventListener("touch"); -- EFM No target arg implies same as calling object.
	ReadButton:addEventListener("touch"); -- EFM No target arg implies same as calling object.
	CaseStudyButton:addEventListener("touch"); -- EFM No target arg implies same as calling object.

end

function scene:show(event)
	local phase = event.phase
		if "did" == phase then
			composer.removeScene("titlePage")
			local showMem = function()
			--EFM add listeners when you create buttons
		end
		memTimer = timer.performWithDelay(1000, showMem,1)
	end
end

function scene:hide(event)
	local phase = event.phase
		if "will" == phase then
			--EFM no need to remove listeners
			timer.cancel(memTimer); memTimer = nil;
		end
end

function scene:destroy(event)
	composer.removeScene(titlePage)
	memTimer = nil -- EFM
end	

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene
			