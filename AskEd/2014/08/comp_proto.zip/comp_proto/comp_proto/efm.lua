local composer = require( "composer" )
local scene = composer.newScene()
local label
function scene:create( event )
	local sceneGroup = self.view
	label = display.newText(sceneGroup, "Hi.", 100, 100, native.systemFont, 44  )
end
function scene:show(event)
	local phase = event.phase
	if phase == "will"  then
		label.text = "You pressed: " .. event.params.buttonName
	elseif phase == "did" then
		timer.performWithDelay( 500, 
			function()
				composer.gotoScene( "menu" , "fade", 400)		
			end )		
	end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
return scene