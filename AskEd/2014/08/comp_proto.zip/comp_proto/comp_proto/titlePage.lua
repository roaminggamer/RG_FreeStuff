_H = display.viewableContentHeight
_W = display.viewableContentWidth

local widget = require ("widget");

local composer = require ("composer");
local scene = composer.newScene();

local memTimer, background, startButton

local function onSceneTouch(self, event)
	if event.phase == "began" then
		composer.gotoScene( "menu", "fade", 400)
		return true
	end
end


function scene:create(event)
	local sceneGroup = self.view
	
	background = display.newImage("wp.png");
	background.y = _H - 240;
	background.x = _W - 160;
	background.xScale = 1.5;
	background.yScale = 1.5;
	
	sceneGroup:insert(background)

	startButton = display.newImage("ttsl.png")
	startButton.xScale = 2;
	startButton.yScale = 2;
	startButton.x = _W + 100;
	startButton.y = _H - 70;
	
	
	sceneGroup:insert(startButton)
	
	startButton.touch = onSceneTouch
end

function scene:show(event)
	local phase = event.phase
		if "did" = phase then
			composer.removeScene("scene4")
			local showMem = function()
			startButton:addEventListener("touch", startButton)
		end
		memTimer = timer.performWithDelay(1000, showMem, 1)
	end
end

function scene:hide(event)
	local phase = event.phase
		if "will" == phase then
			startButton:removeEventListener("touch", startButton)
			timer.cancel(memTimer); memTimer = nil;
		end
end

function scene:destroy(event)
	-- destroy what?
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene