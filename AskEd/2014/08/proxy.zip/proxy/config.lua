application = {
	content = {
		--compatibilityMode = true,
		width = 320,
		height = 480, 
		scale = "letterbox",
	},
}

