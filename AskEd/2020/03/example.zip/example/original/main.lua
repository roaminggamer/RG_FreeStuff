require "ssk2.loadSSK"
_G.ssk.init( { launchArgs 				= ..., 
	            gameFont 				= _G.fontB,
	            measure 					= false,
	            debugLevel 				= 0 } ) 

 
display.setStatusBar(display.HiddenStatusBar)

local physics      = require "physics"
physics.start()

local myCC = ssk.cc:newCalculator()
myCC:addNames( "spike" ) 

local background = display.newRect(centerX,centerY,display.actualContentWidth,display.actualContentHeight) 
background:setFillColor(0,0,0)

local spike = display.newImageRect("enemy.png", 124,123)
spike.x = centerX
spike.y = centerY

local physicsData = require ("physicsData").physicsData(1.0)

physics.addBody( spike, "static", physicsData:get("spike"), {filter = myCC:getCollisionFilter( "spike" ) } )  
--physics.addBody( spike, "static", physicsData:get("spike") )  

physics.setDrawMode("hybrid")