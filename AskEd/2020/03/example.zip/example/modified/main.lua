require "ssk2.loadSSK"
_G.ssk.init( { launchArgs 				= ..., 
	            gameFont 				= _G.fontB,
	            measure 					= false,
	            debugLevel 				= 0 } ) 

 
display.setStatusBar(display.HiddenStatusBar)

local physics      = require "physics"
physics.start()
physics.setDrawMode("hybrid")

local myCC = ssk.cc:newCalculator()
myCC:addNames( "spike" ) 

local background = display.newRect(centerX,centerY,display.actualContentWidth,display.actualContentHeight) 
background:setFillColor(0,0,0)

local spike = display.newImageRect("enemy.png", 124,123)
spike.x = centerX
spike.y = centerY

local physicsData = require ("physicsData").physicsData(1.0)

-- physics.addBody( spike, "static", physicsData:get("spike"), {filter = myCC:getCollisionFilter( "spike" ) } )  
--physics.addBody( spike, "static", physicsData:get("spike") )  

-- 1 Get body params from physicsData
local body_params = physicsData:get("spike") 

-- 2 print body_params before
table.print_r(body_params)

-- 3 Replace body_params filter categoryBits and maskBits with calculator values
body_params.filter.categoryBits = myCC:getCategoryBits( "spike" )
body_params.filter.maskBits = myCC:getMaskBits( "spike" )

-- 4 print body_params before
table.print_r(body_params)

-- 5 Use the modified body
physics.addBody( spike, "static", body_params ) 


