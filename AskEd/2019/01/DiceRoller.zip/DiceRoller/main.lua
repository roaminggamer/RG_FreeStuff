display.setStatusBar( display.HiddenStatusBar )

local storyboard = require "storyboard"
storyboard.gotoScene( "game" )


--[[
http://www.freesound.org/people/LoafDV/sounds/94031/download/94031__loafdv__dice-roll.mp3, http://www.freesound.org/people/LoafDV/sounds/94031/
http://www.freesound.org/people/joanneneedsthesound/sounds/177208/download/177208__joanneneedsthesound__dice-rolling-dungeon-and-dragons.wav
http://www.freesound.org/people/LS/sounds/39048/download/39048__ls__sparkles.wav, http://www.freesound.org/people/LS/sounds/39048/
--]]