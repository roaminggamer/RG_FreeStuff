--menu
local storyboard = require "storyboard"
local scene      = storyboard.newScene()

local magnet 	= require "lib.magnet"
local looper 	= require "lib.looper"
local inspect	= require "lib.inspect"


local menuSnapshot
local menuRect, pauseTitle
local restartButton, resumeButton
local buttonsTrail
local loop

--

local function onResumeTap( e )
	storyboard.hideOverlay()
	local e = {name = "onGameResume"}
	Runtime:dispatchEvent(e)
end

function onRestartTap( e )
	storyboard.hideOverlay()
	local e = {name = "onGameRestart"}
	Runtime:dispatchEvent(e)
end

function newButton( parent, src, onTapListener )
	local btn = display.newImageRect( parent, src, 128 * 0.5, 128 * 0.5)
	btn.src = src
	btn.alpha = 0
	
	function btn:showFrom( xFrom )
		self.alpha = 0.7
		transition.from(self, {x = xFrom, xScale = 1.5, alpha = 0, delay = 750, time = 500, 
			transition = easing.outBack, onComplete = function() buttonsTrail = false end})	
	end

	function btn:createTrail( canvas )
		local trail = display.newImageRect( canvas, src, 128 * 0.5, 128 * 0.5)		
		trail.x, trail.y = menuSnapshot:contentToLocal(self.x, self.y)
		trail.yScale = self.yScale
		trail.alpha = self.alpha
	end

	btn:addEventListener("tap", onTapListener)
	return btn
end

function updateEffects(e, loop)
	local r = display.newRect( menuSnapshot.canvas, 0, 0, magnet.screenWidth, 200 )
	r:setFillColor(1, 0.8)
	r.blendMode = "srcIn"

	if buttonsTrail then
		resumeButton:createTrail( menuSnapshot.canvas )
		restartButton:createTrail( menuSnapshot.canvas )
	end

	menuSnapshot:invalidate("canvas")	
end

function startEffects()
	loop:resume()
	--title
	--buttons
	buttonsTrail = true
	restartButton:showFrom(0)
	resumeButton:showFrom(magnet.screenWidth)	
	
end

function createMenu( gScene )
	--title
	menuSnapshot = display.newSnapshot(magnet.screenWidth, 120)
	gScene:insert(menuSnapshot)
	magnet:centerTop(menuSnapshot, 0, magnet:getPercentY(25))
	menuSnapshot.canvasMode = "discard"
	
	pauseTitle = display.newText(gScene, "Paused", 0, 0, "OptimusPrincepsSemiBold", 40)
	magnet:centerTop(pauseTitle, 0, 30)

	--bar rect
	menuRect = display.newRect(gScene, 0, 0, magnet.screenWidth, 120)
	menuRect.fill = { type="gradient", color1={ 1, 1, 1 }, color2 = {0, 0, 0}}
	menuRect.alpha = 0.1
	magnet:centerTop(menuRect, 0, magnet:getPercentY(25))

	--restart button
	restartButton = newButton(gScene, "img/btnRestart.png", onRestartTap)
	magnet:centerTop(restartButton, -60, magnet:getPercentY(30))
	--resume button
	resumeButton = newButton(gScene, "img/btnResume.png", onResumeTap)
	magnet:centerTop(resumeButton, 60, magnet:getPercentY(30))

	print("MEM:",system.getInfo( "textureMemoryUsed" ) / 1000000)
end


function scene:createScene( event )
	local gScene = self.view
	createMenu( gScene )	
	loop = looper:newLoop(updateEffects)

end

function scene:enterScene( event )
	local gScene = self.view

	startEffects()	
end

function scene:exitScene( event )
	loop:pause()	
end

function scene:didExitScene( event )
end

scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )

return scene