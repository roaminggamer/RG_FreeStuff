--scoreboard
local magnet 	= require "lib.magnet"


local scoreBoard = {}

function scoreBoard:new()
	local self = display.newContainer(magnet.screenWidth, magnet:getPercentY(20))
	self._dicePairs = {}


	local glass = display.newRect( self, 0, 0, magnet.screenWidth, self.height )
	glass.fill = {0, 0, 0, 0.1}

	local rightShadow = display.newRect( self, 0, 0, 30, self.height )
	rightShadow.fill = { type="gradient", color1={ 0, 0, 0, 0 }, color2 = {0, 0, 0, 0.8}, direction = "right"}
	magnet:right(rightShadow)

	function self:pushDicesToRight()
		for _, dicePair in ipairs(self._dicePairs) do
			transition.to(dicePair[1], {x = dicePair[1].x + 50, transition = easing.outBack})
			transition.to(dicePair[2], {x = dicePair[2].x + 50, transition = easing.outBack})
		end
	end

	function self:addDices(diceA, diceB, x1, y1, x2, y2)
		--print("addDices", diceA.pickedFace, diceB.pickedFace)
		self:pushDicesToRight()
			
		local function _newDiceFace( dice, x, y)
			local f = display.newImageRect(string.format("img/%d.png", dice.pickedFace), 32, 32)
			f.x, f.y = x, y
			return f
		end

		local function _attractToDropZone(diceFace, dropX, dropY)
			transition.to(diceFace, { x = dropX, y = dropY, transition = easing.inBack,
				onComplete = function()
					diceFace.x, diceFace.y = self:contentToLocal(dropX, dropY)
					self:insert(diceFace)
					rightShadow:toFront()
					glass:toFront()
				end
			})
		end

		local dA = _newDiceFace(diceA, x1, y1)
		local dB = _newDiceFace(diceB, x2, y2)

		local r = display.newRect(self, 0, 0, 32, 32)
		magnet:topLeft(r, 25, 10)
		local dropX, dropY = self:localToContent(r.x, r.y)
		_attractToDropZone(dA, dropX, dropY)	
		magnet:bottomLeft(r, 25, -10)
		dropX, dropY = self:localToContent(r.x, r.y)
		_attractToDropZone(dB, dropX, dropY)

		self._dicePairs[#self._dicePairs + 1] = {dA, dB}
		r:removeSelf()		
	end

	function self:clear()
	end

	return self
end

return scoreBoard