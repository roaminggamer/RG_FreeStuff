--game
local storyboard = require "storyboard"
local scene      = storyboard.newScene()

local magnet 	= require "lib.magnet"
local looper 	= require "lib.looper"
local inspect 	= require "lib.inspect"
local cube		= require "cube"
local sboard 	= require "scoreBoard"
--local vignetteDesaturate = require "kernel_filter_vignette_desaturate"
--graphics.defineEffect( vignetteDesaturate )


local restartGame, resumeGame, pauseGame, onPauseTap, rollDice, onDicesTouch
local dicesSnapshot, diceSfxSnapshot
local diceSfxData = {}
local background, pauseButton
local loop, onLoop --onEnter frame helper and listener
local diceA, diceB
local rectTouch, isRolling, xRotation, yRotation, isDicePicking
local tapToRollLabel
local updateDiceEffect, renderRollingSfx, activeDice
local scoreBoard


--cache
local Max = math.max
local Min = math.min
local Rand = math.random

--rotations to get each dice face to front
local faceRotations = {
			[1] = { x = 0, 		y = 0  	},
			[2] = { x = 90, 	y = 0  	},
			[3] = { x = 180, 	y = 0  	},
			[4] = { x = 270, 	y = 0  	},
			[5] = { x = 0, 	y = 270 	},
			[6] = { x = 0, 		y = 90	},
		}

function onLoop(e, loop)
	
	local rX = loop.delta * 0.1
	local rY = loop.delta * 0.1
	local rZ = loop.delta * 0.1

	if not diceA.isPicked then
		if diceA.isRolled then
			diceA:rotate(-rX * 8, rY * 3, 1)
		else
			diceA:rotate(-rX, rY, 0)
		end
	end

	if not diceB.isPicked then
		if diceB.isRolled then
			diceB:rotate(rX * 8, -rY * 3, 1)
		else
			diceB:rotate(rX, -rY, 0)
		end
	end
	
	dicesSnapshot:invalidate()	


	if renderRollingSfx then
		updateDiceEffect(rX * 0.06)
		diceSfxSnapshot:invalidate("canvas")
	end
	
end

-- SET DICES IN IDLE STATE
function setDicesReadyToRoll()



	local function resetDice(dice, x, y)
		dice.xScale, dice.yScale = 0.5, 0.5
		dice.isRolled = false
		dice.isPicked = false
		dice.x, dice.y = x, y
		transition.from(dice, {alpha = 0, y = 220, time = 500})
	end
	resetDice(diceA, -50, 70)
	resetDice(diceB, 50, 70)
	activeDice = nil




	transition.cancel("idle")

	local function startLabelEffect()
		transition.fadeIn( tapToRollLabel, { tag = "idle",
			onComplete = function()
				transition.fadeOut( tapToRollLabel, { tag = "idle",
					onComplete = function()
						startLabelEffect()
					end
				})
			end
		})
	end
		
	local function startIdleEffect( dice )
		transition.to(dice, {xScale = 0.6, yScale = 0.6, y = 100, tag = "idle", transition = easing.outQuad, 
			onComplete = function()			
				transition.to(dice, {xScale = 0.5, yScale = 0.5, y = 130, delay = 500, tag = "idle", transition = easing.inBack,
					onComplete = function()
						startIdleEffect(dice)
					end
				})
			end
		})	
	end
	startLabelEffect()
	startIdleEffect(diceA)
	timer.performWithDelay( 300, function() startIdleEffect(diceB) end, 1)	
end

--starts trailling effects on dice
function setRollingSfx( dice )
	if dice then
		activeDice = dice
		renderRollingSfx = true
		diceSfxSnapshot.alpha = 0
		transition.to(diceSfxSnapshot, {alpha = 1, xScale = 1.3, yScale = 1.3, delay = 200, time = 500})
	else
		transition.to(diceSfxSnapshot, {alpha = 0, time = 200, 
			onComplete = function()
				activeDice = nil
				renderRollingSfx = dice or false
			end
		})
	end
end

function rollDice( dice )
	setRollingSfx( dice )
	dice.isRolled = true
	transition.to(dice, {x = 0, y = -70, xScale = 1, yScale = 1, transition = easing.outBack})
end

function pickDice( dice )
	setRollingSfx( false )
	transition.to(dice, {xScale = 1.3, yScale = 1.3, transition = easing.outElastic, time = 200, 
		onComplete = function()
		dice.isPicked = true
		--PICK A FACE AND MAKE IT LOOK RANDOM IN POSITION
		pick = math.random(1, 6)
		dice.pickedFace = pick
		dice:setRotation(faceRotations[pick].x + Rand(20, 30), faceRotations[pick].y + Rand(20, 30), Rand(1, 1))
			transition.to(dice, {xScale = 0.4, yScale = 0.4, transition = easing.outBounce, 
				onComplete = function()
					--FIX ROTATION TO FRONT AND PREPARE TO ADD INTO THE BOARD
					local rX, rY, rZ = dice:getRotation()
					local t = {x = rX, y = rY, z = rZ}
					--from current rotation to current face
					transition.to(t, {x = faceRotations[pick].x, y = faceRotations[pick].y, z = 0})
					timer.performWithDelay( 1, function(e) 
							dice:setRotation(t.x, t.y, t.z)
						end, 50)					

					transition.to(dice, {x = dice.dropAreaX, y = dice.dropAreaY, transition = easing.outBack,
						onComplete = function()
							--OF BOTH DICES ALREADY PICKED THE ADD TO SCOREBOARD
							if diceA.isPicked and diceB.isPicked then
								local x1, y1 = dicesSnapshot:localToContent(diceA.x, diceA.y)
								local x2, y2 = dicesSnapshot:localToContent(diceB.x, diceB.y)
								scoreBoard:addDices(diceA, diceB, x1, y1, x2, y2)
								setDicesReadyToRoll()
							end
						end
					})
				end
			})
		end
	})
	--dice.alpha = 0.1
end

function lightsOnOff( enabled  )
	transition.to(background.fill.effect, {radius = -1, time = 800, transition = easing.inOutBack})
end

function onDicesTap( event )
	transition.cancel("idle")
	tapToRollLabel.alpha = 0
	
	if not diceA.isRolled and not diceA.isPicked then
		rollDice( diceA )	
	elseif not diceA.isPicked then
		pickDice( diceA )
	elseif not diceB.isRolled and not diceB.isPicked then
		rollDice( diceB )
	elseif not diceB.isPicked then
		pickDice( diceB )
	end
end

function newDice(parentGroup, dropX, dropY)
	local dice = cube.new({
		parent = parentGroup,
		wireFrame = false,
		size = 128,
		faceImages = {
			"img/1.png",
			"img/2.png",
			"img/3.png",
			"img/4.png",
			"img/5.png",
			"img/6.png",
		},
	})
	dice.dropAreaX, dice.dropAreaY = dropX, dropY 
	dice:rotate(math.random(1, 180), math.random(1, 180), math.random(1, 180))
	return dice
end



function updateDiceEffect()

	local r = display.newRect( diceSfxSnapshot.canvas, 0, 0, magnet.screenWidth, 200 )
	r:setFillColor(1, 0.9)
	r.blendMode = "srcIn"

	local data = diceSfxData
	local facePoints = activeDice:getFacesPoints()

	data.circles = {}
	local alpha = 0
	local x, y
	local idx = 1
	local lastPoint

	for _, fP in ipairs(facePoints) do
		for i = 1, #fP, 3 do
			x = fP[i]
			y = fP[i + 1]
			z = fP[i + 2]
			if lastPoint then
				local lightSpot = display.newImageRect(diceSfxSnapshot.canvas, "img/lightSpot.png", 16, 16)
				
				alpha = Min(z, 1)
				alpha = Max(alpha, 0)
				lightSpot:scale(0.5+ alpha * 2, 0.5 + alpha * 2)
				--[[
				if math.random(1, 100) > 99 then
					alpha = 1
					lightSpot:scale(4, 4)
					lightSpot.fill.effect = "filter.levels"
					lightSpot.fill.effect.gamma = 1
					lightSpot.fill.effect.white = 1
					lightSpot.fill.effect.black = 1
				end
				--]]

				lightSpot.x, lightSpot.y = x - 64, y - 64
				lightSpot.alpha = alpha
				data.circles[idx] = lightSpot
				idx = idx + 1
			end			
			lastPoint = {x, y}
		end
	end
end

function resumeGame()
	if renderRollingSfx then
		diceSfxSnapshot.alpha = 1
	end
	dicesSnapshot.fill.effect = nil
	dicesSnapshot.alpha = 1
	scoreBoard.alpha = 1
	transition.resume("idle")
	transition.to(background.fill.effect, {radius = 0, time = 800, transition = easing.inOutBack, 
		onComplete = function()
			pauseButton.alpha = 0.2
			loop:resume( true )
		end
		})
end

function restartGame()

end



function pauseGame()
	transition.pause("idle")
	loop:pause( true )
	dicesSnapshot.fill.effect = "filter.polkaDots"
	dicesSnapshot.alpha = 0.2	
	if renderRollingSfx then
		diceSfxSnapshot.alpha = 0.1
	end
	scoreBoard.alpha = 0.05
	--
end

function onPauseTap(e)
	pauseGame()
	pauseButton.alpha = 0.05	
	transition.to(background.fill.effect, {radius = -1, time = 800, transition = easing.inOutBack, onComplete = function()		
			storyboard.showOverlay("menu", {effect = "fade", time = 700, isModal = true})
		end})
end


function setupScene( gScene )
	--Background
	background = display.newImageRect(gScene, "img/background.png", 750 * 0.5, 1150 * 0.5)
	magnet:center(background)
	background.fill.effect = "filter.vignette"
	background.fill.effect.radius = 0
	--Dices Snapshot
	dicesSnapshot = display.newSnapshot(magnet.screenWidth, magnet:getPercentY(70))
	gScene:insert(dicesSnapshot)
	magnet:centerBottom(dicesSnapshot, 0, 0)
	--Dices SFX
	diceSfxSnapshot = display.newSnapshot(150, 150)
	gScene:insert(diceSfxSnapshot)
	diceSfxSnapshot.canvasMode = "discard"
	diceSfxSnapshot.blendMode = "add"

	--diceSfxSnapshot.clearColor = {0, 0, 1}
	magnet:center(diceSfxSnapshot)
	--Pause button
	pauseButton = display.newImageRect(gScene, "img/btnPause.png", 68 * 0.5, 68 * 0.5 )
	magnet:topRight(pauseButton, -10, 10)
	pauseButton.alpha = 0.2
	pauseButton:addEventListener("tap", onPauseTap)
	--Dices
	diceA = newDice(dicesSnapshot.group, -120, -120)
	diceB = newDice(dicesSnapshot.group, -120, -60)	
	--Tap label
	tapToRollLabel = display.newText( gScene, "Tap to Roll", 0, 0, "OptimusPrincepsSemiBold", 32 )
	tapToRollLabel:setFillColor(9/255, 32 / 255, 7/ 255)	
	magnet:center(tapToRollLabel, 0, 50)
	setDicesReadyToRoll()
	--Tap Area
	rectTouch = display.newRect(gScene, 0, 0, magnet.screenWidth, magnet:getPercentY(70))
	rectTouch.isVisible = false
	rectTouch.isHitTestable = true
	rectTouch:addEventListener( "tap", onDicesTap )
	magnet:centerBottom(rectTouch)
	--scoreBoard
	scoreBoard = sboard:new()
	gScene:insert(scoreBoard)
	magnet:centerTop(scoreBoard, 0, magnet:getPercentY(10))
	--Enter Frame Listener	
	loop = looper:newLoop(onLoop, { transitionIn = easing.inSine, timeIn = 1000, transitionOut = easing.inSine, timeOut = 1000})
end

function scene:createScene( event )
	local gScene = self.view
	setupScene( gScene )
end

function scene:enterScene( event )
	loop:resume()
end

function scene:exitScene( event )
	
end

function scene:overlayBegan( event )
    loop:pause()
end
scene:addEventListener( "overlayBegan" )

function scene:overlayEnded( event )
	resumeGame()
    loop:resume()
end
scene:addEventListener( "overlayEnded" )


function scene:didExitScene( event )
end

scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
--game events
Runtime:addEventListener( "onGameRestart", restartGame)
Runtime:addEventListener( "onGameResume", resumeGame)

return scene
