--3d Points
local Point3d = {}
Point3d.__index = Point3d

local Sin = math.sin
local Cos = math.cos

local prototype = {}

function Point3d.__tostring( a )
	return string.format("(%d, %d, %d)", a.x, a.y, a.y)
end

function Point3d:rotateX( radAngle )
	local y = self.y * Cos(radAngle) - self.z * Sin(radAngle)
	local z = self.y * Sin(radAngle) + self.z * Cos(radAngle)
	return Point3d.new(self.x, y, z)
end

function Point3d:rotateY( radAngle )
	local z = self.z * Cos(radAngle) - self.x * Sin(radAngle)
	local x = self.z * Sin(radAngle) + self.x * Cos(radAngle)
	return Point3d.new(x, self.y, z)
end

function Point3d:rotateZ( radAngle )
	local x = self.x * Cos(radAngle) - self.y * Sin(radAngle)
	local y = self.x * Sin(radAngle) + self.y * Cos(radAngle)
	return Point3d.new(x, y, self.z)
end

function Point3d:rotate( xAngle, yAngle, zAngle )
	return self:rotateX( xAngle ):rotateY( yAngle ):rotateZ( zAngle )
end

function Point3d:project(width, height, fieldOfView, viewer_distance)
	local factor = fieldOfView / (viewer_distance + self.z)
	return Point3d.new(self.x * factor + width / 2, -self.y * factor + height / 2, self.z)
end

function Point3d.new( x, y, z)
	return setmetatable({ x = x or 0, y = y or 0, z = z or 0 }, Point3d)
end

setmetatable(Point3d, { __call = function(_, ...) return Point3d.new(...) end })

return Point3d