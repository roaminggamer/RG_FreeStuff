-- 2.5d cube demo
local Point3d = require "lib.point3d"
local cube = {}

local Rad = math.rad
local Deg = math.deg

function cube.new( params )
	local self = display.newGroup()
	self.anchorChildren	= true

	self._rotation 		= {x = 0, y = 0, z = 0}
	self._size			= params.size or 100
	
	self._faces			= {}
	self._points 		= {}	
	self._faceImages	= params.faceImages or {}
	self._wireFrame 	= params.wireFrame or false
	self._wireLines		= {}
	self._facesPoints 	= {} -- transformed face points

	if params.parent then
		params.parent:insert(self)
	end

	local function _initCubeFaces()
		self._points = {
		Point3d( -1,  1, -1),
		Point3d( -1, -1, -1),
		Point3d(  1, -1, -1),
		Point3d(  1,  1, -1),
		Point3d( -1,  1,  1),	
		Point3d( -1, -1,  1),
		Point3d(  1, -1,  1),
		Point3d(  1,  1,  1),		
		}	
		self._faces = {
			{ 1, 2, 3, 4 },
			{ 2, 6, 7, 3 },
			{ 6, 5, 8, 7 },
			{ 5, 1, 4, 8 },
			{ 1, 5, 6, 2 },
			{ 4, 3, 7, 8 },
		}

		local defaultImage = nil
		for i = 1, 6 do
			local fileName = self._faceImages[i] or defaultImage
			if fileName and type(fileName) == "string" then
				defaultImage = fileName
				self._faces[i].image = display.newImageRect(self, fileName, self._size, self._size)
				self._faces[i].image.alpha = 0.98
			end
		end

	end

	local function _newWireLine(idx, x1, y1, x2, y2)
		if self._wireLines[idx] then
			self._wireLines[idx]:removeSelf()
		end
		self._wireLines[idx] = display.newLine( self, x1, y1, x2, y2 )
		self._wireLines[idx].alpha = 1
	end

	function self:setRotation( xAngle, yAngle, zAngle )
		self._rotation = { x = Rad(xAngle or 0), y = Rad(yAngle or 0), z = Rad(zAngle or 0) }
		self:rotate()
	end

	function self:getFacesPoints()
		return self._facesPoints
	end

	function self:cleanUp()
		for _, f in ipairs(self._faces) do
			if f.image then
				f:removeSelf()
			end
		end
	end

	function self:getRotation()
		return Deg(self._rotation.x), Deg(self._rotation.y), Deg(self._rotation.z)
	end

	local r, v
	local x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4
	local wireIndex, path
	local tP = {}
	function self:rotate( xAngle, yAngle, zAngle )
		local rot = self._rotation
		local faces = self._faces
	
		--add rotation in radians
		rot.x = rot.x + Rad(xAngle or 0)
		rot.y = rot.y + Rad(yAngle or 0)
		rot.z = rot.z + Rad(zAngle or 0)

		for idx, p in ipairs(self._points) do
			r = p:rotate( rot.x, rot.y, rot.z )
			v = r:project( self._size, self._size, self._size * 2, 8)
			--save copy of rotated points
			tP[ idx ] = v
		end

		wireIndex = 1
		lastZAvg = 99
		for idx, f in ipairs(faces) do
			
			if self._wireFrame then
				_newWireLine( wireIndex + 1, tP[f[1]].x, tP[f[1]].y, tP[f[2]].x, tP[f[2]].y )
				_newWireLine( wireIndex + 2, tP[f[2]].x, tP[f[2]].y, tP[f[3]].x, tP[f[3]].y )
				_newWireLine( wireIndex + 3, tP[f[3]].x, tP[f[3]].y, tP[f[4]].x, tP[f[4]].y )
				_newWireLine( wireIndex + 4, tP[f[4]].x, tP[f[4]].y, tP[f[1]].x, tP[f[1]].y )
				wireIndex = wireIndex + 4
			end

			if f.image then				
				--update position
				x1, y1, z1 = tP[f[1]].x, tP[f[1]].y, tP[f[1]].z
				x2, y2, z2 = tP[f[2]].x, tP[f[2]].y, tP[f[2]].z
				x3, y3, z3 = tP[f[3]].x, tP[f[3]].y, tP[f[3]].z
				x4, y4, z4 = tP[f[4]].x, tP[f[4]].y, tP[f[4]].z

				f.zAvg =  z1 + z2 + z3 + z4 / 4 
				self._facesPoints[idx] = { x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4 }

				path = f.image.path
				
				path.x1, path.y1 = x1, y1
				path.x2, path.y2 = x2, y2 - self._size
				path.x3, path.y3 = x3 - self._size, y3 - self._size
				path.x4, path.y4 = x4 - self._size, y4
				f.image.x = self._size * 0.5
				f.image.y = self._size * 0.5
			end

		end

		--update zIndex of sorted faces
		table.sort(faces, function(a, b) return a.zAvg > b.zAvg end)
		for _, f in ipairs(faces) do
			if f.image then
				f.image:toFront()
			end
		end
	end

	_initCubeFaces()
	return self
end

return cube
