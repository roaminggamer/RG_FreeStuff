application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterbox",
		xAlign = "center",
        yAlign = "center",
		fps = 60,
	}
}