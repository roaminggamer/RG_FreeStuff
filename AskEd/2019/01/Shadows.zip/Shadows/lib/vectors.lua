-- http://www.nightmareswithin.com/thelab/codedivision/lua-vector-library

local Vector = {}
Vector.__index = Vector

local Rad = math.rad
local Sin = math.sin
local Cos = math.cos
local Sqr = math.sqrt
local Atan2 = math.atan2

function Vector.__add(a, b)
  if type(a) == "number" then
    return Vector.new(b.x + a, b.y + a)
  elseif type(b) == "number" then
    return Vector.new(a.x + b, a.y + b)
  else
    return Vector.new(a.x + b.x, a.y + b.y)
  end
end

function Vector.__sub(a, b)
  if type(a) == "number" then
    return Vector.new(b.x - a, b.y - a)
  elseif type(b) == "number" then
    return Vector.new(a.x - b, a.y - b)
  else
    return Vector.new(a.x - b.x, a.y - b.y)
  end
end

function Vector.__mul(a, b)
  if type(a) == "number" then
    return Vector.new(b.x * a, b.y * a)
  elseif type(b) == "number" then
    return Vector.new(a.x * b, a.y * b)
  else
    return Vector.new(a.x * b.x, a.y * b.y)
  end
end

function Vector.__div(a, b)
  if type(a) == "number" then
    return Vector.new(b.x / a, b.y / a)
  elseif type(b) == "number" then
    return Vector.new(a.x / b, a.y / b)
  else
    return Vector.new(a.x / b.x, a.y / b.y)
  end
end

function Vector.__eq(a, b)
  return a.x == b.x and a.y == b.y
end

function Vector.__lt(a, b)
  return a.x < b.x or (a.x == b.x and a.y < b.y)
end

function Vector.__le(a, b)
  return a.x <= b.x and a.y <= b.y
end

function Vector.__tostring(a)
  return string.format("(%d,%d)", a.x, a.y)
end

function Vector.new(x, y)
  return setmetatable({ x = x or 0, y = y or 0 }, Vector)
end

function Vector:angle()
  return Atan2(self.y,self.x)
end

function Vector.newFromAngleFixed(inAngle, inVelocity)
  local vx = Cos(Rad(inAngle+90))
  local vy = Sin(Rad(inAngle+90))

  if(inVelocity ~= nil)then
    vx = vx * inVelocity
    vy = vy * inVelocity
  end
  return setmetatable({ x = vx or 0, y = vy or 0 }, Vector)
end

function Vector.newFromAngleCorona(inAngle, inVelocity)
  local vx = Cos(Rad(inAngle+180))
  local vy = Sin(Rad(inAngle+180))

  if(inVelocity ~= nil)then
    vx = vx * inVelocity
    vy = vy * inVelocity
  end
  return setmetatable({ x = vx or 0, y = vy or 0 }, Vector)
end

function Vector.newFromAngle(inAngle, inVelocity)
  local vx = Cos(Rad(inAngle-90))
  local vy = Sin(Rad(inAngle-90))

  if(inVelocity ~= nil)then
    vx = vx * inVelocity
    vy = vy * inVelocity
  end
  return setmetatable({ x = vx or 0, y = vy or 0 }, Vector)
end

function Vector.newFromObjects(inObj1, inObj2)
  local vx = inObj2.x - inObj1.x
  local vy = inObj2.y - inObj1.y
  return setmetatable({ x = vx or 0, y = vy or 0 }, Vector)
end

function Vector.newFromObjectsNormalized(inObj1, inObj2)
  tmpVec = Vector.new(inObj2.x - inObj1.x, inObj2.y - inObj1.y)
  return tmpVec:Normalize()
end
function Vector.newFromObjectsCNormalized(inObj1, inObj2)
  tmpVec = Vector.new(inObj2.centerx - inObj1.x, inObj2.centery - inObj1.y)
  return tmpVec:Normalize()
end

function Vector.distance(a, b)
  return (b - a):len()
end

function Vector:distance2( v )
  local dx = self.x - v.x
  local dy = self.y - v.y
  return dx * dx + dy * dy
end

function Vector:copy()
  return Vector.new(self.x, self.y)
end

function Vector:dotproduct(v)
  return ((v.x * self.x) + (v.y * self.y))
end

function Vector:unpack()
  return self.x, self.y
end

function Vector:len()
  return Sqr(self.x * self.x + self.y * self.y)
end

function Vector:lenSqrt()
  return self.x * self.x + self.y * self.y
end
--
function Vector:invert()
	return self * -1
end

function Vector:normalize()
  local len = self:len()
  self.x = self.x / len
  self.y = self.y / len
  return self
end

function Vector:normalized()
  return self / self:len()
end

function Vector:rotate(phi)
  local c = Cos(phi)
  local s = Sin(phi)
  self.x = c * self.x - s * self.y
  self.y = s * self.x + c * self.y
  return self
end

function Vector:rotated(phi)
  return self:copy():rotate(phi)
end

function Vector:reflect(vn)
  local d = self.dotproduct(self, vn)
  self.x = self.x - 2 * d * vn.x
  self.y = self.y - 2 * d * vn.y
  return self
end

function Vector:normal()
  return Vector.new(-self.y, self.x)
end

function Vector:projectOn(other)
  return (self * other) * other / other:lenSq()
end

function Vector:cross(other)
  return self.x * other.y - self.y * other.x
end

-- determines if currect vector is within the bounds defined by the given vectors
function Vector:inBound(topLeft, bottomRight)
	return (topLeft.x < self.x and self.x < bottomRight.x) and 
	       (topLeft.y < self.y and self.y < bottomRight.y)
end

setmetatable(Vector, { __call = function(_, ...) return Vector.new(...) end })
return Vector