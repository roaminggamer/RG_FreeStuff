-- [[ based on http://greweb.me/2012/05/illuminated-js-2d-lights-and-shadows-rendering-engine-for-html5-applications/
display.setStatusBar( display.HiddenStatusBar )

local swCaster = require "swcaster.engine"
local swLigth = require "swcaster.light"
local swShape = require "swcaster.shape"

local magnet = require "lib.magnet"
local looper = require "lib.looper"
local inspect = require "lib.inspect"

local loop = nil

local background = display.newImageRect("img/background.png", magnet.screenWidth, magnet.screenHeight)
magnet:center(background)

swCaster:init(display.contentCenterX, display.contentCenterY, magnet.screenWidth, magnet.screenHeight)
swCaster:toFront()

local light1 = swLigth.new({ 
	x = -30,
	y = 30, 
	color = swLigth.colors.yellow,	
	radius = 20,
	distance = 200, 
	samples = 8,
})
swCaster:addLight(light1)
	
local light2 = swLigth.new({ 
	x = 0,	
	y = 0, 
	color = swLigth.colors.yellow, 
	radius = 20, 
	distance = 150, 
	samples = 8,
	})
swCaster:addLight(light2)

local star = swShape.newPolygon({
	x = 0,
	y = 0,
	vectors = {0,-110, 27,-35, 105,-35, 43,16, 65,90, 0,45, -65,90, -43,15, -105,-35, -27,-35},
	fill = { type = "image", filename = "img/concreteTexture.png"},
	})
swCaster:addShape(star)

local circleFill = { type = "image", filename = "img/concreteTexture.png"}
local function addCircle( x, y, radius )
	local circle = swShape.newCircle({
		x = x,
		y = y,
		radius = radius,
		fill = circleFill,
	})
	swCaster:addShape(circle)
end

addCircle(-195, 0, 15)
addCircle(0, 80, 8)

local rectangle = swShape.newRectangle({
	x = -80,
	y = -80,
	width = 30,
	height = 20,
	fill = { type = "image", filename = "img/concreteTexture2.png"}
})
swCaster:addShape(rectangle)

local rectangle = swShape.newRectangle({
	x = 50,
	y = -80,
	width = 30,
	height = 20,
	fill = { type = "image", filename = "img/concreteTexture2.png"}
})
swCaster:addShape(rectangle)

local rotLight = 0
local onLoop = function(e, loop)
	light1.position.x = 150 * math.cos(math.rad(rotLight)) 
	light1.position.y = 150 * math.sin(math.rad(rotLight))

	light2.position.x = 150 * math.cos(math.rad(-rotLight)) 
	light2.position.y = 150 * math.sin(math.rad(-rotLight))

	rotLight = rotLight + loop.delta * 0.05
	swCaster:update()
end

loop = looper:newLoop(onLoop)
loop:resume()



