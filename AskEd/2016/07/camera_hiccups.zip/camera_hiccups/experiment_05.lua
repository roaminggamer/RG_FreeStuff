--
-- #4 + No Garbage Collection - Run experiment #4 experiment w/ garbage collection off
--

collectgarbage("stop")

require "experiment_04"