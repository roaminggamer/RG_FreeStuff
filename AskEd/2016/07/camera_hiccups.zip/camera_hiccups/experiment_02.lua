--
-- No Garbage Collection - Run baseline experiment w/ garbage collection off
--

collectgarbage("stop")

require "experiment_01"