-- =============================================================
-- Your Copyright Statement Goes Here
-- =============================================================
--  config.lua
-- =============================================================
-- https://docs.coronalabs.com/daily/guide/basics/configSettings/index.html
-- =============================================================

application = {
   content = {
      width              = 320,
      height             = 480,
      scale              = "letterbox",
   },
}