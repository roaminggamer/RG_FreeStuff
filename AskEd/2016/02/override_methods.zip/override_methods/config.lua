application = {
	content = {
		width = 640,
		height = 960,
		scale = "letterbox",
		fps = 60
	},
}

