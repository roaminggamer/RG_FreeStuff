--------------------------------------------------------------------------------
--
-- main.lua
--
--------------------------------------------------------------------------------

-- Global position references

centerX = display.contentCenterX
centerY = display.contentCenterY
actualW = display.actualContentWidth
actualH = display.actualContentHeight
originX = display.screenOriginX
originY = display.screenOriginY
statusBarHeight = display.topStatusBarContentHeight

mRand = math.random
--------------------------------------------------------------------------------

widget = require( "widget" )

if ( system.getInfo( "platform" ) == "android") then
    widget.setTheme( "widget_theme_android_holo_light" )
else
    widget.setTheme( "widget_theme_ios7" )
end

local composer = require("composer")

composer.gotoScene("signupSkillsAddition")
