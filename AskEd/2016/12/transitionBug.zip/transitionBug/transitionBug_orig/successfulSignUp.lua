--------------------------------------------------------------------------------
--
-- successfulSignup.lua
--
--------------------------------------------------------------------------------

local composer = require( "composer" )

local scene = composer.newScene()

-- Global file variables
local background
--------------------------------------------------------------------------------

-- Global file functions

--------------------------------------------------------------------------------

-- create()
function scene:create( event )

    local sceneGroup = self.view

    background = display.newRect(centerX, centerY, actualW, actualH)
    background.fill.effect = "generator.radialGradient"
    background.fill.effect.color1 = {247/255, 194/255, 38/255}
    background.fill.effect.color2 = {240/255, 152/255, 35/255}
    background.fill.effect.center_and_radiuses  =  { 0.5, 0.4, 0.15, 0.75 }
    background.fill.effect.aspectRatio  = 0.4
    sceneGroup:insert(background)

end


-- show()
function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)

    elseif ( phase == "did" ) then

    end
end


-- hide()
function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)

    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen

    end
end


-- destroy()
function scene:destroy( event )

    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view

end


-- -----------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------

return scene
