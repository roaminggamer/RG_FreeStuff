--------------------------------------------------------------------------------
--
-- signupSkillsAddition.lua
--
--------------------------------------------------------------------------------
local composer      = require( "composer" )
local scene         = composer.newScene()

--------------------------------------------------------------------------------
-- Locals
local background
local nextTxt
local nextArrow

--------------------------------------------------------------------------------
-- Function definitions
local function backgroundHandler(event)
    native.setKeyboardFocus(nil)
end
local function handleAddition(event)

end
local function nextStepHandler(event)
    composer.gotoScene("successfulSignUp", "slideDown", 3000) 
end

--------------------------------------------------------------------------------
-- Scene Methods


-- create()
function scene:create( event )

    local sceneGroup = self.view

    background = display.newRect(sceneGroup, centerX, centerY, actualW, actualH)
    if( mode == "test" ) then
        background:setFillColor(1,0,0,0.8)
    else
        background.fill.effect = "generator.radialGradient"
        background.fill.effect.color1 = {239/255, 239/255, 239/255}
        background.fill.effect.color2 = {153/255, 153/255, 153/255}
        background.fill.effect.center_and_radiuses  =  { 0.5, 0.4, 0.15, 0.75 }
        background.fill.effect.aspectRatio  = 0.8
    end
    background:addEventListener("tap", backgroundHandler)


    nextArrow = display.newImage(sceneGroup, "Assets/Navigation/ArrowDown.png", centerX, centerY * 1.95)
    nextArrow:scale(0.05, 0.05)
    nextArrow:addEventListener("tap", nextStepHandler)
    nextTxt = display.newText(sceneGroup, "Next Step", centerX, actualH * 0.875, native.systemFontBold, 20)

end

-- show()
function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
    elseif ( phase == "did" ) then
    end
end

-- hide()
function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
    elseif ( phase == "did" ) then
    end
end

-- destroy()
function scene:destroy( event )
    local sceneGroup = self.view
end


-- -----------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------

return scene
