--------------------------------------------------------------------------------
--
-- successfulSignup.lua
--
--------------------------------------------------------------------------------
local composer      = require( "composer" )
local scene         = composer.newScene()

--------------------------------------------------------------------------------
-- Locals
local background

--------------------------------------------------------------------------------
-- Scene Methods

-- create()
function scene:create( event )

    local sceneGroup = self.view

    background = display.newRect(sceneGroup, centerX, centerY, actualW, actualH)
    if( mode == "test" ) then
        background:setFillColor(0,1,0,0.8)
    else
        background.fill.effect = "generator.radialGradient"
        background.fill.effect.color1 = {247/255, 194/255, 38/255}
        background.fill.effect.color2 = {240/255, 152/255, 35/255}
        background.fill.effect.center_and_radiuses  =  { 0.5, 0.4, 0.15, 1 }
        background.fill.effect.aspectRatio  = 0.4
    end

end

-- show()
function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
    elseif ( phase == "did" ) then
    end
end

-- hide()
function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase
    if ( phase == "will" ) then
    elseif ( phase == "did" ) then
    end
end

-- destroy()
function scene:destroy( event )
    local sceneGroup = self.view
end

-- -----------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------

return scene
