These are the tests for math2d plugins.


Not all tests will not work with basic math2d.