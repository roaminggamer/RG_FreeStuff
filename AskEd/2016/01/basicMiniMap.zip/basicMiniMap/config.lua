application = {
	content = {
		width = 320,
		height = 480, 
		scale = "zoomStretch", 
		fps = 60,
	},
}

