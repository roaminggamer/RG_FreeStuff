-- =============================================================
-- Your Copyright Statement Goes Here
-- =============================================================
--  config.lua
-- =============================================================
-- https://docs.coronalabs.com/daily/guide/basics/configSettings/index.html
-- =============================================================

application = {
   content = {
      width              = 768,
      height             = 1024,
      scale              = "letterBox",
   },
}