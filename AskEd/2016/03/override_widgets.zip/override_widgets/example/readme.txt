step 1 - Copy 'widgetLibrary' folder from downloaded framework-widget-master

step 2 - Modify main.lua (at very top of file) as shown (see my example))