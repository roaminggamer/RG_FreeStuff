application = {
	content = {
		width = 320 * 2,
		height = 480 * 2, 
		scale = "letterbox", 
		--fps = 60,
	},
}

