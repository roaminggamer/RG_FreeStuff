application = {
	content = {
		--compatibilityMode = true,
		width = 640,
		height = 960, 
		scale = "letterbox",
	},
}

