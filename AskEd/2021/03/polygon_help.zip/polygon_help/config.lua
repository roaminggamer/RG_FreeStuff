application = {
	content = {
		width = 640*4,
		height = 960*4,
		scale = "letterbox",
		fps = 30
	},
}

