application = {
	content = {
		width = 640,
		height = 960,
		scale = "letterbox", -- Best
		fps = 30,
	},
}

