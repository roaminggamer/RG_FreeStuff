_W = display.contentWidth;
_H = display.contentHeight;

local composer = require("composer");

composer.gotoScene("scenes.game")
