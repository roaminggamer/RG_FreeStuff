application =
{

	content =
	{
		width = 768,
		height = 1024, 
		scale = "letterBox",
		fps = 60, 
	} 
}
