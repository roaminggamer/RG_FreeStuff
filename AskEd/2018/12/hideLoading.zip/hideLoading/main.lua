io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =====================================================
-- =====================================================
require "scripts.globals"

local composer 	= require "composer" 
composer.gotoScene( "scenes.scene1" )
