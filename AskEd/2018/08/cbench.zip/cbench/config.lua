application = {
	content = {
		width = 640,
		height = 960, 
		scale = "letterBox", -- Good in some cases
		fps = 60,
	},
}