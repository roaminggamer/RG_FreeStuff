application = {
	content = {
		width 	= 1080,
		height 	= 1920,
		scale 	= "letterbox",
		fps 	= 60
	},
}

