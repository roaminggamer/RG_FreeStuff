local assets = {}

assets.bunnies = {
	"assets/rabbitv3_ash.png",
	"assets/rabbitv3_batman.png",
	"assets/rabbitv3_bb8.png",
	"assets/rabbitv3_frankenstein.png",
	"assets/rabbitv3_neo.png",
	"assets/rabbitv3_sonic.png",
	"assets/rabbitv3_spidey.png",
	"assets/rabbitv3_stormtrooper.png",
	"assets/rabbitv3_superman.png",
	"assets/rabbitv3_tron.png",
	"assets/rabbitv3_wolverine.png",
	"assets/rabbitv3.png",
}

return assets
