local page = {}
page.title = "Page 42"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting indu."
page.choices = {
{ "Go To Page 70", 70},
{ "Go To Page 21", 21},
}
return page
