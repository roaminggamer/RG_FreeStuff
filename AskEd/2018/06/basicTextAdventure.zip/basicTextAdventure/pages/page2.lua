local page = {}
page.title = "Page 2"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nL."
page.choices = {
{ "Go To Page 54", 54},
{ "Go To Page 43", 43},
{ "Go To Page 24", 24},
}
return page
