local page = {}
page.title = "Page 59"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of ty."
page.choices = {
{ "Go To Page 90", 90},
{ "Go To Page 82", 82},
{ "Go To Page 52", 52},
}
return page
