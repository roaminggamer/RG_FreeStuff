local page = {}
page.title = "Page 33"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLore."
page.choices = {
{ "Go To Page 85", 85},
{ "Go To Page 78", 78},
{ "Go To Page 16", 16},
}
return page
