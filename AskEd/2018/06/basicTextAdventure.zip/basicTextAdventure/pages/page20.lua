local page = {}
page.title = "Page 20"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesettin."
page.choices = {
{ "Go To Page 49", 49},
{ "Go To Page 16", 16},
{ "Go To Page 65", 65},
}
return page
