local page = {}
page.title = "Page 16"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a gall."
page.choices = {
{ "Go To Page 41", 41},
{ "Go To Page 86", 86},
{ "Go To Page 11", 11},
}
return page
