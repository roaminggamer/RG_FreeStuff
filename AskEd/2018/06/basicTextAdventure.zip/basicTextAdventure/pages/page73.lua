local page = {}
page.title = "Page 73"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever s."
page.choices = {
{ "Go To Page 42", 42},
{ "Go To Page 94", 94},
}
return page
