local page = {}
page.title = "Page 22"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\n\nIt has sur."
page.choices = {
{ "Go To Page 93", 93},
{ "Go To Page 3", 3},
{ "Go To Page 5", 5},
}
return page
