local page = {}
page.title = "Page 63"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n."
page.choices = {
{ "Go To Page 16", 16},
{ "Go To Page 56", 56},
}
return page
