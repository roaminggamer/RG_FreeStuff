local page = {}
page.title = "Page 61"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type spe."
page.choices = {
{ "Go To Page 38", 38},
{ "Go To Page 20", 20},
{ "Go To Page 98", 98},
}
return page
