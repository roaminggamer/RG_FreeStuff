local page = {}
page.title = "Page 40"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text."
page.choices = {
{ "Go To Page 12", 12},
{ "Go To Page 7", 7},
}
return page
