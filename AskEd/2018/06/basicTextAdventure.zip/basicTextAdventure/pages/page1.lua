local page = {}
page.title = "Page 1"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy t."
page.choices = {
{ "Go To Page 75", 75},
{ "Go To Page 77", 77},
}
return page
