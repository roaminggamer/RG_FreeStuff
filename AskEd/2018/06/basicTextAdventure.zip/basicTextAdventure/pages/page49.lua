local page = {}
page.title = "Page 49"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 15."
page.choices = {
{ "Go To Page 82", 82},
{ "Go To Page 26", 26},
}
return page
