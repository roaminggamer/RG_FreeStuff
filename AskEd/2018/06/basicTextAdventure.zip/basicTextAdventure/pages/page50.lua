local page = {}
page.title = "Page 50"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLo."
page.choices = {
{ "Go To Page 75", 75},
{ "Go To Page 80", 80},
}
return page
