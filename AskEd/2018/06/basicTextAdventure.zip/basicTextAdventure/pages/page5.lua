local page = {}
page.title = "Page 5"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text."
page.choices = {
{ "Go To Page 98", 98},
{ "Go To Page 73", 73},
{ "Go To Page 90", 90},
}
return page
