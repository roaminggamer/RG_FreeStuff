local page = {}
page.title = "Page 12"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\n\nIt has survive."
page.choices = {
{ "Go To Page 25", 25},
{ "Go To Page 95", 95},
{ "Go To Page 45", 45},
}
return page
