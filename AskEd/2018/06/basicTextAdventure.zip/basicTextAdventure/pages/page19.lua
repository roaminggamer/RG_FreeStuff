local page = {}
page.title = "Page 19"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a g."
page.choices = {
{ "Go To Page 89", 89},
{ "Go To Page 100", 100},
}
return page
