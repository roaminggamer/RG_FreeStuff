local page = {}
page.title = "Page 47"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took."
page.choices = {
{ "Go To Page 32", 32},
{ "Go To Page 41", 41},
}
return page
