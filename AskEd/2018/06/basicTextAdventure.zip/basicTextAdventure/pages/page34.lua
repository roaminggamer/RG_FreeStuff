local page = {}
page.title = "Page 34"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the i."
page.choices = {
{ "Go To Page 13", 13},
{ "Go To Page 55", 55},
{ "Go To Page 33", 33},
}
return page
