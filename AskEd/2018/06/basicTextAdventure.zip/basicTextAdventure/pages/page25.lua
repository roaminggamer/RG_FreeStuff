local page = {}
page.title = "Page 25"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the in."
page.choices = {
{ "Go To Page 97", 97},
{ "Go To Page 40", 40},
{ "Go To Page 50", 50},
}
return page
