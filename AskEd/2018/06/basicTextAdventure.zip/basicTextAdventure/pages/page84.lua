local page = {}
page.title = "Page 84"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and t."
page.choices = {
{ "Go To Page 77", 77},
{ "Go To Page 43", 43},
}
return page
