local page = {}
page.title = "Page 81"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text."
page.choices = {
{ "Go To Page 40", 40},
{ "Go To Page 40", 40},
}
return page
