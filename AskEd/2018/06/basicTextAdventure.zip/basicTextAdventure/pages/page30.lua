local page = {}
page.title = "Page 30"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown p."
page.choices = {
{ "Go To Page 27", 27},
{ "Go To Page 78", 78},
{ "Go To Page 39", 39},
}
return page
