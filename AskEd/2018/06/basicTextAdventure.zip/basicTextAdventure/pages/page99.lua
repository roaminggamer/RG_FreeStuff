local page = {}
page.title = "Page 99"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and types."
page.choices = {
{ "Go To Page 97", 97},
{ "Go To Page 9", 9},
{ "Go To Page 85", 85},
}
return page
