local page = {}
page.title = "Page 46"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and s."
page.choices = {
{ "Go To Page 30", 30},
{ "Go To Page 65", 65},
{ "Go To Page 54", 54},
}
return page
