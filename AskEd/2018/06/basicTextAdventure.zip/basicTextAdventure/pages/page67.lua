local page = {}
page.title = "Page 67"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since th."
page.choices = {
{ "Go To Page 79", 79},
{ "Go To Page 45", 45},
}
return page
