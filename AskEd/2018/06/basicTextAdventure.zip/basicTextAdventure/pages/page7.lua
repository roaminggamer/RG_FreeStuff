local page = {}
page.title = "Page 7"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy."
page.choices = {
{ "Go To Page 51", 51},
{ "Go To Page 43", 43},
{ "Go To Page 2", 2},
}
return page
