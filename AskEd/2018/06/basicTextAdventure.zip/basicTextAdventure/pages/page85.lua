local page = {}
page.title = "Page 85"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard d."
page.choices = {
{ "Go To Page 33", 33},
{ "Go To Page 89", 89},
}
return page
