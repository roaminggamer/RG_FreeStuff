local page = {}
page.title = "Page 57"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typeset."
page.choices = {
{ "Go To Page 46", 46},
{ "Go To Page 26", 26},
}
return page
