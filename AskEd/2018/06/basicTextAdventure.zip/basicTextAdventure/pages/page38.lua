local page = {}
page.title = "Page 38"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing an."
page.choices = {
{ "Go To Page 12", 12},
{ "Go To Page 32", 32},
}
return page
