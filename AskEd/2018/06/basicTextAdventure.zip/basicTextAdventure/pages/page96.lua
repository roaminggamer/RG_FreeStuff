local page = {}
page.title = "Page 96"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\n\nIt has survived not only fiv."
page.choices = {
{ "Go To Page 100", 100},
{ "Go To Page 58", 58},
{ "Go To Page 40", 40},
}
return page
