local page = {}
page.title = "Page 60"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when."
page.choices = {
{ "Go To Page 41", 41},
{ "Go To Page 20", 20},
{ "Go To Page 20", 20},
}
return page
