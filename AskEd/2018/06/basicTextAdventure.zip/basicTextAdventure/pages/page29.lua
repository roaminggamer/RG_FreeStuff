local page = {}
page.title = "Page 29"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLo."
page.choices = {
{ "Go To Page 72", 72},
{ "Go To Page 87", 87},
}
return page
