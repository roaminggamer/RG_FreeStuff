local page = {}
page.title = "Page 14"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard."
page.choices = {
{ "Go To Page 19", 19},
{ "Go To Page 16", 16},
{ "Go To Page 45", 45},
}
return page
