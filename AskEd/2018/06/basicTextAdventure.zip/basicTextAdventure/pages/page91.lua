local page = {}
page.title = "Page 91"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since."
page.choices = {
{ "Go To Page 31", 31},
{ "Go To Page 87", 87},
{ "Go To Page 82", 82},
}
return page
