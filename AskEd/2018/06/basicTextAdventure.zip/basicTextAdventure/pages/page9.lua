local page = {}
page.title = "Page 9"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's."
page.choices = {
{ "Go To Page 38", 38},
{ "Go To Page 33", 33},
{ "Go To Page 55", 55},
}
return page
