local page = {}
page.title = "Page 87"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry."
page.choices = {
{ "Go To Page 52", 52},
{ "Go To Page 45", 45},
{ "Go To Page 86", 86},
}
return page
