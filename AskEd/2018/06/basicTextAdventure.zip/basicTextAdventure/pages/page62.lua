local page = {}
page.title = "Page 62"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard."
page.choices = {
{ "Go To Page 38", 38},
{ "Go To Page 20", 20},
{ "Go To Page 47", 47},
}
return page
