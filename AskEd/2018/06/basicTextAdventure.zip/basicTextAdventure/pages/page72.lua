local page = {}
page.title = "Page 72"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s."
page.choices = {
{ "Go To Page 36", 36},
{ "Go To Page 28", 28},
{ "Go To Page 66", 66},
}
return page
