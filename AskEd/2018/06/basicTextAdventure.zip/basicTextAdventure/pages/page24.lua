local page = {}
page.title = "Page 24"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took."
page.choices = {
{ "Go To Page 65", 65},
{ "Go To Page 98", 98},
}
return page
