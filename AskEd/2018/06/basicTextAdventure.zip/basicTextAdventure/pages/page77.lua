local page = {}
page.title = "Page 77"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's."
page.choices = {
{ "Go To Page 6", 6},
{ "Go To Page 93", 93},
{ "Go To Page 61", 61},
}
return page
