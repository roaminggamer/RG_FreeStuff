local page = {}
page.title = "Page 44"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type sp."
page.choices = {
{ "Go To Page 6", 6},
{ "Go To Page 91", 91},
}
return page
