local page = {}
page.title = "Page 82"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\."
page.choices = {
{ "Go To Page 37", 37},
{ "Go To Page 69", 69},
{ "Go To Page 44", 44},
}
return page
