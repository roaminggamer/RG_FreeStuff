local page = {}
page.title = "Page 95"
page.content = "\n\nLorem Ipsum is simply dummy text of the printin."
page.choices = {
{ "Go To Page 32", 32},
{ "Go To Page 39", 39},
}
return page
