local page = {}
page.title = "Page 17"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry'."
page.choices = {
{ "Go To Page 68", 68},
{ "Go To Page 35", 35},
}
return page
