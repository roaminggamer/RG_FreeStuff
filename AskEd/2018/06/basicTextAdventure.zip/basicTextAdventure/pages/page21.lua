local page = {}
page.title = "Page 21"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scra."
page.choices = {
{ "Go To Page 82", 82},
{ "Go To Page 88", 88},
{ "Go To Page 65", 65},
}
return page
