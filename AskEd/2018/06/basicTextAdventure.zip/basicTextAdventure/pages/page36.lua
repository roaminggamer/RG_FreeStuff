local page = {}
page.title = "Page 36"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting i."
page.choices = {
{ "Go To Page 81", 81},
{ "Go To Page 33", 33},
{ "Go To Page 73", 73},
}
return page
