local page = {}
page.title = "Page 39"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer."
page.choices = {
{ "Go To Page 51", 51},
{ "Go To Page 17", 17},
{ "Go To Page 68", 68},
}
return page
