local page = {}
page.title = "Page 31"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the ind."
page.choices = {
{ "Go To Page 68", 68},
{ "Go To Page 15", 15},
{ "Go To Page 77", 77},
}
return page
