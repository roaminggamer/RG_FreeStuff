local page = {}
page.title = "Page 15"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum ha."
page.choices = {
{ "Go To Page 100", 100},
{ "Go To Page 81", 81},
{ "Go To Page 16", 16},
}
return page
