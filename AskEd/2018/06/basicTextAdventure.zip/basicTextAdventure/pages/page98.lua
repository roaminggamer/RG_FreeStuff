local page = {}
page.title = "Page 98"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown."
page.choices = {
{ "Go To Page 73", 73},
{ "Go To Page 37", 37},
{ "Go To Page 28", 28},
}
return page
