local page = {}
page.title = "Page 28"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\n\nIt has survived not only five centuri."
page.choices = {
{ "Go To Page 75", 75},
{ "Go To Page 53", 53},
}
return page
