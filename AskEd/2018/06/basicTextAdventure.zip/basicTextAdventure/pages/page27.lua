local page = {}
page.title = "Page 27"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.."
page.choices = {
{ "Go To Page 11", 11},
{ "Go To Page 11", 11},
}
return page
