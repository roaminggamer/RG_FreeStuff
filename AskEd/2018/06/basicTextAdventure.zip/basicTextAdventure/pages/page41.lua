local page = {}
page.title = "Page 41"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of t."
page.choices = {
{ "Go To Page 18", 18},
{ "Go To Page 79", 79},
{ "Go To Page 53", 53},
}
return page
