local page = {}
page.title = "Page 86"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n."
page.choices = {
{ "Go To Page 71", 71},
{ "Go To Page 23", 23},
}
return page
