local page = {}
page.title = "Page 100"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy text ever s."
page.choices = {
{ "Go To Page 92", 92},
{ "Go To Page 88", 88},
}
return page
