local page = {}
page.title = "Page 65"
page.content = "\n\nLorem Ipsum is simply dummy text of the printing and typesetting industry.\n\nLorem Ipsum has been the industry's standard dummy t."
page.choices = {
{ "Go To Page 38", 38},
{ "Go To Page 22", 22},
{ "Go To Page 22", 22},
}
return page
