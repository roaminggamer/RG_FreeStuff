-- =============================================================
-- Minimalistic 'starter' common.lua
-- =============================================================
local common = {}

-- Game Logic Settings
common.gameIsRunning 			= false

-- Your stuff here

return common
