
application = {

	content = {

		width = 720,
		height = 1280,
		scale = "letterbox",
		xAlign = "center", 
		yAlign = "center",  

		fps = 30,
		
	},

}
