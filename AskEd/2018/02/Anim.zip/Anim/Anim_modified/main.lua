display.setStatusBar( display.HiddenStatusBar )

local example = require "example"

local sceneGroup = display.newGroup()

example.create( sceneGroup )