Answer to this question:

http://forums.coronalabs.com/topic/47218-bullets/#entry243948