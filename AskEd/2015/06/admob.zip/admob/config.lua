application = {
	content = {
		width = 320,
		height = 480,
		scale = "letterbox", -- Best
		fps = 30,
	},
}

