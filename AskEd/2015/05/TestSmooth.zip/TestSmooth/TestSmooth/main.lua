-- Hide the status bar.
display.setStatusBar(display.HiddenStatusBar)

require( "test2_alt" )
