local bob = {}
bob.name = "sub-folder bob"
print("Required scripts.bob.lua!")
return bob