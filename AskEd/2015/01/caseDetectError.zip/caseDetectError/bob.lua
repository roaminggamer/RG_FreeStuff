local bob = {}
bob.name = "root bob"
print("Required bob.lua!")
return bob