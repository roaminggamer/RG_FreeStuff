application = {
	content = {
		width = 640,
		height = 960, 
		scale = "letterbox",  -- letterbox, zoomEven, zoomStretch, none, adaptive
		fps = 30, -- 30, 60
	},
}

