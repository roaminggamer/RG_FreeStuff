application = {
	content = {
		width = 640,
		height = 960, 
		--scale = "zoomStretch", 
		scale = "zoomStretch", 
		fps = 30,
	},
}

