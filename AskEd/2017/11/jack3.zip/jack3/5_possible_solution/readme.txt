Similar effect to this:

https://www.youtube.com/watch?feature=youtu.be&t=641&v=vkmfWzolDfo

