-- THIS IS TO FIND OUT IF THE APP RUNS ON A TABLET OR A SMALL DISPLAY
-- IF WE HAVE A TABLET, SCALE DOWN THE GUI TO THE HALF, OTHERWISE THE
-- WIDGETS APPEAR TOO BIG. YOU CAN USE ANY SCALE, BUT .5 IS FINE HERE.
-- CHANGING THE SCALE OF A WIDGET DOES NOT CHANGE ITS WIDTH OR HEIGHT,
-- IT JUST SCALES THE WIDGET GRAPHICS USED (BORDERS, ICONS, TEXT ETC.)
physicalW = math.round( (display.contentWidth  - display.screenOriginX*2) / display.contentScaleX)
physicalH = math.round( (display.contentHeight - display.screenOriginY*2) / display.contentScaleY)
isTablet     = false; if physicalW >= 1024 or physicalH >= 1024 then isTablet = true end
GUIScale     = isTablet == true and .5 or 1.0

local background = display.newImageRect( "images/margins-bg.png", 1200,1600)
background.x = 1200/2-225 -- why? shouldn't this be centered?
background.y = 1600/2
background:toBack()

-- then anchor upper left for the future
display.setDefault( "anchorX", 0 )
display.setDefault( "anchorY", 0 )

s = require( "composer" )
widget = require( "widget" )

s.gotoScene("scenes.test", {time = 250})
