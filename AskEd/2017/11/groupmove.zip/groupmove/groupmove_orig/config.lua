if string.sub(system.getInfo("model"),1,4) == "iPad" then
    application =
    {
        content =
        {
            --graphicsCompatibility = 1,
            
            width = 768,
            height = 1152,
            scale = "letterBox",
            xAlign = "center",
            yAlign = "top",
            imageSuffix =
            {
                ["@2x"] = 1.5,
                ["@4x"] = 3.0,
            },
        },
        notification =
        {
            iphone = {
                types = {
                    "badge", "sound", "alert"
                }
            }
        }
    }

elseif string.sub(system.getInfo("model"),1,2) == "iP" and display.pixelHeight > 960 then
    application =
    {
        content =
        {
            width = 768,
            height = 1152,
            scale = "letterBox",
            xAlign = "center",
            yAlign = "top",
            imageSuffix =
            {
                ["@2x"] = 1.5,
                ["@4x"] = 3.0,
            },
        },
        notification =
        {
            iphone = {
                types = {
                    "badge", "sound", "alert"
                }
            }
        }
    }

elseif string.sub(system.getInfo("model"),1,2) == "iP" then
    application =
    {
        content =
        {
            width = 768,
            height = 1152,
            scale = "letterBox",
            xAlign = "center",
            yAlign = "top",
            imageSuffix =
            {
                ["@2x"] = 1.5,
                ["@4x"] = 3.0,
            },
        },
        notification =
        {
            iphone = {
                types = {
                    "badge", "sound", "alert"
                }
            }
        }
    }
elseif display.pixelHeight / display.pixelWidth > 1.72 then
    application =
    {
        content =
        {
            width = 768,
            height = 1152,
            scale = "letterBox",
            xAlign = "center",
            yAlign = "top",
            imageSuffix =
            {
                ["@2x"] = 1.5,
                ["@4x"] = 3.0,
            },
        },
    }
else
    application =
    {
        content =
        {
            width = 768,
            height = 1152,
            scale = "letterBox",
            xAlign = "center",
            yAlign = "top",
            imageSuffix =
            {
                ["@2x"] = 1.5,
                ["@4x"] = 3.0,
            },
        },
        notification =
        {
            iphone = {
                types = {
                    "badge", "sound", "alert"
                }
            }
        }
    }
end
