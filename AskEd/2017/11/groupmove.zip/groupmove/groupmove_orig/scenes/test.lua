local scene = s.newScene()

local fbm = require "lib.fillbar_m"

local _ctr = 1
local _chargroup
local scaleUp = 1.5

local _rect1X = 60
local _rect1Y = 60

local _rect2X = 60
local _rect2Y = 400

local rects = {}

function scene:create()
    local group = self.view
    
    local background = display.newRect( group, 0, 0, 768, 1152)
    background:setFillColor(unpack{128/255, 128/255, 50/255, 1})

    -- All characters added to this group
    _chargroup = display.newGroup()
    group:insert(_chargroup)

    scene:createRect1()
    scene:createGuideLines1()
    
    scene:createRect2()
    scene:createGuideLines2()
    
    local beginButton = widget.newButton{
        left = 265,
        top = 100,
        label = "enlarge,1,2,3",
        fontSize = 32,
        shape = "rect",
        fillColor = { 
            default={ 1, 0.2, 0.5, 0.7 }, 
            over={ 1, 0.2, 0.5, 1 } 
        },
        onRelease = function(e)
            if _ctr == 1 then
                scene:enlarge1()
                _ctr = _ctr+1
            elseif _ctr == 2 then
                scene:enlarge2()
            end
        end
    }
    group:insert(beginButton)
end
function scene:show( event )
    --local group = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- noop
    elseif ( phase == "did" ) then
        -- noop
    end
end
function scene:destroy( )
    scene:removeEventListener( "create", scene )
    scene:removeEventListener( "show", scene )
    scene:removeEventListener( "destroy", scene )
    --unrequire("images.sprites.test")
    _Sheet = nil
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "destroy", scene )
--------------------
function scene:createRect1()
    --local group = self.view
    
    local slotgroup = display.newGroup()
    slotgroup.anchorX = 0.5
    slotgroup.anchorY = 0.5
    
    local outerGroup = display.newGroup()
    outerGroup:insert(slotgroup)
    _chargroup:insert(outerGroup)

    local member = display.newRect( slotgroup, _rect1X, _rect1Y, 320, 480 )
    member:setFillColor(unpack{0,0,1,1})
    member:scale(0.375,0.375) -- 320x480 becomes 120x180 - Group should shrink, right?!
    member.centerX = member.x+member.width/2
    member.centerY = member.y+member.height/2

    -- Using a custom masked bar would blow out the group to the left to a variable width
    --[[local bar = fbm.new({
        parent=slotgroup,
        x=member.x-4,
        y=member.y+(slotgroup.height)+10, -- height of .375 member height + 5.75% 
        barprefix="runnerlife", 
        useback = true,
        maxval=1000
    })
    bar.setValue(1000-(i*200), true)
    ]]--
    
    rects[1] = {
        member = member,
        --bar = bar,
        group = outerGroup,
    }
    slotgroup:toFront()
end
function scene:createGuideLines1()
    local group = self.view
    -- Guidelines
    -----------------
    -- Start
    local startLabel = display.newText("Start", _rect1X-2, _rect1X-2-14, "Dead Kansas", 12)
    local strokeWidth = 4
    local hLine = display.newLine( group, _rect1X-2, _rect1Y-2, _rect1X-2+120+strokeWidth, _rect1Y-2)
    hLine:setStrokeColor(1,0,0)
    hLine.strokeWidth = strokeWidth
    
    local vLine = display.newLine( group, _rect1X-2, _rect1Y-2, _rect1X-2, _rect1Y-2+180+strokeWidth )
    vLine:setStrokeColor(1,0,0)
    vLine.strokeWidth = strokeWidth
    -----------------
    -- 1.5 * 120x180 = 180x270
    -----------------
    -- Start * 1.5
    local xAdj2 = -30 -- (180-120)/2
    local yAdj2 = -45 -- (270-180)/2
    local largeLabel2 = display.newText("Large", _rect1X-2+xAdj2, _rect1Y-2-14+yAdj2, "Dead Kansas", 12)
    local strokeWidth2 = 4
    local hLine2 = display.newLine( group, _rect1X-2+xAdj2, _rect1Y-2+yAdj2, _rect1X-2+180+strokeWidth2+xAdj2, _rect1Y-2+yAdj2)
    hLine2:setStrokeColor(0,1,0)
    hLine2.strokeWidth = strokeWidth2
    
    local vLine2 = display.newLine( group, _rect1X-2+xAdj2, _rect1Y-2+yAdj2, _rect1X-2+xAdj2, _rect1Y-2+270+strokeWidth2+yAdj2 )
    vLine2:setStrokeColor(0,1,0)
    vLine2.strokeWidth = strokeWidth2
end
function scene:enlarge1()
    local targetGroup = rects[1].group
    local targetMember = rects[1].member
    local xAdj = (scaleUp-1)*targetGroup.width/2
    local yAdj = (scaleUp-1)*targetGroup.height/2
    targetGroup:scale(scaleUp, scaleUp)
    targetGroup.anchorChildren = true
    targetGroup.x = targetMember.x-xAdj
    targetGroup.y = targetMember.y-yAdj
end
--------------------
function scene:createRect2()
    local slotgroup = display.newGroup()
    slotgroup.anchorX = 0.5
    slotgroup.anchorY = 0.5
    
    local outerGroup = display.newGroup()
    outerGroup:insert(slotgroup)
    _chargroup:insert(outerGroup)

    local member = display.newRect( slotgroup, _rect2X, _rect2Y, 320, 480 )
    member:setFillColor(unpack{0,128/255,1,1})
    member:scale(0.375,0.375) -- 320x480 becomes 120x180 - Group should shrink, right?!
    member.centerX = member.x+member.width/2
    member.centerY = member.y+member.height/2

    -- Using a custom masked bar would blow out the group to the left to a variable width
    local bar = fbm.new({
        parent=slotgroup,
        x=member.x-4,
        y=member.y+(slotgroup.height)+10, -- height of .375 member height + 5.75% 
        barprefix="runnerlife", 
        useback = true,
        maxval=1000
    })
    bar.setValue(1000-200, true)
    
    rects[2] = {
        member = member,
        bar = bar,
        group = outerGroup,
    }
    slotgroup:toFront()
end    
function scene:createGuideLines2()
    local group = self.view
    -- Guidelines
    -----------------
    -- Start
    local startLabel = display.newText("Start", _rect2X-2, _rect2Y-2-14, "Dead Kansas", 12)
    local strokeWidth = 4
    local hLine = display.newLine( group, _rect2X-2, _rect2Y-2, _rect2X-2+120+strokeWidth, _rect2Y-2)
    hLine:setStrokeColor(1,0,0)
    hLine.strokeWidth = strokeWidth
    
    local vLine = display.newLine( group, _rect2X-2, _rect2Y-2, _rect2X-2, _rect2Y-2+225+strokeWidth )
    vLine:setStrokeColor(1,0,0)
    vLine.strokeWidth = strokeWidth
    -----------------
    -- 1.5 * 120x180 = 180x270
    -----------------
    -- Start * 1.5
    local xAdj2 = -30 -- (180-120)/2
    local yAdj2 = -45 -- (270-180)/2
    local largeLabel2 = display.newText("Large", _rect2X-2+xAdj2, _rect2Y-2-14+yAdj2, "Dead Kansas", 12)
    local strokeWidth2 = 4
    local hLine2 = display.newLine( group, _rect2X-2+xAdj2, _rect2Y-2+yAdj2, _rect2X-2+180+strokeWidth2+xAdj2, _rect2Y-2+yAdj2)
    hLine2:setStrokeColor(0,1,0)
    hLine2.strokeWidth = strokeWidth2
    
    local vLine2 = display.newLine( group, _rect2X-2+xAdj2, _rect2Y-2+yAdj2, _rect2X-2+xAdj2, _rect2Y-2+270+strokeWidth2+yAdj2 )
    vLine2:setStrokeColor(0,1,0)
    vLine2.strokeWidth = strokeWidth2
end
function scene:enlarge2()
    local targetGroup = rects[2].group
    local targetMember = rects[2].member
    local xAdj = (scaleUp-1)*targetGroup.width/2
    local yAdj = (scaleUp-1)*targetGroup.height/2
    targetGroup:scale(scaleUp, scaleUp)
    targetGroup.anchorChildren = true
    targetGroup.x = targetMember.x-xAdj
    targetGroup.y = targetMember.y-yAdj
end

return scene
