--
-- Run in simulated "Borderless 640 x 960 iPhone"
--
local fullw = display.actualContentWidth
local fullh = display.actualContentHeight
local centerX = display.contentCenterX
local centerY = display.contentCenterY

--
-- Scaling To Fill A Rectangular Space Done Wrong
-- 
local group = display.newGroup()
--
local back = display.newRect( group, centerX, centerY, 320, 480 )
back:setFillColor(0.25,0.25,0.25)
--
local tmp = display.newRect( group, centerX - 160, centerY - 240, 40, 40  )
tmp:setFillColor(1,0,0)
tmp.anchorX = 0
tmp.anchorY = 0
--
local tmp = display.newRect( group, centerX + 160, centerY - 240, 40, 40  )
tmp:setFillColor(0,1,0)
tmp.anchorX = 1
tmp.anchorY = 0
--
local tmp = display.newRect( group, centerX + 160, centerY + 240, 40, 40  )
tmp:setFillColor(0,0,1)
tmp.anchorX = 1
tmp.anchorY = 1
--
local tmp = display.newRect( group, centerX - 160, centerY + 240, 40, 40  )
tmp:setFillColor(1,1,0)
tmp.anchorX = 0
tmp.anchorY = 1
--
local tmp = display.newRect( group, centerX, centerY, 40, 40  )
tmp:setFillColor(1,0,1)
--
-- Scale up by factor of 2 after short delay
local scaleFactor = 2
transition.to( group, { delay = 1000, time = 5000, 
	                     xScale = scaleFactor, yScale = scaleFactor })

