application =
{
	content =
	{
		-- fps = 60,
		width = 600,
		height = 800,
		--scale = "letterBox"
	}
}