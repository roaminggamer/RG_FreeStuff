fnt_reg = "asset/font/Brandon_reg.otf"

scrW = display.contentWidth
scrH = display.contentHeight
orgW = display.actualContentWidth
orgH = display.actualContentHeight
pxW = display.pixelWidth
pxH = display.pixelHeight
centerX = display.contentCenterX
centerY = display.contentCenterY

topLeft = {0, 0}
topRight = {1, 0}
topCenter = {0.5, 0}
centerLeft = {0, 0.5}
center = {0.5, 0.5}
centerRight = {1, 0.5}
bottomLeft = {0, 1}
bottomRight = {1, 1}
bottomCenter = {0.5, 1}

------------------------------------------------------------------
-- newRect
------------------------------------------------------------------
function newRect( parent, x, y, w, h, color, ref )
    local rect = display.newRect(x, y, w, h)

    rect.initX, rect.initY = rect.x, rect.y

    if parent then
        parent:insert(rect)
    end
    
    if color then
        rect.fill = color
    end

    if ref then
        setReferencePoint(rect, ref)
    end

    return rect
end

------------------------------------------------------------------
-- newText
------------------------------------------------------------------
function newText( parent, text, x, y, w, h, font, fontSize, color, align, ref )
    if platform == "android" then
        y = y+3
    end

    local option = 
    { 
        -- parent = parent,
        text = text,
        x = x,
        y = y,
        width = w,
        height = h,
        font = font,
        fontSize = fontSize,
        align = align,
    }

    local txt = display.newText( option )
    txt.initX, txt.initY = txt.x, txt.y

    if parent then
        parent:insert(txt)
    end

    if color then
        txt.fill = color
    end

    if ref then
        setReferencePoint(txt, ref)
    end

    return txt
end