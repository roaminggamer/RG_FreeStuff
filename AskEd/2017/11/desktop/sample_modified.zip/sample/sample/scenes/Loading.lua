local composer = require "composer"
local scene = composer.newScene()

function scene:create( event )
    local group_scene = self.view

    local bg = newRect( group_scene, centerX, centerY, scrW, scrH, {0.8} )
    newText( group_scene, "Hello World!", centerX, centerY, 0, 0, fnt_reg, 60, {0.2} )
end

function scene:show( event )
    local phase = event.phase

    if phase == "will" then

    elseif phase == "did" then
        composer.removeHidden()
    end
end

function scene:hide( event )
    local phase = event.phase

    if phase == "will" then

    elseif phase == "did" then

    end
end

function scene:destroy( event )

end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene