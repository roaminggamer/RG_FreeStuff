require "Common"
-- require "Constant"

local function main()
    math.randomseed( os.time() )
    display.setStatusBar( display.HiddenStatusBar )
    display.setDefault( "background", 1 )
    io.output():setvbuf( "no" ) -- Don't use buffer for console messages
    -- Runtime:hideErrorAlerts()
    if audio.supportsSessionProperty then
        audio.setSessionProperty(audio.MixMode, audio.AmbientMixMode) -- 게임에서 음악 재생 멈추지 않는 모드
    end

    local composer = require "composer"
    composer.gotoScene( "scenes.Loading" )
end

main()
