adaptation of this code:
https://coronalabs.com/blog/2014/08/19/tutorial-building-a-sliding-menu/