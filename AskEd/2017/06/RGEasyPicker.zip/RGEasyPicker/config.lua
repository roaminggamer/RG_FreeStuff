-- Learn more about the config.lua file here: http://docs.coronalabs.com/daily/guide/basics/configSettings/index.html
application = {
	content = {
		width 	= 320,
		height 	= 480, 
		scale 	= "letterbox", 
		fps 	= 30, -- 30 or 60
	},
}

