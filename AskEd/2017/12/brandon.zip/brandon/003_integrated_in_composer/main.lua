-- =============================================================
-- Your Copyright Statement Here
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================

local composer = require "composer"
composer.gotoScene( "scenes.play" )
