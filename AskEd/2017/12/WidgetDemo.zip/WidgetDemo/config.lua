application = 
{
	content = 
	{ 
		scale = "adaptive",
		fps = 60,
		
		imageSuffix = {
			["@2x"] = 2,
			["@3x"] = 3,
		}
	}
}
