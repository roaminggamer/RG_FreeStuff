-----------------------------------------------------------------------------------------
--
-- view1.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local widget = require "widget"
local scene = composer.newScene()
local categories = {}

local nameCategory --EFM

function scene:create( event )
	local sceneGroup = self.view

	-- Called when the scene's view does not exist.
	--
	-- INSERT code here to initialize the scene
	-- e.g. add display objects to 'sceneGroup', add touch listeners, etc.

	-- create a white background to fill screen
	local background = display.newRect( centerX, centerY, fullw, fullh )
	background:setFillColor(0)

	-- create some text
	local title = display.newText("Trash Logger \n", centerX, top + 90, native.systemFont, 20)
	title:setFillColor(1, 0.398, 0, 1)
	local instructions = display.newText("1). Click the 'New Category' button to create \n a new category. \n \n 2). Then, click the green + button to add a subcategory. \n \nHappy Cleaning!", left + 20, title.y + 50, native.systemFont, 12)
	instructions.anchorX = 0
	instructions:setFillColor(1, 0.398, 0, 1)
	--local nameCategory = native.newTextField(instructions.x, instructions.y + 60, fullw / 2, 20) --EFM
	nameCategory = native.newTextField(instructions.x, instructions.y + 60, fullw / 2, 20) --EFM
	nameCategory.anchorX = 0
	nameCategory.anchorY = 0

	local addSubcategoryButton = widget.newButton({
		 label = "",
		 width = 20,
		 height = 20,
		 defaultFile = "Hopstarter-Rounded-Square-Button-Add.jpg"
	})

	addSubcategoryButton.x = nameCategory.x + nameCategory.width + (addSubcategoryButton.width / 2)
	addSubcategoryButton.y = nameCategory.y + (addSubcategoryButton.height / 2) - 1

  --1, 0.398, 0, 1
	-- all objects must be added to group (e.g. self.view)
	sceneGroup:insert( background )
	sceneGroup:insert( title )
	sceneGroup:insert( instructions )
	sceneGroup:insert( nameCategory )
	sceneGroup:insert( addSubcategoryButton )
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase

	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
		nameCategory.isVisible = true -- EFM
	elseif phase == "did" then
		-- Called when the scene is now on screen
		--
		-- INSERT code here to make the scene come alive		
		-- e.g. start timers, begin animation, play audio, etc.		
	end
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase

	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)		
	elseif phase == "did" then
		-- Called when the scene is now off screen
		nameCategory.isVisible = false -- EFM
	end
end

function scene:destroy( event )
	local sceneGroup = self.view

	-- Called prior to the removal of scene's "view" (sceneGroup)
	--
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
