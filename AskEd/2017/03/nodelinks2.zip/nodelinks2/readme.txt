Requires SSK2 lite or PRO

https://roaminggamer.github.io/RGDocs/pages/SSK2/