
application = 
{
	content = 
	{ 
		fps = 60,
		width = 768,
		height = 1024,
		scale = "letterbox",
		xAlign = "center",
		yAlign = "center",
	}
}

	