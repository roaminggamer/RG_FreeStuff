application = {
	content = {
		width = 640/2,
		height = 960/2, 
		scale = "letterBox", -- Good in some cases
	},
}