
display.setStatusBar( display.HiddenStatusBar )

local composer = require( "composer" )
print("entering gotoScene")
composer.gotoScene( "game2" )
print("out from gotoScene")
