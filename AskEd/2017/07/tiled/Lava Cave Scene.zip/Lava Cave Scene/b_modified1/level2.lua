return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "0.18.2",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 30,
  height = 20,
  tilewidth = 32,
  tileheight = 32,
  nextobjectid = 635,
  properties = {},
  tilesets = {
    {
      name = "lava",
      firstgid = 1,
      tilewidth = 624,
      tileheight = 384,
      spacing = 0,
      margin = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {
        {
          id = 0,
          image = "lavacavestuff/tile4.png",
          width = 624,
          height = 384
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      name = "content",
      visible = true,
      opacity = 1,
      offsetx = -4,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 632,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 640,
          width = 960,
          height = 640,
          rotation = 0,
          gid = 1,
          visible = true,
          properties = {}
        },
        {
          id = 633,
          name = "",
          type = "",
          shape = "rectangle",
          x = -960,
          y = 640,
          width = 960,
          height = 640,
          rotation = 0,
          gid = 1,
          visible = true,
          properties = {}
        },
        {
          id = 634,
          name = "",
          type = "",
          shape = "rectangle",
          x = 960,
          y = 640,
          width = 960,
          height = 640,
          rotation = 0,
          gid = 1,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
