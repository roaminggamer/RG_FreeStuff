return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "0.18.2",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 30,
  height = 20,
  tilewidth = 32,
  tileheight = 32,
  nextobjectid = 632,
  properties = {},
  tilesets = {
    {
      name = "proto",
      firstgid = 1,
      tilewidth = 40,
      tileheight = 40,
      spacing = 0,
      margin = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 34,
      tiles = {
        {
          id = 0,
          image = "proto/actionMapHelper.png",
          width = 40,
          height = 40
        },
        {
          id = 1,
          image = "proto/ball.png",
          width = 40,
          height = 40
        },
        {
          id = 2,
          image = "proto/block.png",
          width = 40,
          height = 40
        },
        {
          id = 3,
          image = "proto/blockA.png",
          width = 40,
          height = 40
        },
        {
          id = 4,
          image = "proto/blockB.png",
          width = 40,
          height = 40
        },
        {
          id = 5,
          image = "proto/blockC.png",
          width = 40,
          height = 40
        },
        {
          id = 6,
          image = "proto/blockD.png",
          width = 40,
          height = 40
        },
        {
          id = 7,
          image = "proto/blockE.png",
          width = 40,
          height = 40
        },
        {
          id = 8,
          image = "proto/blockE0.png",
          width = 40,
          height = 40
        },
        {
          id = 9,
          image = "proto/blockE1.png",
          width = 40,
          height = 40
        },
        {
          id = 10,
          image = "proto/blockE2.png",
          width = 40,
          height = 40
        },
        {
          id = 11,
          image = "proto/blockE3.png",
          width = 40,
          height = 40
        },
        {
          id = 12,
          image = "proto/blockF.png",
          width = 40,
          height = 40
        },
        {
          id = 13,
          image = "proto/blockG.png",
          width = 40,
          height = 40
        },
        {
          id = 14,
          image = "proto/blockH.png",
          width = 40,
          height = 40
        },
        {
          id = 15,
          image = "proto/blockP0.png",
          width = 40,
          height = 40
        },
        {
          id = 16,
          image = "proto/blockP1.png",
          width = 40,
          height = 40
        },
        {
          id = 17,
          image = "proto/blockP2.png",
          width = 40,
          height = 40
        },
        {
          id = 18,
          image = "proto/blockP3.png",
          width = 40,
          height = 40
        },
        {
          id = 19,
          image = "proto/camera.png",
          width = 40,
          height = 40
        },
        {
          id = 20,
          image = "proto/damageBlockGreen.png",
          width = 40,
          height = 40
        },
        {
          id = 21,
          image = "proto/damageBlockRed.png",
          width = 40,
          height = 40
        },
        {
          id = 22,
          image = "proto/damageBlockYellow.png",
          width = 40,
          height = 40
        },
        {
          id = 23,
          image = "proto/enemy.png",
          width = 40,
          height = 40
        },
        {
          id = 24,
          image = "proto/gamelogic.png",
          width = 40,
          height = 40
        },
        {
          id = 25,
          image = "proto/keyboard.png",
          width = 40,
          height = 40
        },
        {
          id = 26,
          image = "proto/null.png",
          width = 40,
          height = 40
        },
        {
          id = 27,
          image = "proto/player.png",
          width = 40,
          height = 40
        },
        {
          id = 28,
          image = "proto/projectile.png",
          width = 40,
          height = 40
        },
        {
          id = 29,
          image = "proto/shot0.png",
          width = 40,
          height = 40
        },
        {
          id = 30,
          image = "proto/shot1.png",
          width = 40,
          height = 40
        },
        {
          id = 31,
          image = "proto/shot2.png",
          width = 40,
          height = 40
        },
        {
          id = 32,
          image = "proto/spawner.png",
          width = 40,
          height = 40
        },
        {
          id = 33,
          image = "proto/weapon.png",
          width = 40,
          height = 40
        }
      }
    }
  },
  layers = {
    {
      type = "objectgroup",
      name = "content",
      visible = true,
      opacity = 1,
      offsetx = -4,
      offsety = 0,
      draworder = "topdown",
      properties = {},
      objects = {
        {
          id = 622,
          name = "",
          type = "",
          shape = "rectangle",
          x = 192,
          y = 288,
          width = 40,
          height = 40,
          rotation = 0,
          gid = 4,
          visible = true,
          properties = {}
        },
        {
          id = 623,
          name = "",
          type = "",
          shape = "rectangle",
          x = 320,
          y = 288,
          width = 40,
          height = 40,
          rotation = 0,
          gid = 5,
          visible = true,
          properties = {}
        },
        {
          id = 625,
          name = "",
          type = "",
          shape = "rectangle",
          x = 448,
          y = 288,
          width = 40,
          height = 40,
          rotation = 0,
          gid = 6,
          visible = true,
          properties = {}
        },
        {
          id = 626,
          name = "",
          type = "",
          shape = "rectangle",
          x = 576,
          y = 288,
          width = 40,
          height = 40,
          rotation = 0,
          gid = 7,
          visible = true,
          properties = {}
        },
        {
          id = 627,
          name = "",
          type = "",
          shape = "rectangle",
          x = 704,
          y = 288,
          width = 40,
          height = 40,
          rotation = 0,
          gid = 8,
          visible = true,
          properties = {}
        },
        {
          id = 628,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 21,
          visible = true,
          properties = {}
        },
        {
          id = 629,
          name = "",
          type = "",
          shape = "rectangle",
          x = 0,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 22,
          visible = true,
          properties = {}
        },
        {
          id = 630,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 640,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 23,
          visible = true,
          properties = {}
        },
        {
          id = 631,
          name = "",
          type = "",
          shape = "rectangle",
          x = 928,
          y = 32,
          width = 32,
          height = 32,
          rotation = 0,
          gid = 3,
          visible = true,
          properties = {}
        }
      }
    }
  }
}
