require "ssk2.loadSSK"
_G.ssk.init( )

local tiled = require "com.ponywolf.ponytiled"
local physics = require "physics"
physics.start()

local function doLevel1()
	local level1 	= require "level1"

	-- You've got SSK.... use it for debugging
	table.dump(level1)

	local map = tiled.new( level1 )
end

local function doLevel2()
	local level2 	= require "level2"

	-- You've got SSK.... use it for debugging
	table.dump(level2)

	local map = tiled.new( level2 )
end



doLevel2()
doLevel1()