require "ssk2.loadSSK"
_G.ssk.init( )

local tiled = ssk.tiled

--
-- Configure Physics
--
local physics = require "physics"
physics.start()
physics.setDrawMode("hybrid")	

--
-- Create Layers
--
local layers = ssk.display.quickLayers( nil, 
	"underlay", 
	"world", 
		{ "content", "player" },
	"overlay",
	"interfaces" )

local level1 = tiled.new()
level1.setLevelsPath( "levels" )
level1.load( "level1", {} )
table.dump(level1)

local level2 = tiled.new()
level2.setLevelsPath( "levels" )
level2.load( "level2", {} )
table.dump(level2)

level2.draw( layers.underlay )

level1.draw( layers.content )

