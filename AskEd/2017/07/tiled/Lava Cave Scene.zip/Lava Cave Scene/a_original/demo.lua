return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "1.0.1",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 58,
  height = 12,
  tilewidth = 32,
  tileheight = 32,
  nextobjectid = 28,
  properties = {},
  tilesets = {
    {
      name = "Lava Cave",
      firstgid = 1,
      tilewidth = 64,
      tileheight = 59,
      spacing = 0,
      margin = 0,
      tileoffset = {
        x = 0,
        y = 0
      },
      grid = {
        orientation = "orthogonal",
        width = 1,
        height = 1
      },
      properties = {},
      terrains = {},
      tilecount = 129,
      tiles = {
        {
          id = 0,
          image = "lavacavestuff/tile1.png",
          width = 29,
          height = 32
        },
        {
          id = 1,
          image = "lavacavestuff/tile2.png",
          width = 30,
          height = 40
        },
        {
          id = 2,
          image = "lavacavestuff/tile3.png",
          width = 30,
          height = 40
        },
        {
          id = 4,
          image = "lavacavestuff/tile5.png",
          width = 11,
          height = 11
        },
        {
          id = 5,
          image = "lavacavestuff/tile6.png",
          width = 11,
          height = 11
        },
        {
          id = 6,
          image = "lavacavestuff/tile7.png",
          width = 11,
          height = 11
        },
        {
          id = 7,
          image = "lavacavestuff/tile8.png",
          width = 11,
          height = 11
        },
        {
          id = 8,
          image = "lavacavestuff/tile9.png",
          width = 29,
          height = 32
        },
        {
          id = 9,
          image = "lavacavestuff/tile10.png",
          width = 29,
          height = 32
        },
        {
          id = 10,
          image = "lavacavestuff/tile11.png",
          width = 29,
          height = 32
        },
        {
          id = 11,
          image = "lavacavestuff/tile12.png",
          width = 29,
          height = 32
        },
        {
          id = 12,
          image = "lavacavestuff/tile13.png",
          width = 37,
          height = 37
        },
        {
          id = 13,
          image = "lavacavestuff/tile14.png",
          width = 32,
          height = 32
        },
        {
          id = 14,
          image = "lavacavestuff/tile15.png",
          width = 32,
          height = 32
        },
        {
          id = 15,
          image = "lavacavestuff/tile16.png",
          width = 32,
          height = 32
        },
        {
          id = 16,
          image = "lavacavestuff/tile17.png",
          width = 16,
          height = 14
        },
        {
          id = 17,
          image = "lavacavestuff/tile18.png",
          width = 16,
          height = 14
        },
        {
          id = 18,
          image = "lavacavestuff/tile19.png",
          width = 16,
          height = 14
        },
        {
          id = 19,
          image = "lavacavestuff/tile20.png",
          width = 48,
          height = 55
        },
        {
          id = 20,
          image = "lavacavestuff/tile21.png",
          width = 64,
          height = 55
        },
        {
          id = 21,
          image = "lavacavestuff/tile22.png",
          width = 26,
          height = 14
        },
        {
          id = 22,
          image = "lavacavestuff/tile23.png",
          width = 28,
          height = 27
        },
        {
          id = 23,
          image = "lavacavestuff/tile24.png",
          width = 28,
          height = 27
        },
        {
          id = 24,
          image = "lavacavestuff/tile25.png",
          width = 28,
          height = 27
        },
        {
          id = 25,
          image = "lavacavestuff/tile26.png",
          width = 28,
          height = 27
        },
        {
          id = 26,
          image = "lavacavestuff/tile27.png",
          width = 28,
          height = 27
        },
        {
          id = 27,
          image = "lavacavestuff/tile28.png",
          width = 28,
          height = 27
        },
        {
          id = 28,
          image = "lavacavestuff/tile29.png",
          width = 28,
          height = 27
        },
        {
          id = 29,
          image = "lavacavestuff/tile30.png",
          width = 28,
          height = 27
        },
        {
          id = 30,
          image = "lavacavestuff/tile31.png",
          width = 28,
          height = 27
        },
        {
          id = 31,
          image = "lavacavestuff/tile32.png",
          width = 28,
          height = 27
        },
        {
          id = 32,
          image = "lavacavestuff/tile33.png",
          width = 11,
          height = 14
        },
        {
          id = 33,
          image = "lavacavestuff/tile34.png",
          width = 11,
          height = 14
        },
        {
          id = 34,
          image = "lavacavestuff/tile35.png",
          width = 11,
          height = 14
        },
        {
          id = 35,
          image = "lavacavestuff/tile36.png",
          width = 11,
          height = 14
        },
        {
          id = 36,
          image = "lavacavestuff/tile37.png",
          width = 11,
          height = 14
        },
        {
          id = 37,
          image = "lavacavestuff/tile38.png",
          width = 32,
          height = 32
        },
        {
          id = 38,
          image = "lavacavestuff/tile39.png",
          width = 32,
          height = 32
        },
        {
          id = 39,
          image = "lavacavestuff/tile40.png",
          width = 32,
          height = 32
        },
        {
          id = 40,
          image = "lavacavestuff/tile41.png",
          width = 61,
          height = 37
        },
        {
          id = 41,
          image = "lavacavestuff/tile42.png",
          width = 61,
          height = 59
        },
        {
          id = 42,
          image = "lavacavestuff/tile43.png",
          width = 32,
          height = 32
        },
        {
          id = 43,
          image = "lavacavestuff/tile44.png",
          width = 32,
          height = 32
        },
        {
          id = 44,
          image = "lavacavestuff/tile45.png",
          width = 32,
          height = 32
        },
        {
          id = 45,
          image = "lavacavestuff/tile46.png",
          width = 32,
          height = 32
        },
        {
          id = 46,
          image = "lavacavestuff/tile47.png",
          width = 32,
          height = 32
        },
        {
          id = 47,
          image = "lavacavestuff/tile48.png",
          width = 32,
          height = 32
        },
        {
          id = 48,
          image = "lavacavestuff/tile49.png",
          width = 32,
          height = 32
        },
        {
          id = 49,
          image = "lavacavestuff/tile50.png",
          width = 32,
          height = 32
        },
        {
          id = 50,
          image = "lavacavestuff/tile51.png",
          width = 24,
          height = 22
        },
        {
          id = 51,
          image = "lavacavestuff/tile52.png",
          width = 26,
          height = 28
        },
        {
          id = 52,
          image = "lavacavestuff/tile53.png",
          width = 25,
          height = 28
        },
        {
          id = 53,
          image = "lavacavestuff/tile54.png",
          width = 24,
          height = 28
        },
        {
          id = 54,
          image = "lavacavestuff/tile55.png",
          width = 32,
          height = 32
        },
        {
          id = 55,
          image = "lavacavestuff/tile56.png",
          width = 32,
          height = 32
        },
        {
          id = 56,
          image = "lavacavestuff/tile57.png",
          width = 32,
          height = 32
        },
        {
          id = 57,
          image = "lavacavestuff/tile58.png",
          width = 32,
          height = 32
        },
        {
          id = 58,
          image = "lavacavestuff/tile59.png",
          width = 32,
          height = 32
        },
        {
          id = 59,
          image = "lavacavestuff/tile60.png",
          width = 32,
          height = 32
        },
        {
          id = 60,
          image = "lavacavestuff/tile61.png",
          width = 32,
          height = 32
        },
        {
          id = 61,
          image = "lavacavestuff/tile62.png",
          width = 32,
          height = 32
        },
        {
          id = 62,
          image = "lavacavestuff/tile63.png",
          width = 32,
          height = 32
        },
        {
          id = 63,
          image = "lavacavestuff/tile64.png",
          width = 32,
          height = 32
        },
        {
          id = 64,
          image = "lavacavestuff/tile65.png",
          width = 32,
          height = 32
        },
        {
          id = 65,
          image = "lavacavestuff/tile66.png",
          width = 32,
          height = 32
        },
        {
          id = 66,
          image = "lavacavestuff/tile67.png",
          width = 32,
          height = 32
        },
        {
          id = 67,
          image = "lavacavestuff/tile68.png",
          width = 32,
          height = 32
        },
        {
          id = 68,
          image = "lavacavestuff/tile69.png",
          width = 32,
          height = 32
        },
        {
          id = 69,
          image = "lavacavestuff/tile70.png",
          width = 32,
          height = 32
        },
        {
          id = 70,
          image = "lavacavestuff/tile71.png",
          width = 32,
          height = 32
        },
        {
          id = 71,
          image = "lavacavestuff/tile72.png",
          width = 32,
          height = 32
        },
        {
          id = 72,
          image = "lavacavestuff/tile73.png",
          width = 32,
          height = 32
        },
        {
          id = 73,
          image = "lavacavestuff/tile74.png",
          width = 32,
          height = 32
        },
        {
          id = 74,
          image = "lavacavestuff/tile75.png",
          width = 32,
          height = 32
        },
        {
          id = 75,
          image = "lavacavestuff/tile76.png",
          width = 32,
          height = 32
        },
        {
          id = 76,
          image = "lavacavestuff/tile77.png",
          width = 32,
          height = 32
        },
        {
          id = 77,
          image = "lavacavestuff/tile78.png",
          width = 32,
          height = 32
        },
        {
          id = 78,
          image = "lavacavestuff/tile79.png",
          width = 32,
          height = 32
        },
        {
          id = 79,
          image = "lavacavestuff/tile80.png",
          width = 32,
          height = 32
        },
        {
          id = 80,
          image = "lavacavestuff/tile81.png",
          width = 32,
          height = 32
        },
        {
          id = 81,
          image = "lavacavestuff/tile82.png",
          width = 32,
          height = 32
        },
        {
          id = 82,
          image = "lavacavestuff/tile83.png",
          width = 32,
          height = 32
        },
        {
          id = 83,
          image = "lavacavestuff/tile84.png",
          width = 32,
          height = 32
        },
        {
          id = 84,
          image = "lavacavestuff/tile85.png",
          width = 32,
          height = 32
        },
        {
          id = 85,
          image = "lavacavestuff/tile86.png",
          width = 32,
          height = 32
        },
        {
          id = 86,
          image = "lavacavestuff/tile87.png",
          width = 32,
          height = 32
        },
        {
          id = 87,
          image = "lavacavestuff/tile88.png",
          width = 32,
          height = 32
        },
        {
          id = 88,
          image = "lavacavestuff/tile89.png",
          width = 32,
          height = 32
        },
        {
          id = 89,
          image = "lavacavestuff/tile90.png",
          width = 32,
          height = 32
        },
        {
          id = 90,
          image = "lavacavestuff/tile91.png",
          width = 32,
          height = 32
        },
        {
          id = 91,
          image = "lavacavestuff/tile92.png",
          width = 32,
          height = 32
        },
        {
          id = 92,
          image = "lavacavestuff/tile93.png",
          width = 32,
          height = 32
        },
        {
          id = 93,
          image = "lavacavestuff/tile94.png",
          width = 32,
          height = 32
        },
        {
          id = 94,
          image = "lavacavestuff/tile95.png",
          width = 32,
          height = 32
        },
        {
          id = 95,
          image = "lavacavestuff/tile96.png",
          width = 32,
          height = 32
        },
        {
          id = 96,
          image = "lavacavestuff/tile97.png",
          width = 32,
          height = 32
        },
        {
          id = 97,
          image = "lavacavestuff/tile98.png",
          width = 32,
          height = 32
        },
        {
          id = 98,
          image = "lavacavestuff/tile99.png",
          width = 32,
          height = 32
        },
        {
          id = 99,
          image = "lavacavestuff/tile100.png",
          width = 32,
          height = 32
        },
        {
          id = 100,
          image = "lavacavestuff/tile101.png",
          width = 32,
          height = 32
        },
        {
          id = 101,
          image = "lavacavestuff/tile102.png",
          width = 32,
          height = 32
        },
        {
          id = 102,
          image = "lavacavestuff/tile103.png",
          width = 32,
          height = 32
        },
        {
          id = 103,
          image = "lavacavestuff/tile104.png",
          width = 32,
          height = 32
        },
        {
          id = 104,
          image = "lavacavestuff/tile105.png",
          width = 32,
          height = 32
        },
        {
          id = 105,
          image = "lavacavestuff/tile106.png",
          width = 32,
          height = 32
        },
        {
          id = 106,
          image = "lavacavestuff/tile107.png",
          width = 32,
          height = 32
        },
        {
          id = 107,
          image = "lavacavestuff/tile108.png",
          width = 32,
          height = 32
        },
        {
          id = 108,
          image = "lavacavestuff/tile109.png",
          width = 32,
          height = 32
        },
        {
          id = 109,
          image = "lavacavestuff/tile110.png",
          width = 32,
          height = 32
        },
        {
          id = 110,
          image = "lavacavestuff/tile111.png",
          width = 32,
          height = 32
        },
        {
          id = 111,
          image = "lavacavestuff/tile112.png",
          width = 32,
          height = 32
        },
        {
          id = 112,
          image = "lavacavestuff/tile113.png",
          width = 32,
          height = 32
        },
        {
          id = 113,
          image = "lavacavestuff/tile114.png",
          width = 32,
          height = 32
        },
        {
          id = 114,
          image = "lavacavestuff/tile115.png",
          width = 32,
          height = 32
        },
        {
          id = 115,
          image = "lavacavestuff/tile116.png",
          width = 32,
          height = 32
        },
        {
          id = 116,
          image = "lavacavestuff/tile117.png",
          width = 32,
          height = 32
        },
        {
          id = 117,
          image = "lavacavestuff/tile118.png",
          width = 32,
          height = 32
        },
        {
          id = 118,
          image = "lavacavestuff/tile119.png",
          width = 32,
          height = 32
        },
        {
          id = 119,
          image = "lavacavestuff/tile120.png",
          width = 32,
          height = 32
        },
        {
          id = 120,
          image = "lavacavestuff/tile121.png",
          width = 32,
          height = 32
        },
        {
          id = 121,
          image = "lavacavestuff/tile122.png",
          width = 32,
          height = 32
        },
        {
          id = 122,
          image = "lavacavestuff/tile123.png",
          width = 32,
          height = 32
        },
        {
          id = 123,
          image = "lavacavestuff/tile124.png",
          width = 32,
          height = 32
        },
        {
          id = 124,
          image = "lavacavestuff/tile125.png",
          width = 46,
          height = 30
        },
        {
          id = 125,
          image = "lavacavestuff/tile126.png",
          width = 46,
          height = 30
        },
        {
          id = 126,
          image = "lavacavestuff/tile127.png",
          width = 46,
          height = 30
        },
        {
          id = 127,
          image = "lavacavestuff/tile128.png",
          width = 46,
          height = 30
        },
        {
          id = 128,
          image = "lavacavestuff/tile129.png",
          width = 23,
          height = 37
        },
        {
          id = 129,
          image = "lavacavestuff/tile130.png",
          width = 32,
          height = 25
        }
      }
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "non-interactable",
      x = 0,
      y = 0,
      width = 58,
      height = 12,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "imagelayer",
      name = "background",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      image = "lavacavestuff/tile4.png",
      properties = {}
    },
    {
      type = "imagelayer",
      name = "background2",
      visible = true,
      opacity = 1,
      offsetx = 624,
      offsety = 0,
      image = "lavacavestuff/tile4.png",
      properties = {}
    }
  }
}
