-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local tiled = require "com.ponywolf.ponytiled"
local mapData = require "demo"
local physics = require "physics"

physics.start()

local map = tiled.new(mapData, "lavacavestuff")
map.x, map.y = map.x - map.designedWidth / 2, map.y - map.designedHeight / 2

if map then
   print(map.x, map.y)
end

--map:extend("dragable")
