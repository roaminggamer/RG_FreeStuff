![logo](logo.png)

# Coronium SkyTable Client for Corona

___A performant and secure user scoped table datastore and client for use with [Corona](https://coronalabs.com/).___

__Status:__ _Beta_

## Documentation

[https://develephant.github.io/coronium-skytable-docs](https://develephant.github.io/coronium-skytable-docs)