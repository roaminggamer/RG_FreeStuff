io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =====================================================
-- =====================================================
-- == Uncomment following lines if you need  physics
--local physics = require "physics"
--physics.start()
--physics.setGravity(0,10)
--physics.setDrawMode("hybrid")

-- == Uncomment following line if you need widget library
--local widget = require "widget"

-- =====================================================
-- YOUR CODE BELOW
-- =====================================================

-- 
-- REMEMBER: IN YOUR POST, TELL US:
-- > Corona Version You Are Using. Ex: 2018.2338
-- > OS You are building on: OS X 10.?? or Windows (7/8/10)
-- > Target Device(s) You Are Testing On 
-- > Target OS Version

-- PUT YOUR SHORT SAMPLE DEMONSTRATING THE PROBLEM HERE

-- =====================================================
-- YOUR CODE ABOVE
-- =====================================================


