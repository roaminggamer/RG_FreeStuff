application = 
{
	content = 
	{ 
        graphicsCompatibility = 1,  -- Turn on V1 Compatibility Mode
		width = 320,		-- 768,
		height = 480,		--1024, 
		scale = "letterBox",
		fps = 30,
	}
}