OUYA Dumper
============
This tool is designed to dump OUYA input events to the screen.

1. Build the app for Android.
2. Side load it onto your OUYA (http://docs.coronalabs.com/guide/distribution/androidBuild/index.html#device-installation)
3. Run the app.
4. Press buttons and move joysticks on the controller.
5. Write down the info that is displayed on the screen.
   Pay particular attention to these details:

name - Name of event.
keyName - Name of input key/joystick
phase - Phase(s) the input passes through.

There are more details, but they are not universal to the inputs.




