-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
-- LOAD & INITIALIZE - SSK 2
-- =============================================================
require "ssk2.loadSSK"
_G.ssk.init( { launchArgs 				= ..., 
	            enableAutoListeners 	= true,
	            exportCore 				= true,
	            exportColors 			= true,
	            exportSystem 			= true,
	            measure					= false,
	            useExternal				= true,
	            gameFont 				= native.systemFont,
	            debugLevel 				= 0 } )


-- =============================================================
-- ISSUE CODE BELOW -- ISSUE CODE BELOW -- ISSUE CODE BELOW --
-- =============================================================
local function listener(event)
	table.print_r( event )
end

local request = { timeout = 30, headers = { Authorization = "Basic fakeToken"} }

table.dump(request)

local urlString = 'https://www.fanpoweredmusic.net/api/public/v1/token'

network.request( urlString, "POST", listener, request )

