---------------------------------------------------------------------------------
--
-- scene_MainMenu.lua
--
---------------------------------------------------------------------------------
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local backImage 

-- Callbacks/Functions
local onBack

----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:enterScene( event )   - Called immediately after scene has moved onscreen
-- scene:exitScene( event )    - Called when scene is about to move offscreen
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------
function scene:createScene( event )
	local screenGroup = self.view

	backImage = helpers.addTray(screenGroup, "creditsBack" ) 
	--
	-- Menu Buttons
	--
	local tmpButton
	local buttonWidth    = 270
	local buttonHeight   = 40
	local buttonTopRowY  = 120
	local buttonX        = 160
	local buttonTweenX   = 0
	local buttonTweenY   = 48

	local tmpParams = 
	{ 
		w = buttonWidth,
		h = buttonHeight,
		x = buttonX,
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		buttonType = "push",
		textSize = 32,
		textColor = { 255, 255, 255, 255 },
		textFont = nil,
		textOffset = {0,0},
		pressSound = buttonSound,
		scaleFonts = true
	}

	-- Quit Button
	tmpParams.text      = "Main Menu"
	tmpParams.onRelease = onBack 
	tmpParams.y         = buttonTopRowY + 7 * buttonTweenY
	tmpButton           = buttons:new( tmpParams )
	screenGroup:insert(tmpButton)

	tmpButton = nil

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:enterScene( event )
	local screenGroup = self.view

	storyboard.removeAll() --EFM

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:exitScene( event )
	local screenGroup = self.view	
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:destroyScene( event )
	local screenGroup = self.view
end

----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------

onBack = function ( event )
	storyboard.gotoScene( "scene_MainMenu", "slideLeft", 500  )
	return true
end


---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
---------------------------------------------------------------------------------

return scene

 
