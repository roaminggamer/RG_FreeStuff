-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- =============================================================
-- Extentions To Help Run Old v1 Graphics Code Using v2 Features
-- =============================================================
local type = type

local display_newText = display.newText
function display.newText( ... )
	local obj = display_newText( unpack( arg ) )
	function obj.setTextColor( self, r, g, b, a )
		r = (r or 255)/255
		g = (g or 255)/255
		b = (b or 255)/255
		a = (a or 255)/255
		--
		self:setFillColor(r,g,b,a)
	end

	function obj.setReferencePoint( self, a )
		local toA = {}
		toA[display.CenterReferencePoint] 			= { 0.5, 0.5 }
		toA[display.TopLeftReferencePoint] 			= { 0, 0 }
		toA[display.TopCenterReferencePoint] 		= { 0.5, 0 }
		toA[display.TopRightReferencePoint] 		= { 1, 0 }
		toA[display.CenterRightReferencePoint] 	= { 1, 0.5 }
		toA[display.BottomRightReferencePoint] 	= { 1, 1 }
		toA[display.BottomCenterReferencePoint] 	= { 0.5, 1}
		toA[display.BottomLeftReferencePoint] 		= { 0, 1 }
		toA[display.CenterLeftReferencePoint] 		= { 1, 0.5 }
		self.anchorX = toA[a][1]
		self.anchorY = toA[a][2]
	end

	return obj
end


