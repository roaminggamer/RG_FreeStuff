--[[
This is a simple example of setting up a sprite and playing various sequences.

You will also see how to do this when moving your sprite with arrow keys, although it
could just as easily be applied to tilt functions.

You don't have permission to reuse any of my assets, so please don't :)

You are free to redistribute this tutorial file provided it has not been changed in anyway, you
leave this text in place in it's entirity and you provide me with a backlink and credit.

Enjoy!

Peach Pellen
http://techority.com
--]]

display.setStatusBar (display.HiddenStatusBar)
--> Hides the status bar

----------------------------------------------------------------------
--								BASICS								--
----------------------------------------------------------------------
require "sprite"
-- Very important!

local background = display.newImage ("background.png")
-- Sets the background

----------------------------------------------------------------------
--								SPRITE								--
----------------------------------------------------------------------
local herosheet = sprite.newSpriteSheet("person.png", 32, 36)
-- Our sprite sheet
-- 32 is the width of each "box", this is the image width divided by the number of images across
-- 36 is the height of each "box", this is the image height divided by the number of images down
	
	local heroset = sprite.newSpriteSet (herosheet, 1, 12)
	sprite.add (heroset, "heroleft", 10, 3, 300, 0)
	sprite.add (heroset, "heroright", 4, 3, 300, 0)
	sprite.add (heroset, "heroup", 1, 3, 300, 0)
	sprite.add (heroset, "herodown", 7, 3, 300, 0)
-- The sprite set uses images 1 to 12 (all of them)
-- "heroup" starts at image 1 and includes 3 frames. (In this case 1, 2, 3.)
-- The "300" indicates .3 seconds per frame, the "0" indicates it will repeat until we stop it.
	
	local hero = sprite.newSprite (heroset)	
	hero.x = 160
	hero.y = 200
-- We insert out hero sprite
	
	hero:prepare("herodown")
-- We prepare the sprite	
	
	
----------------------------------------------------------------------
--								ARROWS								--
----------------------------------------------------------------------	
up = display.newImage ("up.png")
up.x = 250
up.y = 380
---
down = display.newImage ("down.png")
down.x = 250
down.y = 440
---
left = display.newImage ("left.png")
left.x = 210
left.y = 410
---
right = display.newImage ("right.png")
right.x = 290
right.y = 410
-- The arrow images to move our sprite

----------------------------------------------------------------------
--								MOVEMENT							--
----------------------------------------------------------------------
local motionx = 0 
local motiony = 0 
local speed = 4
-- These are required below; change the speed if you wish to experiment but not motionx or motiony.

local function stop (event)
	if event.phase =="ended" then
		motionx = 0
		motiony = 0
		hero:pause()
	end
end
Runtime:addEventListener("touch", stop )
-- Here we state that we don't want the sprite animated or moving if we aren't pressing an arrow

local function movehero (event)
hero.x = hero.x + motionx
hero.y = hero.y + motiony
end
timer1 = timer.performWithDelay(1,movehero,0)
-- The function to move the hero; it's on a timer but you could also use a Runtime listener


function touchup (event)
motionx = 0
motiony = -speed
hero:prepare("heroup")
hero:play("heroup")
end
up:addEventListener("touch", touchup)
-- When the up arrow is touched, play hero up and move the hero upwards

function touchdown (event)
motionx = 0
motiony = speed
hero:prepare("herodown")
hero:play("herodown")
end
down:addEventListener("touch", touchdown)
-- When the down arrow is touched, play hero down and move the hero downwards

function touchleft (event)
motionx = -speed
motiony = 0
hero:prepare("heroleft")
hero:play("heroleft")
end
left:addEventListener("touch", touchleft)
-- When the left arrow is touched, play hero left and move the hero left

function touchright (event)
motionx = speed
motiony = 0
hero:prepare("heroright")
hero:play("heroright")
end
right:addEventListener("touch", touchright)
-- When the right arrow is touched, play hero right and move the hero right