-- tokens.lua (currently includes Button class with labels, font selection and optional event model)
-- Version 1.1
module(..., package.seeall)

function tokenize( aString )
	local toks = {}
	for aTok in aString:gmatch("%S+") do
		toks[#toks+1] = aTok
	end
	return toks
end


function detokenize( toks )
	local aString = ""
	for i=1, #toks do
		if(i == 1) then
			aString = toks[i]
		else
			aString = aString .. " " .. toks[i]
		end
	end
	return aString
end
