io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
require "compatabilityExtentions"
require "ssk2.loadSSK"
_G.ssk.init( )
-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------
print("\n\n\n*********************** $$$$$$$$$$$$$$$$$$$$ **********************\n\n")
--display.setStatusBar(display.HiddenStatusBar)

----------------------------------------------------------------------
--								GLOBALS								--
----------------------------------------------------------------------
--w = display.viewableContentWidth
--h = display.viewableContentHeight
w = display.contentWidth
h = display.contentHeight

scaleX = display.contentScaleX
scaleY = display.contentScaleY
deviceW = math.ceil(w/scaleX)
deviceH = math.ceil(h/scaleY)
centerX = w/2
centerY = h/2

print("display.viewableContentWidth  = " .. display.viewableContentWidth)
print("display.viewableContentHeight = " .. display.viewableContentHeight)
print("         display.contentWidth = " .. display.contentWidth)
print("        display.contentHeight = " .. display.contentHeight)
print("        display.contentScaleX = " .. scaleX)
print("        display.contentScaleY = " .. scaleY)
print("                            w = " .. w)
print("                            h = " .. h)
print("                      deviceW = " .. deviceW)
print("                      deviceH = " .. deviceH)
print("                      centerX = " .. centerX)
print("                      centerY = " .. centerY)

musicDir = "sound/"
imagesDir = "images/"

playerScores = {}

currentWord = "TESTING"
guessedWords = {}
guessedTiles = {}

renamingPlayer = false

--dummyObject = display.new

----------------------------------------------------------------------
--								REQUIRES							--
----------------------------------------------------------------------
local storyboard = require "storyboard"

sprite = require("sprite")

-- Classes
labels = require( "class_Labels" )
buttons = require( "class_Buttons" )

-- Utilities
--rgdb = require( "rg_DB" )
_G.rgdb 		= require "dbmgr2"
tokens = require("rg_Tokens")

helpers = require( "rg_helpers" )

rgdr = require("rg_targetResolution")

levelLoader = require("rg_48level")

interactions = require("rg_interactions") 

----------------------------------------------------------------------
--								INITIALIZATION						--
----------------------------------------------------------------------
rgdr.setDesignDevice( "iPod" )

helpers.createSpriteSet( "spriteSet1", imagesDir .. "mapTiles.png" , 70, 70, 48 )
helpers.createSpriteSet( "playerSet", imagesDir .. "pellen.png" , 30, 30, 4 )

--rgdb.initDB()
rgdb.initDB( "data/enable1.tbl" )


buttonSound = audio.loadSound("buttonClick.wav")
diceRollSound = audio.loadSound("diceRoll.wav")

musicSnippets = {}
musicSnippetsToPlay = {1,2,3}
currentSong = 1
musicScore = 0

currentWordGuesses = 0	
wordsScore = 0

currentRoll = 0
diceScore = 0

local feedbackSounds = {}
feedbackSounds[1] =  audio.loadSound("good1.wav")
feedbackSounds[2] =  audio.loadSound("good2.wav")
feedbackSounds[3] =  audio.loadSound("good3.wav")
feedbackSounds[4] =  audio.loadSound("bad1.wav")
feedbackSounds[5] =  audio.loadSound("bad2.wav")
feedbackSounds[6] =  audio.loadSound("bad3.wav")

function delayedFeedback( isGood )
	if(isGood == true ) then
		audio.play(feedbackSounds[math.random(1,3)])
	else
		audio.play(feedbackSounds[math.random(4,6)])
	end
	return true
end

function giveFeedback( isGood, withDelay )
	if( withDelay == true ) then
		local myclosure = function() return delayedFeedback( isGood ) end
		timer.performWithDelay(1200, myclosure)
	else
		delayedFeedback( isGood )
	end 
	return true
end



function randomizeSongs()
	musicScore = 0
	local tmpSongsToPlay = {}
	musicSnippetsToPlay = {}
	
	while #tmpSongsToPlay < 3 do
		local songNum = math.random(1,8)
		tmpSongsToPlay[songNum] = songNum
	end
	
	for k,v in pairs(tmpSongsToPlay) do 
		table.insert( musicSnippetsToPlay, v )
	end

	print("Playing songs: " .. musicSnippetsToPlay[1] .. " " ..
	       musicSnippetsToPlay[2] .. " " ..
	       musicSnippetsToPlay[3] )

	currentSong = 1
end
randomizeSongs()

musicSnippets[1] = { "love", "The Beatles", "Can't Buy Me Love", "s1.wav" }
musicSnippets[2] = { "love", "The Bee Gees", "How Deep Is Your Love", "s2.wav" }
musicSnippets[3] = { "love", "Dixie Cups", "Chapel Of Love", "s3.wav" }
musicSnippets[4] = { "love", "Whitney Houston", "I will always love you", "s4.wav" }
musicSnippets[5] = { "shoes", "Adam & The Ants", "Goody Two Shoes", "s5.wav" }
musicSnippets[6] = { "shoes", "Black Sabbath", "Fairies Wear Boots", "s6.wav" }
musicSnippets[7] = { "shoes", "Elvis Presley", "Blue Suede Shoes", "s7.wav" }
musicSnippets[8] = { "shoes", "Paul Simon", "Diamons On The Soles Of Here Shoes", "s8.wav" }

----------------------------------------------------------------------
--								LOAD FIRST SCENE					--
----------------------------------------------------------------------
storyboard.gotoScene( "scene_MainMenu" )
--storyboard.gotoScene( "scene_LocalMP" )
--storyboard.gotoScene( "scene_PlayGui" )


