-- rg_interactions.lua 
-- Generated via Torque 2D editor mockup


module(..., package.seeall)



function handleInteractionNum( iNum, screenGroup )
	print("Handling interaction number: " .. iNum )

	--
	-- Game Intro
	--
	if(iNum == 1) then
	--if(iNum == 0) then
		screenGroup.introInterface.isVisible = true
	

	--
	-- Music Game
	--
	elseif(iNum == 2) then
		randomizeSongs()
		screenGroup.musicPlay.scoreText.text = "Score: " .. musicScore 
		screenGroup.musicPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

		screenGroup.musicPlay.guessesText.text = "Song: " .. currentSong .. " of 3"
		screenGroup.musicPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)

		screenGroup.musicHelp.isVisible = true

	--
	-- Words Game
	--
	elseif(iNum == 5) then
	--elseif(iNum == 1) then
		wordsScore = 0
		currentWordGuesses = 0
		screenGroup.wordsPlay.scoreText.text = "Score: " .. wordsScore 
		screenGroup.wordsPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

		screenGroup.wordsPlay.guessesText.text = "Guesses: " .. currentWordGuesses .. " of 15"
		screenGroup.wordsPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)
		
		screenGroup.wordsPlay.currentWord.text = ""
		screenGroup.wordsPlay.currentWord.x = 0
		screenGroup.wordsPlay.currentWord:setReferencePoint(display.CenterReferencePoint)

		screenGroup.wordsHelp.isVisible = true

	--
	-- Dice Game
	--
	elseif(iNum == 9) then
	--elseif(iNum == 1) then
		currentRoll = 0
		diceScore = 0
		local currentDice = {1,2,3}
		helpers.changeSprite(screenGroup.dicePlay.die1, currentDice[1] + 32 )
		helpers.changeSprite(screenGroup.dicePlay.die2, currentDice[2] + 32 )
		helpers.changeSprite(screenGroup.dicePlay.die3, currentDice[3] + 32 )

		screenGroup.dicePlay.scoreText.text = "Score: " .. diceScore 
		screenGroup.dicePlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

		screenGroup.dicePlay.guessesText.text = "Roll: " .. currentRoll .. " of 5"
		screenGroup.dicePlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)

		screenGroup.diceHelp.isVisible = true

    -- Red Door
	elseif(iNum == 13) then
		print("at red door")
		if(screenGroup.redKey.isVisible == true) then
			screenGroup.redDoor.isVisible = false
			return true
		end
    -- Green Door
	elseif(iNum == 11) then
		print("at green door")
		if(screenGroup.greenKey.isVisible == true) then
			screenGroup.greenDoor.isVisible = false
			return true
		end
    -- Blue Door
	elseif(iNum == 14) then
		print("at blue door")
		if(screenGroup.blueKey.isVisible == true) then
			screenGroup.blueDoor.isVisible = false
			return true
		end


    -- Red Gem
	elseif(iNum == 12) then
		print("at red door")
		if(screenGroup.redKey.isVisible == true) then
			screenGroup.redGemObj.isVisible = false
			screenGroup.redGem.isVisible = true
			return true
		end
    -- Green Gem
	elseif(iNum == 8) then
		print("at green door")
		if(screenGroup.greenKey.isVisible == true) then
			screenGroup.greenGemObj.isVisible = false
			screenGroup.greenGem.isVisible = true
			return true
		end
    -- Blue Gem
	elseif(iNum == 15) then
		print("at blue door")
		if(screenGroup.blueKey.isVisible == true) then
			screenGroup.blueGemObj.isVisible = false
			screenGroup.blueGem.isVisible = true
			return true
		end

    -- End Game
	elseif(iNum == 16) then
		print("at end of game")
		if( screenGroup.redGem.isVisible == true and screenGroup.greenGem.isVisible == true and screenGroup.blueGem.isVisible == true ) then
			print("Win")
			screenGroup.outroInterface.isVisible = true
		else
			print("Fail")
			screenGroup.outroInterfaceFail.isVisible = true
		end
	end

	return false
end

