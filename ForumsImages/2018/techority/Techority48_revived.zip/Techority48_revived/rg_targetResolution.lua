-- rg_targetResolution.lua 
-- Version 1.1

module(..., package.seeall)

local designX = 600
local designY = 1024

curX = display.contentWidth
curY = display.contentHeight

ratioX = 1
ratioY = 1

function setDesignDevice( deviceName ) 
	if( deviceName == "Fire" ) then
		setDesignResolution(600,1024) 

	elseif( deviceName == "iPad" ) then
		setDesignResolution(768,1024) 

	elseif( deviceName == "iPhone" ) then
		setDesignResolution(320,480) 

	elseif( deviceName == "iPhone4" ) then
		setDesignResolution(640,960) 

	end
end


function setDesignResolution(x, y) 
	designX = x
	designY = y

	ratioX = math.ceil(100 * curX / designX) / 100
	ratioY = math.ceil(100 * curY / designY) / 100

	print( "setDesignResolution() -  Design Resolution: " .. designX .. "," .. designY )
	print( "setDesignResolution() - Current Resolution: " .. curX .. "," .. curY )
	print( "setDesignResolution() -  Resolution Ratios: " .. ratioX .. "," .. ratioY )
end

function getDesignResolution( ) 
	return designX, designY
end

function scaleX( inX )
	local outX = inX * ratioX
	print("scaleX() " .. inX .. " --> " .. outX )
	return outX
end

function scaleY( inY )
	local outY = inY * ratioY
	print("scaleY() " .. inY .. " --> " .. outY )
	return outY
end

function scaleFont( inFontSize )
	local outFontSize = inFontSize
	if(ratioX <= ratioY) then
		outFontSize = outFontSize * ratioX
	else
		outFontSize = outFontSize * ratioY
	end

	return outFontSize
end



