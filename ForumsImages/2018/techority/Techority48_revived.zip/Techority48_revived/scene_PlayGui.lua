---------------------------------------------------------------------------------
--
-- basicGame.lua
--
---------------------------------------------------------------------------------
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local mainOverlay

local thePlayer
local upArrow
local downArrow
local rightArrow
local leftArrow

local spritesLayer


-- Callbacks/Functions
local onSceneTouch
local gotoMainMenu
local onArrowPress

local buildMap
local placePlayer
local placeArrows

local placeIntro
local placeMusicGame
local placeWordsGame
local placeOtherGameHelp
local placeOtherGame
local placeOutro

local introRelease
local intro2Release

local musicHelpRelease
local musicDoneRelease

local wordsHelpRelease
local wordsDoneRelease
local onTileClick
local onWordSubmit

local diceHelpRelease
local diceDoneRelease
local onRollDie

local onPlaySnippet
local onIsLove
local onIsShoes


----------------------------------------------------------------------
--
-- Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:enterScene( event )   - Called immediately after scene has moved onscreen
-- scene:exitScene( event )    - Called when scene is about to move offscreen
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------
function scene:createScene( event )
	local screenGroup = self.view

	local waterBack = helpers.addTray( screenGroup, "waterBack" ) 
	waterBack:toBack()

	levelLoader.createTerrainBase()
	levelLoader.initLayers()

	buildMap( screenGroup )

	placePlayer( screenGroup )

	mainOverlay = helpers.addTray( screenGroup, "protoBack2" ) 
	mainOverlay:toFront()
	mainOverlay.touch = onSceneTouch
	screenGroup.mainOverlay = mainOverlay
	helpers.addQuitButton( gotoMainMenu, screenGroup )


	placeArrows( screenGroup )

	placeIntro( screenGroup )
	placeMusicGame( screenGroup )
	placeWordsGame( screenGroup )
	placeDiceGame( screenGroup )
	placeOutro( screenGroup )

	-- Place Keys and Gems
	local theSprite = helpers.placeSprite( "spriteSet1", 24, -150, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.redKey = theSprite
	screenGroup.redKey.isVisible = false
	theSprite = helpers.placeSprite( "spriteSet1", 23, -130, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.greenKey = theSprite	
	screenGroup.greenKey.isVisible = false
	theSprite = helpers.placeSprite( "spriteSet1", 22, -110, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.blueKey = theSprite	
	screenGroup.blueKey.isVisible = false

	local theSprite = helpers.placeSprite( "spriteSet1", 26, 150, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.redGem = theSprite
	screenGroup.redGem.isVisible = false
	theSprite = helpers.placeSprite( "spriteSet1", 27, 130, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.greenGem = theSprite	
	screenGroup.greenGem.isVisible = false
	theSprite = helpers.placeSprite( "spriteSet1", 25, 110, -210)
	theSprite:scale(0.25,0.25)
	mainOverlay:insert(theSprite)
	screenGroup.blueGem = theSprite	
	screenGroup.blueGem.isVisible = false


end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:enterScene( event )
	local screenGroup = self.view

	mainOverlay:addEventListener( "touch", mainOverlay )
	
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:exitScene()
	local screenGroup = self.view

	mainOverlay:removeEventListener( "touch", mainOverlay )
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:destroyScene( event )	
	--destroyBoard( screenGroup )	
end


----------------------------------------------------------------------
--				FUNCTION DEFINITIONS								--
----------------------------------------------------------------------
buildMap = function( screenGroup )

	spritesLayer = display.newGroup()
	spritesLayer:toFront()
	screenGroup:insert(spritesLayer)
	--spritesLayer:toBack()
	spritesLayer.x = 38 + 35 + 2.5 * 35
	spritesLayer.y = 92  + 1.5 * 35

	local terrainLayer            = levelLoader.terrainLayer
	local staticObjectsLayer      = levelLoader.staticObjectsLayer
	local interactiveObjectsLayer = levelLoader.interactiveObjectsLayer

	
	for i=1, #terrainLayer do
	--for i=1, 100 do
		local x = (((i-1) % 24) - 1) * 35
		local y = (math.floor( (i-1) / 24 ) - 1 ) * 35
		--print(y)
		local theSprite = helpers.placeSprite( "spriteSet1", terrainLayer[i], x, y)
		theSprite:scale(0.5,0.5)
		spritesLayer:insert(theSprite)
	end

	for k,v in pairs(staticObjectsLayer) do 
		local x = (((k-1) % 24) - 1) * 35
		local y = (math.floor( (k-1) / 24 ) - 1 ) * 35
		--print(y)
		local theSprite = helpers.placeSprite( "spriteSet1", v, x, y)
		--theSprite.alpha = 0.5
		theSprite:scale(0.5,0.5)
		spritesLayer:insert(theSprite)
	end


	for k,v in pairs(interactiveObjectsLayer) do 
		local x = (((k-1) % 24) - 1) * 35
		local y = (math.floor( (k-1) / 24 ) - 1 ) * 35
		--print(y)
		local theSprite = helpers.placeSprite( "spriteSet1", v, x, y)
		theSprite:scale(0.5,0.5)
		spritesLayer:insert(theSprite)
		if(v == 9) then
			print("Found red door")
			screenGroup.redDoor = theSprite
		elseif(v == 13) then
			print("Found green door")
			screenGroup.greenDoor = theSprite
		elseif(v == 17) then
			print("Found blue door")
			screenGroup.blueDoor = theSprite
		elseif(v == 26) then
			print("Found red gem")
			screenGroup.redGemObj = theSprite
		elseif(v == 27) then
			print("Found green gem")
			screenGroup.greenGemObj = theSprite
		elseif(v == 25) then
			print("Found blue gem")
			screenGroup.blueGemObj = theSprite
		end
	end

end

placePlayer = function( screenGroup )
	thePlayer = helpers.placeSprite( "playerSet", 1, 38 + 3.5*35, 57 + 3.5*35)
	helpers.changeSprite(thePlayer,2)
	screenGroup:insert(thePlayer)
	thePlayer.row = 3
	thePlayer.col = 2
	thePlayer.arrayOffset = (thePlayer.row - 1) * 24 + thePlayer.col
end


placeArrows = function( screenGroup )
	local arrowButtonParams =
	{
		unselImg = imagesDir .. "arrow_up.png",
		selImg = imagesDir .. "arrow_upPress.png",
		w = 45,
		h = 45,
		x = 250,
		y = 365,
		textSize = 30,
		onRelease = onArrowPress,
		text = ""
	}
	-- Up 1
	upArrow = buttons:new( arrowButtonParams )
	upArrow.dir = 1
	screenGroup:insert(upArrow)

	-- Down 2
	arrowButtonParams.unselImg = imagesDir .. "arrow_down.png"
	arrowButtonParams.selImg = imagesDir .. "arrow_downPress.png"
	arrowButtonParams.x = 250 
	arrowButtonParams.y = 365 + 70
	downArrow = buttons:new( arrowButtonParams )
	downArrow.dir = 2
	screenGroup:insert(downArrow)

	-- Left 3
	arrowButtonParams.unselImg = imagesDir .. "arrow_left.png"
	arrowButtonParams.selImg = imagesDir .. "arrow_leftPress.png"
	arrowButtonParams.x = 250 - 35 
	arrowButtonParams.y = 365 + 35
	leftArrow = buttons:new( arrowButtonParams )
	leftArrow.dir = 3
	screenGroup:insert(leftArrow)

	-- Right 4
	arrowButtonParams.unselImg = imagesDir .. "arrow_right.png"
	arrowButtonParams.selImg = imagesDir .. "arrow_rightPress.png"
	arrowButtonParams.x = 250 + 35 
	arrowButtonParams.y = 365 + 35
	rightArrow = buttons:new( arrowButtonParams )
	rightArrow.dir = 4
	screenGroup:insert(rightArrow)

end
----------------------------------------------------------------------
--				CALLBACK DEFINITIONS								--
----------------------------------------------------------------------
onArrowPress = function (event)
	if(event.phase ~= "ended" ) then return true end
	local target = event.target
	local screenGroup = target.parent

	local terrainLayer            = levelLoader.terrainLayer
	local staticObjectsLayer      = levelLoader.staticObjectsLayer
	local interactiveObjectsLayer = levelLoader.interactiveObjectsLayer
	local interactiveObjectsIndex = levelLoader.interactiveObjectsIndex

	local spritesLayerOffset = {0,0}
	
	--
	-- UP
	--
	if( target.dir == 1) then
	
		helpers.changeSprite( thePlayer, 1)

		if( thePlayer.row > 1 ) then
			local newOffset = thePlayer.arrayOffset - 24
			if( staticObjectsLayer[newOffset]  or interactiveObjectsLayer[newOffset]) then

				local canPass = false

				if(interactiveObjectsIndex[newOffset]) then
					canPass = interactions.handleInteractionNum(interactiveObjectsIndex[newOffset], screenGroup)
				end

				if( canPass ) then
					print("Move up " .. newOffset)
					thePlayer.row = thePlayer.row - 1
					thePlayer.arrayOffset = newOffset
					spritesLayerOffset[2] = 35
				else
					print("Can't move up, BLOCKED @ offset " .. newOffset)
				end
			else
				print("Move up " .. newOffset)
				thePlayer.row = thePlayer.row - 1
				thePlayer.arrayOffset = newOffset
				spritesLayerOffset[2] = 35
			end
		else
			print("Can't move up, @ row " .. thePlayer.row)
		end

	--
	-- DOWN
	--
	elseif( target.dir == 2) then
		helpers.changeSprite( thePlayer, 3)

		if( thePlayer.row < 24 ) then
			local newOffset = thePlayer.arrayOffset + 24
			if( staticObjectsLayer[newOffset]  or interactiveObjectsLayer[newOffset]) then

				local canPass = false
				if(interactiveObjectsIndex[newOffset]) then
					canPass = interactions.handleInteractionNum(interactiveObjectsIndex[newOffset], screenGroup)
				end

				if( canPass ) then
					print("Move down " .. newOffset)
					thePlayer.row = thePlayer.row + 1
					thePlayer.arrayOffset = newOffset
					spritesLayerOffset[2] = -35
				else
					print("Can't move down, BLOCKED @ offset " .. newOffset)
				end
			else
				print("Move down " .. newOffset)
				thePlayer.row = thePlayer.row + 1
				thePlayer.arrayOffset = newOffset
				spritesLayerOffset[2] = -35
			end
		else
			print("Can't move down, @ row " .. thePlayer.row)
		end

	--
	-- LEFT
	--
	elseif( target.dir == 3) then
		helpers.changeSprite( thePlayer, 4)

		if( thePlayer.col > 1 ) then
			local newOffset = thePlayer.arrayOffset - 1

			local canPass = false

			if( staticObjectsLayer[newOffset]  or interactiveObjectsLayer[newOffset]) then
				if(interactiveObjectsIndex[newOffset]) then
					canPass = interactions.handleInteractionNum(interactiveObjectsIndex[newOffset], screenGroup)
				end
				if( canPass ) then
					print("Move left " .. newOffset)
					thePlayer.col = thePlayer.col - 1
					thePlayer.arrayOffset = newOffset
					spritesLayerOffset[1] = 35
				else
					print("Can't move left, BLOCKED @ offset " .. newOffset)
				end
				
			else
				print("Move left " .. newOffset)
				thePlayer.col = thePlayer.col - 1
				thePlayer.arrayOffset = newOffset
				spritesLayerOffset[1] = 35
			end
		else
			print("Can't move left, @ col " .. thePlayer.col)
		end

	--
	-- RIGHT
	--
	elseif( target.dir == 4) then
		helpers.changeSprite( thePlayer, 2)

		if( thePlayer.col < 24 ) then
			local newOffset = thePlayer.arrayOffset + 1

			local canPass = false

			if( staticObjectsLayer[newOffset]  or interactiveObjectsLayer[newOffset]) then
				if(interactiveObjectsIndex[newOffset]) then
					canPass = interactions.handleInteractionNum(interactiveObjectsIndex[newOffset], screenGroup)
				end

				if( canPass ) then
					print("Move right " .. newOffset)
					thePlayer.col = thePlayer.col + 1
					thePlayer.arrayOffset = newOffset
					spritesLayerOffset[1] = -35
				else
					print("Can't move right, BLOCKED @ offset " .. newOffset)
				end
				
			else
				print("Move right " .. newOffset)
				thePlayer.col = thePlayer.col + 1
				thePlayer.arrayOffset = newOffset
				spritesLayerOffset[1] = -35
			end
		else
			print("Can't move right, @ col " .. thePlayer.col)
		end
	end
	spritesLayer.x = spritesLayer.x + spritesLayerOffset[1]
	spritesLayer.y = spritesLayer.y + spritesLayerOffset[2]

	return true
end

onSceneTouch = function ( self, event )
	if(event.phase == "began") then	
	elseif (event.phase == "ended") then
	elseif (event.phase == "cancelled") then
	end
	return false
end

gotoMainMenu = function (event )
	storyboard.gotoScene( "scene_MainMenu", "slideRight", 500  )
	return true
end

outroReleaseWin = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	storyboard.gotoScene( "scene_MainMenu", "slideLeft", 500  )
	return true
end


outroReleaseFail = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.outroInterface.isVisible = false
	screenGroup.outroInterfaceFail.isVisible = false
	return true
end

introRelease = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.introInterface.isVisible = false
	screenGroup.introInterface2.isVisible = true
	return true
end

intro2Release = function (event)
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.introInterface2.isVisible = false
	return true
end

musicHelpRelease = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.musicHelp.isVisible = false
	screenGroup.musicPlay.isVisible = true
	return true
end

musicDoneRelease = function (event)
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.musicHelp.isVisible = false
	screenGroup.musicPlay.isVisible = false
	screenGroup.musicWin.isVisible = false
	screenGroup.musicFail.isVisible = false
	
	return true
end

wordsHelpRelease = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.wordsHelp.isVisible = false
	screenGroup.wordsPlay.isVisible = true
	return true
end

wordsDoneRelease = function (event)
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.wordsHelp.isVisible = false
	screenGroup.wordsPlay.isVisible = false
	screenGroup.wordsWin.isVisible = false
	screenGroup.wordsFail.isVisible = false
	
	return true
end

local onTileClick = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	print("onTileClick ==> " .. target.myLetter)

	screenGroup.wordsPlay.scoreText.text = "Score: " .. wordsScore 
	screenGroup.wordsPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

	screenGroup.wordsPlay.guessesText.text = "Guesses: " .. currentWordGuesses .. " of 15"
	screenGroup.wordsPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)

	local curText = screenGroup.wordsPlay.currentWord.text
	print ("Cur text == " .. curText )
	screenGroup.wordsPlay.currentWord.text = curText .. target.myLetter 
	screenGroup.wordsPlay.currentWord.x = 0
	screenGroup.wordsPlay.currentWord:setReferencePoint(display.CenterReferencePoint)
	
	return true
end

local onWordSubmit = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	local curText = screenGroup.wordsPlay.currentWord.text

	local isWord = rgdb.isWordInDB(curText)

	if(isWord) then
		print(curText .. " is a word!")
		wordsScore = wordsScore + 1
		if( currentWordGuesses < 14 ) then
			giveFeedback( true, false )
		end
	else
		print(curText .. " is not word!")
		if( currentWordGuesses < 14 ) then
			giveFeedback( false, false )
		end
	end

	currentWordGuesses = currentWordGuesses + 1
	
	screenGroup.wordsPlay.scoreText.text = "Score: " .. wordsScore 
	screenGroup.wordsPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

	screenGroup.wordsPlay.guessesText.text = "Guesses: " .. currentWordGuesses .. " of 15"
	screenGroup.wordsPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)
	
		
	screenGroup.wordsPlay.currentWord.text = ""
	screenGroup.wordsPlay.currentWord.x = 0
	screenGroup.wordsPlay.currentWord:setReferencePoint(display.CenterReferencePoint)

	if(currentWordGuesses > 14) then
		screenGroup.wordsHelp.isVisible = false
		screenGroup.wordsPlay.isVisible = false

		if( wordsScore >= 10 ) then
			screenGroup.wordsWin.isVisible = true		
			giveFeedback( true, false )
			wordsScore = 0
			currentWordGuesses = 0
			screenGroup.redKey.isVisible = true

		else
			screenGroup.wordsFail.isVisible = true		
			giveFeedback( false, false )
			wordsScore = 0
			currentWordGuesses = 0
		end
	end


	return true
end

local onRollDie = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	currentRoll = currentRoll + 1

	local currentDice = {}
	currentDice[1] = math.random(1,6)
	currentDice[2] = math.random(1,6)
	currentDice[3] = math.random(1,6)
	helpers.changeSprite(screenGroup.dicePlay.die1, currentDice[1] + 32 )
	helpers.changeSprite(screenGroup.dicePlay.die2, currentDice[2] + 32 )
	helpers.changeSprite(screenGroup.dicePlay.die3, currentDice[3] + 32 )

	audio.play( diceRollSound )

	if( (currentDice[1] + currentDice[1] + currentDice[1] ) >= 11 ) then
		diceScore = diceScore + 1
		if( currentRoll < 5 ) then
			giveFeedback( true, true )
		end
	else
		if( currentRoll < 5 ) then
			giveFeedback( false, true )
		end
	end
	
	screenGroup.dicePlay.scoreText.text = "Score: " .. diceScore
	screenGroup.dicePlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

	screenGroup.dicePlay.guessesText.text = "Roll: " .. currentRoll .. " of 5"
	screenGroup.dicePlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)


	if(currentRoll > 4) then
		screenGroup.diceHelp.isVisible = false
		screenGroup.dicePlay.isVisible = false

		if( diceScore >= 3 ) then
			screenGroup.diceWin.isVisible = true		
			giveFeedback( true, true )
			diceScore= 0
			currentRoll = 0
			screenGroup.greenKey.isVisible = true
		else
			screenGroup.diceFail.isVisible = true		
			giveFeedback( false, true )
			diceScore = 0
			currentRoll = 0
		end
	end

	return true
end



diceHelpRelease = function (event )
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.diceHelp.isVisible = false
	screenGroup.dicePlay.isVisible = true
	return true
end

diceDoneRelease = function (event)
	local target = event.target
	local screenGroup = target.screenGroup
	screenGroup.diceHelp.isVisible = false
	screenGroup.dicePlay.isVisible = false
	screenGroup.diceWin.isVisible = false
	screenGroup.diceFail.isVisible = false
	
	return true
end


onPlaySnippet = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	local currentSongToPlay = musicSnippetsToPlay[currentSong]
	local theSong = musicSnippets[currentSongToPlay]

	print("Play: " .. theSong[3] .. " a " .. theSong[1] .. " song, by " .. theSong[2] )
	
	local tmpHandle = audio.loadSound(theSong[4])
	audio.play( tmpHandle )
	-- EFM not disposing of handle this may break game eventually
	--local myclosure = function() audio.remove( tmpHandle ) end
	--timer.performWithDelay(12000, myclosure)


	return true
end

onIsLove = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	local currentSongToPlay = musicSnippetsToPlay[currentSong]
	local theSong = musicSnippets[currentSongToPlay]

	if( theSong[1] == "love" ) then
		print("correct!")
		musicScore = musicScore + 1
		if(currentSong < 3) then
			giveFeedback( true, false )
		end
	else
		print("incorrect!")
		if(currentSong < 3) then
			giveFeedback( false, false)
		end
	end

	currentSong = currentSong + 1

	screenGroup.musicPlay.scoreText.text = "Score: " .. musicScore 
	screenGroup.musicPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

	screenGroup.musicPlay.guessesText.text = "Song: " .. currentSong .. " of 3"
	screenGroup.musicPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)

	print("musicScore == " .. musicScore)

	if(currentSong > 3) then
		screenGroup.musicHelp.isVisible = false
		screenGroup.musicPlay.isVisible = false

		if( musicScore == 3 ) then
			screenGroup.musicWin.isVisible = true		
			giveFeedback( true, false )
			screenGroup.blueKey.isVisible = true
		else
			screenGroup.musicFail.isVisible = true		
			giveFeedback( false, false )
		end
	end

	return true
end

onIsShoes = function (event)
	local target = event.target
	local screenGroup = target.screenGroup

	local currentSongToPlay = musicSnippetsToPlay[currentSong]
	local theSong = musicSnippets[currentSongToPlay]

	if( theSong[1] == "shoes" ) then
		print("correct!")
		musicScore = musicScore + 1
		giveFeedback( true, false )
	else
		print("incorrect!")
		giveFeedback( false, false )
	end

	currentSong = currentSong + 1

	screenGroup.musicPlay.scoreText.text = "Score: " .. musicScore 
	screenGroup.musicPlay.scoreText:setReferencePoint(display.CenterRightReferencePoint)

	screenGroup.musicPlay.guessesText.text = "Song: " .. currentSong .. " of 3"
	screenGroup.musicPlay.guessesText:setReferencePoint(display.CenterLeftReferencePoint)


	print("musicScore == " .. musicScore)

	if(currentSong > 3) then
		screenGroup.musicHelp.isVisible = false
		screenGroup.musicPlay.isVisible = false
		if( musicScore == 3 ) then
			screenGroup.musicWin.isVisible = true	
			screenGroup.blueKey.isVisible = true	
		else
			screenGroup.musicFail.isVisible = true		
		end
	end

	currentSong = currentSong + 1

	return true
end



placeIntro =  function( screenGroup )

	-- Intro part 1
	local introInterface = helpers.addTray( screenGroup, "gameIntro" ) 
	screenGroup.introInterface = introInterface
	introInterface.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		x = 100,
		y = 210,
		textSize = 24,
		textColor = {0,0,0,255},
		text = "More...",
		onRelease = introRelease,
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	introInterface:insert(tmpButton, false)

	-- Intro part 2
	local introInterface2 = helpers.addTray( screenGroup, "gameIntro2" ) 
	screenGroup.introInterface2 = introInterface2
	introInterface2.isVisible = false

	buttonParams.text = "Done"
	buttonParams.onRelease = intro2Release
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	introInterface2:insert(tmpButton, false)

end


placeOutro =  function( screenGroup )

	-- Win
	local outroInterface = helpers.addTray( screenGroup, "gameOutro" ) 
	screenGroup.outroInterface = outroInterface
	outroInterface.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		x = 100,
		y = 210,
		textSize = 24,
		textColor = {0,0,0,255},
		text = "Done",
		onRelease = outroReleaseWin,
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	outroInterface:insert(tmpButton, false)
	
	-- Lose
	local outroInterfaceFail = helpers.addTray( screenGroup, "gameOutroFail" ) 
	screenGroup.outroInterfaceFail = outroInterfaceFail
	outroInterfaceFail.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		x = 100,
		y = 210,
		textSize = 24,
		textColor = {0,0,0,255},
		text = "Done",
		onRelease = outroReleaseFail,
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	outroInterfaceFail:insert(tmpButton, false)	

end

---------------------------------------------------------
-- MUSIC GAME
---------------------------------------------------------
placeMusicGame =  function( screenGroup )

	-- Music Help
	local musicHelp = helpers.addTray( screenGroup, "musicHelp" ) 
	screenGroup.musicHelp = musicHelp
	musicHelp.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		textSize = 24,
		textColor = {0,0,0,255},
		onRelease = musicHelpRelease,
		text = "Play!",
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = -100
	tmpButton.y = 210
	musicHelp:insert(tmpButton, false)

	buttonParams.text = "No Thanks!"
	buttonParams.onRelease = musicDoneRelease
	buttonParams.w = 150
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = 80
	tmpButton.y = 210
	musicHelp:insert(tmpButton, false)

	-- Music Game
	local musicPlay = helpers.addTray( screenGroup, "gamesBack" ) 
	screenGroup.musicPlay = musicPlay
	musicPlay.isVisible = false


	-- Guesses Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", -150, -220, 100, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)
	musicPlay.guessesText = tmpLabel
	musicPlay:insert( tmpLabel )
	tmpLabel.text = "Song: " .. currentSong .. " of 3"
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)

	-- Score Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", 80, -220, 100, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)
	musicPlay.scoreText = tmpLabel
	musicPlay:insert( tmpLabel )
	tmpLabel.text = "Score: " .. musicScore 
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)


	---- Play Button
	buttonParams.text = "\n\n\n\nPlay Snippet"
	buttonParams.unselImg = imagesDir .. "music.png"
	buttonParams.selImg = imagesDir .. "music.png"
	buttonParams.onRelease = onPlaySnippet
	buttonParams.w = 66
	buttonParams.h = 80
	buttonParams.x = 0
	buttonParams.y = -160
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicPlay:insert(tmpButton, false)

	---- Love Button
	buttonParams.text = "\n\n\n\nLove"
	buttonParams.unselImg = imagesDir .. "love.png"
	buttonParams.selImg = imagesDir .. "love.png"
	buttonParams.onRelease = onIsLove
	buttonParams.w = 66
	buttonParams.h = 80
	buttonParams.x = -60
	buttonParams.y = 0
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicPlay:insert(tmpButton, false)

	---- Shoes Button
	buttonParams.text = "\n\n\n\nShoes"
	buttonParams.unselImg = imagesDir .. "shoes.png"
	buttonParams.selImg = imagesDir .. "shoes.png"
	buttonParams.onRelease = onIsShoes
	buttonParams.w = 66
	buttonParams.h = 80
	buttonParams.x = 60
	buttonParams.y = 0
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicPlay:insert(tmpButton, false)

	buttonParams.text = "Quit"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = musicDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicPlay:insert(tmpButton, false)


	-- Music Win
	local musicWin = helpers.addTray( screenGroup, "musicWin" ) 
	screenGroup.musicWin = musicWin
	musicWin.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = musicDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicWin:insert(tmpButton, false)

	-- Music Fail
	local musicFail = helpers.addTray( screenGroup, "musicFail" ) 
	screenGroup.musicFail = musicFail
	musicFail.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = musicDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	musicFail:insert(tmpButton, false)


end

---------------------------------------------------------
-- WORDS GAME
---------------------------------------------------------
placeWordsGame =  function( screenGroup )

	-- Words Help
	local wordsHelp = helpers.addTray( screenGroup, "wordsHelp" ) 
	screenGroup.wordsHelp = wordsHelp
	wordsHelp.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		textSize = 24,
		textColor = {0,0,0,255},
		onRelease = wordsHelpRelease,
		text = "Play!",
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = -100
	tmpButton.y = 210
	wordsHelp:insert(tmpButton, false)

	buttonParams.text = "No Thanks!"
	buttonParams.onRelease = wordsDoneRelease
	buttonParams.w = 150
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = 80
	tmpButton.y = 210
	wordsHelp:insert(tmpButton, false)

	-- Words Game
	local wordsPlay = helpers.addTray( screenGroup, "gamesBack" ) 
	screenGroup.wordsPlay = wordsPlay
	wordsPlay.isVisible = false

	-- Guesses Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", -150, -220, 180, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)
	wordsPlay.guessesText = tmpLabel
	wordsPlay:insert( tmpLabel )
	tmpLabel.text = "Guesses: " .. currentWordGuesses .. " of 15"
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)

	-- Score Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", 80, -220, 100, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)
	wordsPlay.scoreText = tmpLabel
	wordsPlay:insert( tmpLabel )
	tmpLabel.text = "Score: " .. wordsScore 
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)

	-- Current Word
	local tmpLabel 
	tmpLabel = display.newText( "Testing", 0, 140, 300, 50, native.systemFontBold, rgdr.scaleFont(20))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterReferencePoint)
	wordsPlay.currentWord = tmpLabel
	wordsPlay:insert( tmpLabel )
	wordsPlay.currentWord.text = ""
	tmpLabel.x = 0
	tmpLabel:setReferencePoint(display.CenterReferencePoint)



	---- Letter Buttons
	buttonParams.w = 45
	buttonParams.h = 45
	buttonParams.x = -180
	buttonParams.y = -160
	buttonParams.text = ""
	local someLetters = { "b", "u", "c", "k", "e", "t" }
	for i=1, #someLetters do
		buttonParams.unselImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.selImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.onRelease = onTileClick
		tmpButton = buttons:new( buttonParams )
		tmpButton.screenGroup = screenGroup
		tmpButton.myLetter = someLetters[i]
		wordsPlay:insert(tmpButton, false)
		tmpButton.x = tmpButton.x + i * 45
	end

	buttonParams.y = -110
	local someLetters = { "s", "h", "o", "e", "s"}
	for i=1, #someLetters do
		buttonParams.unselImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.selImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.onRelease = onTileClick
		tmpButton = buttons:new( buttonParams )
		tmpButton.screenGroup = screenGroup
		tmpButton.myLetter = someLetters[i]
		wordsPlay:insert(tmpButton, false)
		tmpButton.x = tmpButton.x + i * 45
	end

	buttonParams.y = -60
	local someLetters = { "w", "a", "t", "e", "r"}
	for i=1, #someLetters do
		buttonParams.unselImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.selImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.onRelease = onTileClick
		tmpButton = buttons:new( buttonParams )
		tmpButton.screenGroup = screenGroup
		tmpButton.myLetter = someLetters[i]
		wordsPlay:insert(tmpButton, false)
		tmpButton.x = tmpButton.x + i * 45
	end

	buttonParams.y = -10
	local someLetters = { "b", "a", "l", "l", "o", "o", "n"}
	for i=1, #someLetters do
		buttonParams.unselImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.selImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.onRelease = onTileClick
		tmpButton = buttons:new( buttonParams )
		tmpButton.screenGroup = screenGroup
		tmpButton.myLetter = someLetters[i]
		wordsPlay:insert(tmpButton, false)
		tmpButton.x = tmpButton.x + i * 45
	end
	buttonParams.y = 40
	local someLetters = { "l", "o", "v", "e"}
	for i=1, #someLetters do
		buttonParams.unselImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.selImg = imagesDir .. someLetters[i] ..".png"
		buttonParams.onRelease = onTileClick
		tmpButton = buttons:new( buttonParams )
		tmpButton.screenGroup = screenGroup
		tmpButton.myLetter = someLetters[i]
		wordsPlay:insert(tmpButton, false)
		tmpButton.x = tmpButton.x + i * 45
	end


	----- Submit Button
	buttonParams.text = "Submit"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = onWordSubmit
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = -100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	wordsPlay:insert(tmpButton, false)

	----- Quit Button
	buttonParams.text = "Quit"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = wordsDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	wordsPlay:insert(tmpButton, false)


	-- Words Win
	local wordsWin = helpers.addTray( screenGroup, "wordsWin" ) 
	screenGroup.wordsWin = wordsWin
	wordsWin.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = wordsDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	wordsWin:insert(tmpButton, false)

	-- Words Fail
	local wordsFail = helpers.addTray( screenGroup, "wordsFail" ) 
	screenGroup.wordsFail = wordsFail
	wordsFail.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = wordsDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	wordsFail:insert(tmpButton, false)

end

---------------------------------------------------------
-- Dice GAME
---------------------------------------------------------
placeDiceGame =  function( screenGroup )

	-- Dice Help
	local diceHelp = helpers.addTray( screenGroup, "diceHelp" ) 
	screenGroup.diceHelp = diceHelp
	diceHelp.isVisible = false

	local tmpButton
	local buttonParams =
	{
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		w = 100,
		h = 40,
		textSize = 24,
		textColor = {0,0,0,255},
		onRelease = diceHelpRelease,
		text = "Play!",
		scaleFonts = true
	}
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = -100
	tmpButton.y = 210
	diceHelp:insert(tmpButton, false)

	buttonParams.text = "No Thanks!"
	buttonParams.onRelease = diceDoneRelease
	buttonParams.w = 150
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	tmpButton.x = 80
	tmpButton.y = 210
	diceHelp:insert(tmpButton, false)

	-- Dice Game
	local dicePlay = helpers.addTray( screenGroup, "gamesBack" ) 
	screenGroup.dicePlay = dicePlay
	dicePlay.isVisible = false


	-- Guesses Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", -150, -220, 100, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)
	dicePlay.guessesText = tmpLabel
	dicePlay:insert( tmpLabel )
	tmpLabel.text = "Roll: " .. currentRoll .. " of 5"
	tmpLabel:setReferencePoint(display.CenterLeftReferencePoint)

	-- Score Label
	local tmpLabel 
	tmpLabel = display.newText( "Testing", 80, -220, 100, 50, native.systemFontBold, rgdr.scaleFont(16))
	tmpLabel:setTextColor(0, 0, 0)
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)
	dicePlay.scoreText = tmpLabel
	dicePlay:insert( tmpLabel )
	tmpLabel.text = "Score: " .. diceScore 
	tmpLabel:setReferencePoint(display.CenterRightReferencePoint)


	---- The Dice
	buttonParams.w = 45
	buttonParams.h = 45
	buttonParams.x = -180
	buttonParams.y = -160
	buttonParams.text = ""

	local currentDice = {3,2,1}

	local theSprite = helpers.placeSprite( "spriteSet1", currentDice[1] + 32, 0, 0)
	theSprite:scale(2,2)
	theSprite:toFront()
	dicePlay:insert( theSprite, false )
	theSprite.x = -80
	theSprite.y = 0
	dicePlay.die1 = theSprite

	local theSprite = helpers.placeSprite( "spriteSet1", currentDice[2] + 32, 0, 0)
	theSprite:scale(2,2)
	theSprite:toFront()
	dicePlay:insert( theSprite, false )
	theSprite.x = 0
	theSprite.y = 0
	dicePlay.die2 = theSprite

	local theSprite = helpers.placeSprite( "spriteSet1", currentDice[3] + 32, 0, 0)
	theSprite:scale(2,2)
	theSprite:toFront()
	dicePlay:insert( theSprite, false )
	theSprite.x = 80
	theSprite.y = 0
	dicePlay.die3 = theSprite


	----- Roll Button
	buttonParams.text = "Roll"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = onRollDie
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = -100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	dicePlay:insert(tmpButton, false)

	----- Quit Button

	buttonParams.text = "Quit"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = diceDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	dicePlay:insert(tmpButton, false)


	-- Dice Win
	local diceWin = helpers.addTray( screenGroup, "diceWin" ) 
	screenGroup.diceWin = diceWin
	diceWin.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = diceDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	diceWin:insert(tmpButton, false)

	-- Dice Fail
	local diceFail = helpers.addTray( screenGroup, "diceFail" ) 
	screenGroup.diceFail = diceFail
	diceFail.isVisible = false

	buttonParams.text = "Done"
	buttonParams.unselImg = imagesDir .. "blueProtoButton.png"
	buttonParams.selImg = imagesDir .. "blueProtoButtonOver.png"
	buttonParams.onRelease = diceDoneRelease
	buttonParams.w = 100
	buttonParams.h = 40
	buttonParams.x = 100
	buttonParams.y = 210
	tmpButton = buttons:new( buttonParams )
	tmpButton.screenGroup = screenGroup
	diceFail:insert(tmpButton, false)

end



---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
---------------------------------------------------------------------------------

return scene