Welcome to the humongous Lost Dragon PCX
tile-art give-away!

Date: 4/11/2000

These pcx files are free for use on
any commercial or non-commercial (shareware,
freeware, give-away-ware, or otherwise) game 
provided that:

1)  You tell me what you're using the graphics for.
2)  You give me (DeBray Bailey) credit somewhere 
    in the final version of your game distribution.
3)  Lost Dragon cannot appear as a character in your 
    game as I reserve that trademark for myself.  I'd
    also appreciate it if you didn't replicate my 
    game world either (which you don't really have 
    access to anyway ;).

Distributors and webmasters:

This distribution must be kept together.  Do not
split it, rename it, or call it your own.

Users:

There are hundreds upon hundreds of graphics
for you to choose from as I spent years drawing
this collection.  Unfortunately, by the time
I got done drawing, I no longer had time to put
into creating my ultimate adventure.  It was
time well spent though - and I have no regrets.

Here are further facts to keep you happy:

Dave Hernandez is one of the great shareware authors
of all time as far as I'm concerned.

They tiles files are 256 color at 640x480.  

The tiles themselves are 24 pixels wide and 35 pixels 
tall.  Yes, you may modify the graphics for your own 
use.

The outline color (you'll see it in npc and object 
tiles) which appears to be black is actually: 
R:8 G:8 B:8 The pink color is r:255 g:0 b:255 - 
a color I call programmer pink.

Some of the icons in this pack were based on the 
original FRUA icon work by Autery.  A few were based
on FRUA work by Trent Troop (all icons were altered 
with permission).

There are some duplicates in the tile files, but you
can filter them out as you like.  Good luck folks!  
I hope to see graphical versions of the rogue-likes 
now...

Lost Dragon
aka DeBray Bailey
lostdragon@worldnet.att.net
http://www.lostdragon.com/

If all else fails, you can try to reach me at: 
silicon_avatar@hotmail.com but that email address is
infrequently checked.
