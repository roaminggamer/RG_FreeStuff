-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- Minimalistic 'starter' config.lua
-- =============================================================
-- https://docs.coronalabs.com/guide/basics/configSettings/index.html
-- =============================================================
application = {
   content = {
      --graphicsCompatibility = 1,  -- Enable V1 Compatibility mode
      width              = 320,
      height             = 480,
      scale              = "letterbox",
      fps                = 60,
   },
   -- Dynamic Image Selection
   --[[
   imageSuffix = {
      ["@2x"] = 2.0,
   },
   --]]
}

