---------------------------------------------------------------------------------
--
-- scene_MainMenu.lua
--
---------------------------------------------------------------------------------
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local backImage 

-- Callbacks/Functions
local onPlay 
local onCredits
local onQuit

----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:enterScene( event )   - Called immediately after scene has moved onscreen
-- scene:exitScene( event )    - Called when scene is about to move offscreen
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------
function scene:createScene( event )
	local screenGroup = self.view

	backImage = helpers.addTray(screenGroup, "mainMenuBack" ) 
	helpers.addTitle( "48-Hour Island", 20, rgdr.scaleFont(40), screenGroup ) 
	--
	-- Menu Buttons
	--
	local tmpButton
	local buttonWidth    = 270
	local buttonHeight   = 40
	local buttonTopRowY  = 120
	local buttonX        = 160
	local buttonTweenX   = 0
	local buttonTweenY   = 48

	local tmpParams = 
	{ 
		w = buttonWidth,
		h = buttonHeight,
		x = buttonX,
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		buttonType = "push",
		textSize = 32,
		textColor = { 255, 255, 255, 255 },
		textFont = nil,
		textOffset = {0,0},
		pressSound = buttonSound,
		scaleFonts = true
	}

	-- Single Player Button
	tmpParams.text      = "Play"
	tmpParams.onRelease = onPlay 
	tmpParams.y         = buttonTopRowY + 1 * buttonTweenY
	tmpButton           = buttons:new( tmpParams )
	screenGroup:insert(tmpButton)

	-- Credis Button
	tmpParams.text      = "Credits"
	tmpParams.onRelease = onCredits 
	tmpParams.y         = buttonTopRowY + 2 * buttonTweenY
	tmpButton           = buttons:new( tmpParams )
	screenGroup:insert(tmpButton)

	-- Quit Button
	tmpParams.text      = "Quit"
	tmpParams.unselImg = imagesDir .. "redProtoButton.png"
	tmpParams.selImg = imagesDir .. "redProtoButtonOver.png"
	tmpParams.onRelease = onQuit 
	tmpParams.y         = buttonTopRowY + 4 * buttonTweenY
	tmpButton           = buttons:new( tmpParams )
	screenGroup:insert(tmpButton)

	tmpButton = nil

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:enterScene( event )
	local screenGroup = self.view

	storyboard.removeAll() --EFM

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:exitScene( event )
	local screenGroup = self.view	
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:destroyScene( event )
	local screenGroup = self.view
end

----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------

onPlay = function (event )
	storyboard.gotoScene( "scene_PlayGui", "slideLeft", 500  )
	return true
end


onCredits =  function ( event )	
	storyboard.gotoScene( "scene_Credits", "slideRight", 500  )
	return true
end

onQuit = function ( event )
	print("Quit!")
	if( system.getInfo( "environment" )  ~= "simulator" ) then
		os.exit()
	end
	return true
end


---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
---------------------------------------------------------------------------------

return scene

 
