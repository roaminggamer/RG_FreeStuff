-- rg_helpers.lua 
-- Version 1.1

module(..., package.seeall)

local highusage = 0
local enableMemDebug = true


-- SPRITE HELPERS
-- SPRITE HELPERS	BEGIN
-- SPRITE HELPERS

local spriteSheets = {}
local spriteSets = {}

local imageSheets = {}

function createSpriteSet( setName, sheetSource, spriteX, spriteY, numSprites )
	spriteSheets[setName] = sprite.newSpriteSheet(sheetSource, spriteX, spriteY)
	spriteSets[setName]   = sprite.newSpriteSet(spriteSheets[setName], 1, numSprites)
	for i = 1, numSprites do
		print("createSpriteSet()", setName, sheetSource, spriteX, spriteY, numSprites );
		if(i > 4) then return end
		sprite.add( spriteSets[setName], setName .. i, i,i,1000,0)
	end
end

function createSpriteSet( setName, sheetSource, spriteW, spriteH, numSprites )
	local options = { width = spriteW, height = spriteH, numFrames = numSprites }
	imageSheets[setName] =  graphics.newImageSheet( sheetSource, options )
end


function placeSprite( setName, spriteNum, x, y)
	if(true) then return end
	--print("placeSprite()", setName, spriteNum, x, y)
	local x = x or 0
	local y = y or 1

	local localSprite = sprite.newSprite ( spriteSets[setName] )	
	localSprite.x = x
	localSprite.y = y

	localSprite:prepare(setName .. spriteNum)
	localSprite:pause()

	localSprite.mySetName   = setName
	localSprite.mySpriteNum = spriteNum

	return localSprite
end
function placeSprite( setName, spriteNum, x, y)
	local localSprite = display.newImage( imageSheets[setName], spriteNum, x, y)
	localSprite.setName = setName
	return localSprite
end

function changeSprite( self, frame )
	self.fill = { type = "image", sheet = imageSheets[self.setName], frame = frame }
	return self
end



-- SPRITE HELPERS
-- SPRITE HELPERS	END
-- SPRITE HELPERS


function addTray( screenGroup, imageName )
	local tray = display.newGroup()
	screenGroup:insert( tray, true )
	local image = display.newImage( imagesDir .. imageName .. ".png" )
	tray:insert( image, true )
	tray.x = w/2
	tray.y = h/2
	return tray
end

function addTitle( titleText, textY, textFontSize, screenGroup )
	local titleOffsets =  {
		{2, 0 },
		{-2, 0},
		{ 0, -2},
		{0, 2},
		{2, 2 },
		{2, -2},
		{ -2, 2},
		{-2, -2},
		{ 0, 0 },
	}

	local titleGroup = display.newGroup()

	local tmpText
	for i = 1, #titleOffsets do
		tmpText = display.newText(titleText, titleOffsets[i][1], titleOffsets[i][2], native.systemFontBold, textFontSize )
		tmpText:setReferencePoint( display.TopLeftReferencePoint )
		tmpText:setTextColor( 255, 255, 255 )
		titleGroup:insert(tmpText)		
	end

	tmpText:setTextColor( 0, 0, 0 ) -- Last one is BLACK
	screenGroup:insert(titleGroup, true)

	titleGroup.x = (w - titleGroup.width) / 2
	titleGroup.y = textY

	return titleGroup
end

function addText( titleText, textY, textFontSize, screenGroup )
	local titleOffsets =  {
		{ 0, 0 },
	}

	local titleGroup = display.newGroup()

	local tmpText
	for i = 1, #titleOffsets do
		tmpText = display.newText(titleText, titleOffsets[i][1], titleOffsets[i][2], native.systemFontBold, textFontSize )
		tmpText:setReferencePoint( display.CenterReferencePoint )
		tmpText:setTextColor( 255, 255, 255 )
		titleGroup:insert(tmpText)		
	end

	screenGroup:insert(titleGroup, true)

	titleGroup.x = (w - titleGroup.width) / 2
	titleGroup.y = textY

	return titleGroup
end

function addTextSimpleText( titleText, textX, textY, textFontSize, textColor )
	local textColor = textColor or {0,0,0,255}
	local tmpText
	tmpText = display.newText(titleText, textX, textY, native.systemFont, textFontSize )
	tmpText:setTextColor( textColor[1], textColor[2], textColor[3], textColor[4] )
	tmpText:setReferencePoint( display.CenterReferencePoint )
	tmpText.x = textX
	tmpText.y = textY

	return tmpText
end


function createOutlineText( outlineText, textFontSize, outerOffset, innerColor, outerColor )
	
	print( "Create outlineText " .. outlineText )
	local outerOffset = outerOffset or {0, 0, 0, 255}
	local innerColor = innerColor or {0, 0, 0, 255}
	local outerColor = outerColor or {255, 255, 255, 255}

--[[
	local titleOffsets =  {
		{outerOffset, 0 },
		{-outerOffset, 0},
		{ 0, -outerOffset},
		{0, outerOffset},
		{outerOffset, outerOffset },
		{outerOffset, -outerOffset},
		{ -outerOffset, outerOffset},
		{-outerOffset, -outerOffset},
		{ 0, 0 },
	}
--]]
	local titleOffsets =  {
		{ 0, 0 },
	}

	local textGroup = display.newGroup()

	local tmpText
	for i = 1, #titleOffsets do
		tmpText = display.newText(outlineText, 0,0, native.systemFontBold, textFontSize )
		tmpText:setReferencePoint( display.CenterReferencePoint )
		tmpText:setTextColor( outerColor[1], outerColor[2], outerColor[3], outerColor[4] )
		tmpText.x = titleOffsets[i][1]
		tmpText.y = titleOffsets[i][2]
		textGroup:insert(tmpText)		
	end

	tmpText:setTextColor( innerColor[1], innerColor[2], innerColor[3], innerColor[4] )
	return textGroup
end


function addQuitButton( callback, screenGroup )
	local quitButton = buttons:new 
	{
		unselImg = imagesDir .. "homeButtonRed.png",
		selImg = imagesDir .. "homeButtonRedOver.png",
		x = 20,
		y = 325,
		w = 32,
		h = 32,
		textSize = 30,
		onRelease = callback,
		text = ""
	}
	screenGroup:insert(quitButton)

	return quitButton
end


function convertToTimer( seconds )
	local minutes = math.floor(seconds/60)
	local remainingSeconds = seconds - (minutes * 60)

	local timerVal = "" 

	if(remainingSeconds < 10) then
		timerVal =  minutes .. ":" .. "0" .. remainingSeconds
	else
		timerVal = minutes .. ":"  .. remainingSeconds
	end

	return timerVal
end


---- MEMORY DEBUG STUFF

function initMemDebug( backImage, screenGroup )
	if( enableMemDebug == false ) then return end
	local memDebugText
	memDebugText = display.newText( "", 0, 0, native.systemFontBold, rgdr.scaleFont(34) )
	memDebugText:setTextColor( 64,160,160, 255 );
	memDebugText:setReferencePoint( display.CenterReferencePoint )
	memDebugText.x = 160 
	memDebugText.y = 460
	screenGroup.memDebugText = memDebugText
	screenGroup:insert( memDebugText )

end

function stopMemDebug( backImage )
	if( enableMemDebug == false ) then return end
	--backImage:removeEventListener( "touch", backImage )
end

function startMemDebug( backImage, screenGroup )
	if( enableMemDebug == false ) then return end
	local backImage = backImage
	local memDebugText = screenGroup.memDebugText

	local showMem = function()
		--backImage:addEventListener( "touch", backImage )
		local usage = math.floor( collectgarbage("count") )
		if(usage > highusage) then
			highusage = usage
			print( "MemUsage: " .. usage .. "KB")
		end
		memDebugText.text = "MemUsage: " .. usage .. "KB"
		memDebugText:setReferencePoint( display.CenterReferencePoint )
		memDebugText.x = 160 
		memDebugText.y = 980
	end

	local memTimer = timer.performWithDelay( 0, showMem, 1 )
end
