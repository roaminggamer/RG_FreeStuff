-- class_Buttons.lua 
-- Version 1.1

module(..., package.seeall)

--
-- Helper Functions
--

function getCurrentRadio( group ) -- Helper function for radio button groups, gets current radio button
	return group.currentRadio
end


--[[
--
-- Button Class (Push, Toggle, Radio)
--
	Helper Functions:
	-- getCurrentRadio( group ) -- Helper function for radio button groups, gets current radio button		
   
	Class Methods:

	-- new( params )   - Create new button using specified params
	-- touch( params ) - The 'touch' handler for all three button types

	Instance Methods:

    -- toggle( )              - Toggle the state of a button (does NOT execute callbacks)
	-- isPressed( )                 - Is the button pressed? (For toggle and radio buttons)
	-- getText( )                   - Get the current text value for button
	-- setText( text )              - Change button text
	-- adjustTextOffset( [offset] ) - Set offset of text (defaults to {0,0})

--]]

buttonClass = {}


function buttonClass:new( params )
	local buttonInstance = display.newGroup()

	-- Snag Setting (assume all set)
	buttonInstance.x            = params.x or 0
	buttonInstance.y            = params.y or 0
	buttonInstance.w            = params.w or 178
	buttonInstance.h            = params.h or 56
	buttonInstance.unselImg     = params.unselImg
	buttonInstance.selImg       = params.selImg
	buttonInstance.onPress      = params.onPress
	buttonInstance.onRelease    = params.onRelease
	buttonInstance.onEvent      = params.onEvent
	buttonInstance.buttonType   = params.buttonType  or "push"

	buttonInstance.text         = params.text or ""
	buttonInstance.textSize     = params.textSize or 20
	buttonInstance.textColor    = params.textColor or {255,255,255,255}
	buttonInstance.textFont     = params.textFont or native.systemFontBold
	buttonInstance.textAlign    = params.textAlign or "center" --EFM
	buttonInstance.textOffset   = params.textOffset or {0,0} --EFM
	buttonInstance.isPressed    = params.isPressed or false --EFM
	buttonInstance.isEnabled    = params.isEnabled or true --EFM
	buttonInstance.pressSound   = params.pressSound --EFM
	buttonInstance.releaseSound = params.releaseSound --EFM
	buttonInstance.sound        = params.sound --EFM

	buttonInstance.scaleSize     = params.scaleSize or false --EFM
	buttonInstance.scalePosition = params.scalePosition or false --EFM
	buttonInstance.scaleFonts    = params.scaleFonts or false --EFM

	-- Adjust vs. design resolution
	if( buttonInstance.scaleSize == true ) then
		--print( "buttonClass:new() - Scaling dimensions" )
		buttonInstance.w = rgdr.scaleX( buttonInstance.w )
		buttonInstance.h = rgdr.scaleY( buttonInstance.h )
	end

	if( buttonInstance.scalePosition == true ) then
		--print( "buttonClass:new() - Scaling positions" )
		buttonInstance.x = rgdr.scaleX( buttonInstance.x )
		buttonInstance.y = rgdr.scaleY( buttonInstance.y )
	end

	if( buttonInstance.scaleFonts == true ) then
		--print( "buttonClass:new() - Scaling font" )
		--print( buttonInstance.textSize )
		buttonInstance.textSize = rgdr.scaleFont( buttonInstance.textSize )
		--print( buttonInstance.textSize )
	end

	
	if(buttonInstance.buttonType == nil) then
		buttonInstance.buttonType = "push"
	end

	-- Create the button
	-- UNSEL IMG
	local unselImg = display.newImageRect( buttonInstance.unselImg, buttonInstance.w, buttonInstance.h)
	buttonInstance:insert( unselImg, true )
	unselImg.isVisible = true
	buttonInstance.unsel = unselImg
	
	-- SEL IMG
	local selImg = display.newImageRect( buttonInstance.selImg, buttonInstance.w, buttonInstance.h)
	buttonInstance:insert( selImg, true )
	selImg.isVisible = false
	buttonInstance.sel = selImg

	-- BUTTON TEXT
	local labelText = display.newText( buttonInstance.text, 0, 0, buttonInstance.textFont, buttonInstance.textSize )
	buttonInstance.labelText = labelText
	labelText:setTextColor( buttonInstance.textColor[1], buttonInstance.textColor[2], 
	                        buttonInstance.textColor[3], buttonInstance.textColor[4] )
	labelText:setReferencePoint( display.CenterReferencePoint )
	buttonInstance:insert( labelText, true )
	labelText.x = buttonInstance.textOffset[1]
	labelText.y = buttonInstance.textOffset[2]

	buttonInstance:addEventListener( "touch", self )

	function buttonInstance:isPressed( ) 
		return self.isPressed
	end


	function buttonInstance:toggle( ) -- Toggle the state of a button (does NOT execute callbacks)
		local buttonEvent = {}
		buttonEvent.target = self
		buttonEvent.id = self.id
		buttonEvent.x = self.x
		buttonEvent.y = self.y
		buttonEvent.name = "touch"
		buttonEvent.phase = "began"
		self:dispatchEvent( buttonEvent )
		buttonEvent.phase = "ended"
		self:dispatchEvent( buttonEvent )
	end

	function buttonInstance:disable( ) 
		self.isEnabled = false
		self.sel.alpha = 0.3
		self.unsel.alpha = 0.3
	end

	function buttonInstance:enable( ) 
		self.isEnabled = true
		self.sel.alpha = 1.0
		self.unsel.alpha = 1.0
	end

	function buttonInstance:isEnabled() 
		return (self.isEnabled == true)
	end

	function buttonInstance:getText( ) 
		return self.labelText.text
	end

	function buttonInstance:setText( text ) 
		local labelText = self.labelText
		labelText.text = text
		labelText:setReferencePoint( display.CenterReferencePoint )
		labelText.x = self.textOffset[1]
		labelText.y = self.textOffset[2]
	end

	function buttonInstance:adjustTextOffset( offset ) 
		local offset = offset or {0,0}
		local labelText = self.labelText
		self.textOffset = offset
		labelText:setReferencePoint( display.CenterReferencePoint )
		labelText.x = self.textOffset[1]
		labelText.y = self.textOffset[2]
	end

	return buttonInstance
end

function buttonClass:touch( params )
	--for k,v in pairs(params) do print(k,v) end
	local result       = true
	local self         = params.target
	local phase        = params.phase
	local sel          = self.sel
	local unsel        = self.unsel
	local onPress      = self.onPress
	local onRelease    = self.onRelease
	local onEvent      = self.onEvent
	local buttonType   = self.buttonType
	local parent       = self.parent
	local sound        = self.sound
	local pressSound   = self.pressSound
	local releaseSound = self.releaseSound

	-- If not enabled, exit immediately
	if(self.isEnabled == false) then
		return result
	end

	local buttonEvent = params -- For passing to callbacks

	if(phase == "began") then
		sel.isVisible  = true
		unsel.isVisible = false
		display.getCurrentStage():setFocus( self )
		self.isFocus = true

		-- Only Pushbutton fires event here
		if(buttonType == "push") then
			-- PUSH BUTTON
			--print("push button began")
			self.isPressed = true
			if( sound ) then audio.play( sound ) end
			if( pressSound ) then audio.play( pressSound ) end
			if( onPress ) then result = result and onPress( buttonEvent ) end
			if( onEvent ) then result = result and onEvent( buttonEvent ) end
		end

	elseif self.isFocus then
		local bounds = self.stageBounds
		local x,y = params.x, params.y
		local isWithinBounds = 
			bounds.xMin <= x and bounds.xMax >= x and bounds.yMin <= y and bounds.yMax >= y

		if( phase == "moved") then
			if(buttonType == "push") then
				sel.isVisible   = isWithinBounds
				unsel.isVisible = not isWithinBounds
			elseif(buttonType == "toggle") then
				if( not isWithinBounds ) then
					sel.isVisible   = self.isPressed
					unsel.isVisible = not self.isPressed
				else
					sel.isVisible   = true
					unsel.isVisible = false
				end
			elseif(buttonType == "radio") then
			end

		elseif(phase == "ended" or phase == "cancelled") then
			--print("buttonType " .. buttonType )
			------------------------------------------------------
			if(buttonType == "push") then -- PUSH BUTTON
			------------------------------------------------------
				--print "push button ended"				
				sel.isVisible   = false
				unsel.isVisible = true

				self.isPressed = false

				if isWithinBounds then
					if( sound ) then audio.play( sound ) end
					if( releaseSound ) then audio.play( releaseSound ) end
					if( onRelease ) then result = result and onRelease( buttonEvent ) end
					if( onEvent ) then result = result and onEvent( buttonEvent ) end
				end
			
			------------------------------------------------------
			elseif(buttonType == "toggle") then -- TOGGLE BUTTON				
			------------------------------------------------------
				--print( "\ntoggle button ended -- " .. buttonEvent.phase )
				if isWithinBounds then
					if(self.isPressed == true) then
						self.isPressed = false
						if( sound ) then audio.play( sound ) end
						if( releaseSound ) then audio.play( releaseSound ) end
						if( onRelease ) then result = result and onRelease( buttonEvent ) end
						if( onEvent ) then result = result and onEvent( buttonEvent ) end
					else
						self.isPressed = true
						buttonEvent.phase = "began"
						if( sound ) then audio.play( sound ) end
						if( pressSound ) then audio.play( pressSound ) end
						if( onPress ) then result = result and onPress( buttonEvent ) end
						if( onEvent ) then result = result and onEvent( buttonEvent ) end
					end					
				end
				sel.isVisible   = self.isPressed
				unsel.isVisible = not self.isPressed				
			------------------------------------------------------
			elseif(buttonType == "radio") then -- RADIO BUTTON
			------------------------------------------------------
				--print "radio button ended" 
				if isWithinBounds then
					if( parent.currentRadio ~= self ) then
						local oldRadio = parent.currentRadio
						if( oldRadio ) then
							oldRadio.isPressed = false
							buttonEvent.self = oldRadio
							if( sound ) then audio.play( sound ) end
							if( releaseSound ) then audio.play( releaseSound ) end
							if( onRelease ) then result = result and onRelease( buttonEvent ) end
							if( onEvent ) then result = result and onEvent( buttonEvent ) end
							oldRadio.sel.isVisible   = false
							oldRadio.unsel.isVisible = true
						end
						
						parent.currentRadio = self
						buttonEvent.self = self

						self.isPressed = true
						buttonEvent.phase = "began"
						if( sound ) then audio.play( sound ) end
						if( pressSound ) then audio.play( pressSound ) end
						if( onPress ) then result = result and onPress( buttonEvent ) end
						if( onEvent ) then result = result and onEvent( buttonEvent ) end
					end
				end
				
				sel.isVisible   = self.isPressed
				unsel.isVisible = not self.isPressed
			end
			
			-- Allow touch events to be sent normally to the objects they "hit"
			display.getCurrentStage():setFocus( nil )
			self.isFocus = false


		end
	end
	return result
end

return buttonClass