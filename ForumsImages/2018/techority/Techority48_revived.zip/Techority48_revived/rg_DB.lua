-- rgdb.lua
-- Version 0.1
module(..., package.seeall)

require "sqlite3"


local path
local db

function initDB()
	print( "version " .. sqlite3.version() )
	path = system.pathForFile("t48.db")
	db = sqlite3.open( path ) 
end

function isWordInDB( word )
	local foundCount = 0
	local cmd = "SELECT * FROM theWords where field1='" .. word .. "'"
	--print(cmd)
	--print( db:nrows("SELECT * FROM words where field1='" .. word .. "'")  )
	for row in db:nrows(cmd) do
		foundCount = foundCount + 1
	end
	print( foundCount )
	return (foundCount > 0)
end

function findWordInDB( word )
	word = string.lower(word)
	local foundCount = 0
	local cmd = "SELECT * FROM theWords where field1='" .. word .. "'"
	for row in db:nrows(cmd) do
		foundCount = foundCount + 1
	end
	print( word .. " " .. foundCount )
	return foundCount
end



function testSearchSpeed( iterations )
	local testwords = {}
	testwords[0] = "actor"
	testwords[1] = "plenty"
	testwords[2] = "dog"
	testwords[3] = "cat"
	testwords[4] = "penny"
	testwords[5] = "quarter"
	testwords[6] = "lane"
	testwords[7] = "man"
	testwords[8] = "woman"
	testwords[9] = "exact"

	local startTime = system.getTimer()
	print( startTime )
	for i=0, iterations do
		findWordInDB( testwords[math.random (0, 9)] )
	end
	local endTime = system.getTimer()
	print( endTime )

	local result = "Did " .. iterations .. " searches in " .. endTime - startTime .. " ms"
	print(result)

	local t = display.newText(result, 20, 30, null, 32)
	t:setTextColor(255,0,0)

end