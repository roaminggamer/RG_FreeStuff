---------------------------------------------------------------------------------
--
-- selectPlayer.lua
--
---------------------------------------------------------------------------------
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local backImage 

local playerListDialog
local tmpPlayerName

local selectedPlayers = {}

-- Callbacks/Functions
local namesButtonHandler
local dialogIFCButtonHandler

----------------------------------------------------------------------
--								LOCAL FUNCTIONS						--
----------------------------------------------------------------------
local function removeNameFromList( name )
	local tmpList = {}
	local playersList = thePlayerData:getPlayersList()
	for i=1, thePlayerData:getNumPlayers() do
		if( name ~= playersList[i] ) then
			table.insert( tmpList, playersList[i] )
		end
	end
	thePlayerData:setPlayersList( tmpList )
end

local function displayPlayerListDialog( screenGroup )
	if(playerListDialog) then
		playerListDialog:removeSelf()
		playerListDialog = nil
	end

	playerListDialog = display.newGroup()

	playerListDialog.screenGroup = screenGroup

	--------------------------------------------------
	-- Players List Buttons
	--------------------------------------------------
	local playerButtonsGroup = display.newGroup()

	helpers.addText( "Select at least 2 players", 70, rgdr.scaleFont(36), screenGroup ) 

	local buttonWidth    = 200
	local buttonHeight   = 40
	local buttonX   = centerX
	local buttonY   = 120
	local buttonTopRowY  = 120
	local buttonTweenY   = 45
	
	local tmpParams = 
	{ 
		w = buttonWidth,
		h = buttonHeight,
		unselImg = imagesDir .. "blueProtoButton.png",
		selImg = imagesDir .. "blueProtoButtonOver.png",
		onEvent = namesButtonHandler,
		buttonType = "toggle",
		textSize = 40,
		textColor = { 255, 255, 255, 255 },
		textFont = nil,
		textOffset = {0,0},
		pressSound = buttonSound,
		scaleFonts = true
	}
	
	for i=1, thePlayerData:getNumPlayers() do		

		local playersList = thePlayerData:getPlayersList()		
		local tmpButton
		local tmpParams = tmpParams
		tmpParams.text  = playersList[i]
		tmpParams.x     = centerX
		tmpParams.y     = buttonTopRowY + (i-1) * buttonTweenY
		tmpButton       = buttons:new( tmpParams )
		playerButtonsGroup:insert(tmpButton)

		if( thePlayerData:getCurrentPlayer() == playersList[i]) then
			tmpButton:toggle()
		end
	end

	playerListDialog:insert(playerButtonsGroup)

	--------------------------------------------------
	-- Add dialog buttons
	--------------------------------------------------
	local dialogButtonsGroup = display.newGroup()
	buttonWidth    = 200
	buttonHeight   = 40
	local buttonOffsetY   = buttonHeight + 5

	tmpParams = 
	{ 
		y = buttonTopRowY + (thePlayerData:getNumPlayers() + 1) * buttonTweenY,
		w = buttonWidth,
		h = buttonHeight,
		unselImg = imagesDir .. "buttonBlue.png",
		selImg = imagesDir .. "buttonBlueOver.png",
		onRelease = dialogIFCButtonHandler,
		buttonType = "push",
		textSize = 40,
		textColor = { 255, 255, 255, 255 },
		textFont = nil,
		textOffset = {0,0},
		pressSound = buttonSound,
		scaleFonts = true
	}

	--
	-- Play! Button
	--
	tmpParams.text = "Play!"
	tmpParams.unselImg = imagesDir .. "greenProtoButton.png"
	tmpParams.selImg = imagesDir .. "greenProtoButtonOver.png"
	tmpParams.x = centerX 
	tmpParams.y = tmpParams.y 
	tmpButton = buttons:new( tmpParams )
	dialogButtonsGroup:insert(tmpButton)

	--
	-- Cancel Button
	--
	tmpParams.unselImg = imagesDir .. "redProtoButton.png"
	tmpParams.selImg = imagesDir .. "redProtoButtonOver.png"

	tmpParams.text = "Cancel"
	tmpParams.x = centerX 
	tmpParams.y = tmpParams.y + buttonOffsetY
	tmpButton = buttons:new( tmpParams )
	dialogButtonsGroup:insert(tmpButton)

	playerListDialog:insert(dialogButtonsGroup)

	screenGroup:insert(playerListDialog)
	
	return playerListDialog
end

local function destroyPlayerListDialog()
	if(playerListDialog) then
		playerListDialog:removeSelf()
		playerListDialog = nil
	end
end

local function redisplayPlayerListDialog()
	local screenGroup = playerListDialog.screenGroup
	displayPlayerListDialog( screenGroup )
end

----------------------------------------------------------------------
--
-- Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:enterScene( event )   - Called immediately after scene has moved onscreen
-- scene:exitScene( event )    - Called when scene is about to move offscreen
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------
function scene:createScene( event )
	local screenGroup = self.view

	backImage = helpers.addTray( screenGroup ) 
	helpers.addTitle( "Local Multiplayer", 20, rgdr.scaleFont(60), screenGroup ) 
	
	helpers.initMemDebug( backImage, screenGroup)
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:enterScene( event )
	local screenGroup = self.view
	helpers.startMemDebug( backImage, screenGroup )

	selectedPlayers = {}

	--------------------------------------------------
	-- Display Player List
	--------------------------------------------------
	destroyPlayerListDialog()
	displayPlayerListDialog( screenGroup )

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:exitScene( event )
	local screenGroup = self.view
	helpers.stopMemDebug( backImage )
end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:destroyScene( event )
	local screenGroup = self.view
	destroyPlayerListDialog()
end

----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------
namesButtonHandler = function (event)
	local buttonText = event.target:getText()

	if(event.phase == "began") then
		selectedPlayers[buttonText] = buttonText
	elseif(event.phase == "ended") then
		selectedPlayers[buttonText] = nil
	end

	for key,value in pairs(selectedPlayers) do
		print( key )
	end

	return true
end

dialogIFCButtonHandler = function (event)
	local buttonText = event.target:getText()

	if( buttonText == "Play!" ) then

		gameOptions:set("currentGameMode" , "LOCALMP" )
		print("Preselecting tiles!")
		gameTiles:preSelectTiles(gameOptions:get( "gridRows" ) * gameOptions:get( "gridCols" ))

		thePlayerData:clearMPPlayers()

		for key,value in pairs(selectedPlayers) do
			thePlayerData:addMPPlayers( key )
			scoring.setPlayerScore( key, 0)
		end

		gameOptions:set("curPlayerNum", 1)
		storyboard.gotoScene( "scene_ReadyScreen", "flip", 100  )

	elseif( buttonText == "Cancel" ) then
		storyboard.gotoScene( "scene_MainMenu", "slideRight", 500  )		

	end

end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
---------------------------------------------------------------------------------

return scene

 
