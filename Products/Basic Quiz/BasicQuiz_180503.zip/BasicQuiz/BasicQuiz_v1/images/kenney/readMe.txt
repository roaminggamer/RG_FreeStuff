These are free assets from the first 'Game Assets' pack by Kenney: http://kenney.nl/

He has three packs at the time of this writing.  

I strongly suggest you buy them each here:  https://kenney.itch.io/