-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local data = {}
--[[ 
===============================================================
                    *** HOW TO ADD QUESTIONS: ***
===============================================================
1. Create new question table
local question = {} 

2. Insert question table into data table at next position:
data[#data+1] = question

3. Specify question text as string.
question.question = "1 + 1"

4. Specify answers as table, where first question is correct answer.
question.answers = { 2, 1, 3 }
===============================================================
--]]

--
local question = {}
data[#data+1] = question
question.text = "1 + 1"
question.answers = { 2, 1, 3 }

--
local question = {}
data[#data+1] = question
question.text = "5 + 4"
question.answers = { 9, 10, 8 }

return data