-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local quizzes = {}
quizzes.add = require "data.add"
quizzes.subtract = require "data.subtract"
quizzes.multiply = require "data.multiply"
quizzes.divide = require "data.divide"
return quizzes