-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onPlay

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local buttonXOffset = w/8
local buttonSize = 55 * 3;



----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view

   -- Background Image
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   --local back = newImageRect( sceneGroup, centerX, centerY, "images/protoBackX.png", { w = 1386, h = 720} )
   local back = newImageRect( sceneGroup, centerX, centerY, "images/plainBack.png", { w = 1386, h = 720} )

   -- Title
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local title = display.newText( sceneGroup, common.menuTitle, 
                                 centerX, top + 120,
                                 common.menuTitleFont, common.menuTitleSize )
   title:setFillColor( unpack( common.menuTitleFill ) )


   -- Message
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local message = display.newText( sceneGroup, common.menuMessage, 
                                 centerX, bottom - 2.5 * buttonSize, 
                                 common.menuMessageFont, common.menuMessageSize )
   message:setFillColor( unpack( common.menuMessageFill ) )


   --
   -- Buttons
   --

   -- ADDITION BUTTON 
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      unselImgSrc       = "images/symbols/add.png",
      selImgSrc         = "images/symbols/add.png",
      touchOffset       = {1,2},
      strokeWidth       = 0,
      labelOffset       = { 0, buttonSize/2 + 20 },
      labelFont         = _G.fontB,
      labelSize         = 40,
      labelColor        = _Y_,
      unselImgFillColor = _Y_,
      selImgFillColor   = _W_,
   }
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   local button = easyIFC:presetPush( sceneGroup, "default", 
                                    centerX - 1 * buttonXOffset, bottom - buttonSize * 1.25, 
                                    buttonSize, buttonSize, "Addition", 
                                    onPlay, params )
   button.quiz = "add"


   -- SUBTRACTION BUTTON 
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      unselImgSrc       = "images/symbols/subtract.png",
      selImgSrc         = "images/symbols/subtract.png",
      touchOffset       = {1,2},
      strokeWidth       = 0,
      labelOffset       = { 0, buttonSize/2 + 20 },
      labelFont         = _G.fontB,
      labelSize         = 40,
      labelColor        = _ORANGE_,
      unselImgFillColor = _ORANGE_,
      selImgFillColor   = _W_,
   }
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   local button = easyIFC:presetPush( sceneGroup, "default", 
                                    centerX - 3 * buttonXOffset, bottom - buttonSize * 1.25, 
                                    buttonSize, buttonSize, "Subtraction", 
                                    onPlay, params )
   button.quiz = "subtract"


   -- MULTIPLICATION BUTTON 
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      unselImgSrc       = "images/symbols/multiply.png",
      selImgSrc         = "images/symbols/multiply.png",
      touchOffset       = {1,2},
      strokeWidth       = 0,
      labelOffset       = { 0, buttonSize/2 + 20 },
      labelFont         = _G.fontB,
      labelSize         = 40,
      labelColor        = _PINK_,
      unselImgFillColor = _PINK_,
      selImgFillColor   = _W_,
   }
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   local button = easyIFC:presetPush( sceneGroup, "default", 
                                    centerX + 1 * buttonXOffset, bottom - buttonSize * 1.25, 
                                    buttonSize, buttonSize, "Multiplication", 
                                    onPlay, params )
   button.quiz = "multiply"


   -- DIVISION BUTTON 
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      unselImgSrc       = "images/symbols/divide.png",
      selImgSrc         = "images/symbols/divide.png",
      touchOffset       = {1,2},
      strokeWidth       = 0,
      labelOffset       = { 0, buttonSize/2 + 20 },
      labelFont         = _G.fontB,
      labelSize         = 40,
      labelColor        = _R_,
      unselImgFillColor = _R_,
      selImgFillColor   = _W_,
   }
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   local button = easyIFC:presetPush( sceneGroup, "default", 
                                    centerX + 3 * buttonXOffset, bottom - buttonSize * 1.25, 
                                    buttonSize, buttonSize, "Division", 
                                    onPlay, params )
   button.quiz = "divide"   


end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onPlay = function( event )
   local target = event.target
   --
   local params = { quiz = target.quiz }
   --
   composer.gotoScene( "scenes.play", { time = 500, effect = "crossFade", params = params } )
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene