-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------

----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view

   local lastTimer

   -- Local helper that will cancel the current timer and then go to 'home scene'.
   --
   local function goHome()
      if( lastTimer ) then
         timer.cancel( lastTimer )
         lastTimer = nil
      end
      composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade" } )   
   end

   -- Background Image
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   --local back = newImageRect( sceneGroup, centerX, centerY, "images/protoBackX.png", { w = 1386, h = 720} )
   local back = newImageRect( sceneGroup, centerX, centerY, "images/plainBack.png", { w = 1386, h = 720} )

   -- Touch listener for background image.
   --
   function back.touch( self, event )
      if( event.phase == "ended" ) then 
         goHome( ) 
      end
      return true      
   end
   back:addEventListener( "touch" )

   -- Title
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local title = display.newText( sceneGroup, common.splashTitle, 
                                 centerX, centerY, 
                                 common.splashTitleFont, common.splashTitleSize )
   title:setFillColor( unpack( common.splashTitleFill ) )

   -- By
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local by = display.newText( sceneGroup, common.splashBy, 
                                 centerX, bottom - 80, 
                                 common.splashByFont, common.splashBySize )
   by:setFillColor( unpack( common.splashByFill ) )

   -- Icons
   --
   local size = 55 * 2.5
   local offset = 20
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   local subtract = newImageRect( sceneGroup, left + size/2 + offset, top + size/2 + offset, "images/symbols/subtract.png",
                                 { size = size, fill = _ORANGE_, rotation = -25 } )

   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   local add = newImageRect( sceneGroup, right - size/2 - offset, top + size/2 + offset, "images/symbols/add.png",
                                 { size = size, fill = _PINK_, rotation = -25 } )

   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   local divide = newImageRect( sceneGroup, right - size/2 - offset, bottom - size/2 - offset, "images/symbols/divide.png",
                                 { size = size, fill = _RED_, rotation = 25 } )

   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   local multiply = newImageRect( sceneGroup, left + size/2 + offset, bottom - size/2 - offset, "images/symbols/multiply.png",
                                 { size = size, fill = _YELLOW_, rotation = 25 } )


   -- User timer to wait.  Then, go to home scene if user hasn't clicked yet.
   -- https://docs.coronalabs.com/api/library/timer/performWithDelay.html
   lastTimer = timer.performWithDelay( common.waitTime, function() goHome() end )
end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene