-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common = {}

common.debugEn = false

common.score = 0

common.firstQuestionDelay = 500
common.questionDelay = 1500

--
-- Used on Splash Screen
--
common.waitTime 				= 5000
common.splashTitle 			= "My Super Awesome Quiz Game!"
common.splashTitleFont 		= _G.fontB -- from main.lua
common.splashTitleSize 		= 58
common.splashTitleFill  	= { 1, 1, 0 }

common.splashBy 				= "by Jane Gamemaker"
common.splashByFont 			= _G.fontN -- from main.lua
common.splashBySize 			= 32
common.splashByFill  		= { 1, 1, 1 }

--
-- Used on Menu Screen
--
common.menuTitle 				= "My Super Awesome Quiz Game!"
common.menuTitleFont 		= _G.fontB -- from main.lua
common.menuTitleSize 		= 58
common.menuTitleFill  		= { 1, 1, 0 }

common.menuMessage 			= "Choose Quiz:"
common.menuMessageFont 		= _G.fontN -- from main.lua
common.menuMessageSize 		= 52
common.menuMessageFill  	= { 1, 1, 0 }

--
-- Used on Play Screen
--
common.gameScoreFont 		= _G.fontB -- from main.lua
common.gameScoreSize 		= 44
common.gameScoreFill  		= { 1, 1, 1 }

common.gameQuestionFont 	= _G.fontB -- from main.lua
common.gameQuestionSize 	= 90
common.gameQuestionFill  	= { 1, 1, 1 }

common.gameAnswerFont 		= _G.fontB -- from main.lua
common.gameAnswerSize 		= 80
common.gameAnswerFill  		= { 1, 1, 1 }

return common