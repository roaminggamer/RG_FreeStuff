-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local common         = require "scripts.common"
local quizData 		= require "data.quizzes"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onAnswer

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local content 
local allQuestions
local questionNum
--
local allowAnswerTouches = false
--
local scoreLabel
local questionLabel
local buttons

----------------------------------------------------------------------
-- Module Begins
----------------------------------------------------------------------
local game = {}

--
-- create( group, name ) - Prepare the module to starting a quiz.
--  > group - A display group to put all content into.
--  > name - Name of quiz.  Used to select specific data from quizData table.
--
function game.init( group, name ) 
	-- Store group we were passed as 'content' so it can be used in all module functions.
	-- Default to 'currentStage' if group == nil
	--
	content = group or display.currentStage

	-- Default to 'add' quiz if name is not passed in.	
	name = name or "add"

	-- Reset score
	common.score = 0
	
	-- Start at 0 (not on a question yet)
	questionNum = 0

	-- Copy quiz data from module.
	-- deepCopy() => https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-utilities
	allQuestions = table.deepCopy( quizData[name] or {} ) 

	-- Randomize questions order
	-- shuffle() => https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-utilities
	table.shuffle( allQuestions )

	-- Dump all entries in quiz
	-- https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-debug-features
	if( common.debugEn ) then
		table.print_r(allQuestions)
	end

	--
	-- Draw the Board
	--
	-- Score Label
	scoreLabel = display.newText( content, "SCORE: " .. tostring(common.score), right - 200, top + 50, 
											common.gameScoreFont, common.gameScoreSize )
	scoreLabel.anchorX = 0
	scoreLabel:setFillColor( unpack( common.gameScoreFill ) )	

	-- Question
	questionLabel = display.newText( content, "QUESTION", centerX, centerY - 80, 
												common.gameQuestionFont, common.gameQuestionSize )
	questionLabel:setFillColor( unpack( common.gameQuestionFill ) )
	questionLabel.isVisible = false

	--
	-- Draw Answer Buttons (meteors) and Labels
	--
	buttons = {}
	local buttonSize = 200
	local tweenX = fullw/4
	local curX = centerX - tweenX

	for i = 1, 3 do		
	   --
	   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
	   local params = {
	      unselImgSrc       = "images/kenney/meteor" .. i .. ".png",
	      selImgSrc         = "images/kenney/meteor" .. i .. ".png",
	      touchOffset       = {1,2},
	      strokeWidth       = 0,
	      labelFont         = common.gameAnswerFont,
	      labelSize         = common.gameAnswerSize,
	      labelColor        = common.gameAnswerFill,
	      unselImgFillColor = _W_,
	      selImgFillColor   = _W_,
	   }
	   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
	   local button = easyIFC:presetPush( sceneGroup, "default", 
	   											curX, bottom - buttonSize/2 - 50,
	                                    buttonSize, buttonSize, tostring(i), 
	                                    onAnswer, params )
	   button.answerNum = i
	   --
	   button.isVisible = false
	   --
	   buttons[i] = button
	   --		
		curX = curX + tweenX
	end

end

--
-- next() - Display next question.
--
function game.next()	
	-- Increment Question
	questionNum = questionNum + 1
	if( common.debugEn ) then
		print( "game.next() questionNum == " .. tostring(questionNum) )
	end

	-- Check if we are out of questions. If we are, pop up 
	-- end of quiz summary.
	if( #allQuestions < questionNum ) then
		game.over()
		return
	end

	-- Get the current question data.
	local currentQuestion = allQuestions[questionNum]

	-- Dump current question data to console.
	-- https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-debug-features
	if( common.debugEn ) then
		table.print_r(currentQuestion)
	end

	--
	-- Fill in questionLabel and update answer buttons
	--
	questionLabel.text = currentQuestion.text .. " = ? "
	questionLabel.isVisible = true
	
	-- Create table of answer button indexes then randomize it
	local answerButtonNum = { 1, 2, 3 }
	table.shuffle(answerButtonNum)
	
	-- Assign answers to buttons, selecting indexes from random table above
	for i = 1, 3 do
		local num = answerButtonNum[i]
		--
		local button = buttons[num]
		--
		button.isVisible = true
		-- 
		button:setText( currentQuestion.answers[i] )
		-- 
		button.isCorrect = (i == 1)
	end

	-- Allow answer touches
	allowAnswerTouches = true
end

--
-- over() - Called when game is complete to show score and percentage correct.
--
function game.over()
	if( common.debugEn ) then
		print( "game.over() "  )
		print( "Score: " .. tostring(common.score)  )
		print( common.score, #allQuestions, 100 * common.score / #allQuestions )
		print( "%" .. tostring( math.floor( 100 * common.score / #allQuestions ) ) .. " correct" )
	end

	-- Do not allow answer touches
	allowAnswerTouches = false

	-- Hide answer buttons.
	buttons[1].isVisible = false
	buttons[2].isVisible = false
	buttons[3].isVisible = false

	-- Move question label.
	questionLabel.y = centerY

	-- Change question label value to show results.
	questionLabel.text = "Game Over - Got " .. 
	                    	tostring( math.floor( 100 * common.score / #allQuestions ) ) .. 
	                    	"% Correct" 

end

--
-- destroy() - Destroy all game content and clean up.
--
function game.destroy() 
	display.remove( content )
	content = nil	
	--
	scoreLabel = nil
	questionLabel = nil
	buttons = nil
	
	-- Do not allow answer touches
	allowAnswerTouches = false

end

--
-- Common answer buttons touch listener
--
onAnswer = function( event )
	-- Ignore if touches disabled.
	if( not allowAnswerTouches ) then 
		return false 
	end
	--
	if( event.phase == "ended" ) then
		-- Temporarily stop allowing touches
		allowAnswerTouches = false

		-- See if this was the correct answer
		local isCorrect = event.target.isCorrect
		
		if( isCorrect ) then
			questionLabel.text = "CORRECT!"
			common.score = common.score + 1
			scoreLabel.text = "SCORE: " .. tostring(common.score)			
		else
			questionLabel.text = "INCORRECT!"			
		end

		-- Wait N seconds, then show next question
		timer.performWithDelay( common.questionDelay, game.next )

	end
	return false
end

return game