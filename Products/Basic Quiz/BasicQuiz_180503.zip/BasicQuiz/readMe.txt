This template contains two variations:

v1 - Made for quizzes with only ONE correct answer.

v2 - Made for quizzes with an arbitrary number of correct and incorrect answers, where the player must select ALL of the correct answers to get the full score.

Both quizzes are set up to handle a total of FOUR answers per question.  Have more than four may code changes.