-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local common         = require "scripts.common"
local quizData 		= require "data.quizzes"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onAnswer

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local content 
local allQuestions
local questionNum
--
local allowAnswerTouches = false
--
local maxScoreLabel
local scoreLabel
local questionBack
local questionLabel
local buttons
local okButton

----------------------------------------------------------------------
-- Module Begins
----------------------------------------------------------------------
local game = {}

--
-- create( group, name ) - Prepare the module to starting a quiz.
--  > group - A display group to put all content into.
--  > name - Name of quiz.  Used to select specific data from quizData table.
--
function game.init( group, name ) 
	-- Store group we were passed as 'content' so it can be used in all module functions.
	-- Default to 'currentStage' if group == nil
	--
	content = group or display.currentStage

	-- Default to 'add' quiz if name is not passed in.	
	name = name or "add"
   print( "Running Quiz: " .. tostring( name ))

	-- Reset scores
	common.score = 0
	common.maxScore = 0
	
	-- Start at 0 (not on a question yet)
	questionNum = 0

	-- Copy quiz data from module.
	-- deepCopy() => https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-utilities

	allQuestions = table.deepCopy( quizData[name] or {} ) 

	-- Randomize questions order
	-- shuffle() => https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-utilities
	table.shuffle( allQuestions )

	-- Dump all entries in quiz
	-- https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-debug-features
	if( common.debugEn ) then
		table.print_r(allQuestions)
	end


	--
	-- Draw the Board
	--
	-- Score Label
	scoreLabel = display.newText( content, "SCORE: " .. tostring(common.score), right - 240, top + 50, 
											common.gameScoreFont, common.gameScoreSize )
	scoreLabel.anchorX = 0
	scoreLabel:setFillColor( unpack( common.gameScoreFill ) )	

	-- Max Label
	maxScoreLabel = display.newText( content, "POSSIBLE: " .. tostring(common.score), right - 240, scoreLabel.y + 50, 
											common.gameScoreFont, common.gameScoreSize )
	maxScoreLabel.anchorX = 0
	maxScoreLabel:setFillColor( unpack( common.gameScoreFill ) )	

	-- Question + Background Rectangle
	questionBack = newRect( content, centerX, bottom - 47, 
		                          { w = 340, h = common.gameQuestionSize + 20, 
		                            fill = _K_, stroke = common.gameQuestionFill, strokeWidth = 3,
		                            isVisible = false } )
	questionLabel = display.newText( content, "QUESTION", centerX, bottom - 50, 
												common.gameQuestionFont, common.gameQuestionSize )
	questionLabel:setFillColor( unpack( common.gameQuestionFill ) )
	questionLabel.isVisible = false

	--
	-- Draw Answer Buttons (meteors) and Labels
	--
	buttons = {}
	local buttonSize = 200
	local tweenX = fullw/4
	local curX = centerX - tweenX * 1.5
	local scale = 0.30

	for i = 1, 4 do		
	   --
	   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
	   local params = {
	      unselImgSrc       = "images/starfish.png",
	      selImgSrc         = "images/starfish.png",
	      touchOffset       = {1,2},
	      strokeWidth       = 0,
	      labelFont         = common.gameAnswerFont,
	      labelSize         = common.gameAnswerSize,
	      labelColor        = common.gameAnswerFill,
	      unselImgFillColor = _DARKGREY_,
	      selImgFillColor   = _W_,
	   }
	   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
	   local button = easyIFC:presetToggle( content, "default", 
	   											curX, centerY - 50,
	                                    767 * scale, 753 * scale, "", 
	                                    nil, params )
	   button.answerNum = i
	   --
	   button.isVisible = true
	   --
	   buttons[i] = button
	   --		
		curX = curX + tweenX		
	end

	--
	-- OK button - User presses this when they think they have all the right
	-- answers selected.
	--
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      labelColor           = { 1, 1, 0 },
      labelSize            = 58,
      abelFont            = _G.fontB, -- using bold font from main.lua
      labelOffset          = {0, -4},
      unselRectFillColor   = { 0.25, 0.25, 0.25 },
      selRectFillColor     = { 0.35, 0.35, 0.35 },
      --strokeWidth          = 0,
      --emboss               = false,
      --touchOffset         = {1,2},
   }

	okButton = easyIFC:presetPush( content, "default", 
                                    centerX, centerY + 150, 
                                    80, 80,
                                    "OK", onAnswer, params )
	okButton.isVisible = false


end

--
-- next() - Display next question.
--
function game.next()	
	-- Increment Question
	questionNum = questionNum + 1
	if( common.debugEn ) then
		print( "game.next() questionNum == " .. tostring(questionNum) )
	end

	-- Check if we are out of questions. If we are, pop up 
	-- end of quiz summary.
	if( #allQuestions < questionNum ) then
		game.over()
		return
	end

	-- Get the current question data.
	local currentQuestion = allQuestions[questionNum]

	-- Dump current question data to console.
	-- https://roaminggamer.github.io/RGDocs/pages/SSK2/extensions/#table-debug-features
	if( common.debugEn ) then
		table.print_r(currentQuestion)
	end

	--
	-- Fill in questionLabel and update answer buttons
	--
	questionLabel.text = currentQuestion.text .. " ? "
	questionLabel.isVisible = true
	questionBack.isVisible = true

	-- Shuffle answers to randomize them
	table.shuffle(currentQuestion.answers)

	-- De-toggle all buttons
	-- Also enable/disable buttons based on answer count
	for i = 1, #buttons do
		if(buttons[i]:pressed()) then
			buttons[i]:toggle()
		end
		--
		if( i <= #currentQuestion.answers ) then
			buttons[i]:enable()
		else
			buttons[i]:disable()
		end
		--
		buttons[i]:setText("")
	end

	-- Assign answers to buttons, selecting indexes from random table above
	for i = 1, #currentQuestion.answers do
		local button = buttons[i]
		-- 
		button:setText( currentQuestion.answers[i][1] )
		-- 
		button.isCorrect = currentQuestion.answers[i][2]
	end

	-- Show OK Button
	okButton.isVisible = true

	-- Allow answer touches
	allowAnswerTouches = true
end

--
-- over() - Called when game is complete to show score and percentage correct.
--
function game.over()
	if( common.debugEn ) then
		print( "game.over() "  )
		print( "Score: " .. tostring(common.score)  )
		print( common.score, #allQuestions, 100 * common.score / #allQuestions )
		print( "%" .. tostring( math.floor( 100 * common.score / #allQuestions ) ) .. " correct" )
	end

	-- Hide OK Button
	okButton.isVisible = false

	-- Do not allow answer touches
	allowAnswerTouches = false

	-- Hide answer buttons.
	buttons[1].isVisible = false
	buttons[2].isVisible = false
	buttons[3].isVisible = false
	buttons[4].isVisible = false

	-- Hide Question Back (not needed any more)
	questionBack.isVisible = false

	-- Move question label.
	questionLabel.y = centerY

	-- Change question label value to show results.
	questionLabel.text = "Game Over - Got " .. 
	                    	tostring( math.floor( 100 * common.score / common.maxScore ) ) .. 
	                    	"% Correct" 

end

--
-- destroy() - Destroy all game content and clean up.
--
function game.destroy() 
	display.remove( content )
	content = nil	
	--
	scoreLabel = nil
	maxScoreLabel = nil
	questionLabel = nil
	questionBack = nil
	buttons = nil
	okButton = nil

	-- Do not allow answer touches
	allowAnswerTouches = false

end

--
-- Common answer buttons touch listener
--
onAnswer = function( event )
	-- Ignore if touches disabled.
	if( not allowAnswerTouches ) then 
		return false 
	end
	--
	if( event.phase == "ended" ) then
		-- Temporarily stop allowing touches
		allowAnswerTouches = false

		-- Add up max possible correct 
      -- and total correct.
      -- 
		local maxCorrect = 0
		local totalCorrect = 0

		for i = 1, #buttons do
			if( buttons[i].isCorrect ) then
				maxCorrect = maxCorrect + 1
				if( buttons[i]:pressed() ) then
					totalCorrect = totalCorrect + 1
				else
					-- take away points for wrong answers
					--totalCorrect = totalCorrect - 1
				end
			else
				if( buttons[i]:pressed() ) then
					-- take away points for wrong answers
					--totalCorrect = totalCorrect - 1
				end 
			end
		end

		-- Update scores and labels
		common.score = common.score + totalCorrect
		scoreLabel.text = "SCORE: " .. tostring(common.score)			

		common.maxScore = common.maxScore + maxCorrect
		maxScoreLabel.text = "MAX: " .. tostring(common.maxScore)			

		if( totalCorrect == maxCorrect ) then
			questionLabel.text = "ALL CORRECT!"
		
		elseif( totalCorrect > 0 ) then
			questionLabel.text = "SOME CORRECT"
		else
			questionLabel.text = "ALL WRONG..."			
		end

		-- Wait N seconds, then show next question
		timer.performWithDelay( common.questionDelay, game.next )

	end
	return false
end

return game