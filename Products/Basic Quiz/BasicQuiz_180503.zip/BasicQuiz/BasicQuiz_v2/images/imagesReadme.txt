The images in this template are from these sites:

> https://dribbble.com/shots/1512391-Sidescroller-Game-Background-Under-the-Ocean

https://openclipart.org/detail/177911/starfish

As far as I can tell they are free to use, but I would verify this before releasing a game using them.