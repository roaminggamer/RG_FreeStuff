-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================

TEMPLATE SUMMARY
================
This is a basic quiz starter.  That is display ready and compatible with mobile and desktop dimensions.

It implements a math quiz, where 

Questions and answers are easily added and modified.  They can even be generated with a little work.

If you have purchased it, you may use it to make one (1) FREE or PAID game.  

USES SSK2
=========
This template uses the SSK 2 library to speed and simplify development.

SSK2 Docs are available here: https://roaminggamer.github.io/RGDocs/pages/SSK2/


CONTAINS
========

main.lua 				- Main entry point for Corona games.
config.lua 				- Display configuration file
build.settings 		- Build settings file.
data\ 					- Tables of questions and answers
fonts\					- Fonts used in game.
images\ 					- Images used in game.
scenes\ 					- composer.* scene files,
scenes\splash.lua 	- Splash Screen
scenes\home.lua 		- Main Menu
scenes\play.lua 		- Play GUI
scripts\					- Game scripts.
scripts\common.lua	- Unified game settings file that controls many debug and visual elemets of game.
scripts\game.lua     - Game module.
ssk\ 						- Super starter kit 2 helper modules and libraries. (https://roaminggamer.github.io/RGDocs/pages/SSK2/)

-------------------------------------------------------------------------------
Language                     files          blank        comment           code
-------------------------------------------------------------------------------
Lua                             12            160            388            584
-------------------------------------------------------------------------------
* SSK excluded from counts.


BASIC STEPS TO MODIFY
=====================

Adding Questions
----------------
1. Open data/easy1, easy2, hard1, hard2.lua and follow the directions at the top of the files.
2. If you rename the quizzes or add more, edit data/quizzes.lua and be sure to modify the require statements.

Changing Art
------------
+ Splash Screen - Edit scenes/splash.lua and change art in images/ folder.
+ Home Screen - Edit scenes/home.lua and change art in images/ folder.
+ Play Screen - Edit scenes/play.lua and change art in images/ folder and sub-folders.
+ Game - Edit scripts/game.lua and change art in images/ folder and sub-folders.

