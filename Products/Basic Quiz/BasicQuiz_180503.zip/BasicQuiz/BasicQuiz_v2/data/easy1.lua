-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local data = {}
--[[ 
===============================================================
                    *** HOW TO ADD QUESTIONS: ***
===============================================================
1. Create new question table
local question = {} 

2. Insert question table into data table at next position:
data[#data+1] = question

3. Specify question text as string.
question.question = "X + 2 > 5"

4. Specify answers as table, of tables. 
> First entry in each sub-table is what is printed.
> Second entry is whether answer is correct or not
question.answers = { 
	{ 1, false },  -- an incorrect answer
	{ 3, false },  -- an incorrect answer
	{ 4, true },  -- a correct answer
	{ 5, true },  -- a correct answer
}

===============================================================
--]]

--
local question = {}
data[#data+1] = question
question.text = "X + 2 > 5"
question.answers = { 
	{ 1, false },  -- an incorrect answer
	{ 3, false },  -- an incorrect answer
	{ 4, true },  -- a correct answer
	{ 5, true },  -- a correct answer
}


--
local question = {}
data[#data+1] = question
question.text = "X - 2 > 2"
question.answers = { 
	{ 1, false },  -- an incorrect answer
	{ 3, false },  -- an incorrect answer
	{ 4, false },  -- a correct answer
	{ 5, true },  -- a correct answer
}

return data