-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local quizzes = {}
quizzes.easy1 	= require "data.easy1"
quizzes.easy2 	= require "data.easy2"
quizzes.hard1 	= require "data.hard1"
quizzes.hard2 	= require "data.hard2"
return quizzes