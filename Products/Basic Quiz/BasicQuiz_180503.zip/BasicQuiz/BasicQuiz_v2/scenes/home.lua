-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onPlay

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local buttonXOffset = w/8
local buttonSize = 55 * 3;



----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view

   -- Background Image
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   --local back = newImageRect( sceneGroup, centerX, centerY, "images/protoBackX.png", { w = 1386, h = 720} )
   local back = newImageRect( sceneGroup, centerX, centerY, "images/plainBack.png", { w = 1386, h = 720} )

   -- Title
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local title = display.newText( sceneGroup, common.menuTitle, 
                                 centerX, top + 50,
                                 common.menuTitleFont, common.menuTitleSize )
   title:setFillColor( unpack( common.menuTitleFill ) )


   -- Message
   --
   -- https://docs.coronalabs.com/api/library/display/newText.html
   local message = display.newText( sceneGroup, common.menuMessage, 
                                 centerX, top + 130, 
                                 common.menuMessageFont, common.menuMessageSize )
   message:setFillColor( unpack( common.menuMessageFill ) )


   --
   -- Buttons
   --
   local quizzes = { 
      {  "Easy Set 1", "easy1" },
      {  "Easy Set 2", "easy2" },
      {  "Hard Set 1", "hard1" },
      {  "Hard Set 2", "hard2" },
   }

   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      labelColor           = { 1, 1, 0 },
      labelSize            = 58,
      abelFont            = _G.fontB, -- using bold font from main.lua
      labelOffset          = {0, -4},
      unselRectFillColor   = { 0.25, 0.25, 0.25 },
      selRectFillColor     = { 0.35, 0.35, 0.35 },
      --strokeWidth          = 0,
      --emboss               = false,
      --touchOffset         = {1,2},
   }


   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   -- 
   local curY           = top + 200
   local tweenY         = 65
   local buttonWidth    = 320
   local buttonHeight   = 60

   for i = 1, #quizzes do
      local button = easyIFC:presetPush( sceneGroup, "default", 
                                    centerX, curY, 
                                    buttonWidth, buttonHeight,
                                    quizzes[i][1], 
                                    onPlay, params )
      button.quiz = quizzes[i][2]
      --
      curY = curY + tweenY
   end
end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onPlay = function( event )
   local target = event.target
   --
   local params = { quiz = target.quiz }
   --
   composer.gotoScene( "scenes.play", { time = 500, effect = "crossFade", params = params } )
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene