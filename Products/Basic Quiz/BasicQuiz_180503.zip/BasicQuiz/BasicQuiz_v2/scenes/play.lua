-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"
local game           = require "scripts.game"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onHome

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local content

----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   table.print_r(event)
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view

   -- Get requested quiz name from event params
   local name = event.params.quiz or "add"
   -- Create new group to contain new content
   content = display.newGroup()
   sceneGroup:insert(content)

   -- Background Image
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/display_standard/#newimagerect
   --local back = newImageRect( content, centerX, centerY, "images/protoBackX.png", { w = 1386, h = 720} )
   local back = newImageRect( content, centerX, centerY, "images/plainBack.png", { w = 1386, h = 720} )

   -- Initialize New Game
   game.init( content, name )

   -- Create Back/Home Button Over Game Content
   --
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-parameters
   local params = {
      unselImgSrc       = "images/kenney/arrowLeft.png",
      selImgSrc         = "images/kenney/arrowLeft.png",
      touchOffset       = {1,2},
      strokeWidth       = 0,
      labelColor        = _W_,
      unselImgFillColor = _W_,
      selImgFillColor   = _W_,
   }
   -- https://roaminggamer.github.io/RGDocs/pages/SSK2/libraries/easy_interfaces/#button-factories
   local button = easyIFC:presetRadio( content, "default", left + 50, top + 50, 
                                       100, 100, "", onHome, params )
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view

   -- Show First Question
   timer.performWithDelay( common.firstQuestionDelay, game.next )
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view

   -- Destory game
   game.destroy() 
   
   -- Destroy any remaining content
   display.remove( content )
   content = nil

end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onHome = function( event )
   composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade"} )
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene