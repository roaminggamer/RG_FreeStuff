application = {
	content = {
	    graphicsCompatibility = 1, 
		width = 320,
		height = 480, 
		scale = "letterBox", -- Good in some cases
		--scale = "zoomStretch", -- Good in other cases
		--scale = "zoomEven", -- blehh!
		--scale = "none", -- blehh!
		--antialias = true, -- weird effect on backImage... hmm
		--[[		
		--fps = 90,
		--fps = 30,
		imageSuffix = {
			["@2x"] = 1.8, -- Force 2X to work for 1.8X and higher situations
		},
		--]]

	},
}