==============================================================================

Roaming Gamer, LLC "Game Template Package" for the game:	Jigsaw Puzzle

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Tips / FAQ - Miscellaneous tips to help you with changing the template, as
   well as answers to question(s) you might have.

D. Reporting Bugs - How to report bugs with this template.

==============================================================================

A. Short and Sweet License 
==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).



2. You MAY NOT:

   - sell or distribute the source code from this package.


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.




B. What's in the template package?
==================================


In this package you will find five (5) versions of of the game and two how-to guides:

How-to Guides
-------------
* GeneralRef.pdf ==> A short document talking about some important topics, including: Corona SDKs framework library, SSKCorona, and the player data class (from SSKCorona).
* MakingRectangularPuzzlePieces.pdf ==> A quick guide to making your own RECTANGULAR puzzle pieces.
* MakingJigsawPuzzlePieces.pdf ==> A quick guide to making your own JIGSAW puzzle pieces.



Pure x 3+
--------
* Jigsaw 1 (Rectangular Pieces) - Pure  ==> A very basic Jigsaw Puzzle game made with Lua and the Corona SDK.  This puzzle uses rectangular puzzle pieces.
* Jigsaw 2 (Jigsaw Shapes) - Pure ==> A very basic Jigsaw Puzzle game made with Lua and the Corona SDK.  This puzzle uses jigsaw (irregular) puzzle pieces.

* Jigsaw 6 (Rectangular + Jigsaw Pieces) - Pure  (module)  ==> 1 and 2 above converted to moudular forms.

* Jigsaw 7 (Rectangular + Jigsaw Pieces + SP Frame) - Hybrid  ==> Jigsaw 6 with slimmed down version of SSKCorona SP Game Frame to produce complete game.



SSK x 4
-------
* Jigsaw 3 (Rectangular Pieces) - SSK ==> Similar to 'Jigsaw 1 (Rectangular Pieces) - Pure', but made with Lua and the Corona SDK + SSKCorona. (Has a little more art + sounds.)
* Jigsaw 4 (Jigsaw Shapes) - SSK      ==> Similar to 'Jigsaw 2 (Jigsaw Shapes)', but made with Lua and the Corona SDK + SSKCorona. (Has a little more art + sounds.)

* Jigsaw 5 (Rectangular + Jigsaw Pieces) - SSK (module) ==> main.lua from 'Jigsaw 3 ...' and 'Jigsaw 4 ...' converted into modules, then used to run the game.
                                                            This version also adds the ability to destroy the board (for cleanup purposes).

* Jigsaw 8 (Rectangular + Jigsaw Pieces + SP Frame) - SSK ==> Jigsaw 5 with slimmed down version of SSKCorona SP Game Frame to produce complete game.



Warning! - Versions 7 and 8 are a bit complex, so take your time working through them.

													   
C. Tips / FAQ
=============
* Before you modify the SSK version - The SSK version of the game includes a copy of the 
SSK library.  However, it is sure to be out of date.  So, be sure to get the latest version 
here: https://github.com/roaminggamer/SSKCorona


* SSKCorona Wiki - There is a free quick reference to SSKCorona here: https://github.com/roaminggamer/SSKCorona/wiki

* Question: "Where can I go to get more template?" 
    Answer: The Roaming Gamer, LLC. website of course: http://roaminggamer.com/
	

D. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please write me here: 

roaminggamer@gmail.com 

Be sure to include this information in your e-mail:

e-mail Title: Template Bug: Jigsaw Puzzle

e-mail Body:

Tell me these details,
	- What you did, 
	- What you expected to see, and 
	- What happened instead.

Please provide any other details about the bug that seem pertinent.


Thanks,

The Roaming Gamer



