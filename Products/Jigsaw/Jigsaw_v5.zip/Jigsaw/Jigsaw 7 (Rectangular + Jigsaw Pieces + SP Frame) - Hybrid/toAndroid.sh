#!/bin/bash
rm -f ./icon*.png
cp ssk/appicons/Android/*.png .
