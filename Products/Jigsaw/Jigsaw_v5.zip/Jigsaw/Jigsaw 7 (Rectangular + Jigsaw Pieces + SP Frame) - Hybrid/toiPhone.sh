#!/bin/bash
rm -f ./icon*.png
cp ssk/appicons/iPhone/*.png .
