-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- SSKCorona Sampler Main Menu
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================
local storyboard = require( "storyboard" )
local scene      = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local screenGroup

local puzzleMode = "Jigsaw"
local puzzleName = "dogs"

local jigsawPuzzleNames = { "dogs", "starrynight" }
local rectangularPuzzleNames = { "dogs", "starrynight", "amsterdam", "brugges", "cave" }

local puzzleNameIndex = 1

local previewPiece

-- Callbacks/Functions

local onMode
local onChoose
local onPlay
local onCredits
local onOptions
local onGameTemplates
local onSSKCorona

----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------

----------------------------------------------------------------------
function scene:createScene( event )
	screenGroup = self.view

	-- Background Image
	ssk.display.backImage( screenGroup, "bruggeBack.png" ) 

	-- ==========================================
	-- Buttons and Labels
	-- ==========================================
	local curY          = 30
	local buttonSpacing = 45
	local buttonWidth   = 160
	local buttonHeight  = 40
	local tmpButton
	local tmpLabel

	-- Game Label / Name
	ssk.labels:quickLabel( screenGroup, "Jigsaw Puzzle Template", centerX+10, 24, gameFont, 36, _BLACK_)

	-- Puzzle Mode Radio Buttons
	local radioGroup = display.newGroup() 
	screenGroup:insert(radioGroup)
	curY = curY + 50 
	ssk.buttons:presetRadio( radioGroup, "blueButton", centerX - buttonWidth/2 - 10 , curY, buttonWidth, buttonHeight,  "Jigsaw", onMode )
	tmpButton = ssk.buttons:presetRadio( radioGroup, "blueButton", centerX + buttonWidth/2 + 10, curY, buttonWidth, buttonHeight,  "Rectangular", onMode )
	tmpButton:toggle()

	-- Show a preview piece based on puzzle mode and current puzzle piece number
	curY = 190
	ssk.display.rect( screenGroup, 160, curY, {w = 260, h = 126, stroke = _DARKERGREY_, strokeWidth = 2 } )

	if( puzzleMode == "Jigsaw" ) then
		previewPiece = ssk.display.imageRect( screenGroup, 100, curY, "images/jig/" .. puzzleName .. "/2.png", {size = 120 } )
	else
		previewPiece = ssk.display.imageRect( screenGroup, 100, curY, "images/slices/" .. puzzleName .. "/5.png", {size = 120 } )
	end

	ssk.buttons:presetPush( screenGroup, "blueButton", centerX - 16, curY - buttonHeight + 10, 120, buttonHeight,  "Next", onChoose )
	ssk.buttons:presetPush( screenGroup, "blueButton", centerX - 16, curY + buttonHeight - 10, 120, buttonHeight,  "Prev", onChoose )

	-- PLAY 
	curY = curY - 45 
	ssk.buttons:presetPush( screenGroup, "greenButton", centerX+140, curY, buttonWidth, buttonHeight,  "Play", onPlay )

	-- OPTIONS
	curY = curY + buttonSpacing 
	ssk.buttons:presetPush( screenGroup, "blueButton", centerX+140, curY, buttonWidth, buttonHeight,  "Options", onOptions ) 

	-- CREDITS
	curY = curY + buttonSpacing 
	ssk.buttons:presetPush( screenGroup, "blueButton", centerX+140, curY, buttonWidth, buttonHeight,  "Credits", onCredits ) 

	-- Game Templates Badge
	ssk.buttons:presetPush( screenGroup, "GTButton", 70, h-20, 130, 40, "", onGameTemplates  )

	-- SSKCorona Badge
	ssk.buttons:presetPush( screenGroup, "SSKButton", w-90, h-20, 130, 40, "", onSSKCorona  )

end

----------------------------------------------------------------------
function scene:destroyScene( event )
	screenGroup = self.view

	previewPiece = nil
end


----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------
onMode = function (event)
	-- 1. Set puzzle mode to the text on this button
	--
	puzzleMode = event.target:getText()

	-- 2.  Reset to the first puzzle name
	--
	puzzleNameIndex =  1
	puzzleName      = "dogs"

	-- 3. Draw a new puzzle piece 
	--
	-- Tip: Won't do anything on first toggle() because no image has been created yet.
	--
	if( previewPiece ) then

		previewPiece:removeSelf() -- Destroy the old picture first

		if( puzzleMode == "Jigsaw" ) then
			previewPiece = ssk.display.imageRect( screenGroup, 100, 190, "images/jig/" .. puzzleName .. "/2.png", {size = 120 } )
		else
			previewPiece = ssk.display.imageRect( screenGroup, 100, 190, "images/slices/" .. puzzleName .. "/5.png", {size = 120 } )
		end

	end

	print("New puzzle mode == ", puzzleMode)

end

onChoose = function (event)

	-- Get the 'direction' from the buttons label/text
	--
	local direction = event.target:getText()

	-- 2. Increment or decrement based on 'direction'
	--
	if( direction == "Next" ) then
		puzzleNameIndex = puzzleNameIndex + 1
	
	else -- Prev
		puzzleNameIndex = puzzleNameIndex - 1

	end

	-- 3. Adjust index to be sure it is valid (points to a entry in the current name table)
	--
	if( puzzleMode == "Jigsaw" ) then
		if(puzzleNameIndex > #jigsawPuzzleNames) then
			puzzleNameIndex = 1
		end
		if(puzzleNameIndex < 1) then
			puzzleNameIndex = #jigsawPuzzleNames
		end

	else
		if(puzzleNameIndex > #rectangularPuzzleNames) then
			puzzleNameIndex = 1
		end
		if(puzzleNameIndex < 1) then
			puzzleNameIndex = #rectangularPuzzleNames
		end
	end

	-- 4. Get the new puzzle name
	--
	if( puzzleMode == "Jigsaw" ) then
		puzzleName = jigsawPuzzleNames[puzzleNameIndex]		
	else		
		puzzleName = rectangularPuzzleNames[puzzleNameIndex]
	end

	-- 5. Draw a new puzzle piece
	--	
	previewPiece:removeSelf() -- Destroy the old picture first

	if( puzzleMode == "Jigsaw" ) then
		previewPiece = ssk.display.imageRect( screenGroup, 100, 190, "images/jig/" .. puzzleName .. "/2.png", {size = 120 } )
	else
		previewPiece = ssk.display.imageRect( screenGroup, 100, 190, "images/slices/" .. puzzleName .. "/5.png", {size = 120 } )
	end


end


onPlay = function ( event ) 
	local options =
	{
		effect = "slideLeft",
		time = 300,
		params =
		{
			puzzleMode = puzzleMode,
			puzzleName = puzzleName,
		}
	}

	storyboard.gotoScene( "interfaces.playGUI", options  )	

	return true
end

onOptions = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 200,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.options", options  )	

	return true
end

onCredits = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 400,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.credits", options  )	

	return true
end


onGameTemplates = function ( event ) 
	system.openURL( "http://roaminggamer.com/makegames"  )
	return true
end

onSSKCorona = function ( event ) 
	system.openURL( "http://roaminggamer.com/sskcorona"  )
	return true
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "willEnterScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
scene:addEventListener( "destroyScene", scene )
scene:addEventListener( "overlayBegan", scene )
scene:addEventListener( "overlayEnded", scene )
---------------------------------------------------------------------------------

return scene
