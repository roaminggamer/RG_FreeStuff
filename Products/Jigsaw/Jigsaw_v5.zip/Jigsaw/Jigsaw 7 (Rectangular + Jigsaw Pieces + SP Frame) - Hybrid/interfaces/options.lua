-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- SSKCorona Sampler Main Menu
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================

local storyboard = require( "storyboard" )
local scene      = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local screenGroup
local objs

-- Callbacks/Functions
local onSoundEffectsEnable
local onMusicEnable
local onEffectsVolumeUpdate
local onMusicVolumeUpdate
local onMusicVolumeDraggingUpdate
local onBack

----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------
function scene:createScene( event )
	screenGroup = self.view

	objs = {} 

	-- Background Image
	objs.backImage   = ssk.display.backImage( screenGroup, "bruggeBack2.png" ) 

	-- ==========================================
	-- Buttons and Labels
	-- ==========================================
	local curY = 30
	local tmpButton
	local tmpLabel

	-- Page Title 
	ssk.labels:quickLabel( screenGroup, "Options", centerX, curY, gameFont, 48, _BLACK_ )

	-- (Sound) Effects On/Off Toggle
	curY = curY + 50
	objs.effectsEnableToggle = ssk.buttons:presetToggle( screenGroup, "checkGel", 60, curY, 30, 30, "", ssk.sbc.tableToggler_CB )
	objs.effectsEnableToggle.hasToggled = false -- Add a flag to allow us to ignore first toggle


	tmpLabel = ssk.labels:quickLabel( screenGroup, "Sound Effects", centerX, curY, gameFont, 18, _BLACK_ )
	tmpLabel.x = objs.effectsEnableToggle.x + objs.effectsEnableToggle.width/2 + tmpLabel.width/2 + 25

	-- (Sound) Effects Volume Slider
	curY = curY + 40
	objs.effectVolumeSlider = ssk.buttons:quickHorizSlider2( centerX, curY, w  - 120, 16, 
											            "interface/trackGelHoriz",
														ssk.sbc.horizSlider2Table_CB, onEffectsVolumeUpdate,
														imagesDir .. "interface/thumbGelHoriz", 40, 29,
														screenGroup )
	ssk.sbc.prep_horizSlider2Table( objs.effectVolumeSlider, currentPlayer, "effectsVolume", nil )


	-- Note: I defered this prep because it may cause an update that affects the sound effects volume slider 
	ssk.sbc.prep_tableToggler( objs.effectsEnableToggle, currentPlayer, "effectsEnabled", onSoundEffectsEnable )


	-- Music On/Off Toggle
	curY = curY + 50
	objs.musicEnableToggle = ssk.buttons:presetToggle( screenGroup, "checkGel", 60, curY, 30, 30, "", ssk.sbc.tableToggler_CB )

	tmpLabel = ssk.labels:quickLabel( screenGroup, "Soundtrack", centerX, curY, gameFont, 18, _BLACK_ )
	tmpLabel.x = objs.musicEnableToggle.x + objs.musicEnableToggle.width/2 + tmpLabel.width/2 + 25


	-- Music Volume Slider
	curY = curY + 40
	objs.musicVolumeSlider = ssk.buttons:quickHorizSlider2( centerX, curY, w  - 120, 16, 
											            "interface/trackGelHoriz",
														ssk.sbc.horizSlider2Table_CB, onMusicVolumeUpdate,
														imagesDir .. "interface/thumbGelHoriz", 40, 29,
														screenGroup )
	ssk.sbc.prep_horizSlider2Table( objs.musicVolumeSlider, currentPlayer, "musicVolume", onMusicVolumeDraggingUpdate ) 

	--objs.musicVolumeSlider:disable()


	-- Note: I defered this prep because it may cause an update that affects the music volume slider 
	ssk.sbc.prep_tableToggler( objs.musicEnableToggle, currentPlayer, "musicEnabled", onMusicEnable )


	-- BACK 
	curY = h - 25
	ssk.buttons:presetPush( screenGroup, "yellowButton", 60 , curY, 100, 40,  "Back", onBack )
end


function scene:destroyScene( event )
	screenGroup = self.view

	objs = nil
end


----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------

onSoundEffectsEnable = function (event)
	local target = event.target

	if(target:pressed() ) then
		objs.effectVolumeSlider:enable()

		if(not target.hasToggled) then
			target.hasToggled = true
		else
			ssk.sounds:play("puzzleclick")
		end
		
	else
		objs.effectVolumeSlider:disable()

		if(not target.hasToggled) then
			target.hasToggled = true
		end

	end

	saveCurrentPlayer()

	return false
end


onMusicEnable = function (event)
	local target = event.target

	if(target:pressed() ) then
		objs.musicVolumeSlider:enable()
		ssk.sounds:play("soundtrack")
	else
		objs.musicVolumeSlider:disable()
		ssk.sounds:stop("soundtrack")
	end

	saveCurrentPlayer()

	return false
end


onEffectsVolumeUpdate = function( event )
	local target = event.target
	saveCurrentPlayer()
	ssk.sounds:setEffectsVolume(target:getValue())
	ssk.sounds:play("puzzleclick")
	return false
end

onMusicVolumeDraggingUpdate = function( event )
	local target = event.target
	ssk.sounds:setMusicVolume(target:getValue())
	return false
end

onMusicVolumeUpdate = function( event )
	local target = event.target
	ssk.sounds:setMusicVolume(target:getValue())
	saveCurrentPlayer()
	return false
end


onBack = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 200,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.mainMenu", options  )	

	return true
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "willEnterScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
scene:addEventListener( "destroyScene", scene )
scene:addEventListener( "overlayBegan", scene )
scene:addEventListener( "overlayEnded", scene )
---------------------------------------------------------------------------------

return scene
