-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- SSKCorona Sampler Main Menu
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================

local storyboard = require( "storyboard" )
local scene      = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local screenGroup

-- Callbacks/Functions
local createLayers
local addInterfaceElements

local onBack
local onRG
local onCorona
local onGameTemplates
local onSSKCorona


----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
----------------------------------------------------------------------
function scene:createScene( event )
	screenGroup = self.view

	-- Background Image
	ssk.display.backImage( screenGroup, "bruggeBack2.png" ) 


	-- Page Title 
	ssk.labels:quickLabel( screenGroup, "Credits", centerX, 30, gameFont, 48, _BLACK_)

	-- Credits Badges
	ssk.buttons:presetPush( screenGroup, "RGButton", centerX - 100, centerY - 60, 100, 100, "", onRG  )
	ssk.buttons:presetPush( screenGroup, "GTButton", centerX - 100, centerY + 60, 260, 80, "", onRG  )
	ssk.buttons:presetPush( screenGroup, "SSKButton", centerX + 100, centerY - 60, 208, 64, "", onCorona  )
	ssk.buttons:presetPush( screenGroup, "CoronaButton", centerX + 100, centerY + 60, 100, 96, "", onCorona  )

	-- BACK 
	curY = h - 25
	ssk.buttons:presetPush( screenGroup, "yellowButton", 60 , curY, 100, 40,  "Back", onBack )
end



----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------
onBack = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 400,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.mainMenu", options  )	

	return true
end

onRG = function(event)
	system.openURL( "http://roaminggamer.com/"  )
	return true
end

onCorona = function(event)
	system.openURL( "http://www.coronalabs.com/"  )
	return true
end

onGameTemplates = function ( event ) 
	system.openURL( "http://roaminggamer.com/makegames"  )
	return true
end

onSSKCorona = function ( event ) 
	system.openURL( "http://roaminggamer.com/sskcorona"  )
	return true
end


---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "willEnterScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
scene:addEventListener( "destroyScene", scene )
scene:addEventListener( "overlayBegan", scene )
scene:addEventListener( "overlayEnded", scene )
---------------------------------------------------------------------------------

return scene
