The Snow Queen Loop by Kevin MacLeod is licensed under a CC Attribution 3.0.

http://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100872.

Permissions beyond the scope of this license are available at http://incompetech.com/music/royalty-free/licenses/.



puzzleclick.wav and puzzlesolved.mp3 by myself.  Feel free to use in your games.