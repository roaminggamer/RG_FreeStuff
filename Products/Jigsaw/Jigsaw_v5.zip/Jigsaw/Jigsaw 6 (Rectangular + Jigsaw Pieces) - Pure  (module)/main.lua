-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

--
-- Load both puzzle modules
--
local rectangularPuzzle = require("rectangularPuzzle")
local jigsawPuzzle = require("jigsawPuzzle")

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 2. Execution - We have very little code to write now in order to
--                run the game. :)
----------------------------------------------------------------------

-- Select one of the two puzzle modules to use
local currentPuzzle = rectangularPuzzle
--local currentPuzzle = jigsawPuzzle

-- Configure the puzzle game (choose a puzzle image and whether debug is on)
-- Note: Remember, only the rectangular puzzle will do anything if debug is on
--
local puzzleName = "starrynight"
--local puzzleName = "dogs"

local debugEn = false
--local debugEn = true


-- This single line of code now builds and runs the puzzle game
--
-- 
currentPuzzle.runGame( display.currentStage, puzzleName, debugEn )

-- Uncomment this line to test the cleanup feature
-- When this function runs, the puzzle is destroyed
-- and its memory will get cleaned up.
--
--currentPuzzle.doCleanup()