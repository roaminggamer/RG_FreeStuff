-- =============================================================
-- !!!         THIS FILE IS GENERATED DO NOT EDIT            !!!
-- =============================================================
--
local buttonMaker = require "easy.buttonMaker"
local imagePath   = "images/buttons/"

-- ============================
-- ======= DOWN Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/down.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/down.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "down", params )

-- ============================
-- ======= LEFT Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/left.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/left.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "left", params )

-- ============================
-- ======= RATE Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/rate.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/rate.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "rate", params )

-- ============================
-- ======= PLAY Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/play.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/play.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "play", params )

-- ============================
-- ======= ACHIEVEMENTS Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/achievements.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/achievements.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "achievements", params )

-- ============================
-- ======= NOADS Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/noads.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/noads.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "noads", params )

-- ============================
-- ======= LEADERBOARD Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/leaderboard.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/leaderboard.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "leaderboard", params )

-- ============================
-- ======= RIGHT Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/right.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/right.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "right", params )

-- ============================
-- ======= INFO Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/info.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/info.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "info", params )

-- ============================
-- ======= TWITTER Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/twitter.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/twitter.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "twitter", params )

-- ============================
-- ======= OPTIONS Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/options.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/options.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "options", params )

-- ============================
-- ======= FACEBOOK Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/facebook.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/facebook.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "facebook", params )

-- ============================
-- ======= UP Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/up.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/up.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "up", params )

-- ============================
-- ======= ABOUT Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/about.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/about.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "about", params )

-- ============================
-- ======= SHOP Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/shop.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/shop.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "shop", params )

-- ============================
-- ======= SHARE Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/share.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/share.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "share", params )

-- ============================
-- ======= HOME Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/home.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/home.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "home", params )

-- ============================
-- ======= GAMECENTER Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/gamecenter.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/gamecenter.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "gamecenter", params )

-- ============================
-- ======= PAUSE Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/pause.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/pause.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "pause", params )

-- ============================
-- ======= SOUND Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/sound_on.png",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/sound_off.png",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = 100,
   height            = 100,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "sound", params )

