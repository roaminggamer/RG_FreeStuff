-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"
local utils          = require "easy.utils"
local buttonMaker    = require "easy.buttonMaker"
local persist        = require "easy.persist"
local game           = require "scripts.game"
local soundMgr       = require "easy.soundMgr"
local persist        = require "easy.persist"
-- =============================================================
-- =============================================================
-- Localizations
-- =============================================================
local getTimer=system.getTimer;local mRand=math.random
local newCircle=display.newCircle;local newRect=display.newRect
local newImageRect=display.newImageRect;local newSprite=display.newSprite
local newText=display.newText

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local manageGroups
local onHome

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local underlay
local content
local overlay

----------------------------------------------------------------------
-- Scene Methods
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view
end

function scene:willShow( event )
   local sceneGroup = self.view
   --
   manageGroups( sceneGroup )
   --
   local back = newImageRect( underlay, "images/protoBackX.png", 720, 1386 )
   back.x = centerX
   back.y = centerY

   local label = newText( overlay, "Play", centerX, top + common.topInset + 40, fontB, 64 )

   local playB = buttonMaker.easyPush( { parent = overlay, preset = "home", x = left + 55, y = top + 55, listener = onHome } )

   game.create( content )
end

function scene:didShow( event )
   local sceneGroup = self.view
end

function scene:willHide( event )
   local sceneGroup = self.view
end

function scene:didHide( event )
   local sceneGroup = self.view
   game.destroy( content )
   manageGroups()
end

function scene:destroy( event )
   local sceneGroup = self.view
   game.destroy( content )
   manageGroups()
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
manageGroups = function( sceneGroup )
   display.remove( underlay )
   display.remove( content )
   display.remove( overlay )
   underlay = nil
   content = nil
   overlay = nil
   --
   if( sceneGroup ) then
      underlay = display.newGroup()
      content = display.newGroup()
      overlay = display.newGroup()
      --
      sceneGroup:insert( underlay )
      sceneGroup:insert( content )
      sceneGroup:insert( overlay )
   end
end

onHome = function( event )
   if( persist.get( "settings.json", "sound_enabled" ) ) then
      soundMgr.playEffect( "click" )
   end
   local params = {}
   composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade", params = params } )
end

---------------------------------------------------------------------------------
-- Custom Dispatch Parser -- DO NOT EDIT THIS
---------------------------------------------------------------------------------
function scene.commonHandler( event )
   local willDid  = event.phase
   local name     = willDid and willDid .. event.name:gsub("^%l", string.upper) or event.name
   if( scene[name] ) then scene[name](scene,event) end
end
scene:addEventListener( "create",   scene.commonHandler )
scene:addEventListener( "show",     scene.commonHandler )
scene:addEventListener( "hide",     scene.commonHandler )
scene:addEventListener( "destroy",  scene.commonHandler )
return scene
