-- =============================================================
-- Word Drop - 'Documentation'
-- =============================================================
This is a 'try before you buy' template.  Feel free to use it and 
make games with it, but if you want to distribute them please buy it.

Thanks,
Roaming Gamer

-- =============================================================
-- Need Help?
-- =============================================================
Aside from fixing bugs and releasing update to the module(s),
support is not provided. 

That said, if you need help making your game, I am available and 
you can pay me to help.

Send me an email titled 'Paid Help - Word Drop' at roaminggamer@gmail.com

I'll get back to you promptly.


-- =============================================================
-- What Comes In This Template
-- =============================================================
+ 1_test1       - Example #1
+ 2_test2       - Example #2
+ easy          - The modules.
+ readMe.txt    - This file.

-- =============================================================
-- Basic Usage
-- =============================================================
There are two (2) examples.  You can work it out. :)


-- =============================================================
-- Quick Reference
-- =============================================================

--
-- New Board
--

worddrop.new( group, x, y, params )
+ group - Display group to place board in.  Default to `display.currentStage`.
+ x, y - X and Y position of board center.  Defaults to centerX, centerY.
+ params - Optional list of named parameters:
    + backColor or { 1, 1, 1 }
    + size or 40
    + outlineSize or (info.cellSize + 8)
    + tween or  4
    + cols or 5
    + rows or 5
    + extraWidth or 0
    + extraHeight or 0
    + boardWidth or 0
    + boardHeight or 0
    + cellBack or "images/circle.png"
    + info.cellOutline    +   = params.cellOutline or "images/circle.png"
    + cellColor or {0.5,0.5,0.5}
    + outlineColor or {1,0,0}
    + lineColor or {1,0,0}
    + lineWidth or math.ceil(info.cellSize/4)
    + lettersPath
    + letterHeight or math.floor(info.cellSize * 0.5)
    + font or native.systemFontBold
    + fontSize or (info.cellSize - 10)
    + fontColor or {0,0,0}
    + scoreFont or native.systemFont
    + scoreSize or math.ceil(info.cellSize/4)
    + scoreColor or {0,1,0}
    + scoreTime or 1000
    + scoreDist or info.cellSize * 1.5
    + letterOX or 0
    + letterOY or 0
    + kickMag or 0.1
    + spinMag or 120
    + settleDelay or 250
    + settleSpeed or 750
    + dropSpeed or 850
    + dropEasing or easing.linear
    + boundsOffset or math.ceil(info.cellSize/6)
    + wordListener
    + scoreListener
   --   


--
-- Test Word 
--
worddrop.testWord( word ) - Returns 'true' if word is valid.  Also returns test word.

Tip: You can assign your own word tester to replace this if you want to.  See test2.


--
-- Get random letter
--
worddrop.getRandomLetter( ) - Returns random capitalized letter.

Tip: You can assign your own function to replace this if you want to.
     That way you can control letter frequencies.  See test2. 

--
-- Get letter value
--
worddrop.getLetterValue( letter ) - Returns numeric score value of 'letter'.  Default is 10 for any letter.

Tip: You can assign your own function to replace this if you want to. 
     That way you can control the value of letters.   See test2. 


-- =============================================================
-- Utility Functions (easy.utils)
-- =============================================================
There are a number of utility functions in this module and they are all 
(for the most part) documented internally, so take a look a the file.

Online docs are coming soon for this module.

-- =============================================================
-- Button Maker Functions (easy.buttonMaker)
-- =============================================================
This kit comes with a set of button makers for:
- Push buttons
- Toggle buttons
- Radio buttons

Online docs are coming soon for this module.

-- =============================================================
-- Sound Manager (easy.soundMgr)
-- =============================================================
This kit comes with a starter sound manager you can tweak as needed.

It handles basic sound management and playing.

Online docs are coming soon for this module.

-- =============================================================
-- Files Lib (easy.files)
-- =============================================================
This kit comes with an advanced file system library.

It is used by the editor, but you can dig into it if you want.

