-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right = round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local getTimer = system.getTimer;local strGSub = string.gsub
local strSub = string.sub; local strFormat = string.format
local mFloor = math.floor; local mRand = math.random
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mAtan2 = math.atan2
local mPi = math.pi; local mAbs = math.abs

-- =============================================================
local function vecScale( vec, scale ) return { x = vec.x * scale, y = vec.y * scale } end
function angle2Vector( angle )
   local screenAngle = mRad(-(angle+90))
   local x = mCos(screenAngle) 
   local y = mSin(screenAngle) 
   return { x=-x, y=y }
end

-- =============================================================
local utils    = require "easy.utils"
local physics  = require "physics"
-- =============================================================
local newCell
local rowToY
local colToX
local sortColumn
local onTouch
local settleBoard
local refillBoard
local reSortBoard
-- =============================================================
local mag1 = 0.1
-- =============================================================
local worddrop = {}

function worddrop.testWord( word )
   return true, word
end

function worddrop.getRandomLetter()
   local letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
   local letter = math.random(1,string.len(letters))
   return strSub( letters, letter, letter)
end

function worddrop.getLetterValue( letter )
   return 10
end

function worddrop.new( group, x, y, params )
   group = group or display.currentStage
   params = params or {}
   x = x or centerX
   y = y or centerY
   --
   local info = {}
   --
   info.backColor       = params.backColor or { 1, 1, 1 }
   info.cellSize        = params.size or 40
   info.outlineSize     = params.outlineSize or (info.cellSize + 8)
   info.cellTween       = params.tween or  4
   info.cols            = params.cols or 5
   info.rows            = params.rows or 5
   info.extraWidth      = params.extraWidth or 0
   info.extraHeight     = params.extraHeight or 0
   info.boardWidth      = params.boardWidth or 0
   info.boardHeight     = params.boardHeight or 0
   info.cellBack        = params.cellBack or "images/circle.png"
   info.cellOutline     = params.cellOutline or "images/circle.png"
   info.cellColor       = params.cellColor or {0.5,0.5,0.5}
   info.outlineColor    = params.outlineColor or {1,0,0}
   info.lineColor       = params.lineColor or {1,0,0}
   info.lineWidth       = params.lineWidth or mCeil(info.cellSize/4)
   info.lettersPath     = params.lettersPath
   info.letterHeight    = params.letterHeight or mFloor(info.cellSize * 0.5)
   info.font            = params.font or native.systemFontBold
   info.fontSize        = params.fontSize or (info.cellSize - 10)
   info.fontColor       = params.fontColor or {0,0,0}
   info.scoreFont       = params.scoreFont or native.systemFont
   info.scoreSize       = params.scoreSize or mCeil(info.cellSize/4)
   info.scoreColor      = params.scoreColor or {0,1,0}
   info.scoreTime       = params.scoreTime or 1000
   info.scoreDist       = params.scoreDist or info.cellSize * 1.5
   info.letterOX        = params.letterOX or 0
   info.letterOY        = params.letterOY or 0
   info.kickMag         = params.kickMag or 0.1
   info.spinMag         = params.spinMag or 120
   info.settleDelay     = params.settleDelay or 250
   info.settleSpeed     = params.settleSpeed or 750
   info.dropSpeed       = params.dropSpeed or 850
   info.dropEasing      = params.dropEasing or easing.linear
   info.boundsOffset    = params.boundsOffset or mCeil(info.cellSize/6)
   info.wordListener    = params.wordListener
   info.scoreListener   = params.scoreListener
   --
   local calcWidth      = ( info.cols * info.cellSize + (info.cols + 1) * info.cellTween )
   local calcHeight     = ( info.rows * info.cellSize + (info.rows + 1) * info.cellTween )
   info.boardWidth = (info.boardWidth < calcWidth) and calcWidth or info.boardWidth
   info.boardHeight = (info.boardHeight < calcHeight) and calcHeight or info.boardHeight
   info.boardWidth = info.boardWidth + info.extraWidth
   info.boardHeight = info.boardHeight + info.extraHeight
   --
   local board = display.newContainer( group, info.boardWidth, info.boardHeight )
   board.x = x
   board.y = y
   board.info = info
   --
   local touchCatcher = display.newImageRect( group, "images/fillT.png", fullw, fullh )
   touchCatcher.x = board.x
   touchCatcher.y = board.y
   board:toFront()
   board.touchCatcher = touchCatcher
   touchCatcher.enabled = true
   touchCatcher.board = board
   touchCatcher.touch = onTouch
   touchCatcher:addEventListener("touch")
   --
   local back = display.newRect( board, 0, 0, info.boardWidth, info.boardHeight )
   back:setFillColor(unpack(info.backColor))
   --
   board.lineGroup = display.newGroup()
   board:insert(board.lineGroup)

   --
   board.cells = {}
   --
   local cols = {} 
   board.cols = cols
   for i = 1, info.cols do
      cols[i] = {}
   end
   --
   for col = 1, info.cols do
      for row = 1, info.rows do
         newCell( board, row, col )
      end
   end
   --
   for i = 1, #cols do
      sortColumn( cols[i] )
   end
   local aCol = cols[1]
   for i = 1, #aCol do
      --print(aCol[i].colNum, aCol[i].rowNum, aCol[i].letter)
   end
   --

   function board.finalize( self ) 
      if( board.lastTimer ) then
         timer.cancel( board.lastTimer )
         board.lastTimer = nil
      end
      display.remove( touchCatcher )
   end; board:addEventListener("finalize")

   return board
end

sortColumn = function( t )
   local function sort( a, b )
      return a.y > b.y
   end
   table.sort( t, sort )
   for i = 1, #t do
      --t[i].colImg.text = i
      t[i].rowNum = i
   end
end

rowToY = function ( info, row )
   local y = (info.rows * info.cellSize + (info.rows+1) * info.cellTween)/2 - info.cellSize/2 - info.cellTween
   y = y - (row-1) * (info.cellSize + info.cellTween)
   return y
end

colToX = function ( info, col )   
   local x = -(info.cols * info.cellSize + (info.cols+1) * info.cellTween)/2 + info.cellSize/2 + info.cellTween
   x = x + (col-1) * (info.cellSize + info.cellTween)
   return x
end

newCell = function( board, rowNum, colNum )
   local info = board.info   
   local col = board.cols[colNum]

   --
   local cell = display.newGroup()
   cell.x = colToX( info, colNum )
   cell.y = rowToY( info, rowNum )
   --
   board:insert(cell)
   col[#col+1] = cell
   --
   cell.myCol = col
   --
   cell.letter = worddrop.getRandomLetter()
   cell.rowNum = rowNum
   cell.colNum = colNum
   --   
   cell.outline = display.newImageRect( cell, info.cellOutline, info.outlineSize, info.outlineSize )
   cell.outline:setFillColor(unpack(info.outlineColor))
   cell.outline.isVisible = false
   --   
   cell.back = display.newImageRect( cell, info.cellBack, info.cellSize, info.cellSize )
   cell.back:setFillColor(unpack(info.cellColor))
   --
   if( info.lettersPath ) then
      local path = string.format( "%s/letter%s.png", info.lettersPath, string.upper(cell.letter))
      local img = display.newImage( cell, path, info.letterOX, info.letterOY )
      cell.letterImg = img
      local scale = info.letterHeight/img.contentHeight
      img:scale(scale,scale)
   else 
      local img = display.newText( cell, cell.letter, info.letterOX, info.letterOY, info.font, info.fontSize )
      img:setFillColor(unpack(info.fontColor))
      cell.letterImg = img
   end 

   --local img = display.newText( cell, "1", 24, 0, fontN, 18 )
   --img:setFillColor(0)
   --cell.colImg = img
   --
   board.cells[cell] = cell
   --
   return cell 
end


local function findCell( cells, event, offset )
   for k,v in pairs(cells) do
      if( utils.isInBounds(event,v, offset) ) then
         return v
      end
   end
   return nil
end
local function validateCell( cell, cur )
   if( not cell ) then return nil end
   if( cell == cur ) then return nil end
   if( not cur and cell ) then return cell end
   local dr = math.abs( cell.rowNum - cur.rowNum )
   local dc = math.abs( cell.colNum - cur.colNum )
   if( dr > 1 or dc > 1 ) then
      --print( dc, dr, cell.rowNum,  cur.rowNum  )
      return nil 
   end
   return cell
end

onTouch = function( self, event )
   local board = self.board
   local info  = board.info
   local phase = event.phase
   local cells = board.cells
   if( not self.enabled ) then return true end
   --
   if( phase == "began" ) then
      display.getCurrentStage():setFocus( self, eventID )
      self.isFocus = true
      for k,v in pairs(cells) do
         v.outline.isVisible = false
      end
      board.oselected = {}
      board.selected = {}
      --
      local cell = findCell( cells, event, info.boundsOffset )
      if( cell ) then
         cell.outline.isVisible = true 
         board.selected[cell] = cell
         board.oselected[1] = cell
      end

   elseif( self.isFocus ) then
      local cell = findCell( cells, event, info.boundsOffset )
      local cur = board.oselected[#board.oselected]
      local last = (#board.oselected>1) and (board.oselected[#board.oselected-1]) or nil
      cell = validateCell( cell, cur )      
      if( cell ) then         
         if( not board.selected[cell] ) then
            cell.outline.isVisible = true 
            board.selected[cell] = cell
            board.oselected[#board.oselected+1] = cell
         elseif( cell == last ) then            
            board.selected[board.oselected[#board.oselected]] = nil
            board.oselected[#board.oselected].outline.isVisible = false
            board.oselected[#board.oselected] = nil
         end
      else
         --print("NO CELL", #board.oselected)
      end
      if(event.phase == "ended" or event.phase == "cancelled" ) then
         display.getCurrentStage():setFocus( self, nil )
         self.isFocus = false
         display.remove(self.line)
         self.line = nil
         for k,v in pairs(cells) do
            v.outline.isVisible = false
         end
         local word = ""
         for i = 1, #board.oselected do
            word = word .. board.oselected[i].letter
            --print(word)
         end
         local goodWord = false
         goodWord, word = worddrop.testWord(word)
         if( goodWord ) then
            --
            if( info.wordListener ) then info.wordListener( word ) end
            self.enabled = false
            --
            local last = board.oselected[#board.oselected]
            for k,v in pairs( board.selected ) do
               local myCol = v.myCol
               table.remove( myCol, table.indexOf( myCol, v ) )
               board.parent:insert(v)
               v.x = v.x + board.x
               v.y = v.y + board.y
               physics.addBody( v )
               v.isSensor = true
               local vec = angle2Vector( mRand( -45, 45 ) )
               vec = vecScale( vec, info.cellSize * v.mass * info.kickMag )
               v:applyLinearImpulse( vec.x, vec.y, v.x,v.y )
               v.angularVelocity = mRand( -info.spinMag/2, info.spinMag/2)
               board.cells[v] = nil
               transition.to( v, { dummy = 1, time = 0, delay = 10000, onComplete = display.remove } )
               --
               local val = worddrop.getLetterValue( v.letter )
               local floatScore = display.newText( board.parent, val, v.x, v.y, info.scoreFont, info.scoreSize  )
               floatScore:setFillColor( unpack( info.scoreColor ) )
               transition.to( floatScore, { y = floatScore.y - info.scoreDist, time = info.scoreTime } )
               transition.to( floatScore, { alpha = 0, delay = info.scoreTime/3, time = 2 * info.scoreTime/3, 
                                            onComplete = display.remove } )
               if( info.scoreListener ) then info.scoreListener( val ) end
            end
            settleBoard( board )
         end
         board.oselected = nil
         board.selected = nil
      else
         display.remove(self.line)
         if( #board.oselected > 1 ) then
            local verts = {}
            for i = 1, #board.oselected do
               verts[#verts+1] = board.oselected[i].x
               verts[#verts+1] = board.oselected[i].y
            end
            self.line = display.newLine( board.lineGroup, unpack(verts) )
            self.line.strokeWidth = info.lineWidth
            self.line:setStrokeColor(unpack(info.lineColor))
         end
      end
   end
   return true
end

settleBoard = function( board )
   local info = board.info
   local cols = board.cols
   local max = info.rows * info.cols
   local total = 0
   --
   for i = 1,#cols do
      total = total + #cols
   end
   --
   for i = 1,#cols do
      local col = cols[i]
      local count = #col
      for j = 1, #col do
         local obj = col[j]
         local curY = obj.y
         local dstY = rowToY( info, j )
         local dist = mAbs( curY - dstY )
         local time = 1000 * dist / info.settleSpeed
         transition.cancel( obj )
         obj.row = j
         obj.moving = true
         obj.onComplete = function( self )
            self.onComplete = nil
            self.moving = false
         end
         transition.to( obj, { y = dstY, time = time, delay = info.settleDelay, onComplete = obj } )
      end      
   end

   if( board.lastTimer ) then
      timer.cancel( board.lastTimer )
      board.lastTimer = nil
      reSortBoard( board )
   end
   board.lastTimer = timer.performWithDelay( info.settleDelay + 100, 
      function() 
         board.lastTimer = nil
         refillBoard( board, max - total )
      end)
end

refillBoard = function( board, toCreate )
   local info = board.info
   local cols = board.cols
   for i = 1,#cols do
      local col = cols[i]
      local startRow = #col
      if( startRow < info.rows ) then
         local fromY = - info.boardHeight/2 - 2 * info.cellSize
         for j = startRow + 1, info.rows do
            local cell = newCell( board, j, i )
            local toY = cell.y
            cell.y = fromY
            fromY = fromY - info.cellSize - info.cellTween

            local dist = mAbs( cell.y - toY )
            local time = 1000 * dist / info.dropSpeed

            cell.onComplete = function( self )
               self.onComplete = nil
               self.moving = false
               reSortBoard( board )
            end
            cell.moving = onComplete
            transition.to( cell, { y = toY, time = time, onComplete = cell,
                                   transition = info.dropEasing} )            

         end
      end      
   end
end

reSortBoard = function( board )
   local canSort = true
   for k,v in pairs(board.cells) do
      canSort = canSort and (not v.moving)
   end
   --
   if( canSort == false ) then return end
   --
   local cols = board.cols
   for i = 1,#cols do
      local col = cols[i]
      sortColumn( col )
   end
   --
   board.touchCatcher.enabled = true
end


return worddrop
