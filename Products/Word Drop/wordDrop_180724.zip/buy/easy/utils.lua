-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right = round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local getTimer = system.getTimer;local strGSub = string.gsub
local strSub = string.sub; local strFormat = string.format
local mFloor = math.floor; local mRand = math.random

-- =============================================================
local platformName            = string.lower(system.getInfo("platformName"))
local platform                = string.lower(system.getInfo("platform"))
local platformEnvironment     = string.lower(system.getInfo("environment"))
-- =============================================================
local utils = {}
local version = "180714"
function utils.version() print("utils.lua", version);return version; end


-- =============================================================
-- Return first argument in list that is 'not nil'
-- =============================================================
function utils.fnn( ... ) 
   for i = 1, #arg do
      local theArg = arg[i]
      if(theArg ~= nil) then return theArg end
   end
   return nil
end

-- =============================================================
-- Native alert helper.
-- =============================================================
function utils.easyAlert( title, msg, buttons )
   buttons = buttons or { {"OK"} }
   local function onComplete( event )
      local action = event.action
      local index = event.index
      if( action == "clicked" ) then
         local func = buttons[index][2]
         if( func ) then func() end 
       end
   end
   local names = {}
   for i = 1, #buttons do
      names[i] = buttons[i][1]
   end
   return native.showAlert( title, msg, names, onComplete )
end

-- =============================================================
-- Make first letter in string 'upper-case'
-- =============================================================
function utils.first_upper(str)
   return str:gsub("^%l", string.upper)
end

-- =============================================================
-- Returns 'true' if obj is still a valid display object.
-- =============================================================
function utils.isValid( obj )
   return ( obj and obj.removeSelf and type(obj.removeSelf) == "function" )
end

-- =============================================================
-- Shorthand for Runtime:addEventListener( name, listener )
-- =============================================================
function utils.listen( name, listener ) 
   Runtime:addEventListener( name, listener ) 
end

-- =============================================================
-- Shorthand for Runtime:removeEventListener( name, listener )
-- =============================================================
function utils.ignore( name, listener ) 
   Runtime:removeEventListener( name, listener ) 
end

-- =============================================================
-- Safe Runtime listener remover similar to 'ignore' (above), but
-- takes list (table of strings) for each listener name to remove.
-- =============================================================
function utils.ignoreList( list, obj )
   if( not obj ) then return end
   for i = 1, #list do
      local name = list[i]
      if(obj[name]) then 
         ignore( name, obj ) 
         obj[name] = nil
      end
  end
end

-- =============================================================
-- Checks if obj is still valid and if not, removes named listener
-- Returns 'true' if object was invalid and listener was removed.
-- =============================================================
function utils.autoIgnore( name, obj ) 
   if( not utils.isValid( obj ) ) then
      ignore( name, obj )
      obj[name] = nil
      return true
   end
   return false 
end

-- =============================================================
-- Shorthand helper that does job of Runtime:dispatchEvent( event )
-- =============================================================
function utils.post( name, params )
   params = params or {}
   local event = {}
   for k,v in pairs( params ) do event[k] = v end
   event.name = name
   if( not event.time ) then event.time = system.getTimer() end
   Runtime:dispatchEvent( event )
end

-- =============================================================
-- utils.save( theTable, fileName [, base ] ) - Saves table to file (Uses JSON library as intermediary)
-- =============================================================
function utils.save( theTable, fileName, base  )
   local json = require "json"
   local base = base or  system.DocumentsDirectory
   local path = system.pathForFile( fileName, base )
   local fh = io.open( path, "w" )

   if(fh) then
      fh:write(json.encode( theTable ))
      io.close( fh )
      return true
   end   
   return false
end

-- =============================================================
-- utils.load( fileName [, base ] ) - Loads table from file 
-- (Uses JSON library as intermediary)
-- =============================================================
function utils.load( fileName, base )
   local json = require "json"
   local base = base or system.DocumentsDirectory
   local path = system.pathForFile( fileName, base )
   if(path == nil) then return nil end
   local fh, reason = io.open( path, "r" )
   if( fh) then
      local contents = fh:read( "*a" )
      io.close( fh )
      local newTable = json.decode( contents )
      return newTable
   else
      return nil
   end
end

-- =============================================================
-- utils:rpad( str, len, char ) - Places padding on right side 
-- of a string, such that the new string is at least len characters long.
-- =============================================================
function utils.rpad( str, len, char)
   local theStr = str
    if char == nil then char = ' ' end
    return theStr .. string.rep(char, len - #theStr)
end

-- =============================================================
-- Table dumper.
-- =============================================================
function utils.dump( theTable, padding, marker ) -- Sorted
   if(marker == nil and type(padding) == "string" ) then
      marker = padding
      padding = 30
   else
      padding = padding or 30
   end
   local theTable = theTable or  {}
   local function compare(a,b)
      return tostring(a) < tostring(b)
   end
   local tmp = {}
   for n in pairs(theTable) do table.insert(tmp, n) end
   table.sort(tmp,compare)

   local padding = padding or 30
   print("\Table Dump:")
   print("-----")
   if(#tmp > 0) then
      for i,n in ipairs(tmp) do     

         local key = tmp[i]
         local value = theTable[key]
         local keyType = type(key)
         local valueType = type(value)
         value = tostring(value)
         local keyString = tostring(key) .. " (" .. keyType .. ")"
         local valueString = tostring(value) .. " (" .. valueType .. ")" 

         keyString = utils.rpad(keyString,padding)
         valueString = utils.rpad(valueString,padding)

         print( keyString .. " == " .. valueString ) 
      end
   else
      print("empty")
   end
   print( marker and ( "-----\n" ..marker .. "\n-----" ) or "-----" )   
end

-- =============================================================
-- utils.print_r( theTable ) - Dumps indexes and values inside 
-- multi-level table (for debug)
-- =============================================================
utils.print_r = function ( t ) 
   local print_r_cache={}
   local function sub_print_r(t,indent)
      if (print_r_cache[tostring(t)]) then
         print(indent.."*"..tostring(t))
      else
         print_r_cache[tostring(t)]=true
         if (type(t)=="table") then
            for pos,val in pairs(t) do
               if (type(val)=="table") then
                  print(indent.."["..pos.."] => "..tostring(t))
                  print(indent.."{")
                  sub_print_r(val,indent..string.rep(" ",3))
                  print(indent..string.rep(" ",0).."}")
               elseif (type(val)=="string") then
                  print(indent.."["..pos..'] => "'..val..'"')
               else
                  print(indent.."["..pos.."] => "..tostring(val))
               end
            end
         else
            print(indent..tostring(t))
         end         
      end
   end
   if (type(t)=="table") then
      print(tostring(t).." {")
      sub_print_r(t," ")
      print("}")
   else
      sub_print_r(t," ")
   end
   return table.concat(print_r_cache, "\n")
end

-- =============================================================
-- Rounds floating point-values to n places.
-- =============================================================
function utils.round(val, n)
  if (n) then
    return math.floor( (val * 10^n) + 0.5) / (10^n)
  else
    return math.floor(val+0.5)
  end
end


-- =============================================================
-- returns: onSim, os
-- - onSim - 'true' if on simulator
-- - os - nil if not on simulator, 'win' or 'osx' otherwise.
-- =============================================================
function utils.onSim(noOs)
   if( noOS ) then
      if( platformEnvironment == "device" ) then return false end
      if( platformName == "mac os x" ) then return true end
      if( platformName == "win" ) then return true end
      return false
   else
      if( platformEnvironment == "device" ) then return false,nil end
      if( platformName == "mac os x" ) then return true, 'osx' end
      if( platformName == "win" ) then return true, 'win' end
      return false, nil
   end
end

-- =============================================================
-- returns true if on a device
-- =============================================================
function utils.onDevice()
   return ( platformEnvironment == "device" )
end

-- =============================================================
-- returns true if on a desktop
-- =============================================================
function utils.onDesktop()
   return ( utils.os() == "osx" or utils.os() == "win" )
end

-- =============================================================
-- Returns: 'ios', 'android', 'tvos', win, osx, or nil if OS is unknown.
-- =============================================================
function utils.os()
   if( (platformName == "iphone os") or (platform == "ios") ) then
      return "ios"
   elseif( (platformName == "android") or (platform == "android") ) then
      return "android"
   elseif( (platformName == "tvos") or (platform == "tvos") ) then      
      return "tvos"   

   elseif( (platformName == "device") and (platformName == "mac os x") ) then
      return "osx"

   elseif( (platformName == "device") and (platformName == "win") ) then
      return "win"   
   end
   return nil
end

-- ==
--    triml(s) - Trim whitespace from left-side of string only.
--    trimr(s) - Trim whitespace from right-side of string only.
-- ==
function utils.triml(s)
    return s:match"^%s*(.*)"
end
function utils.trimr(s)
    return s:match"(.-)%s*$"
end

-- ==
--   trim(s) - Trim whitespace
-- ==
function utils.trim(s)
    local from = s:match"^%s*()"
    return from > #s and "" or s:match(".*%S", from)
end


-- =============================================================
-- Splits a string on specified token and returns table of values.
-- =============================================================
function utils.split(str,tok)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local ftok = "(.-)" .. tok
   local last_end = 1
   local s, e, cap = str:find(ftok, 1)
   while s do
      if s ~= 1 or cap ~= "" then
         table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(ftok, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end
-- =============================================================
-- shallowCopy( src [ , dst ]) - Copies single-level tables; handles non-integer indexes; does not copy metatable
-- =============================================================
function utils.shallowCopy( src, dst )
   local dst = dst or {}
   if( not src ) then return dst end
   for k,v in pairs(src) do 
      dst[k] = v
   end
   return dst
end
-- ==
--    deepCopy( src [ , dst ]) - Copies multi-level tables; handles non-integer indexes; does not copy metatable
-- ==
function utils.deepCopy( src, dst )
   local dst = dst or {}
   for k,v in pairs(src) do 
      if( type(v) == "table" ) then
         dst[k] = utils.deepCopy( v, nil )
      else
         dst[k] = v
      end      
   end
   return dst
end


-- ==
--    generateButtonPresets() - This utility will generate button prese for any images found in 
--    images/buttons
-- ==
local header = 
[[
-- =============================================================
-- !!!         THIS FILE IS GENERATED DO NOT EDIT            !!!
-- =============================================================
--
local buttonMaker = require "easy.buttonMaker"
local imagePath   = "images/buttons/"
]]


local template = 
[[-- ============================
-- ======= bname1 Button
-- ============================
local params = 
{ 
   selImg            = "images/buttons/bimage_sel",
   selColor          = { 1, 1, 1 },
   selLabelColor     = { 1, 1, 1 },

   unselImg          = "images/buttons/bimage_unsel",
   unselColor        = { 0.75, 0.75, 0.75 },
   unselLabelColor   = { 1, 1, 1 },

   width             = bwidth,
   height            = bheight,

   font              = native.systemFontBold,
   fontSize          = 32,
   labelOffset       = { 0, 0 },
}
buttonMaker.addPreset( "bname2", params )
]]

-- ==
-- 
-- ==
-- ==
--    generateButtonPresets( using2XImages ) - This utility will generate button prese for any images found in 
--    images/buttons.  Pass 'true' for first argument if your images are twice as large as you want them displayed.
-- ==
function utils.generateButtonPresets( using2XImages )
   local path = utils.files.resource.getPath("images/buttons/")
   local allFiles = utils.files.util.findAllFiles(path)
   --
   local processed = {}

   -- Process filenames
   for k,v in pairs( allFiles ) do
      local rec = {}
      processed[#processed+1] = rec
      --
      local filename    = v
      local parts       = utils.split( filename, "%." )
      local ext         = parts[#parts]
      local prefix      = parts[1]
      local parts       = utils.split( prefix, "_" )
      rec.filename      = filename
      rec.ext           = ext
      rec.type          = ( #parts == 1 ) and "basic" or parts[2]
      rec.name          = parts[1]
   end
   --

   local function findNameByType( name, btype )
      for i = 1,#processed do
         local rec = processed[i]
         if( rec.name == name and rec.type == btype ) then
            return rec
         end
      end
      return nil
   end

   --
   -- Generate Presets File
   --
   local generated = {}
   --
   local outPath = utils.files.resource.getPath("presets/presets_gen.lua")
   utils.files.util.writeFile( header .. "\n", outPath )

   -- Basic Buttons
   for i = 1, #processed do
      local rec = processed[i]
      if( rec.type == "basic" and not generated[rec.name] ) then
         generated[rec.name] = true
         --
         local bwidth, bheight = utils.getImageSize( "images/buttons/" .. rec.filename )
         local out = template
         out = string.gsub( out, "bname1", string.upper(rec.name) )
         out = string.gsub( out, "bname2", rec.name )
         out = string.gsub( out, "bimage_unsel", rec.filename )
         out = string.gsub( out, "bimage_sel", rec.filename )
         out = string.gsub( out, "bwidth", bwidth )
         out = string.gsub( out, "bheight", bheight )
         --print(out)
         --
         utils.files.util.appendFile( out, outPath )
         utils.files.util.appendFile( "\n", outPath )
      end
   end

   -- sel/unsel buttons
   for i = 1, #processed do
      local rec = processed[i]
      local other 
      if( rec.type == "sel" ) then
         other = findNameByType( rec.name, "unsel" )
      end
      if( other and not generated[rec.name] ) then
         generated[rec.name] = true
         --
         local bwidth, bheight = utils.getImageSize( "buttons/" .. rec.filename )
         local out = template
         out = string.gsub( out, "bname1", string.upper(rec.name) )
         out = string.gsub( out, "bname2", rec.name )
         out = string.gsub( out, "bimage_unsel", rec.name .. "_unsel." .. rec.ext )
         out = string.gsub( out, "bimage_sel", rec.name .. "_sel." .. rec.ext )
         out = string.gsub( out, "bwidth", bwidth )
         out = string.gsub( out, "bheight", bheight )
         --print(out)
         --
         utils.files.util.appendFile( out, outPath )
         utils.files.util.appendFile( "\n", outPath )
      end
   end

   -- on/off buttons
   for i = 1, #processed do
      local rec = processed[i]
      local other 
      if( rec.type == "on" ) then
         other = findNameByType( rec.name, "off" )
      end
      if( other and not generated[rec.name] ) then
         generated[rec.name] = true
         --
         local bwidth, bheight = utils.getImageSize( "images/buttons/" .. rec.filename )
         local out = template
         out = string.gsub( out, "bname1", string.upper(rec.name) )
         out = string.gsub( out, "bname2", rec.name )
         out = string.gsub( out, "bimage_unsel", rec.name .. "_off." .. rec.ext )
         out = string.gsub( out, "bimage_sel", rec.name .. "_on." .. rec.ext )
         out = string.gsub( out, "bwidth", bwidth )
         out = string.gsub( out, "bheight", bheight )
         --print(out)
         --
         utils.files.util.appendFile( out, outPath )
         utils.files.util.appendFile( "\n", outPath )
      end
   end
end

-- ==
--    getImageSize( path[, basePath ] ) - Returns size of image at path
-- ==
utils.getImageSize = function ( path, basePath )
   basePath = basePath or system.ResourceDirectory 
   local tmp = display.newImage( path, basePath, 10000,10000 )
   if( not tmp ) then
      return 0, 0
   end
   local sx = tmp.contentWidth
   local sy = tmp.contentHeight
   display.remove(tmp)
   return sx,sy
end

-- ==
--    hexcolor(  ) - converts hex color codes to rgba Graphics 2.0 value
-- ==
function utils.hexcolor( code )
   code = code or "FFFFFFFF"
   code = string.gsub( code , " ", "")
   code = string.gsub( code , "0x", "")
   code = string.gsub( code , "#", "")
   local colors = {1,1,1,1}
   while code:len() < 8 do
      code = code .. "F"
   end
   local r = tonumber( "0X" .. strSub( code, 1, 2 ) )
   local g = tonumber( "0X" .. strSub( code, 3, 4 ) )
   local b = tonumber( "0X" .. strSub( code, 5, 6 ) )
   local a = tonumber( "0X" .. strSub( code, 7, 8 ) )
   local colors = { r/255, g/255, b/255, a/255  }
   return colors
end

-- ==
--    repairPath(  ) - Force path to use forward slashes for consistency in later parsing.
-- ==
function utils.repairPath( path )   
   path = strGSub( path, "\\", "/" )
   path = strGSub( path, "//", "/" )
   return path
end

-- ==
--    shuffle( t ) - Randomizes the order of a numerically indexed (non-sparse) table.
-- ==
utils.shuffle = function( t, iter )
   local iter = iter or 1
   local n

   for i = 1, iter do
      n = #t 
      while n >= 2 do
         -- n is now the last pertinent index
         local k = math.random(n) -- 1 <= k <= n
         -- Quick swap
         t[n], t[k] = t[k], t[n]
         n = n - 1
      end
   end

   return t
end

-- ==
--    isInBounds( obj, obj2 ) - Returns true if obj is in bounds of obj2
-- ==
function utils.isInBounds( obj, obj2, offset )
   offset = offset or 0
   if(not obj2) then return false end
   local bounds = obj2.contentBounds
   if( obj.x > bounds.xMax - offset ) then return false end
   if( obj.x < bounds.xMin + offset ) then return false end
   if( obj.y > bounds.yMax - offset ) then return false end
   if( obj.y < bounds.yMin + offset ) then return false end
   return true
end

-- ==
--    createSlicedImage( group, path, x, y, width, height ) - Draws a single image from 9 
--    sub-slices.
-- ==
function utils.createSlicedImage( group, path, x, y, width, height )
    group = group or display.currentStage
    local slices = display.newGroup()
    group:insert( slices )
    local function cw( obj ) return obj.contentWidth end
    local function ch( obj ) return obj.contentHeight end
    local w2 = width/2
    local h2 = height/2
    local slice_1 = display.newImage( slices, path .. "/slice_1.png", 0, 0  )
    local slice_2 = display.newImage( slices, path .. "/slice_2.png", 0, 0  )
    local slice_3 = display.newImage( slices, path .. "/slice_3.png", 0, 0  )
    --
    slice_1.anchorX = 0
    slice_1.anchorY = 0
    slice_1.x = -w2
    slice_1.y = -h2
    --
    slice_2.anchorY = 0
    slice_2.y = -h2
    --
    slice_3.anchorX = 1
    slice_3.anchorY = 0
    slice_3.x = w2
    slice_3.y = -h2
    --
    local slice_4 = display.newImage( slices, path .. "/slice_4.png", 0, 0  )
    local slice_5 = display.newImage( slices, path .. "/slice_5.png", 0, 0  )
    local slice_6 = display.newImage( slices, path .. "/slice_6.png", 0, 0  )
    --
    slice_4.anchorX = 0
    slice_4.x = -w2
    --
    slice_6.anchorX = 1
    slice_6.x = w2
    
    --
    local slice_7 = display.newImage( slices, path .. "/slice_7.png", 0, 0  )
    local slice_8 = display.newImage( slices, path .. "/slice_8.png", 0, 0  )
    local slice_9 = display.newImage( slices, path .. "/slice_9.png", 0, 0  )
    --
    slice_7.anchorX = 0
    slice_7.anchorY = 1
    slice_7.x = -w2
    slice_7.y = h2
    --
    slice_8.anchorY = 1
    slice_8.y = h2
    --
    slice_9.anchorX = 1
    slice_9.anchorY = 1
    slice_9.x = w2
    slice_9.y = h2

    local wscale = (width - (cw(slice_1) + cw(slice_3)))/cw(slice_2)
    local hscale = (height - (ch(slice_2) + ch(slice_8)))/ch(slice_5)
    slice_2:scale( wscale, 1 )
    slice_4:scale( 1, hscale )
    slice_5:scale( wscale, hscale )
    slice_6:scale( 1, hscale )
    slice_8:scale( wscale, 1 )


    slices.x = x
    slices.y = y
    return slices
end


-- =============================================================
-- Attach external modules to utils
-- =============================================================
utils.files = require "easy.files"
utils.files.prepare( utils )

return utils
