-- ==========================================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- Example Begins Here
-- ==========================================================================

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************
local physics = require "physics"


-- **************************************************************************
-- Initialization
-- **************************************************************************
physics.start()
physics.setGravity( 0, 0 )
--physics.setDrawMode( "hybrid" )


-- **************************************************************************
-- Local Variables
-- **************************************************************************
--
-- 1. Frequently used 'concepts' pre-calculated and stored in easy to 
--    type & remember variable.
--
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

--
-- 2. (Game) Variables specific to this game and its logic.
--
local layers                        -- Top group containing all child groups
local gameIsRunning        = false  -- Flag to help track if game is running
local waitingToStartBall   = true
local gameTimer                     -- Handle to store timer id

local gameDuration      = 30        -- Game ends after 30 seconds

local startTime                     -- Time (in milliseconds) when game started
local lives             = 3         -- Current Lives

local minBricks         = 1         -- Minimum number of bricks to show per brick logic run
local maxBricks         = 3         -- Maximum number of bricks to show per brick logic run

-- Angles at which ball can start moving
local ballSpeed            = 500    -- Magnitude of ball starting velocity
local maxBallSpeedDelta    = 1      -- Speed can be off by this much and will be ignored

local paddleSpeed       = 1200      -- Magnitude of paddle velocity
local paddleSnapDist    = 15        -- If the paddle doesn't stop consistently, increase this value

local paddle                        -- The Paddle 
local ball                          -- Current ball

local ballSize          = 40

local bricks            = {}        -- Table to track brick instances
local brickWidth        = 94        -- Brick width
local brickHeight       = 44        -- Brick height

local paddleWidth       = 130       -- Paddle width
local paddleHeight      = 35        -- Paddle height

local bricksLabel
local livesLabel
local tapToStartLabel


-- **************************************************************************
-- Localize Commonly Used Functions 
--
-- Why Do This?: It gives small execution speedup, but mostly I do it 
-- to simplify typing.  I may not use them all, bit it is handy to have
-- them ready if I need them.
-- 
--
--  !!Warning!!: Don't take this too far.  Lua has a limit of 200 
--               local variables in scope at any time.
--
--     Pro Tip:  Be a DRY coder, not a WET coder.
--               WET ==> Write Everything Twice; We Enjoy Typing; ...
--               DRY ==> Don't Repeat Yourself
--
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Forward Declarations
--
-- Tip: This makes the following function names VISIBLE for the rest of the file.
--      They can be called anywhere below as long as they have been defined before
--      the are called. (As soon as this file 'loads', all of the functions will 
--      be defined.)
-- 
-- Note: I split game logic into create, destroy, start, stop... etc. because:
--
-- 1. It makes reading these parts of the code easier.
--
-- 2. It promotes the concepts associated with these function to you.
--
-- 3. Having this functionality broken up discretely helps you prepare for
--    writing game modules, and then for using composer.*.
-- 
-- **************************************************************************
local destroyGame
local createGame
local startGame
local stopGame
local nextRound
local countBricks
local calculateBallVector

-- **************************************************************************
-- Function Definitions
-- **************************************************************************

--
-- destroyGame( ) - Create the game content
--
destroyGame = function( group )

   -- Do any work to stop the game
   -- 
   stopGame()
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   layers = display.remove( layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear the bricks tracking table by setting it to nil.
   --
   bricks = nil

   -- Stop enterFrame listener and clear paddle varaible
   --
   Runtime:removeEventListener( "enterFrame", paddle )
   paddle = nil


   -- Clear label references so they can be garbage collected
   --
   bricksLabel = nil
   livesLabel = nil

end


--
-- createGame( group ) - Create the game content
--
createGame = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   destroyGame()

   -- Start with three lives
   --
   lives = 3

   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.content    = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.content )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( layers.background, "images/protoBack.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 0

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      for k,v in pairs( event ) do
         --print(k,v)      
      end

      -- Are we waiting to start the ball moving?
      --
      if( waitingToStartBall and event.phase == "ended" ) then

         -- Clear the flag
         --
         waitingToStartBall = false

         -- Hide 'tap to start' message
         --
         tapToStartLabel.isVisible = false
         
         -- Resume Physics
         --
         physics.start()

         -- Give the ball a random bounce
         local vx,vy = calculateBallVector()
         ball:setLinearVelocity( vx, vy )

      -- Not waitint to start the ball?  The update the paddle target
      elseif( not waitingToStartBall ) then
         
         -- Set target x-position for paddle.  The paddle's 'enterFrame' listener 
         -- will use this value to try to move the paddle.
         paddle.targetX = event.x
         --print( event.x )
      end
      return true
   end
   back:addEventListener( "touch" )

   --
   -- Brick Functions & Methods - Builder function and methods for each brick.
   --   

   -- Shared Brick Methods
   --
   bricks = {} -- Create fresh table for our bricks.

   -- Shared Collision Listener (also a method)
   --
   local function onCollision( self, event )
      local phase = event.phase
      local other = event.other

      -- Is this the end of the collision and were we struck by a ball?
      --
      if( phase == "ended" and other == ball ) then

         -- Remove this brick from the bricks table
         --
         bricks[self] = nil

         -- Destroy the brick
         --
         display.remove(self)

         -- Count remaining bricks
         --
         local remainingBricks = countBricks()

         -- Update the brick counter label
         --
         bricksLabel.text = remainingBricks

         -- Last brick destroyed? 
         --
         if( remainingBricks <= 0 ) then

            -- Stop the Game
            --
            stopGame()

         end

      end

      return false 
   end


   -- Brick Builder Function
   --
   local function newBrick( x, y )

      -- Draw an 'empty hole'
      local brick = newRect( layers.content, x, y, brickWidth-4, brickHeight-4 )
      brick:setFillColor(0.25,0.25,0.25)
      brick.strokeWidth = 2
      brick:setStrokeColor(1,1,0,0.5)


      -- Attach body to brick
      --
      physics.addBody( brick, "static", { bounce = 1, friction = 0 } )

      -- Attach common collision listener and start listening for collisions
      brick.collision = onCollision
      brick:addEventListener( "collision" )

      -- Set flag(s) on brick.
      brick.isShowing = false
      brick.color = color

      -- Add to bricks list
      bricks[brick] = brick

      -- Return reference to brick
      return brick
   end

   -- Draw Labels Elements
   --
   local livesPrefix = newText( layers.interface, "Lives: ", centerX - 100, 40, native.systemFont, 40 )
   livesPrefix.anchorX = 1
   livesLabel = newText( layers.interface, lives, livesPrefix.x, 40, native.systemFont, 40 )
   livesLabel.anchorX = 0

   local bricksPrefix = newText( layers.interface, "Bricks: ", centerX + 150, 40, native.systemFont, 40 )
   bricksPrefix.anchorX = 1
   bricksLabel = newText( layers.interface, 0, bricksPrefix.x, 40, native.systemFont, 40 )
   bricksLabel.anchorX = 0

   -- Tap To Start Label
   --
   tapToStartLabel = newText( layers.interface, "Tap To Start", centerX, centerY + 100, native.systemFont, 40 )
   

   --
   -- Draw a grid of bricks
   --
   local brickCols      = 6
   local brickRows      = 3

   local startX         = centerX - (brickCols * brickWidth)/2 + brickWidth/2
   local startY         = top + 300
   local curX           = startX 
   local curY           = startY

   local last 
   for row = 1, brickRows do
      for col = 1, brickCols do
         --print( row, col, curX, curY)
         local brick = newBrick( curX, curY )      
         curX = curX + brickWidth
         last = brick
      end
      curX = startX
      curY = curY + brickHeight
   end

   -- Update bricks counter label
   --
   bricksLabel.text = countBricks()

   -- Create Walls
   local leftWall = newRect( layers.content, left, centerY, 40, fullh )
   leftWall.anchorX = 1
   leftWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( leftWall, "static", { bounce = 1, friction = 0 } )
   
   local rightWall = newRect( layers.content, right, centerY, 40, fullh )
   rightWall.anchorX = 0
   rightWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( rightWall, "static", { bounce = 1, friction = 0 } )

   local topWall = newRect( layers.content, centerX, top + 80, fullw, 80 )
   topWall.anchorY = 1
   topWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( topWall, "static", { bounce = 1, friction = 0 } )

   local bottomWall = newRect( layers.content, centerX, bottom, fullw, 40 )
   bottomWall.anchorY = 0   
   bottomWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( bottomWall, "static", { bounce = 1, friction = 0 } )
   bottomWall.isSensor = true
   bottomWall.isBottomWall = true

   -- Add collision listener to bottom wall to handle 'missed ball' logic
   --
   function bottomWall.collision( self, event )
      if( event.phase == "began" and event.other == ball ) then
         
         -- Out of lives? 
         --
         if( lives <= 0 ) then

            -- Game over
            stopGame()

         -- Use up a life and reset board
         else

            -- Decrement life (counter)
            --
            lives = lives - 1

            -- Update life label
            --
            livesLabel.text = lives

            -- Prep for next round
            --
            -- Tip: We need to wait till next frame to handle this or physics engine will complain.
            --      The easiest way to do this is to wait 1-millsecond which defaults to the next frame.
            performWithDelay( 1, nextRound )
         end
      end
   end
   bottomWall:addEventListener( "collision" )

   -- Create Paddle
   -- 
   paddle = newRect( layers.content, centerX, bottom - 100, paddleWidth, paddleHeight  )
   paddle:setFillColor(0.25,0.5,0.5)
   physics.addBody( paddle, "kinematic", { bounce = 1, friction = 1 } )

   -- Set initial (move) target to current position of paddle
   paddle.targetX = paddle.x

   -- Pre-calculate min and max move positions of paddle
   --
   local paddleMinX = left + paddleWidth/2
   local paddleMaxX = right - paddleWidth/2

   -- Add 'enterFrame' listener to paddle
   --
   function paddle.enterFrame( self )

      -- If game is not running, exit early
      --
      if( not gameIsRunning ) then return end

      -- If we are waiting to move, exit early
      --
      if( waitingToStartBall ) then return end

      -- Ensure target is within bounds
      --
      -- Trick: This is the equivalent of a C-language ternary operator (var = condition ? true_value : false_value)
      --
      self.targetX = ( self.targetX < paddleMinX ) and paddleMinX or self.targetX
      self.targetX = ( self.targetX > paddleMaxX ) and paddleMaxX or self.targetX

      -- How far from the target are we?
      local dx = self.x - self.targetX 

      if( mAbs(dx) <= paddleSnapDist ) then
         self:setLinearVelocity(0,0)
         self.x = paddle.targetX
         return
      end

      -- Ensure we never pass the bounds of play
      --
      if ( self.x < paddleMinX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMinX
         return 
      end
      if ( self.x > paddleMaxX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMaxX
         return 
      end

      -- If we get this far, move the paddle
      --
      if( dx < 0 ) then
         self:setLinearVelocity( paddleSpeed )
      else
         self:setLinearVelocity( -paddleSpeed )
      end
   end 
   Runtime:addEventListener( "enterFrame", paddle )


   -- Create Ball
   -- 
   ball = newCircle( layers.content, paddle.x, paddle.y - paddleHeight/2 - ballSize/2, ballSize/2  )
   physics.addBody( ball, "dynamic", { radius = ballSize/2 - 1, bounce = 1, friction = 0.25 } )
   ball.isFixedRotation = true -- Don't let ball rotate
   ball:setFillColor(0.25,0.5,0.5)


   -- Add an 'enterFrame' event listener to the ball to keep it moving at a fixed rate
   --
   function ball.enterFrame( self )
      -- Exit early if game is not running or we are waiting for the ball to move
      if( not gameIsRunning or waitingToStartBall ) then return end
      local vx,vy = ball:getLinearVelocity()

      -- Determine current speed of ball
      --
      local len = vx * vx + vy * vy
      len = mSqrt( len )

      -- If ball is within maximum delta, leave it alone
      --
      if( mAbs(len - ballSpeed) <= maxBallSpeedDelta ) then return end

      -- Adjust the speed of the ball
      --
      vx = ballSpeed *  vx/len
      vy = ballSpeed *  vy/len
      self:setLinearVelocity( vx, vy )
   end
   Runtime:addEventListener( "enterFrame", ball )


   nextRound()
end   

--
-- startGame( ) - Start the game running
--
startGame = function( )
   gameIsRunning = true
end

--
-- stopGame( ) - Start the game running
--
stopGame = function( )   
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end

   -- Pause physics
   --
   physics.pause()

end


--
-- countBricks( ) - Utility function to count bricks in brick table.
--
function countBricks()
   if( not bricks ) then return 0 end

   -- Start with 0
   local count = 0

   -- Iterate over 'bricks' table ane increment count for each entry
   for k,v in pairs(bricks) do
      count = count + 1
   end
   
   -- Return the final count
   return count
end


--
-- nextRound( ) - Reset paddle, ball, and tap to start message
--
function nextRound()

   -- Mark 'waiting' flag as true
   --
   waitingToStartBall = true


   -- Stop the ball & paddle
   --
   ball:setLinearVelocity( 0, 0 )
   paddle:setLinearVelocity( 0, 0 )

   -- Move the paddle and ball to start position
   -- 
   paddle.x = centerX
   paddle.targetX = centerX
   ball.x = paddle.x
   ball.y = paddle.y - paddleHeight/2 - ballSize/2

   -- Pause Physics
   --
   physics.pause()

   -- Show the 'tap to start' label
   --
   tapToStartLabel.isVisible = true

end

--
-- calculateBallVector( ) - Calculated a starting velocity vector for our ball
--
function calculateBallVector()

   -- Choose an angle
   --
   local angle = 45

   -- Covert to vector
   angle = mRad(-(angle+90))
   local vx = mCos(angle) 
   local vy = mSin(angle) 

   --  Scale vector by velocity
   vx = vx * ballSpeed
   vy = vy * ballSpeed

   return vx,vy
end


-- **************************************************************************
-- Create and Start The Game
-- **************************************************************************

--newRect( centerX, centerY, 200, 200 )

createGame()

startGame()