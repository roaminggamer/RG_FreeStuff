-- ==========================================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- Example Begins Here
-- ==========================================================================

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************
local physics = require "physics"



-- **************************************************************************
-- Initialization
-- **************************************************************************
physics.start()
physics.setGravity( 0, 0 )
--physics.setDrawMode( "hybrid" )



-- **************************************************************************
-- Local Variables
-- **************************************************************************
--
-- 1. Frequently used 'concepts' pre-calculated and stored in easy to 
--    type & remember variable.
--
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

--
-- 2. (Game) Variables specific to this game and its logic.
--
local layers                        -- Top group containing all child groups
local gameIsRunning        = false  -- Flag to help track if game is running
local waitingToStartBall   = true
local gameTimer                     -- Handle to store timer id

local startTime                     -- Time (in milliseconds) when game started
local lives             = 3         -- Current Lives

local brickColors       = {
   "blue",
   --"grey",
   "green",
   --"orange",
   --"pink",
   --"black",
   "red",
   "yellow",
}

local wallAlpha         = 1.0       -- Translucency of walls


-- Angles at which ball can start moving
local ballStartAngles   = { -60, -45, -30, - 15, 15, 30, 45, 60 } 
local ballSpeed         = 500       -- Magnitude of ball starting velocity
local maxBallSpeedDelta    = 1         -- Speed can be off by this much and will be ignored

local paddleSpeed       = 1200       -- Magnitude of paddle velocity
local paddleSnapDist    = 15         -- If the paddle doesn't stop consistently, increase this value

local paddle                        -- The Paddle 
local ball                          -- Current ball

local ballSize          = 40

local bricks            = {}        -- Table to track brick instances
local brickWidth        = 94        -- Brick width
local brickHeight       = 44        -- Brick height

local paddleWidth       = 130       -- Paddle width
local paddleHeight      = 35        -- Paddle height
local paddleOffsetY     = -60

local borderStrokeWidth = 8
local boardOffsetY      = 0        -- Vertical offset for board center
local firstRowOffsetY   = 160

local topLabelsY        = top + 40
local startLabelY       = centerY + fullh/4

local labelFont         = "Prime.ttf"
local labelSize         = 40
local labelBuffer       = 80

local bricksLabel
local livesLabel
local tapToStartLabel

-- (Pre-) Load some sounds for use in our game
--
local sounds = {}
sounds.ready = audio.loadSound( "sounds/ready.ogg" )
sounds.go = audio.loadSound( "sounds/go.ogg" )
sounds.bounce = audio.loadSound( "sounds/bounce.wav" )
sounds.hit = audio.loadSound( "sounds/hurt1.ogg" )
sounds.miss = audio.loadSound( "sounds/fall3.ogg" )
sounds.gameOver = audio.loadSound( "sounds/game_over.ogg" )
sounds.lose = audio.loadSound( "sounds/you_lose.ogg" )
sounds.win = audio.loadSound( "sounds/you_win.ogg" )



-- **************************************************************************
-- Localize Commonly Used Functions 
--
-- Why Do This?: It gives small execution speedup, but mostly I do it 
-- to simplify typing.  I may not use them all, bit it is handy to have
-- them ready if I need them.
-- 
--
--  !!Warning!!: Don't take this too far.  Lua has a limit of 200 
--               local variables in scope at any time.
--
--     Pro Tip:  Be a DRY coder, not a WET coder.
--               WET ==> Write Everything Twice; We Enjoy Typing; ...
--               DRY ==> Don't Repeat Yourself
--
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Forward Declarations
--
-- Tip: This makes the following function names VISIBLE for the rest of the file.
--      They can be called anywhere below as long as they have been defined before
--      the are called. (As soon as this file 'loads', all of the functions will 
--      be defined.)
-- 
-- Note: I split game logic into create, destroy, start, stop... etc. because:
--
-- 1. It makes reading these parts of the code easier.
--
-- 2. It promotes the concepts associated with these function to you.
--    Ex: While 'pausing' may not be super helpful in this game, you might want
--    to have this concept in a future game.  So, practicing the design 
--    pattern now, will be useful to you later.
--
-- 3. Having this functionality broken up discretely helps you prepare for
--    writing game modules, and then for using composer.*.
-- 
-- **************************************************************************
local destroyGame
local createGame
local startGame
local stopGame
local pauseGame
local resumeGame
local nextRound
local countBricks
local calculateBallVector


-- **************************************************************************
-- Function Definitions
-- **************************************************************************

--
-- destroyGame( ) - Create the game content
--
destroyGame = function( group )

   -- Do any work to stop the game
   -- 
   stopGame()
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   layers = display.remove( layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear the bricks tracking table by setting it to nil.
   --
   bricks = nil

   -- Stop enterFrame listener and clear paddle varaible
   --
   Runtime:removeEventListener( "enterFrame", paddle )
   paddle = nil


   -- Clear label references so they can be garbage collected
   --
   bricksLabel = nil
   livesLabel = nil

end


--
-- createGame( group ) - Create the game content
--
createGame = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   destroyGame()

   -- Start with three lives
   --
   lives = 3

   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.content    = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.content )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   --local back = newImageRect( layers.background, "images/protoBack.png", 760, 1140)
   local back = newImageRect( layers.background, "images/background.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 0

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      for k,v in pairs( event ) do
         --print(k,v)      
      end

      -- Are we waiting to start the ball moving?
      --
      if( waitingToStartBall and event.phase == "ended" ) then

         -- Clear the flag
         --
         waitingToStartBall = false

         -- Hide 'tap to start' message
         --
         tapToStartLabel.isVisible = false
         
         -- Resume Physics
         --
         physics.start()

         -- Give the ball a random bounce
         local vx,vy = calculateBallVector()
         ball:setLinearVelocity( vx, vy )

         -- Play Go! sound
         --
         audio.play( sounds.go )
      
      -- Not waitint to start the ball?  The update the paddle target
      elseif( not waitingToStartBall ) then
         
         -- Set target x-position for paddle.  The paddle's 'enterFrame' listener 
         -- will use this value to try to move the paddle.
         paddle.targetX = event.x
         --print( event.x )
      end
      return true
   end
   back:addEventListener( "touch" )

   --
   -- Brick Functions & Methods - Builder function and methods for each brick.
   --   

   -- Shared Brick Methods
   --
   bricks = {} -- Create fresh table for our bricks.

   -- Shared Collision Listener (also a method)
   --
   local function onCollision( self, event )
      local phase = event.phase
      local other = event.other

      -- Is this the end of the collision and were we struck by a ball?
      --
      if( phase == "ended" and other == ball ) then

         -- Play hit sound
         --
         audio.play( sounds.hit )

         -- Remove this brick from the bricks table
         --
         bricks[self] = nil

         -- Destroy the brick
         --
         display.remove(self)

         -- Count remaining bricks
         --
         local remainingBricks = countBricks()

         -- Update the brick counter label
         --
         bricksLabel.text = remainingBricks

         -- Last brick destroyed? 
         --
         if( remainingBricks <= 0 ) then

            -- Play You Win! sound
            --
            audio.play( sounds.win )

            -- Stop the Game
            --
            stopGame()

         end

      end

      return false 
   end


   -- Brick Builder Function
   --
   local function newBrick( x, y, color )

      -- Draw an 'empty hole'
      local brick = newImageRect( layers.content, "images/kenney/bricks/" .. color ..".png", brickWidth, brickHeight )
      brick.x = x
      brick.y = y

      -- Attach body to brick
      --
      physics.addBody( brick, "static", { bounce = 1, friction = 0 } )

      -- Attach common collision listener and start listening for collisions
      brick.collision = onCollision
      brick:addEventListener( "collision" )

      -- Set flag(s) on brick.
      brick.isShowing = false
      brick.color = color

      -- Add to bricks list
      bricks[brick] = brick

      -- Return reference to brick
      return brick
   end

   -- Draw Labels Elements
   --
   local livesPrefix = newText( layers.interface, "Lives: ", centerX - 100, topLabelsY, labelFont, labelSize )
   livesPrefix.anchorX = 1
   livesPrefix:setFillColor(0,0,0)
   livesLabel = newText( layers.interface, lives, livesPrefix.x, topLabelsY, labelFont, labelSize )
   livesLabel.anchorX = 0
   livesLabel:setFillColor(0,0,0)

   local bricksPrefix = newText( layers.interface, "Bricks: ", centerX + 150, topLabelsY, labelFont, labelSize )
   bricksPrefix.anchorX = 1
   bricksPrefix:setFillColor(0,0,0)
   bricksLabel = newText( layers.interface, 0, bricksPrefix.x, topLabelsY, labelFont, labelSize )
   bricksLabel.anchorX = 0
   bricksLabel:setFillColor(0,0,0)

   -- Tap To Start Label
   --
   tapToStartLabel = newText( layers.interface, "Tap To Start", centerX, startLabelY, labelFont, labelSize )
   tapToStartLabel:setFillColor(0,0,1)
   

   --
   -- Draw a grid of bricks
   --
   local brickCols      = mFloor( w / brickWidth )
   local brickRows      = #brickColors
   local boardHeight    = fullh - labelBuffer
   local boardWidth     = fullw - (fullw - brickCols * brickWidth) + borderStrokeWidth
   local boardTop       = top + labelBuffer
   local boardBottom    = boardTop + boardHeight

   local startX         = centerX - (brickCols * brickWidth)/2 + brickWidth/2
   local startY         = boardTop + firstRowOffsetY
   local curX           = startX 
   local curY           = startY

   local last 
   for row = 1, brickRows do
      for col = 1, brickCols do
         --print( row, col, curX, curY)
         local brick = newBrick( curX, curY, brickColors[row] )      
         curX = curX + brickWidth
         last = brick
      end
      curX = startX
      curY = curY + brickHeight
   end

   -- Update bricks counter label
   --
   bricksLabel.text = countBricks()

   -- Draw Play Area Border
   --
   local boardOutline = newRect( layers.interface, centerX, boardTop, boardWidth, boardHeight - borderStrokeWidth * 2 )
   boardOutline.anchorY = 0
   boardOutline:setFillColor( 0, 0, 0, 0 )
   boardOutline:setStrokeColor( 0, 0, 0 )
   boardOutline.strokeWidth = borderStrokeWidth

   -- Create Walls
   local leftWall = newRect( layers.content, boardOutline.x - boardWidth/2, boardOutline.y, 2000, 2000 )
   leftWall.anchorX = 1
   leftWall.alpha = wallAlpha
   leftWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( leftWall, "static", { bounce = 1, friction = 0 } )
   
   local rightWall = newRect( layers.content, boardOutline.x + boardWidth/2, boardOutline.y, 2000, 2000 )
   rightWall.anchorX = 0
   rightWall.alpha = wallAlpha
   rightWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( rightWall, "static", { bounce = 1, friction = 0 } )

   local topWall = newRect( layers.content, boardOutline.x, boardOutline.y, boardWidth, 20000 )
   topWall.anchorY = 1
   topWall.alpha = wallAlpha
   topWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( topWall, "static", { bounce = 1, friction = 0 } )

   local bottomWall = newRect( layers.content, boardOutline.x, boardOutline.y + boardHeight - borderStrokeWidth * 2, boardWidth, 20000 )
   bottomWall.anchorY = 0
   bottomWall.alpha = wallAlpha
   bottomWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( bottomWall, "static", { bounce = 1, friction = 0 } )
   bottomWall.isSensor = true
   bottomWall.isBottomWall = true

   -- Add collision listener to bottom wall to handle 'missed ball' logic
   --
   function bottomWall.collision( self, event )
      if( event.phase == "began" and event.other == ball ) then

         -- Play miss sound
         --
         audio.play( sounds.miss )

         
         -- Out of lives? 
         --
         if( lives <= 0 ) then

            -- Play lose sound
            --
            audio.play( sounds.lose )

            -- Game over
            stopGame()

         -- Use up a life and reset board
         else

            -- Decrement life (counter)
            --
            lives = lives - 1

            -- Update life label
            --
            livesLabel.text = lives

            -- Prep for next round
            --
            -- Tip: We need to wait till next frame to handle this or physics engine will complain.
            --      The easiest way to do this is to wait 1-millsecond which defaults to the next frame.
            performWithDelay( 1, nextRound )
         end
      end
   end
   bottomWall:addEventListener( "collision" )

   -- Create Paddle
   -- 
   paddle = newImageRect( layers.content, "images/kenney/paddle.png", paddleWidth, paddleHeight  )
   paddle.x = centerX
   paddle.y = boardOutline.y + boardHeight + paddleOffsetY
   physics.addBody( paddle, "kinematic", { bounce = 1, friction = 1 } )

   -- Set initial (move) target to current position of paddle
   paddle.targetX = paddle.x

   -- Pre-calculate min and max move positions of paddle
   --
   local paddleMinX = boardOutline.x - boardOutline.contentWidth/2 + paddleWidth/2 + borderStrokeWidth
   local paddleMaxX = boardOutline.x + boardOutline.contentWidth/2 - paddleWidth/2 - borderStrokeWidth

   -- Add 'enterFrame' listener to paddle
   --
   function paddle.enterFrame( self )

      -- If game is not running, exit early
      --
      if( not gameIsRunning ) then return end

      -- If we are waiting to move, exit early
      --
      if( waitingToStartBall ) then return end

      -- Ensure target is within bounds
      --
      -- Trick: This is the equivalent of a C-language ternary operator (var = condition ? true_value : false_value)
      --
      self.targetX = ( self.targetX < paddleMinX ) and paddleMinX or self.targetX
      self.targetX = ( self.targetX > paddleMaxX ) and paddleMaxX or self.targetX

      -- How far from the target are we?
      local dx = self.x - self.targetX 

      if( mAbs(dx) <= paddleSnapDist ) then
         self:setLinearVelocity(0,0)
         self.x = paddle.targetX
         return
      end

      -- Ensure we never pass the bounds of play
      --
      if ( self.x < paddleMinX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMinX
         return 
      end
      if ( self.x > paddleMaxX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMaxX
         return 
      end

      -- If we get this far, move the paddle
      --
      if( dx < 0 ) then
         self:setLinearVelocity( paddleSpeed )
      else
         self:setLinearVelocity( -paddleSpeed )
      end
   end 
   Runtime:addEventListener( "enterFrame", paddle )


   -- Create Ball
   -- 
   ball = newImageRect( layers.content, "images/kenney/ball.png", ballSize, ballSize  )
   ball.x = paddle.x
   ball.y = paddle.y - paddleHeight/2 - ballSize/2
   physics.addBody( ball, "dynamic", { radius = ballSize/2 - 1, bounce = 1, friction = 0.25 } )
   ball.isFixedRotation = true -- Don't let ball rotate

   -- Add an 'enterFrame' event listener to the ball to keep it moving at a fixed rate
   --
   function ball.enterFrame( self )
      -- Exit early if game is not running or we are waiting for the ball to move
      if( not gameIsRunning or waitingToStartBall ) then return end
      local vx,vy = ball:getLinearVelocity()

      -- Determine current speed of ball
      --
      local len = vx * vx + vy * vy
      len = mSqrt( len )

      -- If ball is within maximum delta, leave it alone
      --
      if( mAbs(len - ballSpeed) <= maxBallSpeedDelta ) then return end

      -- Adjust the speed of the ball
      --
      vx = ballSpeed *  vx/len
      vy = ballSpeed *  vy/len
      self:setLinearVelocity( vx, vy )
   end
   Runtime:addEventListener( "enterFrame", ball )


   -- Add a collision listener to ball to play bounce souncd
   --
   function ball.collision( self, event )
      if( event.phase == "began" and not event.other.isBottomWall ) then
         -- Play bounce sound
         --
         audio.play( sounds.bounce )
      end
      return false
   end
   ball:addEventListener( "collision" )


   nextRound()

end   

--
-- startGame( ) - Start the game running
--
startGame = function( )
   gameIsRunning = true
end

--
-- stopGame( ) - Start the game running
--
stopGame = function( )   
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end

   -- Pause physics
   --
   physics.pause()

end

--
-- pauseGame( ) - Like stopping, but non-destructive.
--
pauseGame = function( )
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end

end

--
-- resumeGame( ) - Start the game running
--
resumeGame = function( )   
   -- Mark game as 'running'
   gameIsRunning = true

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end

end

--
-- countBricks( ) - Utility function to count bricks in brick table.
--
function countBricks()
   if( not bricks ) then return 0 end

   -- Start with 0
   local count = 0

   -- Iterate over 'bricks' table ane increment count for each entry
   for k,v in pairs(bricks) do
      count = count + 1
   end
   
   -- Return the final count
   return count
end


--
-- nextRound( ) - Reset paddle, ball, and tap to start message
--
function nextRound()

   -- Mark 'waiting' flag as true
   --
   waitingToStartBall = true


   -- Stop the ball & paddle
   --
   ball:setLinearVelocity( 0, 0 )
   paddle:setLinearVelocity( 0, 0 )

   -- Move the paddle and ball to start position
   -- 
   paddle.x = centerX
   paddle.targetX = centerX
   ball.x = paddle.x
   ball.y = paddle.y - paddleHeight/2 - ballSize/2


   -- Pause Physics
   --
   physics.pause()


   -- Show the 'tap to start' label
   --
   tapToStartLabel.isVisible = true

   audio.play( sounds.ready )
end

--
-- calculateBallVector( ) - Calculated a starting velocity vector for our ball
--
function calculateBallVector()

   -- Choose an angle
   --
   local angle = ballStartAngles[mRand(1,#ballStartAngles)]

   -- Covert to vector
   angle = mRad(-(angle+90))
   local vx = mCos(angle) 
   local vy = mSin(angle) 

   --  Scale vector by velocity
   vx = vx * ballSpeed
   vy = vy * ballSpeed

   return vx,vy
end


-- **************************************************************************
-- Create and Start The Game
-- **************************************************************************

--newRect( centerX, centerY, 200, 200 )

createGame()

startGame()