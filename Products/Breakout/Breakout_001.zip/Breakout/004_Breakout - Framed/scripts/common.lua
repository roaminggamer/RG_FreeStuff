-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- This module contains common settings and is also used by the
-- other modules as a 'scratch-pad' for sharing references and
-- values between modules instead of using globals.
--
-- =============================================================

local common = {}

common.gameIsRunning        = false  -- Flag to help track if game is running
common.waitingToStartBall   = true

common.lives             = 3         -- Current Lives

common.brickColors       = {
   "blue",
   --"grey",
   "green",
   --"orange",
   --"pink",
   --"black",
   "red",
   "yellow",
}

common.wallAlpha         = 1.0       -- Translucency of walls


-- Angles at which ball can start moving
common.ballStartAngles   = { -60, -45, -30, - 15, 15, 30, 45, 60 } 
common.ballSpeed         = 500       -- Magnitude of ball starting velocity
common.maxBallSpeedDelta    = 1         -- Speed can be off by this much and will be ignored

common.paddleSpeed       = 1200       -- Magnitude of paddle velocity
common.paddleSnapDist    = 15         -- If the paddle doesn't stop consistently, increase this value

common.ballSize          = 40

common.bricks            = {}        -- Table to track brick instances
common.brickWidth        = 94        -- Brick width
common.brickHeight       = 44        -- Brick height

common.paddleWidth       = 130       -- Paddle width
common.paddleHeight      = 35        -- Paddle height
common.paddleOffsetY     = -60

common.borderStrokeWidth = 8
common.boardOffsetY      = 0        -- Vertical offset for board center
common.firstRowOffsetY   = 160

common.topLabelsY        = top + 40
common.startLabelY       = centerY + fullh/4

common.labelFont         = "Raleway-Black.ttf"
common.labelSize         = 40
common.labelBuffer       = 80


-- (Pre-) Load some sounds for use in our game
--
common.sounds = {}
common.sounds.ready = audio.loadSound( "sounds/ready.ogg" )
common.sounds.go = audio.loadSound( "sounds/go.ogg" )
common.sounds.bounce = audio.loadSound( "sounds/bounce.wav" )
common.sounds.hit = audio.loadSound( "sounds/hurt1.ogg" )
common.sounds.miss = audio.loadSound( "sounds/fall3.ogg" )
common.sounds.gameOver = audio.loadSound( "sounds/game_over.ogg" )
common.sounds.lose = audio.loadSound( "sounds/you_lose.ogg" )
common.sounds.win = audio.loadSound( "sounds/you_win.ogg" )


return common