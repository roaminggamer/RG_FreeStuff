-- ==========================================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- ==========================================================================
-- main.lua
-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- https://roaminggamer.github.io/RGDocs/pages/SSK2/
--require "ssk2.loadSSK" 
--_G.ssk.init( {} )
-- ==========================================================================

-- ==========================================================================
-- Example Begins Here
-- ==========================================================================


-- **************************************************************************
-- Global Variables
-- **************************************************************************
-- Common Wisdom: 
--
-- When in doubt, DO NOT make a variable a global.  It is generally a bad practice.
--
-- **************************************************************************
--
-- Exception:
--
-- I find these variable so useful that I commonly make them globals in my
-- projects.  If you disagree, feel free to modify the code to suit your own 
-- style.
--
-- **************************************************************************
_G.centerX = display.contentCenterX       -- Horizontal center of screen
_G.centerY = display.contentCenterY       -- Vertical center of screen
_G.w = display.contentWidth               -- Content width (specified in config.lua)
_G.h = display.contentHeight              -- Content height (specified in config.lua)
_G.fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
_G.fullh = display.actualContentHeight    -- May be taller or shorter than content height.
_G.left = centerX - fullw/2               -- True left-edge of screen
_G.right = left + fullw                   -- True right-edge of screen
_G.top = centerY - fullh/2                -- True top-edge of screen
_G.bottom = top + fullh                   -- True bottom-edge of screen

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************
local physics = require "physics"
local game = require "scripts.game"


-- **************************************************************************
-- Initialization
-- **************************************************************************
physics.start()
physics.setGravity( 0, 0 )
--physics.setDrawMode( "hybrid" )



-- **************************************************************************
-- Create & Start Game
-- **************************************************************************
game.create()
game.start()


