-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- game.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"
local brickM    	= require "scripts.bricks"
local ballM    	= require "scripts.ball"
local paddleM    	= require "scripts.paddle"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local game = {}

-- **************************************************************************
-- Locals
-- **************************************************************************

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

--
-- destroy( ) - Create the game content
--
game.destroy = function( group )

   -- Do any work to stop the game
   -- 
   game.stop()
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   common.layers = display.remove( common.layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   common.layers = nil

   -- Clear the bricks tracking table by setting it to nil.
   --
   common.bricks = nil

   -- Stop enterFrame listener and clear paddle varaible
   --
   Runtime:removeEventListener( "enterFrame", common.paddle )
   common.paddle = nil


   -- Clear label references so they can be garbage collected
   --
   common.bricksLabel = nil
   common.livesLabel = nil
end

--
-- create( group ) - Create the game content
--
game.create = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   game.destroy()

   -- Start with three lives
   --
   common.lives = 3

   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   common.layers            = display.newGroup()
   common.layers.background = display.newGroup()
   common.layers.content    = display.newGroup()
   common.layers.interface  = display.newGroup()
   group:insert( common.layers )
   common.layers:insert( common.layers.background )
   common.layers:insert( common.layers.content )
   common.layers:insert( common.layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( common.layers.background, "images/background.png", 760, 1140 )
   back.x = centerX
   back.y = centerY
   back.rotation = 0

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      for k,v in pairs( event ) do
         --print(k,v)      
      end

      -- Are we waiting to start the ball moving?
      --
      if( common.waitingToStartBall and event.phase == "ended" ) then

         -- Clear the flag
         --
         common.waitingToStartBall = false

         -- Hide 'tap to start' message
         --
         common.tapToStartLabel.isVisible = false
         
         -- Resume Physics
         --
         physics.start()

         -- Give the ball a random bounce
         local vx,vy = game.calculateBallVector()
         common.ball:setLinearVelocity( vx, vy )

         -- Play Go! sound
         --
         audio.play( common.sounds.go )
      
      -- Not waitint to start the ball?  The update the paddle target
      elseif( not common.waitingToStartBall ) then
         
         -- Set target x-position for paddle
         -- The paddle's 'enterFrame' listener will use this value to try to move
         -- the paddle
         common.paddle.targetX = event.x
         --print( event.x )
      end
      return true
   end
   back:addEventListener( "touch" )

   --
   -- Brick Functions & Methods - Builder function and methods for each brick.
   --   

   -- Shared Brick Methods
   --
   common.bricks = {} -- Create fresh table for our bricks.


   -- Draw Labels Elements
   --
   local livesPrefix = newText( common.layers.interface, "Lives: ", centerX - 100, common.topLabelsY, common.labelFont, common.labelSize )
   livesPrefix.anchorX = 1
   livesPrefix:setFillColor(0,0,0)
   common.livesLabel = newText( common.layers.interface, common.lives, livesPrefix.x, common.topLabelsY, common.labelFont, common.labelSize )
   common.livesLabel.anchorX = 0
   common.livesLabel:setFillColor(0,0,0)

   local bricksPrefix = newText( common.layers.interface, "Bricks: ", centerX + 150, common.topLabelsY, common.labelFont, common.labelSize )
   bricksPrefix.anchorX = 1
   bricksPrefix:setFillColor(0,0,0)
   common.bricksLabel = newText( common.layers.interface, 0, bricksPrefix.x, common.topLabelsY, common.labelFont, common.labelSize )
   common.bricksLabel.anchorX = 0
   common.bricksLabel:setFillColor(0,0,0)

   -- Tap To Start Label
   --
   common.tapToStartLabel = newText( common.layers.interface, "Tap To Start", centerX, common.startLabelY, common.labelFont, common.labelSize )
   common.tapToStartLabel:setFillColor(0,0,1)
   

   --
   -- Draw a grid of bricks
   --
   local brickCols      = mFloor( w / common.brickWidth )
   local brickRows      = #common.brickColors
   local boardHeight    = fullh - common.labelBuffer
   local boardWidth     = fullw - (fullw - brickCols * common.brickWidth) + common.borderStrokeWidth
   local boardTop       = top + common.labelBuffer
   local boardBottom    = boardTop + boardHeight

   local startX         = centerX - (brickCols * common.brickWidth)/2 + common.brickWidth/2
   local startY         = boardTop + common.firstRowOffsetY
   local curX           = startX 
   local curY           = startY

   local last 
   for row = 1, brickRows do
      for col = 1, brickCols do
         --print( row, col, curX, curY)
         local brick = brickM.new( curX, curY, common.brickColors[row] )      
         curX = curX + common.brickWidth
         last = brick
      end
      curX = startX
      curY = curY + common.brickHeight
   end

   -- Update bricks counter label
   --
   common.bricksLabel.text = brickM.count()

   -- Draw Play Area Border
   --
   local boardOutline = newRect( common.layers.interface, centerX, boardTop, boardWidth, boardHeight - common.borderStrokeWidth * 2 )
   boardOutline.anchorY = 0
   boardOutline:setFillColor( 0, 0, 0, 0 )
   boardOutline:setStrokeColor( 0, 0, 0 )
   boardOutline.strokeWidth = common.borderStrokeWidth

   -- Create Walls
   local leftWall = newRect( common.layers.content, boardOutline.x - boardWidth/2, boardOutline.y, 2000, 2000 )
   leftWall.anchorX = 1
   leftWall.alpha = wallAlpha
   leftWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( leftWall, "static", { bounce = 1, friction = 0 } )
   
   local rightWall = newRect( common.layers.content, boardOutline.x + boardWidth/2, boardOutline.y, 2000, 2000 )
   rightWall.anchorX = 0
   rightWall.alpha = wallAlpha
   rightWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( rightWall, "static", { bounce = 1, friction = 0 } )

   local topWall = newRect( common.layers.content, boardOutline.x, boardOutline.y, boardWidth, 20000 )
   topWall.anchorY = 1
   topWall.alpha = wallAlpha
   topWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( topWall, "static", { bounce = 1, friction = 0 } )

   local bottomWall = newRect( common.layers.content, boardOutline.x, boardOutline.y + boardHeight - common.borderStrokeWidth * 2, boardWidth, 20000 )
   bottomWall.anchorY = 0
   bottomWall.alpha = wallAlpha
   bottomWall:setFillColor( 0.5, 0.5, 0.5 )
   physics.addBody( bottomWall, "static", { bounce = 1, friction = 0 } )
   bottomWall.isSensor = true
   bottomWall.isBottomWall = true

   -- Add collision listener to bottom wall to handle 'missed ball' logic
   --
   function bottomWall.collision( self, event )
      if( event.phase == "began" and event.other == common.ball ) then

         -- Play miss sound
         --
         audio.play( common.sounds.miss )
         
         -- Out of common.lives? 
         --
         if( common.lives <= 0 ) then

            -- Play lose sound
            --
            audio.play( common.sounds.lose )

            -- Game over
            game.stop()

         -- Use up a life and reset board
         else

            -- Decrement life (counter)
            --
            common.lives = common.lives - 1

            -- Update life label
            --
            common.livesLabel.text = common.lives

            -- Prep for next round
            --
            -- Tip: We need to wait till next frame to handle this or physics engine will complain.
            --      The easiest way to do this is to wait 1-millsecond which defaults to the next frame.
            performWithDelay( 1, game.nextRound )
         end
      end
   end
   bottomWall:addEventListener( "collision" )

   -- Create Paddle
   -- 
   paddleM.new( boardOutline, boardHeight )

   -- Create Ball
   -- 
   ballM.new()

   game.nextRound()
end   

--
-- start( ) - Start the game running
--
game.start = function( )
	common.gameIsRunning = true

end

--
-- stop( ) - Stop the game running
--
game.stop = function( )   
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.pause( common.gameTimer )
   end

   -- Hide the ball
   --
   if( common.ball ) then
   	common.ball.isVisible = false
   end

   -- Pause physics
   --
   physics.pause()
end

--
-- pause( ) - Like stopping, but non-destructive.
--
game.pause = function( )
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- Pause Physics
   physics.pause()

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.pause( common.gameTimer )
   end
end

--
-- resume( ) - Start the game running
--
game.resume = function( )   
   -- Mark game as 'running'
   common.gameIsRunning = true

   -- Resume Physics
   physics.start()

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.resume( common.gameTimer )
   end
end



--
-- game.nextRound( ) - Reset paddle, ball, and tap to start message
--
function game.nextRound()

   -- Mark 'waiting' flag as true
   --
   common.waitingToStartBall = true

   -- Stop the ball & common.paddle
   --
   common.ball:setLinearVelocity( 0, 0 )
   common.paddle:setLinearVelocity( 0, 0 )

   -- Move the paddle and ball to start position
   -- 
   common.paddle.x = centerX
   common.paddle.targetX = centerX
   common.ball.x = common.paddle.x
   common.ball.y = common.paddle.y - common.paddleHeight/2 - common.ballSize/2


   -- Pause Physics
   --
   physics.pause()


   -- Show the 'tap to start' label
   --
   common.tapToStartLabel.isVisible = true

   audio.play( common.sounds.ready )
end

--
-- calculateBallVector( ) - Calculated a starting velocity vector for our ball
--
function game.calculateBallVector()

   -- Choose an angle
   --
   local angle = common.ballStartAngles[mRand(1,#common.ballStartAngles)]

   -- Covert to vector
   angle = mRad(-(angle+90))
   local vx = mCos(angle) 
   local vy = mSin(angle) 

   --  Scale vector by velocity
   vx = vx * common.ballSpeed
   vy = vy * common.ballSpeed

   return vx,vy
end



return game