-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- mole.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local brickM = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
local onCollision

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

-- Builder Function
--
function brickM.new( x, y, color )

      -- Draw an 'empty hole'
      local brick = newImageRect( common.layers.content, "images/kenney/bricks/" .. color ..".png", common.brickWidth, common.brickHeight )
      brick.x = x
      brick.y = y

      -- Attach body to brick
      --
      physics.addBody( brick, "static", { bounce = 1, friction = 0 } )

      -- Attach common collision listener and start listening for collisions
      brick.collision = onCollision
      brick:addEventListener( "collision" )

      -- Set flag(s) on brick.
      brick.isShowing = false
      brick.color = color

      -- Add to bricks list
      common.bricks[brick] = brick

      -- Return reference to brick
      return brick

end


--
-- countBricks( ) - Utility function to count bricks in brick table.
--
function brickM.count()
   if( not common.bricks ) then return 0 end

   -- Start with 0
   local count = 0

   -- Iterate over 'bricks' table ane increment count for each entry
   for k,v in pairs(common.bricks) do
      count = count + 1
   end
   
   -- Return the final count
   return count
end




-- Shared Collision Listener (also a method)
--
onCollision = function( self, event )
   local phase = event.phase
   local other = event.other

   -- Is this the end of the collision and were we struck by a ball?
   --
   if( phase == "ended" and other == common.ball ) then

      -- Play hit sound
      --
      audio.play( common.sounds.hit )

      -- Remove this brick from the bricks table
      --
      common.bricks[self] = nil

      -- Destroy the brick
      --
      display.remove(self)

      -- Count remaining bricks
      --
      local remainingBricks = brickM.count()

      -- Update the brick counter label
      --
      common.bricksLabel.text = remainingBricks

      -- Last brick destroyed? 
      --
      if( remainingBricks <= 0 ) then

         -- Play You Win! sound
         --
         audio.play( common.sounds.win )

         -- Stop the Game
         --
         local game = require "scripts.game"
         game.stop()

      end

   end

   return false 
end



return brickM