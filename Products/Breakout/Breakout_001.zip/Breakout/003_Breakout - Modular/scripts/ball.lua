-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- mole.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local ballM = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
-- None.

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

-- Builder Function
--
function ballM.new( )

   common.ball = newImageRect( common.layers.content, "images/kenney/ball.png", common.ballSize, common.ballSize  )
   common.ball.x = common.paddle.x
   common.ball.y = common.paddle.y - common.paddleHeight/2 - common.ballSize/2
   physics.addBody( common.ball, "dynamic", { radius = common.ballSize/2 - 1, bounce = 1, friction = 0.25 } )
   common.ball.isFixedRotation = true -- Don't let ball rotate

   -- Add an 'enterFrame' event listener to the ball to keep it moving at a fixed rate
   --
   function common.ball.enterFrame( self )
      -- Exit early if game is not running or we are waiting for the ball to move
      if( not common.gameIsRunning or common.waitingToStartBall ) then return end
      local vx,vy = common.ball:getLinearVelocity()

      -- Determine current speed of ball
      --
      local len = vx * vx + vy * vy
      len = mSqrt( len )

      -- If ball is within maximum delta, leave it alone
      --
      if( mAbs(len - common.ballSpeed) <= common.maxBallSpeedDelta ) then return end

      -- Adjust the speed of the ball
      --
      vx = common.ballSpeed *  vx/len
      vy = common.ballSpeed *  vy/len
      self:setLinearVelocity( vx, vy )
   end
   Runtime:addEventListener( "enterFrame", common.ball )


   -- Add a collision listener to ball to play bounce souncd
   --
   function common.ball.collision( self, event )
      if( event.phase == "began" and not event.other.isBottomWall ) then
         -- Play bounce sound
         --
         audio.play( common.sounds.bounce )
      end
      return false
   end
   common.ball:addEventListener( "collision" )

end

return ballM