-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- mole.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local paddleM = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
-- None.

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

-- Builder Function
--
function paddleM.new( boardOutline, boardHeight )
   common.paddle = newImageRect( common.layers.content, "images/kenney/paddle.png", common.paddleWidth, common.paddleHeight  )
   common.paddle.x = centerX
   common.paddle.y = boardOutline.y + boardHeight + common.paddleOffsetY

   -- Tip: If you want to learn more about physics body styles...
   --
   -- 1. You should uncomment the setDrawMode line, then ...
   -- 2. try each diffent body style below, one-by-one to see the difference.   
   
   --physics.setDrawMode( "hybrid" )

   --[[
   -- Style 1 - Standard rectangle (not a good edge bounce)
   physics.addBody( common.paddle, "kinematic", { bounce = 1, friction = 1 } )
   --]]

   ----[[
   -- Style 2 - Uses an outline (Quite good on my machine, but you should test this thoroughly on your devices.)
   -- Warning: My have prohibitive cost overhead if you use a high 'coarsness' value and you call 
   -- graphics.newOutline() in a frame.
   -- https://docs.coronalabs.com/daily/api/library/graphics/newOutline.html
   -- https://docs.coronalabs.com/daily/api/library/physics/addBody.html#outline-body
   local paddleOutline = graphics.newOutline( 8, "images/kenney/paddle.png" )
   physics.addBody( common.paddle, "kinematic", { outline = paddleOutline, bounce = 1, friction = 1 } )
   --]]

   --[[
   -- Style 3 - Polygonal Body (Hand tuned, limited to 8 vertices, but fully controlled by you [see tip below].)
   --
   -- Tip: I gave this paddle a weird wedge shape to allow for last second saves when the ball passes the 
   -- vertical center of the paddle.
   --
   -- https://docs.coronalabs.com/daily/api/library/physics/addBody.html#polygonal-body
   local paddleShape = { 
      -common.paddleWidth/2,      -common.paddleHeight/2 + 15,    -- vertex 1 
      -common.paddleWidth/2 + 10, -common.paddleHeight/2,         -- vertex 2 
       common.paddleWidth/2 - 10, -common.paddleHeight/2,         -- vertex 3
       common.paddleWidth/2,      -common.paddleHeight/2 + 15,    -- vertex 4
       common.paddleWidth/2 + 10,  common.paddleHeight/2,         -- vertex 5
      -common.paddleWidth/2 - 10,  common.paddleHeight/2          -- vertex 6
   }
   physics.addBody( common.paddle, "kinematic", { shape = paddleShape, bounce = 1, friction = 1 } )
   --]]

   --[[
   -- Style 4 - Chain Body (Hand tuned and unlimited number of vertices.)
   --
   -- Tip: I gave this paddle a weird wedge shape to allow for last second saves when the ball passes the 
   -- vertical center of the paddle.
   --
   -- https://docs.coronalabs.com/daily/api/library/physics/addBody.html#edge-shape-chain-body
   local paddleChain = { 
      -common.paddleWidth/2,      -common.paddleHeight/2 + 15,    -- vertex 1 
      -common.paddleWidth/2 + 10, -common.paddleHeight/2,         -- vertex 2 
       common.paddleWidth/2 - 10, -common.paddleHeight/2,         -- vertex 3
       common.paddleWidth/2,      -common.paddleHeight/2 + 15,    -- vertex 4
       common.paddleWidth/2 - 10,  common.paddleHeight/2,         -- vertex 5
      -common.paddleWidth/2 + 10,  common.paddleHeight/2          -- vertex 6
   }
   physics.addBody( common.paddle, "kinematic", { chain = paddleChain, 
                                                  connectFirstAndLastChainVertex = true, 
                                                  bounce = 1, friction = 1 } )
   --]]


   -- Set initial (move) target to current position of paddle
   common.paddle.targetX = common.paddle.x

   -- Pre-calculate min and max move positions of paddle
   --
   local paddleMinX = boardOutline.x - boardOutline.contentWidth/2 + common.paddleWidth/2 + common.borderStrokeWidth
   local paddleMaxX = boardOutline.x + boardOutline.contentWidth/2 - common.paddleWidth/2 - common.borderStrokeWidth

   -- Add 'enterFrame' listener to paddle
   --
   function common.paddle.enterFrame( self )

      -- If game is not running, exit early
      --
      if( not common.gameIsRunning ) then return end

      -- If we are waiting to move, exit early
      --
      if( common.waitingToStartBall ) then return end

      -- Ensure target is within bounds
      --
      -- Trick: This is the equivalent of a C-language ternary operator (var = condition ? true_value : false_value)
      --
      self.targetX = ( self.targetX < paddleMinX ) and paddleMinX or self.targetX
      self.targetX = ( self.targetX > paddleMaxX ) and paddleMaxX or self.targetX

      -- How far from the target are we?
      local dx = self.x - self.targetX 

      if( mAbs(dx) <= common.paddleSnapDist ) then
         self:setLinearVelocity(0,0)
         self.x = self.targetX
         return
      end

      -- Ensure we never pass the bounds of play
      --
      if ( self.x < paddleMinX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMinX
         return 
      end
      if ( self.x > paddleMaxX ) then
         self:setLinearVelocity(0,0)
         self.x = paddleMaxX
         return 
      end


      -- If we get this far, move the paddle
      --
      if( dx < 0 ) then
         self:setLinearVelocity( common.paddleSpeed )
      else
         self:setLinearVelocity( -common.paddleSpeed )
      end
   end 
   Runtime:addEventListener( "enterFrame", common.paddle )

end

return paddleM