-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
--[[
		IMPORTANT CONCEPTS/TERMS

	tile - The background for a letter tile and/or the image of a letter tile.
	letter - The letter for a tile (not created when using letter tile images).
	land - The board area underneath a tile.

]]
-- =============================================================
local utils = require "easy.utils"
-- =============================================================
-- Localizations
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right = round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local getTimer = system.getTimer;local strGSub = string.gsub
local strSub = string.sub; local strFormat = string.format
local mFloor = math.floor; local mRand = math.random
local files = utils.files

-- =============================================================
-- Forward Declarations
-- =============================================================
local getPuzzleData
local drawPuzzle
local adjustLayout
local attemptSnap
local testForWin
local countLands

-- =============================================================
-- Locals
-- =============================================================
local viewerFont 	= native.systemFontBold

local editingLayout = false
local curLayout
local puzzleGroup
local rows
local cols
local tileWidth = 60
local tileHeight = 60
local snapDist = math.floor((tileWidth < tileHeight) and tileWidth/2 or tileHeight/2) - 2
local letterFontSize = 30
local flyTime = 750
local flyEasing = easing.outBack

local sets = {}
local lands = {}
local curPuzzle = {}
local levelsFolder = "puzzles"
local isRunning = false
local strictWinRules = false

-- =============================================================
-- Module Begins
-- =============================================================
local public = {}

function public.setFont( vFont )
	viewerFont = vFont or native.systemFontBold
end

function public.setTileDimensions( width, height )
	tileWidth = width
	tileHeight = height
	snapDist = math.floor((tileWidth < tileHeight) and tileWidth/2 or tileHeight/2) - 2
end

function public.setFlySettings( newTime, newEasing )
	flyTime = newTime or 750
	flyEasing = newEasing or easing.outBack
end

function public.start( )
	isRunning = true
end

function public.stop( )
	isRunning = false
end

function public.getPuzzleInfo( puzzleName )
	local sets = {}
	local info = { width = 100, height = 100, rows = 1, cols = 1, sets = 1 }
	local loadData = utils.load( levelsFolder .. "/" .. puzzleName, system.ResourceDirectory )
	--
	for k,v in pairs( loadData.puzzle ) do
		info.rows = (v.row > info.rows) and v.row or info.rows
		info.cols = (v.col > info.cols) and v.col or info.cols
		sets[v.set] = true
		--utils.dump(v)
	end
	--
	local count = 0
	for k,v in pairs(sets) do
		count = count + 1
	end
	info.sets = count
	--
	info.width = info.cols * tileWidth
	info.height = info.rows * tileHeight
	return info
end

-- ==
--    
-- ==
function public.destroy( )
	if( inputBox ) then
		inputBox:removeEventListener( "userInput" )
	end
	lands = {}
	sets = {}
	isRunning = false
end

-- ==
--    
-- ==
function public.create( group, x, y, puzzleName, params )
	editingLayout = false
	group = group or display.currentStage
	params = params or {}
	--
	public.destroy()
	--
	isRunning = true
	--
	--
	local data, curLayout = getPuzzleData( puzzleName )		
	local viewer = drawPuzzle( group, x, y, data, params ) 
	--
	for k,v in pairs( curLayout ) do
		local set = tonumber(v.setNum)
		for l,m in pairs(curPuzzle) do			
			if( m.set == set ) then
				m.x = m.xSolved + v.dx
				m.y = m.ySolved + v.dy
				m.x1 = m.x
				m.y1 = m.y
			end
		end
	end
	return viewer
end

-- ==
--    
-- ==
function public.editLayout( group, x, y, data, layoutIn )
	editingLayout = true
	curLayout = layoutIn
	group = group or display.currentStage
	public.destroy()
	--
	drawPuzzle( group, x, y, data ) 
	--
	for k,v in pairs( curLayout ) do
		local set = tonumber(v.setNum)
		for l,m in pairs(curPuzzle) do			
			if( m.set == set ) then
				m.x = m.xSolved + v.dx
				m.y = m.ySolved + v.dy
			end
		end
	end
	isRunning = true
end

-- ==
--    
-- ==
function public.resetLayout( )	
	curLayout = {}
	for k,v in pairs( sets ) do
		for l, m in pairs( v ) do
			m.x = m.xSolved
			m.y = m.ySolved
		end
	end
end

-- ==
--    
-- ==
function public.resetLayoutToStart( instant )	
	for _, set in pairs( sets ) do
		for _, tile in pairs(set) do
			if( tile.land ) then 
				tile.land.busy = false
				tile.land = nil
			end
			if( instant ) then
				tile.x = tile.x1
				tile.y = tile.y1
			else
				transition.to( tile, { x = tile.x1, y = tile.y1, time = flyTime, transition = flyEasing })
			end
		end
	end
end

-- ==
--    
-- ==
getPuzzleData = function( puzzleName )
	local data = {}
	local loadData = utils.load( levelsFolder .. "/" .. puzzleName, system.ResourceDirectory )
	--	
	for k,v in pairs( loadData.puzzle ) do
		row = data[v.row] or {}
		data[v.row] = row
		row[v.col] = v
	end
	return data, loadData.layout
end

-- ==
--    
-- ==
drawPuzzle = function( group, x, y, data, params )
	params = params or {}
	curPuzzle = {}
	sets = {}
	rows = 0
	cols = 0
	--
	for i = 1, #data do
		local row = data[i]
		for j = 1, #row do
			local rc = row[j]
			rows = (rows < rc.row) and rc.row or rows
			cols = (cols < rc.col) and rc.col or cols
		end
	end
	--
	local function touch( self, event )		
		if( not isRunning ) then return false end
		local phase 	= event.phase
		local id 		= event.id
		local setNum 	= self.set
		local set 		= sets[setNum]
		if( phase == "began" ) then

			self.isFocus = true
			display.currentStage:setFocus( self, id )
			for k,v in pairs( set ) do
				transition.cancel(v)
				v:toFront()
				v.x0 = v.x
				v.y0 = v.y
				if( v.land ) then
					v.land.busy = false
					v.land = nil
				end
			end

		elseif( self.isFocus ) then
			local dx = event.x - event.xStart
			local dy = event.y - event.yStart
			if( editingLayout ) then 
				local quarterWidth = tileWidth/4
				local quarterHeight = tileHeight/4
				dx = utils.round(dx/quarterWidth) * quarterWidth
				dy = utils.round(dy/quarterHeight) * quarterHeight
			end
			for k,v in pairs( set ) do
				v:toFront()
				v.x = v.x0 + dx
				v.y = v.y0 + dy
			end

			if( phase == "ended" or phase == "cancelled" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				if( editingLayout ) then					
					adjustLayout( setNum, self.x - self.xSolved, self.y - self.ySolved )
				else
					if( attemptSnap( setNum ) ) then
						local won = testForWin()
						if( won and params.listener ) then 
							timer.performWithDelay( 10, function() params.listener() end )
						end
					end
				end
			end
		end
		return true
	end
	--
	display.remove(puzzleGroup)
	puzzleGroup = display.newGroup()
	puzzleGroup.x = x
	puzzleGroup.y = y
	group:insert(puzzleGroup)
	--
	local sx = -(tileWidth*cols)/2 - tileWidth/2
	local sy = -(tileHeight*rows)/2- tileHeight/2
	for i = 1, #data do
		local row = data[i]
		for j = 1, #row do
			local rc = row[j]			
			local tile = display.newGroup()
			puzzleGroup:insert(tile)
			tile.set = rc.set
			tile.x = sx + rc.col * tileWidth
			tile.y = sy + rc.row * tileHeight
			--
			local land
			local landWidth = params.landWidth or tileWidth
			local landHeight = params.landHeight or tileHeight
			if( editingLayout ) then
				landWidth = landWidth - 4
				landHeight = landHeight - 4

				land = display.newRect( puzzleGroup, tile.x, tile.y, landWidth, landHeight )
				land:setFillColor( 0.35, 0.35, 0.35 )
				land:setStrokeColor( 1, 1, 1 )
				land.strokeWidth = 2
			
			elseif(  params.landImage == nil ) then
				local offset = (params.landStrokeWidth) and (2 * params.landStrokeWidth) or 0
				landWidth = landWidth - offset
				landHeight = landHeight - offset

				land = display.newRect( puzzleGroup, tile.x, tile.y, landWidth, landHeight )
			
			else
				land = display.newImageRect( puzzleGroup, params.landImage, landWidth, landHeight )
				land.x = tile.x
				land.y = tile.y
			end
			--
			if( params.landColor ) then
				land:setFillColor( unpack(params.landColor) )
			end
			if( params.landStroke ) then
				land:setStrokeColor( unpack(params.landStroke) )
			end
			if( params.landStrokeWidth ) then
				land.strokeWidth = params.landStrokeWidth
			end
			--
			--display.newText( land.parent, utils.round(land.x) .. ", " .. utils.round(land.y), land.x, land.y - 30, native.systemFont, 10 )
			--tile.land = land
			tile:toFront()
			lands[land] = land
			land.inUse = false
			--local back = newRect( tile, 0, 0, { w = tileWidth - 4, h = tileHeight - 4 } )
			local back			
			if( editingLayout ) then
				back = display.newRect( tile, 0, 0, tileWidth-4, tileHeight-4 )
				back:setFillColor( 0.35, 0.35, 0.35 )
				back:setStrokeColor( 1, 1, 1 )
				back.strokeWidth = 2
			
			elseif( params.tileImages ) then
				local ext = params.tileExtension or ".png"
				local imgPath = params.tileImages .. "/letter_" .. string.upper( rc.letter ) .. ext
				back = display.newImageRect( tile, imgPath, tileWidth, tileHeight )

			elseif( params.tileImage ) then
				back = display.newImageRect( tile, params.tileImage, tileWidth, tileHeight )

			else
				local offset = (params.tileStrokeWidth) and (2 * params.tileStrokeWidth) or 0
				back = display.newRect( tile, 0, 0, tileWidth - offset, tileHeight - offset )			
			end
			--
			if( params.tileColor ) then
				back:setFillColor( unpack(params.tileColor) )
			end
			if( params.tileStroke ) then
				back:setStrokeColor( unpack(params.tileStroke) )
			end
			if( params.tileStrokeWidth ) then
				back.strokeWidth = params.tileStrokeWidth
			end
			--
			if( params.tileImages == nil ) then
				local letter = display.newText( tile, rc.letter, 0, 0, 
					                             params.letterFont or viewerFont, 
					                             params.letterSize or letterFontSize )
				if( params.letterColor ) then
					letter:setFillColor( unpack(params.letterColor) )
				else
					letter:setFillColor(0,0,0)
				end
			end
			--back.alpha = 0.25
			--
			--local lbl = display.newText( tile, utils.round(tile.x) .. ", " .. utils.round(tile.y), 0, -30, native.systemFont, 10 )
			--function tile.enterFrame( self)
				--lbl.text = utils.round(tile.x) .. ", " .. utils.round(tile.y)
			--end;utils.listen("enterFrame", tile )
			--
			local set = sets[rc.set] or {}
			sets[rc.set] = set
			set[tile] = tile
			tile.xSolved = tile.x
			tile.ySolved = tile.y
			tile.touch = touch
			tile:addEventListener("touch")
			curPuzzle[tile] = tile
		end
	end
	return puzzleGroup	
end

-- ==
--    
-- ==
local function isOverNonBusyLand( tile )
	if( tile.land ) then
		tile.land.busy = false
		tile.land = nil
	end
	--	
	for _, land in pairs( lands ) do
		local ox = utils.round(math.abs(land.x - tile.x))
		local oy = utils.round(math.abs(land.y - tile.y))
		if( not land.busy and ox == 0 and oy == 0 ) then
			tile.land = land
			land.busy = true
		end
	end
	return (tile.land ~= nil)
end

-- ==
--    
-- ==
countLands = function()
	local totalLands = 0
	local busyLands = 0
	for k, v in pairs( lands ) do	
		totalLands = totalLands + 1
	end
	print("YO", totalLands)
	local count = 1
	for _, tile in pairs(curPuzzle) do
		if(tile.land ~= nil) then
			busyLands = busyLands + 1
		end
	end
	return totalLands, busyLands
end

-- ==
--    
-- ==
local function looseWin()
	-- If lands are covered, if so player solved puzzle
	local totalLands, busyLands = countLands()
	print(totalLands,busyLands)
	if( totalLands == busyLands ) then return true end
end

local function strictWin()
	-- Win only true if all pieces are in ORIGINAL positions
	local won = true
	for _, tile in pairs(curPuzzle) do
		won = (won and (tile.x == tile.xSolved) and (tile.y == tile.ySolved))
	end
end

testForWin = function()
	if( strictWinRules ) then
		return strictWin()
	end
	return looseWin()
end


-- ==
--    
-- ==
local function findNearestLand( tile, lands )
	local land
	for k, v in pairs( lands ) do
		local dx = math.abs( tile.x - v.x )
		local dy = math.abs( tile.y - v.y )
		if( not land and not v.busy and dx < snapDist and dy < snapDist ) then
			land = v 
		end
	end
	return land
end

-- ==
--    
-- ==
attemptSnap = function( setNum )
	local set = sets[setNum]
	--
	local canSnap = true
	for _, tile in pairs(set) do
		local land = findNearestLand( tile, lands )
		if( not land or land.busy ) then
			canSnap = false
		end
	end
	--
	if( canSnap ) then 
		for _, tile in pairs(set) do
			local land = findNearestLand( tile, lands )
			tile.land = land
			tile.x = land.x
			tile.y = land.y
			land.busy = true
		end
	else
		for _, tile in pairs(set) do
			transition.to( tile, { x = tile.x1, y = tile.y1, time = flyTime, transition = flyEasing })
		end
	end
	--
	return canSnap
end

-- ==
--    
-- ==
adjustLayout = function( setNum, dx, dy )
	curLayout[setNum] = { dx = dx, dy = dy, setNum = setNum }
end


return public



