-- =============================================================
-- Copyright Roaming editorr, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
require "easy.globals"
local utils 	= require "easy.utils"
local editor 	= require "easy.wordSnapEditor"
local viewer 	= require "easy.wordSnapViewer"
-- =============================================================
local editorFont 	= native.systemFont
local viewerFont 	= native.systemFontBold
-- =============================================================
local public = {}

-- ==
--    
-- ==
function public.setFonts( vFont, eFont )
	editorFont = ef or native.systemFont
	viewerFont = vFont or native.systemFontBold
	editor.setFonts( vFont, eFont )
	viewer.setFont( vFont )
end

-- ==
--    
-- ==
function public.setTileDimensions( width, height, quiet )
	if( not quiet and ( (width % 2 ~= 0) or (height % 2 ~= 0) ) ) then
		utils.easyAlert("Width / Height Not Even Number", "For best results use a tile widths and heights that is a multiple of 2.")
	end
	editor.setTileDimensions( width, height )
	viewer.setTileDimensions( width, height )
end; public.setTileDimensions( 60, 60 )

-- ==
--    
-- ==
function public.createEditor( group )
	group = group or display.currentStage
	editor.create( group )
end

-- ==
--    
-- ==
function public.createViewer( group, x, y, puzzleName, params )	
	group = group or display.currentStage
	if( not params ) then
	params = 
		{
			tileColor   		= utils.hexcolor("#505050"),
			tileStroke 			= utils.hexcolor("FFFFFF"),
			tileStrokeWidth	= 2,

			landColor   		= {0.2,0.2,0.8},
			landStroke 			= {1,1,0.5},
			landStrokeWidth	= 2,

			letterFont 			= viewerFont,
			letterColor 		= {1,1,1},
		}
	end

	return viewer.create( group, x, y, puzzleName, params )
end

public.resetLayoutToStart = viewer.resetLayoutToStart

public.setFlySettings = viewer.setFlySettings
public.getPuzzleInfo = viewer.getPuzzleInfo
public.start = viewer.start
public.stop = viewer.stop

return public