-- =============================================================
-- Copyright Roaming publicr, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local utils 		= require "easy.utils"
local buttonMaker = require "easy.buttonMaker"


-- =============================================================
-- Localizations
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right = round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local getTimer = system.getTimer;local strGSub = string.gsub
local strSub = string.sub; local strFormat = string.format
local mFloor = math.floor; local mRand = math.random
local files = utils.files

-- =============================================================
-- Forward Declarations
-- =============================================================
local drawPuzzle
local doLayout
local savePuzzle
local loadPuzzle
local restorePuzzle

-- =============================================================
-- Locals
-- =============================================================
local editorFont 	= native.systemFont
local viewerFont 	= native.systemFontBold

local publicFont1 = native.newFont( editorFont, 28 )

local editorGroup
local puzzleGroup
--
local puzzleEditorBox
local puzzleNameBox
--
local curWords 	= ""
local curPuzzle 	= {}
local curLayout 	= {}
local rows 			= 0
local cols 			= 0
--
local levelsFolder 	= "puzzles"
local levelsRoot 		= system.pathForFile(levelsFolder)
local tileWidth 		= 60
local tileHeight 		= 60
local letterFontSize = 30
--
local groupColors = {}
groupColors[1] = utils.hexcolor("#009999")
groupColors[2] = utils.hexcolor("#ff7c00")
groupColors[3] = utils.hexcolor("#ff0000")
groupColors[4] = utils.hexcolor("#66cccc")
groupColors[5] = utils.hexcolor("#ffb066")
groupColors[6] = utils.hexcolor("#ff6666")
groupColors[7] = utils.hexcolor("#006666")
groupColors[8] = utils.hexcolor("#b25700")
groupColors[9] = utils.hexcolor("#af0101")
local set = 1

-- =============================================================
-- Module Begins
-- =============================================================
local public = {}


function public.setTileDimensions( width, height )
	tileWidth = width
	tileHeight = height
end

function public.setFonts( vFont, eFont )
	editorFont = eFont or native.systemFont
	viewerFont = vFont or native.systemFontBold
	publicFont1 = native.newFont( editorFont, 28 )
end

-- ==
--    
-- ==
function public.destroy( )
	if( puzzleEditorBox ) then
		puzzleEditorBox:removeEventListener( "userInput" )
	end
	display.remove(puzzleNameBox)
	display.remove(puzzleEditorBox)
	display.remove(editorGroup)
	editorGroup = nil
	puzzleEditorBox = nil
	puzzleNameBox = nil
	curLayout = {}
end

-- ==
--    
-- ==
function public.create( group )
	group = group or display.currentStage
	public.destroy()
	editorGroup = display.newGroup()
	group:insert( editorGroup )
	--
	curWords = "ZIP\nSPY\nJAM\nMIX"

	local function textListener( self, event )
		self.text = string.upper(self.text)
		curWords = self.text
	end

	local tmp = display.newText( editorGroup, "1. Edit Puzzle", left + 25, top + 40, editorFont, 20 )
	tmp.anchorX = 0

	-- Create text box
	puzzleEditorBox = native.newTextBox( left + 125, top + 225, 200, 300 )
	puzzleEditorBox.text = curWords
	puzzleEditorBox.isEditable = true	
	puzzleEditorBox.font = publicFont1
	puzzleEditorBox.userInput = textListener
	puzzleEditorBox:addEventListener( "userInput" )
	editorGroup:insert(puzzleEditorBox)

	buttonMaker.easyPush( { parent = editorGroup, x = puzzleEditorBox.x, y = top + 400,  fontSize = 20,
		                     width = 200, height = 30, labelText = "2. Draw Puzzle", listener = drawPuzzle } )	
	
	drawPuzzle()

	local tmp = display.newText( editorGroup, "3. Group Letters By Set", left + 250, top + 40, editorFont, 20) 
	tmp.anchorX = 0

	-- Cur Group Color Buttons
	local chipSize = 60
	local cx = left + 325
	local cy = top + 80 + chipSize/2
	local chips = {}
	local function touch( self, event )		
		set = self.myColor
		for k,v in pairs(chips) do
			v.strokeWidth = 0
		end
		self.strokeWidth = 3
		return true
	end	
	for i = 1, #groupColors do
		local fill = groupColors[i]
		local chip = display.newRect( editorGroup, cx, cy, chipSize-6, chipSize-6 )
		chip:setFillColor(unpack(fill))
		chip:setStrokeColor(1,1,1)
		chip.strokeWidth = 0
		chip.myColor = i
		chip.touch = touch
		chip:addEventListener("touch")
		display.newText( editorGroup, i, cx, cy, viewerFont, chipSize/2 )
		chips[chip] = chip
		cy = cy + chipSize
		if( i == 1 ) then chip.strokeWidth = 3 end
	end

	buttonMaker.easyPush( { parent = editorGroup, x = left + 675, y = top + 40,  fontSize = 20,
		                     width = 200, height = 30, labelText = "4. Do Layout", listener = doLayout } )	

	local tmp = display.newText( editorGroup, "5. Name Puzzle", left + 25, top + 440, editorFont, 20 )
	tmp.anchorX = 0

	puzzleNameBox = native.newTextField( left + 150, top + 470, 280, 30 )
	puzzleNameBox.text = ""
	buttonMaker.easyPush( { parent = editorGroup, x = puzzleEditorBox.x, y = top + 510,  fontSize = 20,
		                     width = 200, height = 30, labelText = "6. Save Puzzle", listener = savePuzzle } )	
	buttonMaker.easyPush( { parent = editorGroup, x = puzzleEditorBox.x, y = top + 590,  fontSize = 20,
		                     width = 200, height = 60, labelText = "Load Puzzle", listener = loadPuzzle } )	
	--restorePuzzle( "level_1_1.json" )
	--doLayout()
end

-- ==
--    
-- ==
drawPuzzle = function( )
	curPuzzle = {}
	--local rows = 0
	--local cols = 0
	--event.target:disable()
	--puzzleEditorBox.isEditable = false
	local letters = string.gsub(curWords,"\r","")
	letters = utils.split(letters,"\n")
	rows = #letters
	for i = 1, #letters do
		local oldRow = letters[i]
		local len = string.len(oldRow)
		cols = (len>cols) and len or cols
		local row = {}
		for j = 1, len do
			row[j] = string.sub(oldRow,j,j)
		end
		letters[i] = row
	end
	--
	local function touch( self, event )		
		self:setFillColor(unpack(groupColors[set]))
		self.set = set
		return true
	end
	--
	display.remove(puzzleGroup)
	puzzleGroup = display.newGroup()
	puzzleGroup.x = puzzleEditorBox.x + 300
	puzzleGroup.y = top + 75
	editorGroup:insert(puzzleGroup)
	--
	local sx = tileWidth/2
	local sy = tileHeight/2
	local cx = sx
	local cy = sy
	for i = 1, cols do
		for j = 1, rows do
			local tile = display.newRect( puzzleGroup, cx, cy, tileWidth - 4, tileHeight - 4 )
			tile.touch = touch
			tile:addEventListener("touch")
			tile.letter = letters[j][i] or "#"
			tile.set = 0
			tile.row = j
			tile.col = i
			curPuzzle[tile] = tile
			local letter = display.newText( puzzleGroup, tile.letter, cx, cy, viewerFont, letterFontSize )
			letter:setFillColor(0)
			cy  = cy + tileHeight
		end
		cx  = cx + tileWidth
		cy = sy
	end
end

-- ==
--    
-- ==
doLayout = function( )
	local viewer = require "easy.wordSnapViewer"
	local layoutGroup = display.newGroup()
	puzzleEditorBox.isVisible = false
	puzzleNameBox.isVisible = false
	local blocker = display.newRect( layoutGroup, centerX, centerY, fullw, fullh )

	local lx = centerX - 20 * tileWidth
	lx = (cols%2==0) and (lx + tileWidth/2) or lx
	local ly = centerY - 20 * tileHeight
	ly = (cols%2==0) and (ly + tileHeight/2) or ly

	for i = 1, 80 do
		local tmp = display.newLine( layoutGroup, lx + (i-1) * tileWidth/2, top, lx + (i-1) * tileWidth/2, bottom)
		tmp.strokeWidth = 1
		tmp.alpha = 0.25
	end
	for i = 1, 80 do
		local tmp = display.newLine( layoutGroup, left, ly + (i-1) * tileHeight/2, right, ly + (i-1) * tileHeight/2 )
		tmp.strokeWidth = 1
		tmp.alpha = 0.25
	end

	blocker:setFillColor(0.125,0.125,0.125)
	blocker.touch = function() return true end 
	blocker:addEventListener("touch")
	--viewer.editLayout( layoutGroup, centerX, centerY, puzzleNameBox.text .. ".json", curLayout )

	local puzzle = {}
	for k,v in pairs( curPuzzle ) do
		local data = { row = v.row, col = v.col, set = v.set, letter = v.letter }
		puzzle[#puzzle+1] = data
	end
	local data = {}
	for k,v in pairs( puzzle ) do
		row = data[v.row] or {}
		data[v.row] = row
		row[v.col] = v
	end


	viewer.editLayout( layoutGroup, centerX, centerY, data, curLayout )

	local function onClose()		
		display.remove(layoutGroup)
		puzzleEditorBox.isVisible = true
		puzzleNameBox.isVisible = true
	end

	local function onReset()
		viewer.resetLayout()
	end

	buttonMaker.easyPush( { parent = layoutGroup, x = right - 55, y = top + 20,  fontSize = 20,
		                     width = 100, height = 30, labelText = "Close", listener = onClose } )	
	buttonMaker.easyPush( { parent = layoutGroup, x = right - 55, y = bottom - 20,  fontSize = 20,
		                     width = 100, height = 30, labelText = "Reset", listener = onReset } )	
end

-- ==
--    
-- ==
savePuzzle = function( )
	local canSave = true
	for k,v in pairs( curPuzzle ) do
		if(v.set == 0) then 
			canSave = false
		end
	end
	--[[
	if( not canSave ) then
		utils.easyAlert( "Puzzle Not Complete Defined", "Sorry.  You don't have all letters in a colored set.  I can't save yet." )
		return 
	end
	--]]
	local saveData = {}
	for k,v in pairs(  curPuzzle ) do
		local data = { row = v.row, col = v.col, set = v.set, letter = v.letter }
		saveData[#saveData+1] = data
	end
	saveData = { puzzle = saveData, layout = curLayout }
	files.util.saveTable( saveData, levelsRoot .. "/" .. puzzleNameBox.text .. ".json" )
end

-- ==
--    
-- ==
loadPuzzle = function( )
	print(puzzleNameBox.text)
	restorePuzzle( puzzleNameBox.text .. ".json" )
	--[[
	local tfd = require("plugin.tinyfiledialogs")

	-- Next statement is blocking!
	local file = tfd.openFileDialog( 
	{
	   title                   = "Choose File(s)", 
	   default_path_and_file   = levelsRoot,
	   filter_patterns         = { "*.json" }, -- May be table of strings, or table.
	   filter_description      = "Level Files",        -- Name for pattern (above)
	   allow_multiple_selects  = false
	} )

	if( file == false ) then
		-- CANCELLED
	else
		local file = utils.repairPath(file)
		local parts = utils.split( file, "/")		
		local toLoad = parts[#parts]		
		puzzleNameBox.text = string.gsub( toLoad, ".json", "")
		restorePuzzle( toLoad )
	end
	--]]
end

-- ==
--    
-- ==
restorePuzzle = function( toLoad )
	local organized = {}
	local loadData = files.util.loadTable( levelsRoot .. "/" .. toLoad )
	curLayout = loadData.layout or {}
	--	
	for k,v in pairs( loadData.puzzle ) do
		row = organized[v.row] or {}
		organized[v.row] = row
		row[v.col] = v
	end
	local words = ""
	for i = 1, #organized do
		local row = organized[i]
		for j = 1, #row do
			words = words .. row[j].letter
		end
		if( i < #organized ) then
			words = words .. "\n"
		end
	end
	curWords = words
	puzzleEditorBox.text = curWords
	--
	drawPuzzle()
	--
	local function findCell( row, col )
		for k,v in pairs( curPuzzle ) do
			if( v.row == row and v.col == col ) then
				return v 
			end
		end
	end
	for i = 1, #organized do
		local row = organized[i]
		for j = 1, #row do
			local rc = row[j]
			local cell = findCell( rc.row, rc.col )
			cell.set = rc.set
			if( cell.set and cell.set > 0 ) then
				cell:setFillColor(unpack(groupColors[cell.set]))
			end
		end
	end
end

return public



