-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local mFloor = math.floor
local function round(val, n)
   if (n) then
      return mFloor( (val * 10^n) + 0.5) / (10^n)
   else
      return mFloor(val+0.5)
   end
end

_G.w              = display.contentWidth
_G.h              = display.contentHeight
_G.centerX        = display.contentCenterX
_G.centerY        = display.contentCenterY
_G.fullw          = display.actualContentWidth 
_G.fullh          = display.actualContentHeight
_G.unusedWidth    = _G.fullw - _G.w
_G.unusedHeight   = _G.fullh - _G.h
_G.left           = 0 - _G.unusedWidth/2
_G.top            = 0 - _G.unusedHeight/2
_G.right          = _G.w + _G.unusedWidth/2
_G.bottom         = _G.h + _G.unusedHeight/2

_G.w              = round(_G.w)
_G.h              = round(_G.h)
_G.left           = round(_G.left)
_G.top            = round(_G.top)
_G.right          = round(_G.right)
_G.bottom         = round(_G.bottom)
_G.fullw          = round(_G.fullw)
_G.fullh          = round(_G.fullh)

_G.left           = (_G.left>=0) and math.abs(_G.left) or _G.left
_G.top            = (_G.top>=0) and math.abs(_G.top) or _G.top

