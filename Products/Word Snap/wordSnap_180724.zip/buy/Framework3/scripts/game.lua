-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- game.lua - Placeholder 'dummy' game to show basic usage of features.
-- =============================================================
local composer       = require( "composer" )
local common         = require "scripts.common"
local utils          = require "easy.utils"
local buttonMaker    = require "easy.buttonMaker"
local persist   		= require "easy.persist"
local soundMgr       = require "easy.soundMgr"
local persist        = require "easy.persist"
-- =============================================================
-- Locals
-- =============================================================
local diedCount = 0
local interstitialFrequency = 2 -- every other death show interstitial
local curHealth = 100
local incrButton
local decrButton
local yesButton
local noButton

-- =============================================================
-- Game Module Begins
-- =============================================================
local game = {}

function game.giveReward()
end


function game.create( group )

	curHealth = 100

	local healthLabel = display.newText( group, "", centerX, centerY - 160, _G.fontB, 44)

	local function updateHealth( value )
		curHealth = curHealth + value
		curHealth = (curHealth < 0 ) and 0 or curHealth
		curHealth = (curHealth > 100 ) and 100 or curHealth
		--
		if( curHealth == 0 ) then			
			incrButton.isVisible = false
			decrButton.isVisible = false
			yesButton.isVisible = true	
			noButton.isVisible = true
			healthLabel.text = "You Died!"
			diedCount = diedCount + 1
			
			if( diedCount >= interstitialFrequency and persist.get( "settings.json", "ads_enabled" ) ) then
				_G.adsHelper.showInterstitial() 
				diedCount = 0
			end

		else
			healthLabel.text = "Health: " .. curHealth			
		end
	end

	local function goHome( self, event )
      if( persist.get( "settings.json", "sound_enabled" ) ) then
         soundMgr.playEffect( "click" )
      end
		local params = {  }
	   composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade", params = params } )
	end

	local function onFailed( self, event )
		local params = {  }
	   composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade", params = params } )
	end

	local function incrementHealth( self, event )
	   if( persist.get( "settings.json", "sound_enabled" ) ) then
	      soundMgr.playEffect( "click" )
	   end
		updateHealth( math.random(10,20) )
	end

	local function decrementHealth( self, event )
	   if( persist.get( "settings.json", "sound_enabled" ) ) then
	      soundMgr.playEffect( "click" )
	   end
		updateHealth( math.random(-20,-10) )
	end

	local function watchVideo( self, event )
      if( persist.get( "settings.json", "sound_enabled" ) ) then
         soundMgr.playEffect( "click" )
      end
		local function onSuccess()
			diedCount = 0 -- Reset count interstitials too
			incrButton.isVisible = true
			decrButton.isVisible = true
			yesButton.isVisible = false	
			noButton.isVisible = false
			updateHealth(100)
		   if( persist.get( "settings.json", "ads_enabled") ) then
		      _G.adsHelper.showBanner( "bottom" )
		   end
		end
		_G.adsHelper.showRewarded( onSuccess, onFailed ) -- second arg is what we do on failure
	end

	incrButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY, 
		labelText = "Increase Health", width = 400, height = 40, font = _G.fontN, listener = incrementHealth } )	

	decrButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY + 60, 
		labelText = "Decrease Health", width = 400, height = 40, font = _G.fontN, listener = decrementHealth } )	

	yesButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY + 120, 
		labelText = "Watch Video To Continue?", width = 400, height = 40, font = _G.fontN, listener = watchVideo } )	

	noButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY + 180, 
		labelText = "No Thanks...", width = 400, height = 40, font = _G.fontN, listener = goHome } )	
	yesButton.isVisible = false	
	noButton.isVisible = false

	updateHealth(0)

end

function game.destroy()
	incrButton = nil
	decrButton = nil
	yesButton = nil
	noButton = nil
end


return game
