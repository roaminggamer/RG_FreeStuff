==============================================================================

Roaming Gamer, LLC "Game Template Package" for the game: Swordy (Experimental Game)

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Tips / FAQ - Miscellaneous tips to help you with changing the template, as
   well as answers to question(s) you might have.

D. Reporting Bugs - How to report bugs with this template.

==============================================================================

A. Short and Sweet License 
==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).



2. You MAY NOT:

   - sell or distribute the source code from this package.


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.


B. What's in the template package?
==================================

Swordy is an experimental (infinite) sword fighting game implemented using Box 2D physics and a dragging algorithm.

In this package you will find eight (8) versions of of the game:

Pure x 6
--------
* Swordy - Pure 1 ==> A very basic player, sword, and swordy dragging algorithm.
* Swordy - Pure 2 ==> Improves collission boxes, dragging algorithm, sword joint, and adds debug mode.
* Swordy - Pure 3 ==> Adds an anchor to hold player on screen.
* Swordy - Pure 4 ==> Adds basic enemies, kill counter, and sounds.
* Swordy - Pure 5 ==> Adds better enemy movement and game restart.

* Swordy1K        ==> A simple implemenation of game using less than 1K of code (1021 bytes to be exact.)


SSK x 2
-------
* Swordy - SSK 1 ==> Same as Pure 5, implemented using SSK features.
* Swordy - SSK 2 ==> A nice version of the game.

                                                            
													   
C. Tips / FAQ
=============
* Before you modify the SSK version - The SSK version of the game includes a copy of the 
SSK library.  However, it is sure to be out of date.  So, be sure to get the latest version 
here: https://github.com/roaminggamer/SSKCorona


* SSKCorona Wiki - There is a free quick reference to SSKCorona here: https://github.com/roaminggamer/SSKCorona/wiki

* Question: "Where can I go to get more template?" 
    Answer: The Roaming Gamer, LLC. website of course: http://roaminggamer.com/
	

D. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please write me here: 

roaminggamer@gmail.com 

Be sure to include this information in your e-mail:

e-mail Title: "Template Bug: Swordy"

e-mail Body:

Tell me these details,
	- What you did, 
	- What you expected to see, and 
	- What happened instead.

Please provide any other details about the bug that seem pertinent.


Thanks,

The Roaming Gamer



