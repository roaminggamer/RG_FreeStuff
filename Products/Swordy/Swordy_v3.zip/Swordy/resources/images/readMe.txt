
The sword image is from clker.com (EULA: http://www.clker.com/disclaimer.html).



I made the box man and the knight image.

I also generated the scale images directly from Genetica 3.6.



Lastly, the original piece are not included, but the nicer ground was made using tiles from the Lost Garden:

http://www.lostgarden.com/search/label/free%20game%20graphics

Please read his license here if you want to know more:

http://www.lostgarden.com/2007/03/lost-garden-license.html

