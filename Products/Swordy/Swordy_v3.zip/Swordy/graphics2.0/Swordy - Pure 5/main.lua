-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

--[[	Notes about this game:
	
	This version of the game improves on 'Pure 4' by improving and adding:

	* Enemy movement algorithm.
	* Restart.  When the player dies, the game restarts after a short pause.

--]]

local debugMode = true

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- This game uses physics for: player movement damping (drag), joints, sword dragging, ...

local physics = require("physics")
physics.start()

physics.setGravity( 0, 0 )			-- We don't need gravity, so turn it off

if( debugMode ) then
	physics.setDrawMode("hybrid")		-- This is a useful physics visualization that
										-- will show us where our collision boxes, and where the different
										-- joints and pivot points are.
end

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
--
-- Locals
--
											-- Some helper variables specifying:
local w       = display.contentWidth		-- Design width, height, and center <x,y> positions.
local h       = display.contentHeight
local centerX = display.contentWidth/2 
local centerY = display.contentHeight/2


-- == Variables to control how the interactive parts of the player + sword behave.
--
-- Note: I have placed these all here so you can quickly play with settings without skipping about in the file.
--
local swordDragMultX		= 4  -- Multiplies X inputs by 3 for more exagerated movement
local swordDragMultY		= 4  -- Multiplies Y inputs by 3 for more exagerated movement

local playerLinearDamping	= 100	-- The higher this number is, the more the player's linear movement  
									-- is affected by drag and slowed down.

local playerAngularDamping	= 1000	-- The higher this number is, the more the player's rotational movement
									-- is affected by drag and slowed down.

local swordLinearDamping	= 0		-- The higher this number is, the more the sword's linear movement  
									-- is affected by drag and slowed down.

local swordAngularDamping	= 0		-- The higher this number is, the more the sword's rotational movement
									-- is affected by drag and slowed down.

local shoulderPivotLimitEn	= true	-- Set this to true to limit the range of the sword joint (shoulder)
local shoulderPivotLimits	= { min = -45,  max = 75 } 


local touchJointForce		= 10	-- This controls how strongly the 'touch joint' drags the sword
									-- Tips: Try low and high values to see what happens.


local gameIsRunning = true			-- A flag to track whether the game is running or over.

								 
-- == Variables for holding references to game objects. 
local gameGroup
local backImage
local thePlayer
local theSword
local swordJoint

-- == Anchor enable and variables to hold references to the anchor parts
local anchorEn			= true
local thePlayerAnchor
local playerAnchorJoint
local anchorOffsetY = 15
local anchorDampingRatio = 0.2
local anchorFrequencyRatio = 1

--
-- Labels, Buttons, Etc
--
local scoreCounter					-- A variable to hold the handler to our score counter


--
-- Sounds
--
local soundEnabled = true	-- A flag to enable/disble sound
local hitSounds    = {}		-- A table to store our sword hit sounds if we load them
local ughSounds    = {}		-- A table to store our ugh sounds if we load them
local effectVolume = 0.8	-- Effect volume for all sound effects

if( soundEnabled ) then
							-- Load seven homemade audio files for the sword hit sounds (we'll select a random one each hit)
	for i = 1, 7 do
		hitSounds[i] = audio.loadSound( "sounds/sword" .. i .. ".mp3" )
	end

							-- Load seven homemade audio files for the sword ugh sounds (we'll select a random one each hit)
	for i = 1, 5 do
		ughSounds[i] = audio.loadSound( "sounds/ugh" .. i .. ".mp3" )
	end
end


--
-- Function Declarations
--
local createLayers			-- Function to create rendering layers 
local createScene			-- Function to create the game scene (except for player and enemies)
local createPlayer			-- Function to create the player and its sword.
local createEnemy			-- Function to create a single enemy.
local createEnemies			-- Function to schedule the creation of enemies (more and more over time)
local pursuePlayer			-- Function to make enemies move towards player
local cleanup				-- Function to remove all display objects and other game related content

--
-- Listener Declarations
--
local dragTheSword			-- Touch handler for dragging the player's sword.
local onCollision			-- A general touch handle used to handle: sword vs. other object collisions

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--		createScene() - This function creates the game scene.
--
--		* Creates a 'ground' image (texture)
--		* Adds a touch handler to the 
--
-- ==
createScene = function(  )

	--
	-- 0. Create a display group and store all display objects in it, for easy cleanup
	--
	gameGroup = display.newGroup()

	--
	-- 1. Add an image to the scene to act as a 'ground' texture and
	-- so we have something to add our touch listener to.
	--	
	backImage = display.newImage(gameGroup, "images/interface/protoBack.png") 
	backImage.x = centerX
	backImage.y = centerY

	backImage:setFillColor(0,0,0,0)  -- TIP: Both: 'backImage.alpha = 0'      AND 
	                                 --            'backImage.isVisible = 0' will disable touch,
									 --  setting the fourth fill argument to 0 does not.

	if( debugMode ) then
		backImage:setFillColor(1,1,1,1)
	end

	--
	-- 2. Add event listener for sword dragging
	--
	backImage:addEventListener( "touch", dragTheSword )

	--
	-- 3. Add a score counter
	--
	scoreCounter = display.newText(gameGroup,  0, 30, 30 )

end


-- ==
--		createPlayer() - This function creates the player and it's sword.
--	
--		Note: It optionally creates an anchor that 'pulls the player' back if 
--		s/he moves to far from it.
--
-- ==
createPlayer = function(  )
	--
	-- 1. Create the player
	--

	-- A. First create a simple representation of the player with the supplied image: boxman.png
	--
	thePlayer = display.newImageRect( gameGroup, "images/boxman.png", 100, 67  )
	thePlayer.x = centerX
	thePlayer.y = centerY+100


	-- B. Attach a physics body to the player
	--

	-- Our shape's points: x1,  y1   x2,  y2   x3, y3    x4, y4
	local playerShape = { -30, -10,  30, -10,  30, 20,  -30, 20 }

	-- Adding a "dynamic" target with a tighter fitting collsion box.
	physics.addBody( thePlayer, "dynamic", { shape=playerShape } )

	-- C. Add some linear and angular drag to the target.
	-- This keeps the target from sliding and twirling too much when we drag it by the sword.
	--
	-- Tip:To see the effect of this, I suggest you experiment with low and high values for each 
	-- of these settings (specified at top of file).
	--	
	thePlayer.linearDamping   = playerLinearDamping
	thePlayer.angularDamping  = playerAngularDamping


	-- D. (Optionally) add an anchor and attach the player to it using a "distance" joint.
	-- This will drag the player back to the anchor point when you stop dragging the sword.
	-- This also tends to keep the player's back aligned to the anchor point.
	-- You may like this better than the free movement model. 
	
	if( anchorEn ) then
		--
		-- Player Anchor -- A "static" object that will act as the anchor.
		--
		-- Tip: I made this into a sensor so it will not give 'physical' collision
		-- feedback (i.e the player, sword, and other moving objects will all pass through it.)
		--
		thePlayerAnchor = display.newCircle( gameGroup,  thePlayer.x, thePlayer.y+50, 10  )
		physics.addBody( thePlayerAnchor, "static", {  isSensor = true } )

		thePlayerAnchor.isVisible = false

		if( debugMode ) then
			thePlayerAnchor.isVisible = true
		end

		--
		-- Player to Anchor Joint - A physics joint that connects the player target to the anchor.
		--
		playerAnchorJoint = physics.newJoint( "distance", thePlayerAnchor, thePlayer, 
									           thePlayerAnchor.x, thePlayerAnchor.y, 
											   thePlayer.x, thePlayer.y + anchorOffsetY )
	
		playerAnchorJoint.dampingRatio	= anchorDampingRatio
		playerAnchorJoint.frequency		= anchorFrequencyRatio

		print("playerAnchorJoint.length       == " .. playerAnchorJoint.length )
		print("playerAnchorJoint.frequency    == " .. playerAnchorJoint.frequency )
		print("playerAnchorJoint.dampingRatio == " .. playerAnchorJoint.dampingRatio )
	end

	
	-- E. Create the sword and attach a tight fitting target to it.
	--
	theSword = display.newImageRect( gameGroup, "images/sword.png", 31, 100  )
	theSword.x = thePlayer.x + 40
	theSword.y = thePlayer.y - 70

	-- Basic target and collision box
	--physics.addBody( theSword, "dynamic" )

	-- Better target and collision box
	local swordShape = { -5,-50, 5,-50, 5,50, -5,50 }
	physics.addBody( theSword, "dynamic", { shape=swordShape } )


	-- F. (Optionally) add some linear and angular drag to the target.
	-- This keeps the target from sliding and twirling too much when we drag it by the sword.
	--
	theSword.linearDamping = swordLinearDamping
	theSword.angularDamping  = swordAngularDamping


	-- G. Attach the player target to the sword using a "pivot" joint that acts like a shoulder joint
	-- (or an elbow if you prefer).
	--
	swordJoint = physics.newJoint( "pivot", thePlayer, theSword, thePlayer.x+40, thePlayer.y  )
	
	-- We can limit the min/max rotation of this joint.  
	-- Note: As with most of the settings I've exposed, you will find a variable at the top of
	-- this file to configure it with. 
	swordJoint.isLimitEnabled = shoulderPivotLimitEn
	swordJoint:setRotationLimits( shoulderPivotLimits.min, shoulderPivotLimits.max )
	
end

createEnemies = function( )

	createEnemy( math.random( 0, w ) , -h/2 )

	-- F. Automatically call this function again in 2 seconds while the game is running
	--
	if( gameIsRunning ) then
		createEnemiesTimer = timer.performWithDelay( 750, createEnemies )
	end

end

pursuePlayer = function( self )

	if( gameIsRunning ) then
		transition.to( self, { x = thePlayer.x, y = thePlayer.y, time = 5000,  onComplete = pursuePlayer } )
	end

end

-- ==
--		createEnemy() - This function creates a single enemy that will move towards the player
-- ==
createEnemy = function( startX, startY )

	-- 
	-- If the game has stopped running, do not create an enemy
	--
	if( not gameIsRunning ) then
		return
	end


	--
	-- 1. Create a single enemy
	--
	
	-- A. First create a simple representation of the enemy with the supplied image: boxman.png
	--
	local enemy = display.newImageRect( gameGroup, "images/boxman.png", 50, 34  )
	enemy.x = startX
	enemy.y = startY
	
	enemy.rotation = 180
	enemy:setFillColor( 255, 0, 0)


	-- B. Attach a physics body to the enemy
	--

	-- Our shape's points: x1,  y1   x2,  y2   x3, y3    x4, y4
	local enemyShape = { -15, -5,  15, -5,  15, 10,  -15, 10 }

	-- Adding a "dynamic" target with a tighter fitting collsion box.
	-- Make the enemy a sensor so it collides but doesn't push 
	physics.addBody( enemy, "dynamic", { shape=enemyShape, isSensor = true } )

	-- C. Use a transition to move the enemy from its current Y position to a position well off the bottom of the screen
	--
	pursuePlayer( enemy )
	


	-- D. Attach a timer to the enemy that will cleanup it in 10.5 seconds
	--
	local function autoRemove( self ) 
		-- To be absolutely sure the object is a valid display object before removing
		-- it, lets check to see if:
		--
		-- a. It exists,
		-- b. The removeSelf() method exists and is still a function.
		--
		if(self and self.removeSelf and type(self.removeSelf) == "function") then
			self:removeSelf()
		end
	end

	-- This is a trick (of sorts).  By attaching the function 'autoRemove' to 
	-- our object, we can use the object itself as an argument to 'timer.performWithDelay()'
	-- This will do a couple things for us:
	--
	-- 1. It will call the function we attached to the object's 'timer' field like a method
	--    and automatically pass a reference to the object (which we get with the argument self).
	--
	-- 2. If the object is cleanuped before the timer event, the timer event is automatically cancelled.
	--
	-- This gives us both a reference to the object and safety in case the object is removed early.
	--
	enemy.timer = autoRemove
	timer.performWithDelay( 19500, enemy )

	-- E.  Add a collision event listener to this enemy
	enemy.collision = onCollision
	enemy:addEventListener( "collision", enemy )
		
end

-- ==
--    cleanup() - This function can be used to safely remove all objects and clean up memory.
-- ==
cleanup = function( )
	
	--
	-- 1. Remove the display group which automatically removes all objects stored in it.
	--
	gameGroup:removeSelf()

	--
	-- 2. Remove any remaining physics objects we created
	--
	if(playerAnchorJoint) then
		playerAnchorJoint:removeSelf()
	end

	if(swordJoint) then 
		swordJoint:removeSelf()
	end

	--
	-- 3. Clear all references by setting them to nil		
	--
	backImage = nil
	thePlayerAnchor = nil
	playerAnchorJoint = nil
	swordJoint = nil
	thePlayer = nil
	theSword = nil
	scoreCounter = nil
	gameGroup = nil

end


--==
-- ================================= LISTENER DEFINITIONS
--==

 
-- ==
--		dragTheSword() - This event listener function has the job of moving the sword around, which in turn drags the
--		player's target with it.
--
--		To achieve this, I have used a physics feature called a 'touch joint'.  These joints can be used
--		to drag objects around the screen using physics to give the drag a nice behavior.
--		Among other things, you can adjust the 'maxForce' of the 'touch joint'.  High values pull harder.
--
--
--		In this touch listener, I will create a new touch joint when the touch begins and attach it to the 
--		center of the sword.
--
--		Then, I will allow it to be dragged around during move events.
--
--		Finally, when the touch ends, I will remove the joint.
--
-- ==
dragTheSword = function( event )
        local target = event.target
        local phase = event.phase
 
		-- A finger just touched the screen (and the sword still exists)
		--
        if( phase == "began" and theSword ) then

			-- If we somehow failed to remove the previous temp joint, remove it now)
			--
			if( theSword.tempJoint ) then
				theSword.tempJoint:removeSelf()
			end

			-- Create a temporary touch joint and store it in the object for later reference
			--
			theSword.tempJoint = physics.newJoint( "touch", theSword, theSword.x, theSword.y )

			-- Give it a 'maxForce' value 
			theSword.tempJoint.maxForce = touchJointForce

			-- Start tracking the last position of the touch.  We will use this to 
			-- figure out how much individual moves have changed (their delta)
			-- and then only use the delta's to move the 'touch joint'.				
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y
 

		-- The finger has been moved (swiped) on the screen (and the sword still exists)
		--
        elseif( phase == "moved"  and theSword ) then
			-- Calculate how much our finger moved (delta)
			--                
			local deltaX =  theSword.lastmoveX - event.x
			local deltaY =  theSword.lastmoveY - event.y

			-- Multiply the delta values by the sword drag multipliers (make the delta bigger)
			--
			deltaX = deltaX * swordDragMultX
			deltaY = deltaY * swordDragMultY

			-- Update our last move trackers for the next move calculation
			--
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y

			-- Finally, update the joint's (target) position.  In other words, we are telling
			-- the physics system where we want the joint to be, then it will use physics
			-- calculations to move it there, based on the settings we provided (maxForce, 
			-- frequency, and dampingRatio) when we created and configured the joint.
			--
			-- Note: I have left frequencing and dampingRatio at their default values.
			-- 
			theSword.tempJoint:setTarget( theSword.x - 10 * deltaX, theSword.y - 10 *deltaY)

		-- The finger has been lifted from the screen
		-- 
        elseif( phase == "ended" )then

			if(theSword and theSword.tempJoint) then
				-- We are done with this touch joint now and should remove it.
				theSword.tempJoint:removeSelf()
				theSword.tempJoint = nil
			end
        end
 
        -- Don't forget to return true.  This will tell Corona that the
		-- touch has been handled and not more listeners need to receive it.
		--
        return true
end

-- ==
--		onCollision() - This event listener handles all enemy collisions with other objects.  
--		It operates as follows:
--
--		1. Check the phase, and only do any work in the "began" phase.
--
--		2. If the 'other' object it has collided with is the sword, it removes the enemy.
--
--		3. If the 'other' object it has collided with is the player, it removes the enemy,
--		the player, the sword, and the sword joint.  (Optionally) remove the anchor parts too.
--
--		4. It ignores all other collisions.
--
-- ==
onCollision =  function( self, event )
	local other = event.other  -- The object the enemy has collided with
	local phase = event.phase

	if(phase == "began") then

		-- Did the enemy collide with the sword?
		if( other == theSword ) then
			-- We use a delay to remove objects because removing objects that are
			-- in the middle of collision processing is illegal.
			timer.performWithDelay( 1,
				function()
					self:removeSelf()
				end 
			)

			-- Add one 'kill' to our score counter
			local score = tonumber(scoreCounter.text)
			score = score + 1
			scoreCounter.text = score

			if( soundEnabled ) then
				-- Randomly play either a sword hit sound or an ugh sound
				--
				local freeChannel	= audio.findFreeChannel() 
				audio.setVolume( effectVolume , {channel = freeChannel} )

				if(math.random(1,12) > 5 ) then
					audio.play( hitSounds[math.random(1,7)], {channel = freeChannel} )
				else
					-- Note: There are 5 ugh sounds, but #5 is for the player die sound only.
					audio.play( ughSounds[math.random(1,4)], {channel = freeChannel} ) 
				end
			end

	
		-- Did the enemy collide with the player?			
		elseif( other == thePlayer ) then
			-- We use a delay to remove objects because removing objects that are
			-- in the middle of collision processing is illegal.
			timer.performWithDelay( 1,
				function()
					self:removeSelf()

					backImage:removeEventListener( "touch", dragTheSword )

					cleanup()
				end
			)

			if( soundEnabled ) then
				-- Randomly play one of the 5 ugh sounds
				--
				local freeChannel	= audio.findFreeChannel() 
				audio.setVolume( effectVolume , {channel = freeChannel} )

				audio.play( ughSounds[5], {channel = freeChannel} )
			end

			gameIsRunning = false

			timer.performWithDelay( 2000, 
				function()
					gameIsRunning = true
					createScene()
					createPlayer()
					createEnemies()
				end
			)

		end
	end

	return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
createScene()
createPlayer()
createEnemies()