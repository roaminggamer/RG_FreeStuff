-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

--[[	Notes about this game:
	
	This version of the game implements a very basic player, sword, and swordy dragging algorithm.

	It's ugly and doesn't function nicely, but it gives us a place to start.

--]]

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- Because we are using SSKCorona to build this version of the game, we need to include it below.

-- This game uses physics for: player movement damping (drag), joints, sword dragging, ...

local physics = require("physics")
physics.start()

physics.setGravity( 0, 0 )			-- We don't need gravity, so turn it off

physics.setDrawMode("hybrid")		-- This is a useful physics visualization that
									-- will show us where our collision boxes, and where the different
									-- joints and pivot points are.

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
--
-- Locals
--
											-- Some helper variables specifying:
local w       = display.contentWidth		-- Design width, height, and center <x,y> positions.
local h       = display.contentHeight
local centerX = display.contentWidth/2 
local centerY = display.contentHeight/2

-- == Variables for holding references to game objects. 
local backImage
local thePlayer
local theSword
local swordJoint

--
-- Function Declarations
--
local createScene			-- Function to create the game scene (except for player and enemies)
local createPlayer			-- Function to create the player and its sword.

--
-- Listener Declarations
--
local dragTheSword			-- Touch handler for dragging the player's sword.

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--		createScene() - This function creates the game scene.
--
--		* Creates a 'ground' image (texture)
--		* Adds a touch handler to the 
--
-- ==
createScene = function(  )

	--
	-- 1. Add an image to the scene to act as a 'ground' texture and
	-- so we have something to add our touch listener to.
	--	
	backImage = display.newImage("images/interface/protoBack.png") 
	backImage.x = centerX
	backImage.y = centerY

	backImage:setFillColor(255,255,255,255)

	--
	-- 2. Add event listener for sword dragging
	--
	backImage:addEventListener( "touch", dragTheSword )
end


-- ==
--		createPlayer() - This function creates the player and it's sword.
--	
-- ==
createPlayer = function(  )
	--
	-- 1. Create the player
	--

	-- A. First create a simple representation of the player with the supplied image: boxman.png
	--
	thePlayer = display.newImageRect( "images/boxman.png", 100, 67  )
	thePlayer.x = centerX
	thePlayer.y = centerY+100


	-- B. Attach a physics body to the player
	--
	
	physics.addBody( thePlayer, "dynamic"  )


	-- C. Create the sword
	--
	theSword = display.newImageRect( "images/sword.png", 31, 100  )
	theSword.x = thePlayer.x + 40
	theSword.y = thePlayer.y - 70

	physics.addBody( theSword, "dynamic" )

	
	-- D. Attach the player target to the sword using a "pivot" joint that acts like a shoulder joint
	-- (or an elbow if you prefer).
	--
	swordJoint = physics.newJoint( "pivot", thePlayer, theSword, thePlayer.x+40, thePlayer.y  )
		
end


--==
-- ================================= LISTENER DEFINITIONS
--==

 
-- ==
--		dragTheSword() - This event listener function has the job of moving the sword around, which in turn drags the
--		player's target with it.
--
--		To achieve this, I have used a physics feature called a 'touch joint'.  These joints can be used
--		to drag objects around the screen using physics to give the drag a nice behavior.
--		Among other things, you can adjust the 'maxForce' of the 'touch joint'.  High values pull harder.
--
--
--		In this touch listener, I will create a new touch joint when the touch begins and attach it to the 
--		center of the sword.
--
--		Then, I will allow it to be dragged around during move events.
--
--		Finally, when the touch ends, I will remove the joint.
--
-- ==
dragTheSword = function( event )
        local target = event.target
        local phase = event.phase
 
		-- A finger just touched the screen
		--
        if( phase == "began" ) then

			-- If we somehow failed to remove the previous temp joint, remove it now)
			--
			if( theSword.tempJoint ) then
				theSword.tempJoint:removeSelf()
			end

			-- Create a temporary touch joint and store it in the object for later reference
			--
			theSword.tempJoint = physics.newJoint( "touch", theSword, theSword.x, theSword.y )

			-- Start tracking the last position of the touch.  We will use this to 
			-- figure out how much individual moves have changed (their delta)
			-- and then only use the delta's to move the 'touch joint'.				
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y
 

		-- The finger has been moved (swiped) on the screen
		--
        elseif( phase == "moved" ) then
			-- Calculate how much our finger moved (delta)
			--                
			local deltaX =  theSword.lastmoveX - event.x
			local deltaY =  theSword.lastmoveY - event.y

			-- Multiply the delta values by the sword drag multipliers (make the delta bigger)
			--
			deltaX = deltaX 
			deltaY = deltaY 

			-- Update our last move trackers for the next move calculation
			--
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y

			-- Finally, update the joint's (target) position.  In other words, we are telling
			-- the physics system where we want the joint to be, then it will use physics
			-- calculations to move it there, based on the settings we provided (maxForce, 
			-- frequency, and dampingRatio) when we created and configured the joint.
			--
			-- Note: I have left frequencing and dampingRatio at their default values.
			-- 
			theSword.tempJoint:setTarget( theSword.x - 10 * deltaX, theSword.y - 10 *deltaY)

		-- The finger has been lifted from the screen
		-- 
        elseif( phase == "ended" )then

            -- We are done with this touch joint now and should remove it.
            theSword.tempJoint:removeSelf()
			theSword.tempJoint = nil
        end
 
        -- Don't forget to return true.  This will tell Corona that the
		-- touch has been handled and not more listeners need to receive it.
		--
        return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
createScene()
createPlayer()
