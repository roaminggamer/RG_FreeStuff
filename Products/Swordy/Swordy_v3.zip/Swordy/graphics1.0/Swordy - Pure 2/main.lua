-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

--[[	Notes about this game:
	
	This version of the game improves on 'Pure 1' by improving:
	
	* The collision boxes for the player and sword.
	* The dragging algorithm.
	* The sword joint.
	* Debug (adds a debug mode).

--]]

local debugMode = true

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- This game uses physics for: player movement damping (drag), joints, sword dragging, ...

local physics = require("physics")
physics.start()

physics.setGravity( 0, 0 )			-- We don't need gravity, so turn it off

if( debugMode ) then
	physics.setDrawMode("hybrid")		-- This is a useful physics visualization that
										-- will show us where our collision boxes, and where the different
										-- joints and pivot points are.
end

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
--
-- Locals
--
											-- Some helper variables specifying:
local w       = display.contentWidth		-- Design width, height, and center <x,y> positions.
local h       = display.contentHeight
local centerX = display.contentWidth/2 
local centerY = display.contentHeight/2


-- == Variables to control how the interactive parts of the player + sword behave.
--
-- Note: I have placed these all here so you can quickly play with settings without skipping about in the file.
--
local swordDragMultX		= 4  -- Multiplies X inputs by 3 for more exagerated movement
local swordDragMultY		= 4  -- Multiplies Y inputs by 3 for more exagerated movement

local playerLinearDamping	= 100	-- The higher this number is, the more the player's linear movement  
									-- is affected by drag and slowed down.

local playerAngularDamping	= 1000	-- The higher this number is, the more the player's rotational movement
									-- is affected by drag and slowed down.

local swordLinearDamping	= 0		-- The higher this number is, the more the sword's linear movement  
									-- is affected by drag and slowed down.

local swordAngularDamping	= 0		-- The higher this number is, the more the sword's rotational movement
									-- is affected by drag and slowed down.

local shoulderPivotLimitEn	= true	-- Set this to true to limit the range of the sword joint (shoulder)
local shoulderPivotLimits	= { min = -45,  max = 75 } 


local touchJointForce		= 10	-- This controls how strongly the 'touch joint' drags the sword
									-- Tips: Try low and high values to see what happens.
								 
-- == Variables for holding references to game objects. 
local backImage
local thePlayer
local theSword
local swordJoint

--
-- Function Declarations
--
local createScene			-- Function to create the game scene (except for player and enemies)
local createPlayer			-- Function to create the player and its sword.

--
-- Listener Declarations
--
local dragTheSword			-- Touch handler for dragging the player's sword.

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==


-- ==
--		createScene() - This function creates the game scene.
--
--		* Creates a 'ground' image (texture)
--		* Adds a touch handler to the 
--
-- ==
createScene = function(  )

	--
	-- 1. Add an image to the scene to act as a 'ground' texture and
	-- so we have something to add our touch listener to.
	--	
	backImage = display.newImage("images/interface/protoBack.png") 
	backImage.x = centerX
	backImage.y = centerY

	backImage:setFillColor(0,0,0,0)  -- TIP: Both: 'backImage.alpha = 0'      AND 
	                                 --            'backImage.isVisible = 0' will disable touch,
									 --  setting the fourth fill argument to 0 does not.

	if( debugMode ) then
		backImage:setFillColor(255,255,255,255)
	end

	--
	-- 2. Add event listener for sword dragging
	--
	backImage:addEventListener( "touch", dragTheSword )
end


-- ==
--		createPlayer() - This function creates the player and it's sword.
--	
-- ==
createPlayer = function(  )
	--
	-- 1. Create the player
	--

	-- A. First create a simple representation of the player with the supplied image: boxman.png
	--
	thePlayer = display.newImageRect( "images/boxman.png", 100, 67  )
	thePlayer.x = centerX
	thePlayer.y = centerY+100


	-- B. Attach a physics body to the player
	--

	-- ======== SIMPLE BODY AND COLLISION BOX ========
	--
	-- The default collision box is a rectangle with the same size and shape as the object
	-- it is being created for.  
	--
	-- To see this collision box shape, enable this code at the top of this file:
	--
	--   physics.setDrawMode("hybrid")
	--

	-- Adding a simple "dynamic" physics target with a default collision box.
	--physics.addBody( thePlayer, "dynamic"  )


	-- ======== BETTER BODY AND COLLISION BOX ========
	--
	-- We can make a tighter fitting and better collision shape as follows:
	--
	-- a. Create a table containing up to eight (8) x,y pairs, where each of 
	--    these pairs specifies a point in our collision shape.
	--    Note: These points must be specified in COUNTER-CLOCKWISE ORDER
	--	
	-- Our shape's points: x1,  y1   x2,  y2   x3, y3    x4, y4
	local playerShape = { -30, -10,  30, -10,  30, 20,  -30, 20 }

	--
	-- b. Pass the table containing our shape to the 'physics.addBody()' function
	--    as shown below:
	--
	-- Adding a "dynamic" target with a tighter fitting collsion box.
	physics.addBody( thePlayer, "dynamic", { shape=playerShape } )


	-- C. Add some linear and angular drag to the target.
	-- This keeps the target from sliding and twirling too much when we drag it by the sword.
	--
	-- Tip:To see the effect of this, I suggest you experiment with low and high values for each 
	-- of these settings (specified at top of file).
	--	
	thePlayer.linearDamping   = playerLinearDamping
	thePlayer.angularDamping  = playerAngularDamping

	
	-- D. Create the sword and attach a tight fitting target to it.
	--
	theSword = display.newImageRect( "images/sword.png", 31, 100  )
	theSword.x = thePlayer.x + 40
	theSword.y = thePlayer.y - 70

	-- Basic target and collision box
	--physics.addBody( theSword, "dynamic" )

	-- Better target and collision box
	local swordShape = { -5,-50, 5,-50, 5,50, -5,50 }
	physics.addBody( theSword, "dynamic", { shape=swordShape } )


	-- E. (Optionally) add some linear and angular drag to the target.
	-- This keeps the target from sliding and twirling too much when we drag it by the sword.
	--
	theSword.linearDamping = swordLinearDamping
	theSword.angularDamping  = swordAngularDamping


	-- F. Attach the player target to the sword using a "pivot" joint that acts like a shoulder joint
	-- (or an elbow if you prefer).
	--
	swordJoint = physics.newJoint( "pivot", thePlayer, theSword, thePlayer.x+40, thePlayer.y  )
	
	-- We can limit the min/max rotation of this joint.  
	-- Note: As with most of the settings I've exposed, you will find a variable at the top of
	-- this file to configure it with. 
	swordJoint.isLimitEnabled = shoulderPivotLimitEn
	swordJoint:setRotationLimits( shoulderPivotLimits.min, shoulderPivotLimits.max )
	
end


--==
-- ================================= LISTENER DEFINITIONS
--==

 
-- ==
--		dragTheSword() - This event listener function has the job of moving the sword around, which in turn drags the
--		player's target with it.
--
--		To achieve this, I have used a physics feature called a 'touch joint'.  These joints can be used
--		to drag objects around the screen using physics to give the drag a nice behavior.
--		Among other things, you can adjust the 'maxForce' of the 'touch joint'.  High values pull harder.
--
--
--		In this touch listener, I will create a new touch joint when the touch begins and attach it to the 
--		center of the sword.
--
--		Then, I will allow it to be dragged around during move events.
--
--		Finally, when the touch ends, I will remove the joint.
--
-- ==
dragTheSword = function( event )
        local target = event.target
        local phase = event.phase
 
		-- A finger just touched the screen
		--
        if( phase == "began" ) then

			-- If we somehow failed to remove the previous temp joint, remove it now)
			--
			if( theSword.tempJoint ) then
				theSword.tempJoint:removeSelf()
			end

			-- Create a temporary touch joint and store it in the object for later reference
			--
			theSword.tempJoint = physics.newJoint( "touch", theSword, theSword.x, theSword.y )

			-- Give it a 'maxForce' value 
			theSword.tempJoint.maxForce = touchJointForce

			-- Start tracking the last position of the touch.  We will use this to 
			-- figure out how much individual moves have changed (their delta)
			-- and then only use the delta's to move the 'touch joint'.				
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y
 

		-- The finger has been moved (swiped) on the screen
		--
        elseif( phase == "moved" ) then
			-- Calculate how much our finger moved (delta)
			--                
			local deltaX =  theSword.lastmoveX - event.x
			local deltaY =  theSword.lastmoveY - event.y

			-- Multiply the delta values by the sword drag multipliers (make the delta bigger)
			--
			deltaX = deltaX * swordDragMultX
			deltaY = deltaY * swordDragMultY

			-- Update our last move trackers for the next move calculation
			--
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y

			-- Finally, update the joint's (target) position.  In other words, we are telling
			-- the physics system where we want the joint to be, then it will use physics
			-- calculations to move it there, based on the settings we provided (maxForce, 
			-- frequency, and dampingRatio) when we created and configured the joint.
			--
			-- Note: I have left frequencing and dampingRatio at their default values.
			-- 
			theSword.tempJoint:setTarget( theSword.x - 10 * deltaX, theSword.y - 10 *deltaY)

		-- The finger has been lifted from the screen
		-- 
        elseif( phase == "ended" )then

            -- We are done with this touch joint now and should remove it.
            theSword.tempJoint:removeSelf()
			theSword.tempJoint = nil
        end
 
        -- Don't forget to return true.  This will tell Corona that the
		-- touch has been handled and not more listeners need to receive it.
		--
        return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
createScene()
createPlayer()
