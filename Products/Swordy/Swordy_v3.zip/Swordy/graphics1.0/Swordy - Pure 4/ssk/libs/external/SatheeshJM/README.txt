This code was provided by Satheesh JM here:
https://github.com/SatheeshJM/Ascii85-Encoding-in-Pure-Lua




**Ascii 85 Encoding in Pure Lua **


USAGE


local ascii85 = require "ascii85"

local enc = ascii85.encode(input)
local dec = ascii85.decode(enc)