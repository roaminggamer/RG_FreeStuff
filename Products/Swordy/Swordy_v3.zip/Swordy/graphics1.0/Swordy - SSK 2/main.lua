-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

--[[	Notes about this game:
	
	This version of the game improves on 'SSK 1' by improving:

	* By adding a nicer ground texture and improving the player and enemy armour images.
	* Shrinking the player + sword a little so there is more play spaces.

--]]

local debugMode = false

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- Because we are using SSKCorona to build this version of the game, we need to include it below.
require( "ssk.globals" )
require( "ssk.loadSSK" )

-- Lastly, I have created a short custom preset to define the click and "puzzle solved!" sounds.
-- See the file 'data/soundPresets.lua"

require("soundPresets")

-- This game uses physics for: player movement damping (drag), joints, sword dragging, ...

local physics = require("physics")
physics.start()

physics.setGravity( 0, 0 )			-- We don't need gravity, so turn it off

if( debugMode ) then
	physics.setDrawMode("hybrid")		-- This is a useful physics visualization that
										-- will show us where our collision boxes, and where the different
										-- joints and pivot points are.
end

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
--
-- Locals
--

-- == Variables to control how the interactive parts of the player + sword behave.
--
-- Note: I have placed these all here so you can quickly play with settings without skipping about in the file.
--
local swordDragMultX		= 4  -- Multiplies X inputs by 3 for more exagerated movement
local swordDragMultY		= 4  -- Multiplies Y inputs by 3 for more exagerated movement

local playerLinearDamping	= 100	-- The higher this number is, the more the player's linear movement  
									-- is affected by drag and slowed down.

local playerAngularDamping	= 1000	-- The higher this number is, the more the player's rotational movement
									-- is affected by drag and slowed down.

local swordLinearDamping	= 0		-- The higher this number is, the more the sword's linear movement  
									-- is affected by drag and slowed down.

local swordAngularDamping	= 0		-- The higher this number is, the more the sword's rotational movement
									-- is affected by drag and slowed down.

local shoulderPivotLimitEn	= true	-- Set this to true to limit the range of the sword joint (shoulder)
local shoulderPivotLimits	= { min = -45,  max = 75 } 


local touchJointForce		= 10	-- This controls how strongly the 'touch joint' drags the sword
									-- Tips: Try low and high values to see what happens.


local gameIsRunning = true			-- A flag to track whether the game is running or over.

								 
-- == Variables for holding references to game objects. 
local backImage
local thePlayer
local theSword
local swordJoint

-- == Anchor enable and variables to hold references to the anchor parts
local anchorEn			= true
local thePlayerAnchor
local playerAnchorJoint
local anchorOffsetY = 15
local anchorDampingRatio = 0.2
local anchorFrequencyRatio = 1

--
-- Labels, Buttons, Etc
--
local scoreCounter					-- A variable to hold the handler to our score counter

--
-- Sounds
--
local soundEnabled = true	-- A flag to enable/disble sound
ssk.sounds:setEffectsVolume( 0.8 )

--
-- Function Declarations
--
local createLayers			-- Function to create rendering layers 
local createScene			-- Function to create the game scene (except for player and enemies)
local createPlayer			-- Function to create the player and its sword.
local createEnemy			-- Function to create a single enemy.
local createEnemies			-- Function to schedule the creation of enemies (more and more over time)
local pursuePlayer			-- Function to make enemies move towards player
local cleanup				-- Function to remove all display objects and other game related content

--
-- Listener Declarations
--
local dragTheSword			-- Touch handler for dragging the player's sword.
local onCollision			-- A general touch handle used to handle: sword vs. other object collisions

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--		createLayers() - Creates and sorts rendering layers.
-- ==
createLayers = function( )
	layers = ssk.display.quickLayers( display.currentStage, 
		"ground",		-- Bottom
		"content",		-- Middle
		"interfaces" )	-- Top
end

-- ==
--		createScene() - This function creates the game scene.
--
--		* Creates a 'ground' image (texture)
--		* Adds a touch handler to the 
--
-- ==
createScene = function(  )

	--
	-- 1. Add an image to the scene to act as a 'ground' texture and
	-- so we have something to add our touch listener to.
	--	
	backImage = ssk.display.backImage( layers.ground, "LostGardenBack.png" ) 

	--
	-- 2. Add event listener for sword dragging
	--
	backImage:addEventListener( "touch", dragTheSword )

	--
	-- 3. Add a score counter
	--
	scoreCounter = ssk.labels:quickLabel( layers.interfaces, 0, 30, 30, native.systemFont, 24 )		

end


-- ==
--		createPlayer() - This function creates the player and it's sword.
--	
--		Note: It optionally creates an anchor that 'pulls the player' back if 
--		s/he moves to far from it.
--
-- ==
createPlayer = function(  )
	--
	-- 1. Create the player
	--

	-- A. First create a simple representation of the player with the supplied image: knight.png
	--
	local playerScale = 0.7
	local playerShape = { -30 * playerScale, -10 * playerScale,
	                       30 * playerScale, -10 * playerScale,  
						   30 * playerScale, 20 * playerScale,  
						  -30 * playerScale, 20 * playerScale }

	thePlayer = ssk.display.imageRect( layers.content, centerX, centerY,
									   "images/knight.png", { w = 100 * playerScale, h = 67 * playerScale }, 
									   { shape = playerShape,
									     linearDamping   = playerLinearDamping,
										 angularDamping  = playerAngularDamping  } )


	-- B. (Optionally) add an anchor and attach the player to it using a "distance" joint.
	-- This will drag the player back to the anchor point when you stop dragging the sword.
	-- This also tends to keep the player's back aligned to the anchor point.
	-- You may like this better than the free movement model. 
	
	if( anchorEn ) then
		--
		-- Player Anchor -- A "static" object that will act as the anchor.
		--
		-- Tip: I made this into a sensor so it will not give 'physical' collision
		-- feedback (i.e the player, sword, and other moving objects will all pass through it.)
		--
		thePlayerAnchor = ssk.display.circle( layers.content, thePlayer.x, thePlayer.y+50,
								{ radius = 10, isVisible = debugMode },
								{ bodyType = "static", isSensor = true } )
								
		--
		-- Player to Anchor Joint - A physics joint that connects the player target to the anchor.
		--
		playerAnchorJoint = physics.newJoint( "distance", thePlayerAnchor, thePlayer, 
									           thePlayerAnchor.x, thePlayerAnchor.y, 
											   thePlayer.x, thePlayer.y + anchorOffsetY )
	
		playerAnchorJoint.dampingRatio	= anchorDampingRatio
		playerAnchorJoint.frequency		= anchorFrequencyRatio

		print("playerAnchorJoint.length       == " .. playerAnchorJoint.length )
		print("playerAnchorJoint.frequency    == " .. playerAnchorJoint.frequency )
		print("playerAnchorJoint.dampingRatio == " .. playerAnchorJoint.dampingRatio )
	end

	
	-- C. Create the sword and attach a tight fitting target to it.
	--
	local swordShape = { -5 * playerScale, -50 * playerScale, 
	                      5 * playerScale, -50 * playerScale, 
						  5 * playerScale,  50 * playerScale, 
						 -5 * playerScale,  50 * playerScale }
	theSword = ssk.display.imageRect( layers.content, thePlayer.x + 40  * playerScale, thePlayer.y - 70 * playerScale,
									   "images/sword.png", { w = 31 * playerScale, h = 100 * playerScale }, 
									   { shape = swordShape,
									     linearDamping   = swordLinearDamping,
										 angularDamping  = swordAngularDamping  } )

	-- D. Attach the player target to the sword using a "pivot" joint that acts like a shoulder joint
	-- (or an elbow if you prefer).
	--
	swordJoint = physics.newJoint( "pivot", thePlayer, theSword, 
	                               thePlayer.x + 40 * playerScale , thePlayer.y  )
	
	-- We can limit the min/max rotation of this joint.  
	-- Note: As with most of the settings I've exposed, you will find a variable at the top of
	-- this file to configure it with. 
	swordJoint.isLimitEnabled = shoulderPivotLimitEn
	swordJoint:setRotationLimits( shoulderPivotLimits.min, shoulderPivotLimits.max )
	
end

-- ==
--		createEnemies() - A small wrapper function for 'createEnemy()' that call itself
--		repeatedly while the game is running.
-- ==
createEnemies = function( )

	-- A. Call the 'createEnemy()' function to do all the heavy lifting
	--
	createEnemy( math.random( 0, w ) , -h/2 )

	-- B. Automatically call 'createEnemies()' again in 2 seconds while the game is running
	--
	if( gameIsRunning ) then
		createEnemiesTimer = timer.performWithDelay( 750, createEnemies )
	end

end

-- ==
--		pursuePlayer() - A simple AI algorithm that causes the enemy to move towards the player.
--		Then, when it reaches that point, if the player has moved, the enemy moves to the player's 
--		new position.
--
-- ==
pursuePlayer = function( self )

	-- If the game isn't running, do nothing
	--
	if( gameIsRunning ) then
		
		-- If this is the second (third, ...) time the enemy is moving, move faster than the first time
		--
		if( self.hasMoved ) then
			transition.to( self, { x = thePlayer.x, y = thePlayer.y, time = 2000,  onComplete = pursuePlayer } )
		
		-- This is the first move, so take more time as we have further to go
		--
		else
			transition.to( self, { x = thePlayer.x, y = thePlayer.y, time = 5000,  onComplete = pursuePlayer } )

			-- Mark this enemy as having moved so next time it moves it will move faster
			--
			self.hasMoved = true 

		end
	end

end

-- ==
--		createEnemy() - This function creates a single enemy that will move towards the player
-- ==
createEnemy = function( startX, startY )

	-- 
	-- If the game has stopped running, do not create an enemy
	--
	if( not gameIsRunning ) then
		return
	end

	--
	-- 1. Create a single enemy
	--
	
	-- A. First create a simple representation of the enemy with the supplied image: knight.png
	--
	-- Our shape's points: x1,  y1   x2,  y2   x3, y3    x4, y4
	local enemyShape = { -15, -5,  15, -5,  15, 10,  -15, 10 }

	enemy = ssk.display.imageRect( layers.content, startX, startY, "images/knight.png", 
									{ w = 50, h = 34,  rotation = 180, fill = _RED_ },
									{ shape=enemyShape, isSensor = true } )

	-- B. Use a transition to move the enemy from its current Y position to a position well off the bottom of the screen
	--
	pursuePlayer( enemy )

	-- C.  Add a collision event listener to this enemy
	--
	enemy.collision = onCollision
	enemy:addEventListener( "collision", enemy )
		
end

-- ==
--    cleanup() - This function can be used to safely remove all objects and clean up memory.
-- ==
cleanup = function( )
	
	--
	-- 1. Remove the display group which automatically removes all objects stored in it.
	--
	layers:destroy()

	--
	-- 2. Remove any remaining physics objects we created
	--
	safeRemove( playerAnchorJoint ) -- 'safeRemove()' is a global function added by SSK
	safeRemove( swordJoint ) -- 'safeRemove()' is a global function added by SSK

	--
	-- 3. Clear all references by setting them to nil		
	--
	backImage = nil
	thePlayerAnchor = nil
	playerAnchorJoint = nil
	swordJoint = nil
	thePlayer = nil
	theSword = nil
	scoreCounter = nil
	gameGroup = nil

end


--==
-- ================================= LISTENER DEFINITIONS
--==

 
-- ==
--		dragTheSword() - This event listener function has the job of moving the sword around, which in turn drags the
--		player's target with it.
--
--		To achieve this, I have used a physics feature called a 'touch joint'.  These joints can be used
--		to drag objects around the screen using physics to give the drag a nice behavior.
--		Among other things, you can adjust the 'maxForce' of the 'touch joint'.  High values pull harder.
--
--
--		In this touch listener, I will create a new touch joint when the touch begins and attach it to the 
--		center of the sword.
--
--		Then, I will allow it to be dragged around during move events.
--
--		Finally, when the touch ends, I will remove the joint.
--
-- ==
dragTheSword = function( event )
        local target = event.target
        local phase = event.phase
 
		-- A finger just touched the screen (and the sword still exists)
		--
        if( phase == "began" and theSword ) then

			-- If we somehow failed to remove the previous temp joint, remove it now)
			--
			if(theSword and theSword.tempJoint) then
				safeRemove( theSword.tempJoint ) -- 'safeRemove()' is a global function added by SSK
			end

			-- Create a temporary touch joint and store it in the object for later reference
			--
			theSword.tempJoint = physics.newJoint( "touch", theSword, theSword.x, theSword.y )

			-- Give it a 'maxForce' value 
			theSword.tempJoint.maxForce = touchJointForce

			-- Start tracking the last position of the touch.  We will use this to 
			-- figure out how much individual moves have changed (their delta)
			-- and then only use the delta's to move the 'touch joint'.				
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y
 

		-- The finger has been moved (swiped) on the screen (and the sword still exists)
		--
		-- Note: I added a check for 'lastmoveX' because of a strange issue with the simulator.
		--       When loading a new game via the menu, you can get a phantom touch moved/ended
		--       in some cases.  This resulted in a bug when trying to access 'lastmoveX' (only created
		--       in the "began" phase.
	    --       This bug can't occur on a real device.
        elseif( phase == "moved"  and theSword and theSword.lastmoveX) then
			-- Calculate how much our finger moved (delta)
			--                
			local deltaX =  theSword.lastmoveX - event.x
			local deltaY =  theSword.lastmoveY - event.y

			-- Multiply the delta values by the sword drag multipliers (make the delta bigger)
			--
			deltaX = deltaX * swordDragMultX
			deltaY = deltaY * swordDragMultY

			-- Update our last move trackers for the next move calculation
			--
			theSword.lastmoveX = event.x
			theSword.lastmoveY = event.y

			-- Finally, update the joint's (target) position.  In other words, we are telling
			-- the physics system where we want the joint to be, then it will use physics
			-- calculations to move it there, based on the settings we provided (maxForce, 
			-- frequency, and dampingRatio) when we created and configured the joint.
			--
			-- Note: I have left frequencing and dampingRatio at their default values.
			-- 
			theSword.tempJoint:setTarget( theSword.x - 10 * deltaX, theSword.y - 10 *deltaY)

		-- The finger has been lifted from the screen
		-- 
		-- Note: I added a check for 'lastmoveX' because of a strange issue with the simulator.
		--       When loading a new game via the menu, you can get a phantom touch moved/ended
		--       in some cases.  This resulted in a bug when trying to access 'lastmoveX' (only created
		--       in the "began" phase.
	    --       This bug can't occur on a real device.
        elseif( phase == "ended" and theSword.lastmoveX) then

			if(theSword and theSword.tempJoint) then
				safeRemove( theSword.tempJoint ) -- 'safeRemove()' is a global function added by SSK
			end
        end
 
        -- Don't forget to return true.  This will tell Corona that the
		-- touch has been handled and not more listeners need to receive it.
		--
        return true
end

-- ==
--		onCollision() - This event listener handles all enemy collisions with other objects.  
--		It operates as follows:
--
--		1. Check the phase, and only do any work in the "began" phase.
--
--		2. If the 'other' object it has collided with is the sword, it removes the enemy.
--
--		3. If the 'other' object it has collided with is the player, it removes the enemy,
--		the player, the sword, and the sword joint.  (Optionally) remove the anchor parts too.
--
--		4. It ignores all other collisions.
--
-- ==
onCollision =  function( self, event )
	local other = event.other  -- The object the enemy has collided with
	local phase = event.phase

	if(phase == "began") then

		-- Did the enemy collide with the sword?
		if( other == theSword ) then
			-- We use a delay to remove objects because removing objects that are
			-- in the middle of collision processing is illegal.
			self.timer = safeRemove
			timer.performWithDelay( 1, self )

			-- Add one 'kill' to our score counter
			local score = tonumber(scoreCounter.text)
			score = score + 1
			scoreCounter.text = score

			if( soundEnabled ) then
				-- Randomly play either a sword hit sound or an ugh sound
				--
				if(math.random(1,12) > 4 ) then
					ssk.sounds:play("hit" .. math.random(1,7))
				else
					-- Note: There are 5 ugh sounds, but #5 is for the player die sound only.
					ssk.sounds:play("ugh" .. math.random(1,4))
				end
			end

	
		-- Did the enemy collide with the player?			
		elseif( other == thePlayer ) then
			-- We use a delay to remove objects because removing objects that are
			-- in the middle of collision processing is illegal.
			timer.performWithDelay( 1,
				function()
					safeRemove( thePlayer ) -- 'safeRemove()' is a global function added by SSK
					safeRemove( theSword.tempJoint ) -- 'safeRemove()' is a global function added by SSK
					safeRemove( theSword ) -- 'safeRemove()' is a global function added by SSK
					backImage:removeEventListener( "touch", dragTheSword )					
				end
			)

			if( soundEnabled ) then
				ssk.sounds:play("ugh5")
			end

			gameIsRunning = false

			timer.performWithDelay( 2000, 
				function()
					cleanup()
					gameIsRunning = true
					createLayers()
					createScene()
					createPlayer()
					createEnemies()
				end
			)

		end
	end

	return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
createLayers()
createScene()
createPlayer()
createEnemies()