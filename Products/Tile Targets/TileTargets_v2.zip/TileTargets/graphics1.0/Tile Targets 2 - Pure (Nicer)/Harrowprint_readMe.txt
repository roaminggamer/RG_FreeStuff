
I downloaded this font as part of a Corona example.  As far as I know it is free to 
use in free projects, but may require a license for paid projects, so if you choose
to use it in your paid projects do the research.  

Cheers,

Ed