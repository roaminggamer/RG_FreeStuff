-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- targets.lua- A module for creating target and target rows.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------
-- Localize the global 'minScale' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from globals.lua.  This is a nice debugging technique.
--
local minScale		= minScale or 0.001
local maxScale		= maxScale or 1
local targetWidth	= targetWidth or 80
local targetHeight	= targetHeight or 90
local edgeWidth		= edgeWidth or 2
local baseWidth		= baseWidth or 6
local baseHeight	= baseHeight or 15

-- ==
--	touch() - A generic function attached to all targets to handle touches on those targets.
-- ==
local function touch( self, event )
	-- Only do any work if this is the end of the touch (i.e. finger lifted)
	--
	if(event.phase == "ended") then
		-- Play SFX (if enabled)
		--
		soundModule.playEffect( "boop" )

		-- If the target specified a callback, call it now.
		--
		if( self.callback ) then
			self:callback()
		end

		-- Spin the target
		--
		self:spinTarget()

		-- If this target is marked as being a button (used by main menu),
		-- Show it after it gets done spinning.  
		--
		if(self.isButton) then
			timer.performWithDelay( spinTime2 * 8, function() self:showTarget() end )
		end
	end
	return true
end

-- ==
--	createTarget() - Create a single target. 
-- ==
local function createTarget( layer, x, y, params )
	
	-- 1. Localize the parameters list and set up default values if neccesary.
	--
	local params	 = params or {}
	local x          = x or centerX
	local y          = y or centerY
	local goodTarget = fnn(params.goodTarget, false)
	local color      = params.color or colorModule.randomColorCode()
	local imagePath  = params.imagePath or  imageModule.randomImagePath()
	local callback   = params.callback

	local text       = params.text
	local fontSize   = params.fontSize or 14
	local isButton   = params.isButton

	-- 1. Create the Target (starts off scaled down so it isn't showing).
	--

	-- Use a display group as our target and as a container for all parts of the target.
	--
	local target = display.newGroup()

	-- Initialize the various settings for this target
	--
	target.callback   = callback	-- Attach callback is provided
	target.goodTarget = goodTarget	-- Mark as 'good' or 'bad' target
	target.isButton   = isButton	-- Is or is not a button
	target.touch      = touch       -- Attach the touch listner function

	-- Create the target background and scale it down to start.
	--
	target.back = display.newImageRect(target, "images/wood/tileback2.png", targetWidth, targetHeight)
	target.back:setStrokeColor( 64,64,64 )
	target.back.strokeWidth = 2
	target.back.x = targetWidth/2
	target.back.y = targetHeight/2
	target.back.xScale = minScale

	-- If text was specified, make the target content a label, otherwise show an image.
	-- Again, scale the content down to the minimum settings.
	--
	if( text ) then
		target.content = display.newEmbossedText( target, text, 0, 0, gameFont, fontSize )
		target.content.x = targetWidth/2
		target.content.y = targetHeight/2
		target.content:setTextColor( 0 )
		target.content.xScale = minScale
	else
		target.content = display.newImageRect(target, imagePath, targetWidth-4, targetHeight-4)
		target.content:setFillColor( unpack( color ) )
		target.content.x = targetWidth/2
		target.content.y = targetHeight/2
		target.content.xScale = minScale
	end

	-- Create a rectangle representing the edge-on view of the target.  
	--
	target.edge = display.newImageRect(target, "images/wood/edge2.png",  edgeWidth, targetHeight + baseHeight )
	target.edge:setStrokeColor( 64,64,64 )
	target.edge.strokeWidth = 2
	target.edge.x = targetWidth/2
	target.edge.y = (targetHeight + baseHeight)/2

	-- Create a 'base' for the target
	--
	target.base = display.newImageRect(target, "images/wood/base2.png",  baseWidth, baseHeight  )
	target.base:setStrokeColor( 64,64,64 )
	target.base.strokeWidth = 2
	target.base.x = targetWidth/2
	target.base.y = targetHeight + baseHeight/2
	--target.base.xScale = minScale

	-- 2. Move the target to the requested <x,y>-position
	--
	layer:insert(target)
	target:setReferencePoint( display.BottomCenterReferencePoint )
	target.x = x
	target.y = y	

	-- 3. Add the showTarget(), hideTarget(), and spinTarget() methjods to this target.
	--

	-- This method scales the target up and hides the edge rectangle, to look like it is flipping open.
	-- It also enables the touch listener at the end of the scaling.
	function target:showTarget( )
		self.edge.isVisible = false
		transition.to( self.content, { xScale = maxScale, time = spinTime, transition=easing.outQuad } ) 		
		transition.to( self.back,  { xScale = maxScale, time = spinTime, transition=easing.outQuad } )
		timer.performWithDelay( spinTime, function() self:addEventListener( "touch", self ) end )
	end

	-- This method scales the target down and shows the edge rectangle, to look like it is flipping closed.
	-- It also disables the touch listener at the end of the scaling.
	function target:hideTarget( )
		self:removeEventListener( "touch", self )
		transition.to( self.content, { xScale = minScale, time = spinTime, transition=easing.outQuad } ) 		
		transition.to( self.back,  { xScale = minScale, time = spinTime, transition=easing.outQuad } ) 		
		timer.performWithDelay( spinTime-(spinTime/5), function() self.edge.isVisible = true end )
	end

	-- This method is like showTarget() w/o the listener code.
	-- It uses the faster spinTime2 variable for the scaling time.
	function target:showTarget2( )
		self.edge.isVisible = false
		transition.to( self.content, { xScale = maxScale, time = spinTime2, transition=easing.outQuad } ) 		
		transition.to( self.back,  { xScale = maxScale, time = spinTime2, transition=easing.outQuad } )
	end

	-- This method is like hideTarget() w/o the listener code.
	-- It uses the faster spinTime2 variable for the scaling time.
	function target:hideTarget2( )
		transition.to( self.content, { xScale = minScale, time = spinTime2, transition=easing.outQuad } ) 		
		transition.to( self.back,  { xScale = minScale, time = spinTime2, transition=easing.outQuad } ) 		
		timer.performWithDelay( spinTime2-(spinTime2/5), function() self.edge.isVisible = true end )
	end

	-- This method uses the showTarget2() and hideTarget2() methods to 'spin' the target a few times.
	-- Since the show/hideTarget2() methods don't deal with the touch listener, this method removes the
	-- listener on its own.
	function target:spinTarget( )

		-- Remove the touch listener so this target can't receive more touches while spinning.			
		self:removeEventListener( "touch", self )
		
		-- Spin, spin, spin...
		self:hideTarget2( )
		timer.performWithDelay( 1 * (spinTime2 + 1), function() self:showTarget2( ) end )
		timer.performWithDelay( 2 * (spinTime2 + 1), function() self:hideTarget2( ) end )
		timer.performWithDelay( 3 * (spinTime2 + 1), function() self:showTarget2( ) end )
		timer.performWithDelay( 4 * (spinTime2 + 1), function() self:hideTarget2( ) end )
		timer.performWithDelay( 5 * (spinTime2 + 1), function() self:showTarget2( ) end )
		timer.performWithDelay( 6 * (spinTime2 + 1), function() self:hideTarget2( ) end )
	end

	return target
end

-- ==
--	createTargetSet() - Create three targets in a row.
-- ==
local function createTargetSet( layer, y, side, params1, params2, params3, doSlideOff )

	-- Optionally disable the sliding off animation below.
	--
	local doSlideOff = fnn(doSlideOff, true)

	-- These tables contain/specify the parameters for the targets in this row (left-to-right).
	local params1 = params1 or {}  -- Left
	local params2 = params2 or {}  -- Middle
	local params3 = params3 or {}  -- Right

	-- If not specified, slide in from the right.
	local side = side or "right"

	-- 1. Create a display group to hold all three targets (makes it easy to remove them later, 
	-- and to position and slide them.)
	--
	local targetSet = display.newGroup()
	layer:insert(targetSet)

	-- 2. Create the three targets.
	--
	targetSet.target1 = createTarget( targetSet, w/5, y-5, params1 )	
	targetSet.target2 = createTarget( targetSet, centerX, y-5, params2 )
	targetSet.target3 = createTarget( targetSet, w - w/5, y-5, params3 )

	-- 3. Change the reference point of our target set (after creation and before moving it).
	targetSet:setReferencePoint( display.CenterReferencePoint )

	-- 4. Move the row off screen and the slide it on screen over time.
	-- This code also optionally hides the targets and slides them back off screen.
	--
	if( side == "right" ) then 
		targetSet.x = centerX + w
		transition.to( targetSet, { x = centerX, time = slideInTime } )
		timer.performWithDelay( slideInTime + showDelay, 
			function()
				targetSet.target1:showTarget()
				targetSet.target2:showTarget()
				targetSet.target3:showTarget()
			end )

		-- If the slide off animation is disabled, skip it.
		if(doSlideOff) then
			timer.performWithDelay( slideInTime + showDelay + visibleTime, 
				function()
					targetSet.target1:hideTarget()
					targetSet.target2:hideTarget()
					targetSet.target3:hideTarget()
				end )

			timer.performWithDelay( slideInTime + showDelay + visibleTime + slideOutDelay, 
				function()
					transition.to( targetSet, { x = centerX - w, time = slideOutTime, onComplete=removeSelf } )
				end )
		end

	else
		targetSet.x = centerX - w
		transition.to( targetSet, { x = centerX, time = slideInTime } )
		timer.performWithDelay( slideInTime + showDelay, 
			function()
				targetSet.target1:showTarget()
				targetSet.target2:showTarget()
				targetSet.target3:showTarget()
			end )

		-- If the slide off animation is disabled, skip it.
		if(doSlideOff) then
			timer.performWithDelay( slideInTime + showDelay + visibleTime, 
				function()
					targetSet.target1:hideTarget()
					targetSet.target2:hideTarget()
					targetSet.target3:hideTarget()
				end )

			timer.performWithDelay( slideInTime + showDelay + visibleTime + slideOutDelay, 
				function()
					transition.to( targetSet, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )
				end )
		end
	end

	return targetSet
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createTargetSet

return public