-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- justgame.lua- A phrase guessing and word-assocation game.
--
-- This code implements the logic for a simple word-association game.
-- Each round, a "Just..." category is selected and three images matching that
-- category are shown.  The remaining six images are of things that don't fit the
-- category.  The player is awarded a point for every target clicked that matches the
-- current category.
--
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

-- A local counter for the number of good hits this round
local goodHits = 0

-- Our categories database/list (add more if you like)
--
-- The first entry in each table is the category name.
--
-- The next three entries in each table are images that match that category.
--
-- The last two entries in each table specify image sets to randomly select from for NON-matching images.
-- If need be, both values can be the same set name, just be sure no images in the set(s) match your current
-- "Just ..." category.
--
local categoryData = {
	{ "Just PETS",  imageModule.getPath( "animals", "bunny" ), 
	                imageModule.getPath( "animals", "dog" ),
					imageModule.getPath( "animals", "cat" ), "dinos", "people"  },

	{ "Just CATS",  imageModule.getPath( "animals", "cheetah" ), 
	                imageModule.getPath( "animals", "tiger" ),
					imageModule.getPath( "animals", "lion" ), "misc", "people"  },

	{ "Just HERBIVORES",  imageModule.getPath( "dinos", "brontosaurus" ), 
	                imageModule.getPath( "animals", "cow" ),
					imageModule.getPath( "animals", "giraffe" ), "monsters", "people"  },

	{ "Just CARNIVORES",  imageModule.getPath( "dinos", "trex" ), 
	                imageModule.getPath( "animals", "tiger" ),
					imageModule.getPath( "dinos", "velociraptor" ), "monsters", "misc"  },

	{ "Just OMNIVORES",  imageModule.getPath( "animals", "gorilla" ), 
	                imageModule.getPath( "animals", "bear" ),
					imageModule.getPath( "people", "lady1" ), "monsters", "misc"  },

	{ "Just BRAINS",  imageModule.getPath( "monsters", "zombie1" ), 
	                imageModule.getPath( "monsters", "zombie2" ), 
					imageModule.getPath( "monsters", "zombie3" ), "animals", "misc"  },

	{ "Just DOWN UNDER",  imageModule.getPath( "animals", "penguin" ), 
	                imageModule.getPath( "animals", "kiwi" ), 
					imageModule.getPath( "animals", "kangaroo" ), "monsters", "misc"  },

	{ "Just PEOPLE",  imageModule.getPath( "people", "lady2" ), 
	                imageModule.getPath( "people", "santa" ), 
					imageModule.getPath( "people", "lincoln" ), "animals", "misc"  },

	{ "Just SPORTS",  imageModule.getPath( "people", "skier" ), 
	                imageModule.getPath( "people", "golf" ), 
					imageModule.getPath( "people", "tennis" ), "animals", "misc"  },

	{ "Just MONSTERS",  imageModule.getPath( "monsters", "frankenstein" ), 
	                imageModule.getPath( "monsters", "mummy" ), 
					imageModule.getPath( "monsters", "vampire" ), "people", "animals"  },

	{ "Just ANIMALS",  imageModule.getPath( "dinos", "trex" ), 
	                imageModule.getPath( "animals", "baboon" ), 
					imageModule.getPath( "animals", "rat" ), "monsters", "misc"  },
}

-- Randomize the order of our categories table so each time you load this app/game you will get a new order.
--
table.shuffle(categoryData,100)


-- ==
--	touchCallback() - An event listener function to handle target touches.
-- ==
local function touchCallback( self )

	-- If this was a good target, add points to our goodHits counter.
	--
	if( self.goodTarget ) then	
		goodHits = goodHits +1
	end

	-- Calculate the maximum 'good hits' and then update the hits text
	--
	local maxGoodHits = gameLogicModule.getCurRound() * 3
	worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )
				
	-- Some alternative ways of showing how well the player is doing.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )

	-- Alternately, show percentage of total possible hits
	--worldModule.setHitsText( round( 100 * goodHits / maxGoodHits, 0 ) .. "%" )
	--]]
end


-- ==
--	generateTables() - This function generates the data tables that will be used to create targets for this game.
-- ==
local function generateTables( curRound )

	-- 1. Randomly select this round phrase and color image
	-- 
	local phraseNum = 1 + curRound % #categoryData
	local phraseEntry = categoryData[phraseNum]

	timer.performWithDelay( slideInTime + showDelay, 
		function()
			worldModule.setTitleText( phraseEntry[1] )
		end )			

	-- 2. Create blank table to hold 9 target's data tables
	--
	local dataTables = {}

	-- 3. Create three  tables with the target image
	--
	local dataTable = {}
	dataTable.goodTarget = true
	dataTable.imagePath = phraseEntry[2]
	dataTable.callback = touchCallback
	dataTables[#dataTables+1] = dataTable

	local dataTable = {}
	dataTable.goodTarget = true
	dataTable.imagePath = phraseEntry[3]
	dataTable.callback = touchCallback
	dataTables[#dataTables+1] = dataTable

	local dataTable = {}
	dataTable.goodTarget = true
	dataTable.imagePath = phraseEntry[4]
	dataTable.callback = touchCallback
	dataTables[#dataTables+1] = dataTable
		
	-- 4. Create six tables with other images
	--
	local otherSet
	for i = 1, 6 do
		local dataTable = {}
		dataTable.goodTarget = false

		otherSet = phraseEntry[math.random(5,6)]

		-- Randomly select an image till we get one that does not match the phrase associated image
		local otherImagePath = imageModule.randomImagePath(otherSet)
		while( phraseEntry[2] == otherImagePath or
		       phraseEntry[3] == otherImagePath or
			   phraseEntry[4] == otherImagePath ) do
			
			otherImagePath = imageModule.randomImagePath(otherSet)
		end
		dataTable.imagePath = otherImagePath
		dataTable.callback = touchCallback
		dataTables[#dataTables+1] = dataTable
	end

	-- 5. Shuffle the dataTables. i.e. Randomize their order
	--
	table.shuffle(dataTables, 100)

	-- 6. Return our 9 new target data tables
	--
	return dataTables

end

-- ==
--	gameEnded() - This function does cleanup work at the end of the game.
-- ==
local function gameEnded()

	-- 1. Calcualte the maximum good hits and then show how well we did using the title HUD/label.
	--
	local maxGoodHits = gameRounds * 3
	worldModule.setTitleText( goodHits .. " out of " .. maxGoodHits .. "!")
				
	-- Some alternative ways of showing how well the player did.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setTitleText( targetsModule.getGoodHits() .. " out of " .. maxGoodHits )
				
	-- Alternately, show percentage of total possible hits
	--worldModule.setTitleText( round( 100 * targetsModule.getGoodHits() / maxGoodHits, 0 ) .. "%" )
	--]]

	-- 2. Reset the good hits counter
	--
	goodHits = 0
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.generateTables  = generateTables
public.gameEnded       = gameEnded

return public