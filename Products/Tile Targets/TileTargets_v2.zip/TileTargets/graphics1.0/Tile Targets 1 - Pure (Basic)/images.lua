-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- images.lua- A module to handle image selection and randomization.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

-- A list of the different image sets we have
--
local setNames = { "animals", "dinos", "misc", "monsters", "people" }

-- The individual sets and the images they contain
--
local sets = {}

sets.animals = {
"baboon", "bear", "bull", "bunny", "camel", "cat", "cheetah", "cow", 
"dog", "dove", "elephant", "frog", "giraffe", "gorilla", "horse", 
"kangaroo", "kiwi", "lion", "ox", "rat", "tiger", "wolf", "penguin",
}

sets.dinos = {
"apatosaurus", "brontosaurus", "stegosaurus", "trex", "triceratops", 
"velociraptor", 
}

sets.misc = {
"55", "bottle", "breeze", "clock", "delorean", "eye", "reaper", "target", 
}

sets.monsters = {
"mummy", "vampire", "zombie1", "zombie2", "zombie3", 
}

sets.people = {
"disco", "golf", "karate", "lady1", "lady2", "lincoln", "robinhood", 
"santa", "sherlock", "skier", "tennis", 
}


-- ==
--	randomImagePath( [ setName ] ) - Randomly select an image our image sets.
--     If the optiona 'setName' is specified, restrict random selection to that set.
-- ==
local function randomImagePath( setName )
	local setName = setName or  setNames[ math.random(1,#setNames) ]
	
	local theSet = sets[setName]
	
	local imageName = theSet[ math.random(1,#theSet) ]

	local path = "images/" .. setName .. "/" .. imageName .. ".png"

	return path
end

-- ==
--	getPath() - Based on the supplied 'setName' and 'imageName' provide a full path
--     to the correct image file.
-- ==
local function getPath( setName, imageName )
	local path = "images/" .. setName .. "/" .. imageName .. ".png"
	return path
end


----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.randomImagePath  = randomImagePath
public.getPath          = getPath

return public