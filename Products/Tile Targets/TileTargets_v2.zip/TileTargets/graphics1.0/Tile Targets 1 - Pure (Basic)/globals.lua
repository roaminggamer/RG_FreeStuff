-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- globals.lua
-- =============================================================

-- Useful design sizing and position variables
_G.w = display.contentWidth
_G.h = display.contentHeight
_G.centerX = w/2
_G.centerY = h/2

-- Variables to control sounds
_G.sfxEnabled = false
_G.musicEnabled = false
_G.musicVolume = 0.8
_G.sfxVolume   = 0.5

-- A debug variable used during development to skip the splash screen.
_G.showSplash = true

-- This variable controls how many rounds each mini-game plays
_G.gameRounds     = 3

-- Variables to control the sizing and scaling of our 'targets'
--
_G.minScale		= 0.001
_G.maxScale		= 1
_G.targetWidth	= 80
_G.targetHeight	= 90
_G.edgeWidth	= 2
_G.baseWidth	= 6
_G.baseHeight	= 15

-- Variables to control the speed at which the game plays
--
-- Tip: This is implemented w/ a function to allow us to adjust the speed
--     mid-game.
--
--
_G.speed              = 0.85           -- Higher == faster; Lower = slower
function _G.computeSpeeds()
	_G.slideInTime    = 1000/speed  -- Time it takes a target row to slide on screen.
	_G.showDelay      = 500/speed   -- Time to delay before showing (flipping) middle.
	_G.visibleTime    = 6000/speed  -- Duration middle remain visible for.
	_G.slideOutDelay  = 500/speed   -- Time to delay before sliding out
	_G.slideOutTime   = 1000/speed  -- Time it takes a target row to slide off screen.
	_G.tweenRoundTime = 1000/speed
	_G.totalTime      = slideInTime + 
						showDelay +
						visibleTime +
						slideOutDelay +
						slideOutTime +
						tweenRoundTime
	_G.spinTime       = 500/speed -- Normal hide/show speed
	_G.spinTime2      = 250/speed -- Target Spinning hide/show speed
end
computeSpeeds()