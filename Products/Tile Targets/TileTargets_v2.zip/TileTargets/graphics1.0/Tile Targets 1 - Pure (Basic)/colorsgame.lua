-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- colorsGame.lua- A color matching game.
--
-- This code implements the logic for a simple color matching game.
-- Each round, a random color is selected and three of the nine targets
-- will have that color.  Clicking the right colored targets gains points
-- for that round.
--
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

-- A local counter for the number of good hits this round
local goodHits = 0

-- ==
--	touchCallback() - An event listener function to handle target touches.
-- ==
local function touchCallback( self )

	-- If this was a good target, add points to our goodHits counter.
	if( self.goodTarget ) then	
		goodHits = goodHits + 1
	end

	-- Calculate the maximum 'good hits' and then update the hits text
	--
	local maxGoodHits = gameLogicModule.getCurRound() * 3
	worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )

	-- Some alternative ways of showing how well the player is doing.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )

	-- Alternately, show percentage of total possible hits
	--worldModule.setHitsText( round( 100 * goodHits / maxGoodHits, 0 ) .. "%" )
	--]]
end


-- ==
--	generateTables() - This function generates the data tables that will be used to create targets for this game.
-- ==
local function generateTables()

	-- 1. Randomly select this round's color
	-- 
	local colorName = colorModule.randomColorName()

	timer.performWithDelay( slideInTime + showDelay, 
		function()
			worldModule.setTitleText( colorName .. "!" )
		end )			

	-- 2. Create blank table to hold 9 target's data tables
	--
	local dataTables = {}

	-- 3. Create three tables with the target color
	--
	for i = 1, 3 do
		local dataTable = {}
		dataTable.goodTarget = true
		dataTable.color = colorModule.getColorCode(colorName)
		dataTable.callback = touchCallback
		dataTables[#dataTables+1] = dataTable
	end

	-- 4. Create six tables with other colors
	--
	for i = 1, 6 do
		local dataTable = {}
		dataTable.goodTarget = false

		-- Randomly select a color till we get a color other than the current one
		local otherColorName = colorModule.randomOtherColorName( colorName )
		dataTable.color = colorModule.getColorCode(otherColorName)
		dataTable.callback = touchCallback
		dataTables[#dataTables+1] = dataTable
	end

	-- 5. Shuffle the dataTables. i.e. Randomize their order
	--
	table.shuffle(dataTables, 100)

	-- 6. Return our 9 new target data tables
	--
	return dataTables

end

-- ==
--	gameEnded() - This function does cleanup work at the end of the game.
-- ==
local function gameEnded()

	-- 1. Calcualte the maximum good hits and then show how well we did using the title HUD/label.
	--
	local maxGoodHits = gameRounds * 3
	worldModule.setTitleText( goodHits .. " out of " .. maxGoodHits .. "!")

	-- Some alternative ways of showing how well the player did.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setTitleText( targetsModule.getGoodHits() .. " out of " .. maxGoodHits )
				
	-- Alternately, show percentage of total possible hits
	--worldModule.setTitleText( round( 100 * targetsModule.getGoodHits() / maxGoodHits, 0 ) .. "%" )
	--]]

	-- 2. Reset the good hits counter
	--
	goodHits = 0
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.generateTables  = generateTables
public.gameEnded       = gameEnded

return public