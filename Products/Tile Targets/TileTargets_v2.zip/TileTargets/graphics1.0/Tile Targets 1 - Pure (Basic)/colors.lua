-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- colors.lua- A simple module to handle color selection and randomization.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

-- A basic table of color codes indexed by strings.
--
local colorsTable = {}
colorsTable["RED"]    = {255,   0,   0, 255}
colorsTable["GREEN"]  = {0,   255,   0, 255}
colorsTable["BLUE"]   = {0,   0,   255, 255}
colorsTable["YELLOW"] = {0xff, 0xff,    0, 255}
colorsTable["ORANGE"] = {0xff, 0x99,    0, 255}
colorsTable["PURPLE"] = {0xa0, 0x20, 0xf0, 255}
colorsTable["PINK"]   = {0xf5, 0x28, 0x87, 255}
colorsTable["WHITE"]  = {255, 255, 255, 255}
colorsTable["BLACK"]  = {0, 0, 0, 255}

-- Using a the Lua pairs() iterator, create a table containing just the indexes from colorsTable.
-- 
-- Tip: This code never needs to be updated.  Simply add and remove entries from colorsTable and 
-- code below will build a list of the indexes for you.
--
local colorNames = {}
for k,v in pairs(colorsTable) do
	colorNames[#colorNames+1] = k
end

-- This variable is used locally to track the last color we 'randomly' selected.
-- It is used to keep us from selecting the same random color in adjacent requests.
--
local lastColor = "BLACK" 

-- ==
--	randomColorName() - Returns a randomly selected color name (index).
-- ==
local function randomColorName( )
	local colorName = colorNames[math.random(1, #colorNames)]
	while(lastColor == colorName) do
		colorName = colorNames[math.random(1, #colorNames)]
	end
	lastColor = colorName
	return colorName
end

-- ==
--	randomColorCode() - Returns a randomly selected color code (table of color values).
-- ==
local function randomColorCode( )
	local colorName = colorNames[math.random(1, #colorNames)]
	while(lastColor == colorName) do
		colorName = colorNames[math.random(1, #colorNames)]
	end
	lastColor = colorName
	return colorsTable[colorName]
end

-- ==
--	randomOtherColorName( color ) - Returns a randomly selected color name (index) that is not 
--     the same as 'color'.
-- ==
local function randomOtherColorName( color )
	local color = color or "BLACK"
	local colorName = colorNames[math.random(1, #colorNames)]
	while(color == colorName) do
		colorName = colorNames[math.random(1, #colorNames)]
	end
	return colorName
end

-- ==
--	getColorCode() - Converts a string (index) into a color code.
-- ==
local function getColorCode( color )
	local color = color or "BLACK"
	return colorsTable[color]
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.randomColorName      = randomColorName
public.randomColorCode      = randomColorCode
public.randomOtherColorName = randomOtherColorName
public.getColorCode         = getColorCode

return public