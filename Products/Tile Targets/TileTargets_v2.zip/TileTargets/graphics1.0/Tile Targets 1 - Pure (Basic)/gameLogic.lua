-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- gameLogic.lua- A module containing the game logic for this game.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------
-- Variables
local curRound = 0

-- Function Pre-declarations
local splashScreen
local mainMenu
local prepGame
local runGame
local sweep1
local sweep2

-- ==
--	runGame() - This is the master function to run all games.
--     It simply loops on itself round after round and calls the current game module
--     to fill in targets and to supply the logic for scoring.
-- ==
runGame = function ( layer, curGameModule, rounds, totalRounds )

	-- 1. Are ther any more rounds?  If not, call the 'gameEnded()' function
	-- on the current module and then show the main menu after a short delay.
	--
	if( rounds <= 0 ) then
		curGameModule.gameEnded()
		timer.performWithDelay( slideInTime + showDelay, function() mainMenu( layer ) end )
		return
	end

	-- 2. Calculate total rounds and current round.
	--
	-- Tip: When runGame() is called from the main menu, no value is passed for totalRounds.
	-- Instead, in the code below, we snag the initial value for total rounds from the 'rounds' 
	-- variable.  Make sense?
	--
	local totalRounds = totalRounds or rounds
	curRound = totalRounds - rounds + 1

	-- 3. Update the current round HUD/indicator.
	--
	timer.performWithDelay( slideInTime + showDelay, 
		function()
			worldModule.setRoundText( "Round " .. curRound .. " of " .. totalRounds )
		end )
	
	-- 4. If the current round is a multiple of 2, sweep the targets in using this pattern:
	-- row 1 - Sweep from right
	-- row 2 - Swqeep from left
	-- row 3 - Sweep from right
	--
	-- Otherwise, use the opposite pattern, and alternate every other round.
	--
	if(curRound % 2 == 0) then
		sweep1( layer, curGameModule )
	else
		sweep2( layer, curGameModule )
	end

	-- 5. Wait for the total time allocated for a round, then call runGame() again, but this
	-- time pass in a new 'rounds' value and pass in the totalRounds count.
	--
	-- See globals.lua for 'totalTime' and how it is calculated.
	--
	timer.performWithDelay( totalTime, function() runGame(  layer, curGameModule, rounds - 1, totalRounds) end )
end

-- ==
--	mainMenu() - This function uses the same logic as the runGame() code but instead displays a main menu.
-- ==
mainMenu = function ( layer )

	-- 1. Pre-declare varibles to hold the rows.
	--
	-- Tip: By doing this, we can write functions that reference the rows before we've created them.
    --      We need to do this, because when we create the rows, we pass in references to the functions.
	--      In otherwords, we've got a circular dependency.  The functions need to reference the rows,
	--      but the rows need to know about the functions before being created.
	--
	--  Read the code carefully and you will see how this relationship works.
	--
	local row1
	local row2
	local row3

	-- 2. Implement functions to handle clicks on the different 'targets'/buttons.
	--

	-- This function is used for clicks on the 'Colors' game target/button.
	local function onColors( self )
		-- Clear the different HUDS/labels.
		--
		worldModule.setTitleText("")
		worldModule.setHitsText("")
		worldModule.setRoundText("")

		-- Move the main menu rows off the screen and destroy them.
		--
		transition.to( row1, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row2, { x = centerX - w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row3, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )

		-- Wait for the main menu rows to slide off screen and start the game.
		--
		timer.performWithDelay( slideOutTime, 
			function()
				runGame( layer, colorsGameModule, gameRounds )
			end )
	end

	-- This function is used for clicks on the 'Phrases' game target/button.
	local function onPhrases( self )
		-- Clear the different HUDS/labels.
		--		
		worldModule.setTitleText("")
		worldModule.setHitsText("")
		worldModule.setRoundText("")

		-- Move the main menu rows off the screen and destroy them.
		--
		transition.to( row1, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row2, { x = centerX - w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row3, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )

		-- Wait for the main menu rows to slide off screen and start the game.
		--
		timer.performWithDelay( slideOutTime, 
			function()
				runGame( layer, phrasesGameModule, gameRounds )
			end )
	end

	-- This function is used for clicks on the 'Just...' game target/button.
	local function onJust( self )
		-- Clear the different HUDS/labels.
		--
		worldModule.setTitleText("")
		worldModule.setHitsText("")
		worldModule.setRoundText("")

		-- Move the main menu rows off the screen and destroy them.
		--
		transition.to( row1, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row2, { x = centerX - w, time = slideOutTime, onComplete=removeSelf } )
		transition.to( row3, { x = centerX + w, time = slideOutTime, onComplete=removeSelf } )
	
		-- Wait for the main menu rows to slide off screen and start the game.
		--
		timer.performWithDelay( slideOutTime, 
			function()
				runGame( layer, justGameModule, gameRounds )
			end )
	end

	-- This function is used for clicks on the 'Music On/Off' target/button.
	local function onMusic( self )
		
		-- Toggle music on/off based on the value of the target/button text.
		--
		if(self.content.text == "Music\n   On") then
			self.content.text = "Music\n   Off"
			soundModule.stopMusic()
			musicEnabled = false
		else
			self.content.text = "Music\n   On"
			musicEnabled = true
			soundModule.playMusic()
		end
	end

	-- This function is used for clicks on the 'Sound On/Off' target/button.
	local function onSound( self )

		-- Toggle sound on/off based on the value of the target/button text.
		--	
		if(self.content.text == "Sound\n   On") then
			self.content.text = "Sound\n   Off"
			sfxEnabled = false
		else
			self.content.text = "Sound\n   On"
			sfxEnabled = true
			soundModule.playEffect("boop")
		end
	end

	-- The following two functions load a web page if the respective target/button is clicked.
	--
	local function onPlayGames( self )
		print("Play Games")
		system.openURL( "http://roaminggamer.com/games")
	end
	local function onMakeGames( self )
		print("Make Games")
		system.openURL( "http://roaminggamer.com/makegames" )
	end

	-- 3. Define the data tables for the targets on each row of our main menu
	--
	-- See targets.lua for details on these tables.
	--	
	local dataTables = {}
	dataTables[1] = { text = "Colors", fontSize = 20, callback = onColors, isButton = true }
	dataTables[2] = { text = "Phrases", fontSize = 20, callback = onPhrases, isButton = true }
	dataTables[3] = { text = "Just...", fontSize = 20, callback = onJust, isButton = true }

	if( musicEnabled ) then
		dataTables[4] = { text = "Music\n   On", fontSize = 20, callback = onMusic, isButton = true }
	else
		dataTables[4] = { text = "Music\n   Off", fontSize = 20, callback = onMusic, isButton = true }
	end
	
	dataTables[5] = { isButton = true }

	if( sfxEnabled ) then
		dataTables[6] = { text = "Sound\n   On", fontSize = 20, callback = onSound, isButton = true }
	else
		dataTables[6] = { text = "Sound\n   Off", fontSize = 20, callback = onSound, isButton = true }
	end
	dataTables[7] = { isButton = true }
	dataTables[8] = { text = "  Play\nGames", fontSize = 20, callback = onPlayGames, isButton = true }
	dataTables[9] = { text = "  Make\nGames", fontSize = 20, callback = onMakeGames, isButton = true }

	-- 4. Create the three rows (always use the same slide in directions).
	--
	row1 = targetsModule.create( layer, 50 + 115 , "right", dataTables[1], dataTables[2], dataTables[3], false )
	row2 = targetsModule.create( layer, 50 + 115 + 1 * 125 , "left", dataTables[4], dataTables[5], dataTables[6], false)
	row3 = targetsModule.create( layer, 50 + 115 + 2 * 125 , "right", dataTables[7], dataTables[8], dataTables[9], false)

	--  5. Wait till the rows slide in and show themselves before updating the HUDS/labels.
	--
	timer.performWithDelay( slideInTime + showDelay, 
		function()
			worldModule.setTitleText("Main Menu")
			worldModule.setHitsText("Tile Targets")
			worldModule.setRoundText("Game Template")
		end )
end

-- ==
--	splashScreen() - This function uses the same logic as the runGame() code but instead displays a splash screen.
-- ==
splashScreen = function ( layer )

	-- 1. Pre-declare varibles to hold the rows.
	--
	-- Not really needed this time, but I did this in case I (or you) later wanted to implement 
	-- more complex code like the main menu above.
	--
	local row1
	local row2
	local row3

	-- 2. Define the data tables for the targets on each row of our splash screen.
	--
	local dataTables = {}
	dataTables[1] = { text = nil, fontSize = 20, isButton = true }
	dataTables[2] = { text = nil, fontSize = 20, isButton = true }
	dataTables[3] = { text = nil, fontSize = 20, isButton = true }
	dataTables[4] = { text = "Tile", fontSize = 20, isButton = true }
	dataTables[5] = { text = nil, fontSize = 20, isButton = true }
	dataTables[6] = { text = "Targets", fontSize = 20, isButton = true }
	dataTables[7] = { text = nil, fontSize = 20, isButton = true }
	dataTables[8] = { text = nil, fontSize = 20, isButton = true }
	dataTables[9] = { text = nil, fontSize = 20, isButton = true }

	-- 3. Create the three rows (always use the same slide in directions).
	--
	row1 = targetsModule.create( layer, 50 + 115 , "right", dataTables[1], dataTables[2], dataTables[3] )
	row2 = targetsModule.create( layer, 50 + 115 + 1 * 125 , "left", dataTables[4], dataTables[5], dataTables[6])
	row3 = targetsModule.create( layer, 50 + 115 + 2 * 125 , "right", dataTables[7], dataTables[8], dataTables[9])

	-- 4. Immediately update the HUDS/labels.
	--
	worldModule.setTitleText("")
	worldModule.setHitsText("A Roaming Gamer")
	worldModule.setRoundText("Game Template")

	-- 5. Wait for one 'game round' equivalent ammount of time, then build the main menu.
	--
	timer.performWithDelay( totalTime, function() mainMenu( layer ) end )
end


-- ==
--	sweep1() - Create three rows and sweep them in right, left, right (rows 1, 2, 3 respectively).
-- ==
sweep1 = function( layer, curGameModule )	
	local dataTables = curGameModule.generateTables( curRound )
	targetsModule.create( layer, 50 + 115 , "right", dataTables[1], dataTables[2], dataTables[3] )
	targetsModule.create( layer, 50 + 115 + 1 * 125 , "left", dataTables[4], dataTables[5], dataTables[6])
	targetsModule.create( layer, 50 + 115 + 2 * 125 , "right", dataTables[7], dataTables[8], dataTables[9])
end

-- ==
--	sweep2() - Create three rows and sweep them in left, right, left (rows 1, 2, 3 respectively).
-- ==
sweep2 = function( layer, curGameModule )
	local dataTables = curGameModule.generateTables( curRound )
	targetsModule.create( layer, 50 + 115 , "left", dataTables[1], dataTables[2], dataTables[3] )
	targetsModule.create( layer, 50 + 115 + 1 * 125 , "right", dataTables[4], dataTables[5], dataTables[6] )
	targetsModule.create( layer, 50 + 115 + 2 * 125 , "left", dataTables[7], dataTables[8], dataTables[9] )
end


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.run          = runGame
public.mainMenu     = mainMenu
public.splashScreen = splashScreen

-- Provide some extra functions on the module to get and set the counters.
--

-- ==
--	getCurRound() - Returns the current round value.
-- ==
public.getCurRound = function()
	return curRound
end

return public