-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- sounds.lua - A module for loading and playing game sounds and music.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

local musicChannel	= -1 -- Assume unavailable
local musicHandle	= -1 -- Assume no handle
local musicFile		= "How it Begins.mp3"

-- Notes:
-- 1. Currently we only have one sound effect "boop".
-- 2. You can easily add more as by duplicating the code for:
--    sfxChannels, sfxHandles, and sfxSoundFiles below.
--
local sfxChannels	= {}
sfxChannels.boop	= -1 -- Assume unavailable

local sfxHandles	= {}
sfxHandles.boop		= -1 -- Assume no handle

local sfxSoundFiles	= {}
sfxSoundFiles.boop	= { "boop1.wav", "boop2.wav", "boop3.wav", "boop4.wav" }
--
-- Tip: Alternately, we could have had a single sound file for "boop" like this:
-- sfxSoundFiles.boop	= "boop1.wav"
--
-- Providing multiple sound files for a single effect, allows the game to randomly
-- select one of those sounds each time the named effect is played.  IMHO , it makes the game
-- a little more 'organic'.
--

-- ******************************************************************************
-- ******************************************************************************
--- *** YOU DO NOT NEED TO EDIT BELOW TO ADD MORE SOUNDS EFFECTS.
--- *** JUST MODIFY THE CODE ABOVE THIS COMMENT.
-- ******************************************************************************
-- ******************************************************************************

-- ==
--	initSound() - Initialize sound settings and load sound files.
-- ==
local function initSound()

	-- Select Music channel gets first dibs
	musicChannel = audio.findFreeChannel() -- Get first free channel


	-- Set the music volume
	--
	if( musicChannel >= 0 ) then
		--print("Setting volume for music on channel ", musicChannel )
		audio.setVolume( musicVolume , {channel = musicChannel} )
	end

	-- Now that we know how many channels are available, lets load the sounds we need
	--
	if( musicChannel >= 0 ) then
		--print("Loading sound file for music" )
		musicHandle = audio.loadStream( "sounds/music/" .. musicFile ) -- Load music as stream to save memory
	end

	-- Load sounds into memory because we need them to play immediately and often
	--
	for name,channelNum in pairs( sfxSoundFiles ) do

		local fileName = sfxSoundFiles[name]

		sfxHandles[name] = {}

		-- Just a single file for this sound effect
		--
		if( type( fileName ) == "string" ) then
			--print("Loading SINGLE sound file ", sfxSoundFiles[name], " for sound effect ", name )
			sfxHandles[name][1] = audio.loadSound( "sounds/sfx/" .. sfxSoundFiles[name] ) 

		-- Multiple files for this sound effect
		--
		else
			for k,v in ipairs( fileName ) do
				--print("Loading MULTI sound file ", v, " for sound effect ", name )
				sfxHandles[name][k] = audio.loadSound( "sounds/sfx/" .. v ) 				
			end
		end
	end
end

----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.init  = initSound

-- Provide some extra functions on the module to get and set the counters.
--
-- ==
--	playEffect() - Plays the named sound effect. (Loops 'loop' times; -1 == loop till stopped)
-- ==
public.playEffect = function( name, loops, specificHandleNum )

	local loops = loops or 0

	-- If sound effects are not enabled, don't play sound effect
	--
	if( not sfxEnabled ) then 
		return  
	end

	audio.setVolume( sfxVolume , {channel = channelNum} )
	
	-- If the channel and handle are valid, play the sound effect
	--
	if( sfxChannels[name] ~= nil and 
	    sfxHandles[name]  ~= nil ) then

		--print("Play Sound Effect:", name)

		local sfxChannel = audio.findFreeChannel( musicChannel + 1 ) -- Get next free channel
		audio.setVolume( sfxVolume , { channel = sfxChannel } )

		local handleNum = 1

		-- Use requested handle num if supplied
		if( specificHandleNum ) then
			handleNum = specificHandleNum
		else
			-- Multiple handles, so select one randomly
			--
			if( #sfxHandles[name] > 1 ) then
				handleNum = math.random( 1, #sfxHandles[name] )
			end
		end

		audio.play( sfxHandles[name][handleNum] , { channel = sfxChannel, loops = loops } )

		--print("Play Sound Effect:", name, handleNum)
	end

end


-- ==
--	playMusic() - Plays the sound track music.
-- ==
public.playMusic = function( )

	-- If music is not enabled, don't play sound track
	--
	if( not musicEnabled ) then 
		return  
	end

	-- If the music channel and handle are valid, then play the sound track
	--
	if( musicHandle ~= nil  and 
	    musicChannel ~= nil and 
		musicChannel >= 0 ) then

		--print("Play Sound Track")
		audio.play( musicHandle , {channel = musicChannel, loops=-1, fadein = 1000} )

	end
end

-- ==
--	stopMusic() - Plays the sound track music.
-- ==
public.stopMusic = function( )
	-- If the music channel and handle are valid, then play the sound track
	--
	if( musicHandle ~= nil  and 
	    musicChannel ~= nil and 
		musicChannel >= 0 ) then
		
		--print("Stop Sound Track")
		audio.stop( musicChannel )

	end
end


return public
