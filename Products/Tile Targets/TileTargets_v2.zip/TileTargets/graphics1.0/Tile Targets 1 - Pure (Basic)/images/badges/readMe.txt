
Corona(R) Badges
----------------

These are from the Corona SDK. Use them as per guidelines (See CoronaLabs.com for more details.)

rg.png
------
This is a badge for Roaming Gamer products.  Feel free to use it to credit Roaming Gamer, LLC. in your game(s) if you use this template, SSKCorona, etc.  

Just be sure it is a hot link back to http://roaminggamer.com/