-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- foreground.lua- A module for creating and destroying the game foreground
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

local titleText
local hitsText
local roundText

-- ==
--	createBar() - Create a single 'bar' on the screen to give the impression that
--    the targets are resting on something.
-- ==
local function createBar( layer, y)
	local tmp
	tmp = display.newRect( layer, 0, 0, w, 20)
	tmp:setFillColor( 64,64,255 )
	tmp:setStrokeColor( 64,64,64 )
	tmp.strokeWidth = 2
	tmp.x = centerX
	tmp.y = y
	return tmp
end

-- ==
--	create() - This function uses createBar() to create three bars on the screen.
--     It also adds the title, hits, and round HUDS/labels.
-- ==
local function create( backLayer, frontLayer )
	local backLayer = backLayer or display.currentStage
	local frontLayer = frontLayer or display.currentStage

	-- 1. Create a simple background
	--
	local g = graphics.newGradient( { 255, 255, 255 }, { 128, 128, 128 }, "down" )
	local rect = display.newRect( backLayer, 0, 0, w, h )
	rect:setFillColor( g ) 
	
	-- 2. Create three bars for the targets to 'slide behind'
	--
	createBar( frontLayer, 50 + 115 )
	createBar( frontLayer, 50 + 115 + 1 * 125)
	createBar( frontLayer, 50 + 115 + 2 * 125)

	-- 3. Create Simple HUDS
	--
	titleText = display.newText( frontLayer, "TITLE TEXT", 0, 0, native.systemFontBold, 24 )
	titleText.x = centerX
	titleText.y = titleText.contentHeight/2 + 10
	titleText:setTextColor( 0 )

	hitsText = display.newText( frontLayer, "PERCENTAGE", 0, 0, native.systemFontBold, 16 )
	hitsText.x = hitsText.contentWidth/2 + 15
	hitsText.y = h - hitsText.contentHeight/2 - 10
	hitsText:setTextColor( 0 )

	roundText = display.newText( frontLayer, "ROUNDS COUNT", 0, 0, native.systemFontBold, 16 )
	roundText.x = w - roundText.contentWidth/2 - 15
	roundText.y = h - roundText.contentHeight/2 - 10
	roundText:setTextColor( 0 )	


	-- 4. Create an overlay to make different screen sizes look nice.
	--
	-- Tip: I am using the magic screen size recipe: http://www.coronalabs.com/blog/2010/11/20/content-scaling-made-easy/
	--
	-- This overlay image hides the edges on devices with different design ratios from 480:320 (3:2)
	--
	--local overlay = display.newImageRect( frontLayer, "images/magicOverlayDebug.png", 570, 380 )
	local overlay = display.newImageRect( frontLayer, "images/magicOverlay.png", 570, 380 )
	overlay.x = centerX
	overlay.y = centerY
	overlay.rotation = 90

end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = create

-- Add some additional functions to the module
--

-- ==
--	setTitleText() - A helper function for setting the title text.
-- ==
public.setTitleText = function (text)
	titleText.text = text
	titleText.x = centerX
end

-- ==
--	setHitsText() - A helper function for setting the hits text.
-- ==
public.setHitsText = function (text)
	hitsText.text = text
	hitsText.x = hitsText.contentWidth/2 + 15
end

-- ==
--	setRoundText() - A helper function for setting the round text.
-- ==
public.setRoundText = function (text)
	roundText.text = text
	roundText.x = w - roundText.contentWidth/2 - 15
end

return public