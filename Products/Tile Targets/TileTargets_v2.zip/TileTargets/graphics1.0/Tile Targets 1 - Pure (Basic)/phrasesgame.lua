-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- phrasesGame.lua- A phrase guessing and word-assocation game.
--
-- This code implements the logic for a simple word-association game.
-- Each round a new 'phrase' is selected for the list at the top of this file.
-- One target will show an image associated with that phrase, and the other
-- eight will randomly be assigned images that do not match the prhase image.
-- Clicking on the one good image gains points for that round.
-- 
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------

-- A local counter for the number of good hits this round
local goodHits = 0

-- Our phrases database/list (add more if you like)
local phraseData = {
	--{ "PHRASE", imageModule.getPath( "misc", "55" ),  },
	{ "I can't drive ...",  imageModule.getPath( "misc", "55" ),         "I can't drive 55." },
	{ "Shooting the ...",   imageModule.getPath( "misc", "breeze" ),     "Shooting the BREEZE." },
	{ "What ... is love?",  imageModule.getPath( "misc", "clock" ),      "What TIME is love?" },
	{ "Got my ... on you.", imageModule.getPath( "misc", "eye" ),        "Got my EYE on you."},
	{ "Don't fear the ...", imageModule.getPath( "misc", "reaper" ),     "Don't fear the REAPER." },
	{ "Stay on ...",        imageModule.getPath( "misc", "target" ),     "Stay on TARGET."  },
	{ "Back to the ...",    imageModule.getPath( "misc", "delorean" ),   "Back to the FUTURE." },
	{ "Off the ...",        imageModule.getPath( "misc", "bottle" ),     "Off the BOTTLE." },
	{ "Strike a ...",       imageModule.getPath( "people", "disco" ),    "Strike a POSE." },
	{ "My dear ...",        imageModule.getPath( "people", "sherlock" ), "My dear WATSON." },
}

-- Randomize the order of our phrase table so each time you load this app/game you will get a new order.
--
table.shuffle(phraseData,100)

-- ==
--	touchCallback() - An event listener function to handle target touches.
-- ==
local function touchCallback( self )

	-- If this was a good target, add points to our goodHits counter.
	-- Also show the completed phrase.
	--
	-- Otherwise show the 'Sorry, wrong answer.' message.
	--
	if( self.goodTarget ) then	
		goodHits = goodHits +1
		local phraseNum = 1 + gameLogicModule.getCurRound() % #phraseData
		worldModule.setTitleText( phraseData[phraseNum][3])
	else
		worldModule.setTitleText( "Sorry, wrong answer.")
	end

	-- Calculate the maximum 'good hits' and then update the hits text
	--
	local maxGoodHits = gameLogicModule.getCurRound() * 1
	worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )

	-- Some alternative ways of showing how well the player is doing.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setHitsText( goodHits .. " out of " .. maxGoodHits )

	-- Alternately, show percentage of total possible hits
	--worldModule.setHitsText( round( 100 * goodHits / maxGoodHits, 0 ) .. "%" )
	--]]
end


-- ==
--	generateTables() - This function generates the data tables that will be used to create targets for this game.
-- ==
local function generateTables( curRound )

	-- 1. Randomly select this round's phrase and image.
	-- 
	local phraseNum = 1+ curRound % #phraseData
	local phraseEntry = phraseData[phraseNum]

	-- 2. Display the hint phrase.
	timer.performWithDelay( slideInTime + showDelay, 
		function()
			worldModule.setTitleText( phraseEntry[1] )
		end )			

	-- 3. Create blank table to hold 9 target's data tables
	--
	local dataTables = {}

	-- 4. Create one tables with the target image
	--
	local dataTable = {}
	dataTable.goodTarget = true
	dataTable.imagePath = phraseEntry[2]
	dataTable.callback = touchCallback
	dataTables[#dataTables+1] = dataTable

	-- 5. Create eight tables with other images
	--
	for i = 1, 8 do
		local dataTable = {}
		dataTable.goodTarget = false

		-- Randomly select an image till we get one that does not match the phrase associated image
		local otherImagePath = imageModule.randomImagePath()
		local imagePath = phraseEntry[2]
		while( imagePath == otherImagePath) do
			otherImagePath = imageModule.randomImagePath()
		end
		dataTable.imagePath = otherImagePath
		dataTable.callback = touchCallback
		dataTables[#dataTables+1] = dataTable
	end

	-- 5. Shuffle the dataTables. i.e. Randomize their order
	--
	table.shuffle(dataTables, 100)

	-- 6. Return our 9 new target data tables
	--
	return dataTables

end


-- ==
--	gameEnded() - This function does cleanup work at the end of the game.
-- ==
local function gameEnded()

	-- 1. Calcualte the maximum good hits and then show how well we did using the title HUD/label.
	--
	local maxGoodHits = gameRounds * 1
	worldModule.setTitleText( goodHits .. " out of " .. maxGoodHits .. "!")
				
	-- Some alternative ways of showing how well the player did.
	--[[
	-- Alternately, show number of hits out of total possible.
	--worldModule.setTitleText( targetsModule.getGoodHits() .. " out of " .. maxGoodHits )
				
	-- Alternately, show percentage of total possible hits
	--worldModule.setTitleText( round( 100 * targetsModule.getGoodHits() / maxGoodHits, 0 ) .. "%" )
	--]]

	-- 2. Reset the good hits counter
	--
	goodHits = 0
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.generateTables  = generateTables
public.gameEnded       = gameEnded

return public