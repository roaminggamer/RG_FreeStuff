-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================
----------------------------------------------------------------------
--	1. Globals - Load first as these are used by most modules.
----------------------------------------------------------------------
require( "globals" )
require( "globalFunctions" )

----------------------------------------------------------------------
--	2. Requires
----------------------------------------------------------------------

-- Core Modules
colorModule         = require( "colors" )
gameLogicModule	    = require( "gameLogic" )
imageModule         = require( "images" )
soundModule         = require( "sounds" )
targetsModule	    = require( "targets" )
worldModule	        = require( "world" )

-- Three Game Rule Modules
colorsGameModule	= require( "colorsgame" )
phrasesGameModule	= require( "phrasesgame" )
justGameModule	    = require( "justgame" )

----------------------------------------------------------------------
--	3. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no")						-- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)	-- Hide that pesky bar

soundModule.init()
soundModule.playMusic()

----------------------------------------------------------------------
-- 4. Local Variables and Functions
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
-- Use display groups to implement a simple rendering layer system.
--
-- Tip 1: Groups created first are lower than groups created after them.
--
local layers =  {}
layers.gameGroup  = display.newGroup()
layers.back       = display.newGroup()
layers.middle     = display.newGroup()
layers.front      = display.newGroup()

-- Tip 2: Group layering order can also be controled by the order they are
--        inserted into a parent group.  As with creation, those groups inserted
--        first are sorted lower than those inserted afterwards.
--
--  Note: I only inserted these layers as children of 'gameGroup' to make it 
--  easy to cleanup.  Now, I can destroy all game display objects that are in
--  any layer by simply calling this code: 
--  > layers.gameGroup:removeSelf()
--  > layers = nil
--
layers.gameGroup:insert(layers.back)
layers.gameGroup:insert(layers.middle)
layers.gameGroup:insert(layers.front)

-- Let's create the 'world' once and the re-use it over an over for all of our different
-- interfaces: Splash, Main Menu, Play GUI.
--
worldModule.create( layers.back, layers.front )
worldModule.setTitleText("")
worldModule.setHitsText("")
worldModule.setRoundText("")

-- Start The Game
--
if( showSplash ) then
	gameLogicModule.splashScreen( layers.middle )	
else
	gameLogicModule.mainMenu( layers.middle )  
end