-------------------------------------------------------------------------------
Starter: Action Pack #1 (SSK2 Co-Product) (Version 2016.001)
-------------------------------------------------------------------------------
**************             REQUIRES SSK2 (lite or PRO)           **************

https://roaminggamer.github.io/RGDocs/pages/SSK2/
-------------------------------------------------------------------------------
Last Updated: 09 DEC 2016
-------------------------------------------------------------------------------
Copyright Roaming Gamer, LLC. 2008-2016 (All Rights Reserved)
-------------------------------------------------------------------------------

DOCUMENTATION
=============
You can find the online documentation for this starter here: https://roaminggamer.github.io/RGDocs/pages/Starters/ActionPack1/

CONTENTS OF THIS PACK
=====================
+ examples\   - Five example games/starters in two formats: Standalone & Framed.
                > Standalone - Basic mechanics of game w/o a composer.* framework.
                > Framed - Standalone + composer.* framework.

+ frame\      - Starter (composer.*) game framework. 
                Includes these scenes/interfaces: Splash, Home, and PlayGUI.

+ template\   - The base game starter from which all examples were derived.

+ credits.txt - List of credits and sources for free assets used in examples/template.

+ license.txt - Licensing rules for this pack.

+ readMe.txt  - This file.


SSK2 CO-PRODUCT?
================
This is an SSK2 co-product.  That means, it requires SSK2 (lite or PRO) to run properly.

See this page to learn more about SSK2:  https://roaminggamer.github.io/RGDocs/pages/SSK2/


SUPPORT
=======
> Please read instructions: https://roaminggamer.github.io/RGDocs/pages/Starters/ActionPack1/help/
> Please do not e-mail me directly.  Use the forums (as outlined on docs page) instead.


WHAT IT "ssk2j.bat"?
====================
I work (primarily on Windows).  To make my life easier, I do not copy ssk2 to my work folders.  I use a junction.

Junctions are (basically) the windows equivalent of a symbolic link.  
(https://www.cyberciti.biz/faq/creating-soft-link-or-symbolic-link/)

You may ignore this file, or you may make your own equivalent on Windows or OS X systems.  
(http://www.howtogeek.com/howto/16226/complete-guide-to-symbolic-links-symlinks-on-windows-or-linux/)


