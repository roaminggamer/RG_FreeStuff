==============================================================================

Roaming Gamer, LLC "Game Template Package" for the game: Gear Jumper

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Tips / FAQ - Miscellaneous tips to help you with changing the template, as
   well as answers to question(s) you might have.

D. Reporting Bugs - How to report bugs with this template.

==============================================================================

A. Short and Sweet License 
==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.
   - use anything in this kit to make game templates, starter kits, or any other
     training and/or educational products.


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.




B. What's in the template package?
==================================

Gear Jumper is a customer requested pseudo-clone of the game: Jump-O-Clock.

The first to versions (Pure and SSK) are mechanics only implementations of mechanics w/ sound and music.  The third
version (Hybrid) combines 'Gear Jumper 1 - Pure' with a modified version of SSKCorona SP game framework.  

Please note, this last version (Hybrid) is for intermediate to advanced users only.  The SSKCorona game framework is
still a bit complicated and a simplified version is on the way. 

The game mechanics in this game are simple and differ slightly from Jump-O-Clock:

- The game world is made up of a background, walls, gears, gems, and the player.
- The game world uses a standard gravity setting of < 0, 9.8>
- Only the player is affected by gravity.
- Tapping the screen makes the player jump.
- Tapping the screen while the player is jumping has no affect. (No air jumping.)
- When the player collides with a gear, it sticks to the gear and aligns itself so the 'feet' point 
  towards the center of the gear.
- Colliding with gems picks up the gems.
- When the player collides with a wall, it bounces off (Jump-O-Clock has wall sliding instead.)
- The camera tracks the player's vertical position and readjusts after the player sticks to a gear.
- Dropping into the red 'pit' at the bottom of the level restarts the game/level.
- Jumping into the green 'trigger' at the top of the level starts a new level.
- During any single level, the player's vertical position and gem count are displayed at the top of the screen.
- The game has a single soundtrack.
- The game has 3 jumping sounds, 3 gem sounds, one lose sound, and one win sound.


In this package you will find three versions of of the game:

* Gear Jumper 1 - Pure (Basic)        
* Gear Jumper 2 - Pure (SSK)          
* Gear Jumper 3 - Hybrid (Interfaces) 
                                                            
													   
C. Tips / FAQ
=============
* Before you modify the SSK version - The SSK version of the game includes a copy of the 
SSK library.  However, it is sure to be out of date.  So, be sure to get the latest version 
here: https://github.com/roaminggamer/SSKCorona


* SSKCorona Wiki - There is a free quick reference to SSKCorona here: https://github.com/roaminggamer/SSKCorona/wiki

* Question: "Where can I go to get more template?" 
    Answer: The Roaming Gamer, LLC website of course: http://roaminggamer.com/
	


D. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please write me here: 

roaminggamer@gmail.com 

Be sure to include this information in your e-mail:

e-mail Title: "Template Bug: Gear Jumper"

e-mail Body:

Tell me these details,
	- What you did, 
	- What you expected to see, and 
	- What happened instead.

Please provide any other details about the bug that seem pertinent.


Thanks,

The Roaming Gamer



