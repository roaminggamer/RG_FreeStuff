Excluding "thrust.wav", I made all of the effect sounds using  the offline version of bFxr:
http://www.bfxr.net/

Feel free to use them as you wish.


