Slider Parts
------------
I modified the slider art from the Corona demos.  Feel free to use in your own games.
I also used http://cooltext.com/ to generate some wide narrow buttons for the track and thumb.


Check Boxes
-----------
I made these and/or generated them using http://cooltext.com/, feel free to use them as you wish.