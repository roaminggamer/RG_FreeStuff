I made these, feel free to use them.

Note: I used Genetica to produce these: http://www.spiralgraphics.biz/genetica.htm