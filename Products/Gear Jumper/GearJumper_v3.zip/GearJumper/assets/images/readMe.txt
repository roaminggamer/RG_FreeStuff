
Overlays, Gradients, red/blueBackImage.png
------------------------------------------
I made these, feel free to use them.


Smiley (player.png)
-------------------
I found it on this page: http://s720.beta.photobucket.com/user/erickcore/media/smiley.png.html

There was no statement re: usage.


