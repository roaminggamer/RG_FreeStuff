
Corona(R) Badges
----------------

These are from the Corona SDK. Use them as per guidelines (See CoronaLabs.com for more details.)

rg.png, gametemplates.png, sskcorona.png
----------------------------------------
This is a badge for Roaming Gamer products.  Feel free to use these to credit Roaming Gamer, LLC. in your game(s) if you use this template, SSKCorona, etc.  

Just be sure they hot link back to:
* http://roaminggamer.com/
* http://roaminggamer.com/makegames
* http://roaminggamer.com/sskcorona

