-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- level.lua- A module for creating a single Gear Jumper level.
--
-- The positions of gears and gems are all randomly determined,
-- but because we set the seed (in main.lua) to a fixed value, the 
-- first time the level is built we will always get the same setup.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Localize the global 'wallBlockSize' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from main.lua.  This is a nice debugging technique.
--
local wallBlockSize  = wallBlockSize or 40
local wallColor		 = wallColor or "blue"
local maxRows        = maxRows or 48
local debugTime      = debugTime or maxRows * 500
local mountOffset    =  mountOffset or 6
local gemSize		 = gemSize or 10

local halfBlockSize = wallBlockSize/2

local thePit
local theWinTrigger
local gears = {}
local gems = {}

-- ==
--	onPitCollision() - This function is used with the collision listener for the pit object.
--                     The game ends (with a fail) if the player collides with the pit.
-- ==
function onPitCollision( self, event )

	-- Do our work as soon as the collision occurs.
	--
	if(event.phase == "began") then
		
		-- 1. After a short delay, turn off gravity and hide the player.
		--
		timer.performWithDelay( 1, 
			function()
				physics.setGravity(0,0)
				playerModule.hidePlayer()
			end ) 

		-- 2. In this version of the game, simply wait a bit then end and restart the game.
		--
		timer.performWithDelay( 2000, endGame )
		--timer.performWithDelay( 2010, playGame ) -- OLD BUD_RESPAWN
		timer.performWithDelay( 2010, function() playGame(true) end ) -- NEW BUD_RESPAWN


		-- 3. Play a sound if enabled
		--
		soundsModule.playEffect("lose")
	end

	return true
end

-- ==
--	onWinTriggerCollision() - This function is used with the collision listener for the 
--                            (end-of-level) trigger object.
--                            The game ends (with a win) if the player collides with the pit.
-- ==
function onWinTriggerCollision( self, event )

	-- Do our work as soon as the collision occurs.
	--
	if(event.phase == "began") then
		
		-- 1. After a short delay, turn off gravity and hide the player.
		--
		timer.performWithDelay( 1, 
			function()
				physics.setGravity(0,0)
				playerModule.hidePlayer()
			end ) 
		
		-- 2. In this version of the game, simply wait a bit then end and restart the game.
		--
		timer.performWithDelay( 2000, endGame )
		timer.performWithDelay( 2010, playGame )
	
		-- 3. Play a sound if enabled
		--
		soundsModule.playEffect("win")	
	end

	return true
end


-- ==
--	onGemCollision() - This function is used with the collision listener for the 
--                     gem objects.
-- ==
function onGemCollision( self, event )

	-- Do our work as soon as the collision occurs.
	--
	if(event.phase == "began") then
		
		-- 1. After a short delay, remove the collision listener, remove the gem, and
		-- increment the gem counter.
		--
		timer.performWithDelay( 1, 
			function()
				self:removeEventListener( "collision", self )
				gems[self] = nil
				self:removeSelf()
				playguisModule.addGem()

			end ) 

		-- 2. Play a sound if enabled 
		--
		-- Tip: We have three gem sounds and 5 gem images, so 
		--     we play these sounds per gem image:
		--     gem1.png - gem1.wav
		--     gem2.png - gem2.wav
		--     gem3.png - gem3.wav
		--     gem4.png - gem1.wav
		--     gem5.png - gem2.wav
		--
		-- Algorithm: Sound Num == gemNum % 3 + 1
		--
		soundsModule.playEffect("gem", 0, self.gemNum  % 3 + 1)
	end

	return true
end

-- ==
--	createGem() - This function creates a single gem at the specified position
-- ==
function createGem( layer , x, y, gemNum )

	local layer = layer or display.currentStage -- Default to top display group
	local gemNum = gemNum or 1

	-- 1. Create the gem using a the requested gem image and position
	--
	local gem  = display.newImageRect( layer, "images/gems/" .. gemNum .. ".png", gemSize, gemSize )
	gem.x = x
	gem.y = y
	gem.gemNum = gemNum

	-- 2. Add a body to the gem
	--
	physics.addBody( gem, "static", { isSensor = true, filter = filtersModule.gem } )

	-- 3. Attach the "collision" listener to our new gem
	--
	gem.collision = onGemCollision
	gem:addEventListener( "collision", gem )

	-- 4. Keep track in the gems table (so we can remove all gem "collision" listeners during cleanup.)
	--
	gems[gem] = gem
end

-- ==
--	createLevel() - This function creates a background layer and the walls
--                   has left the screen or not.
-- ==
local hangers -- REPLACE DROP GEARS
-- REPLACE DROP GEARS 1 BEGIN
reHangGears = function() 
	if( hangers == nil ) then return end
	for i = 1, #hangers do
		local hanger= hangers[i]
		local gear = hanger.myGear

		if(gear.mountJoint == nil) then
			gear.x = hanger.x
			gear.y = hanger.y
			gear:setLinearVelocity(0,0)
			gear.mountJoint = physics.newJoint( "pivot", gear, hanger, gear.x, gear.y ) 
		end
	end
end
-- REPLACE DROP GEARS 1 END
function createLevel( layer  )
	hangers = {} -- REPLACE DROP GEARS

	local layer = layer or display.currentStage -- Default to top display group

	-- 1. Create Some 'The Pit'.  Dropping into this ends the game (with a fail).
	--
	thePit = display.newImageRect( layer, "images/pitGradient2.png", w, h/4 )
	thePit.x = centerX
	thePit.y = h - h/8
	thePit.blendMode = "multiply"

	physics.addBody( thePit, "static", { isSensor = true, filter = filtersModule.trigger } )

	thePit.collision = onPitCollision
	thePit:addEventListener( "collision", thePit )

	-- 2. Create random gears up to the top of the level.  
	--
	--    Also place a random number of gems around each gear.
	--
	local x = -halfBlockSize
	local y = h+halfBlockSize

	local gearColumn
	local gearSize
	local gearNum
	local gearSpeed
	local gearDirection
	local gemCount

	local hanger
	local gear
	local joint

	local firstGear = true

	-- 2a. Iterate over the inner 'placer' algorithm twice.
	--
	-- Tip: I did this to make it easy to split the gears where half are on the left and 
	-- half are on the left, every other row.  I don't want to risk gears being too close 
	-- to each other, and this makes it easy to ensure at least one row of separation.
	--
	for i = 1, 2 do
	
		-- Start on the 5th row (just above the 'pit')
		for rows = 5 + i, maxRows, 2 do

			if( i == 1) then
				gearColumn    = pRandModule:randInt( 2, 4 ) -- Don't allow gears in columns next to walls
			else
				gearColumn    = pRandModule:randInt( 5, 7 ) -- Don't allow gears in columns next to walls
			end

			gearSize      = pRandModule:randInt( halfBlockSize*10, wallBlockSize * 11 ) /10

			gearNum       = pRandModule:randInt( 1, 7 ) -- There are 7 gear images, select one randomly
			gearSpeed     = pRandModule:randInt( 3, 8 ) 
			gearDirection = pRandModule:randInt( 0, 1 )
			if(gearDirection == 0) then 
				gearDirection = -1
			end

			if( gearSize == halfBlockSize ) then
				gemCount = pRandModule:randInt( 0, 5 )
			
			elseif( gearSize < wallBlockSize * 0.8 ) then
				gemCount = pRandModule:randInt( 0, 8 )
			
			else
				gemCount = pRandModule:randInt( 0, 10 )
			end

			-- Always place first gear just left of center and use same size and speed
			--
			if( firstGear ) then
				gearColumn = 4.5
				gearSize   = wallBlockSize * 0.75
				gearSpeed  = 5
				
				--BUDMOD firstGear = false
			end

			-- A. Place a hidden gear hanger (the gear is attached to this object)
			hanger = display.newRect( layer, 0,0,10,10)
			hangers[#hangers+1] = hanger -- REPLACE DROP GEARS
		
			if( i == 1 ) then
				hanger.x = x + gearColumn * wallBlockSize - halfBlockSize/2
			else
				hanger.x = x + gearColumn * wallBlockSize + halfBlockSize/2
			end
			
			hanger.y = y - rows * wallBlockSize

			hanger.alpha = 0

			physics.addBody( hanger, "static", { filter = filtersModule.hanger, radius = gearSize/2 } )

			-- B. Place a random gear on the hanger
			gear = display.newImageRect( layer, "images/gears/" .. gearNum .. ".png", gearSize, gearSize)

			gear.x = hanger.x
			gear.y = hanger.y

			physics.addBody( gear, "dynamic", { filter = filtersModule.gear, radius = gearSize/2, density = 1000 } )

			gear.type = "gear"

			-- BUDMOD joint = physics.newJoint( "pivot", gear, hanger, gear.x, gear.y ) -- ORIGINAL
			gear.mountJoint = physics.newJoint( "pivot", gear, hanger, gear.x, gear.y ) -- BUDMOD -- NEW VERSION
			hanger.myGear = gear
			gear.speed = gearSpeed * gearDirection
			gear.radius = gearSize/2


			-- BUDMOD BEGIN 
			local dropGear = math.random( 1, 10 ) --(just for demo purpose; choose your own better method for choosing 'drop' gears )
			if( not firstGear and dropGear > 5 ) then
				gear.blinkState = 1
				gear.blinkTime = 300
				gear.isDropGear = true

				local function onTimer( self ) -- Every 'drop' gear gets its own blinker function
						
					-- Safetey checks (is this a recently deleted object?  If so, exit function early.)
					if( not self.removeSelf ) then return end 
					if( type(self.removeSelf) ~= "function" ) then return end 

					if( self.blinkState == 1 ) then
						self.blinkState = 0
						self:setFillColor( 1, 0, 1 )
						self.xScale = 0.90
						self.yScale = 0.90
						self.alpha = 0.8
					else
						self.blinkState = 1
						self:setFillColor( 1, 1, 1 )
						self.xScale = 1
						self.yScale = 1
						self.alpha = 1
					end

					timer.performWithDelay( self.blinkTime, self )
				end
				gear.timer = onTimer

				local function onCollision( self, event )
					if( self.isDropGear ~= true ) then return end
					if( self.mountJoint == nil ) then return end
					if( event.phase == "began" ) then

						-- Start the blinker as a warning!
						timer.performWithDelay( 0, self )

	-- Start Drop after delay (3000 ms)
	timer.performWithDelay( 3000,
		function()
			self.mountJoint:removeSelf()
			self.mountJoint = nil
			self:removeEventListener( "collision", self )
			timer.performWithDelay( 1000, function() self:addEventListener( "collision", self ) end ) -- REPLACE DROP GEARS
		end )
					end
					return true
				end

				gear.collision = onCollision
				gear:addEventListener( "collision", gear )

				--timer.performWithDelay( 0, gear )  -- Uncomment this line for debugging to see which gears are 'drop' gears
				
			end
			-- BUDMOD END


			-- C. Add an "enterFrame" listener to this gear and have it rotate the gear every frame
			gear.enterFrame = function( self )
				self.rotation = self.rotation + self.speed
				if (self.rotation > 360) then
					self.rotation = self.rotation - 360
				end
				if (self.rotation < 0) then
					self.rotation = self.rotation + 360
				end
			end

			Runtime:addEventListener( "enterFrame", gear )

			gears[#gears+1] = gear

			-- D. Place any gems we need to.
			--
			-- Note: No gems in the last three (3) rows 
			--
			if( maxRows - rows > 3 ) then
				local gemNum = pRandModule:randInt( 1, 5 )
				for j = 1, gemCount do
					local angleIncrement = 360 / gemCount
					local angle = angleIncrement * j + 180
					local gx, gy = mathModule.angle2Vector( angle )
					gx,gy = mathModule.scale( gx, gy, gear.radius + mountOffset )
					gx,gy = mathModule.add( gx, gy, gear.x, gear.y )
					createGem( layer, gx, gy, gemNum)			
				end
			end

			if( firstGear ) then --BUDMOD
				firstGear = false --BUDMOD
			end --BUDMOD

		end
	end

	-- 3. Create Some 'The Win Trigger'.  Jumping into this ends the game (with a win).
	--
	theWinTrigger = display.newImageRect( layer, "images/winGradient.png", w, h/4 )
	theWinTrigger.x = centerX
	theWinTrigger.y = h - maxRows * wallBlockSize + h/8
	theWinTrigger.blendMode = "multiply"

	physics.addBody( theWinTrigger, "static", { isSensor = true, filter = filtersModule.trigger } )

	theWinTrigger.collision = onWinTriggerCollision
	theWinTrigger:addEventListener( "collision", theWinTrigger )


	-- 4. Debug code.
	--
	-- If debug is enabled, move the layer slowly to the top.  This lets us see how it turned out 
	-- without having to play it.
	-- 
	if( debugEn ) then
		transition.to( layer, { y = layer.contentHeight - h, time = debugTime } )
	end
end

-- ==
--	destroyLevel() - Do some local cleanup.
-- ==
local function destroyLevel()

	-- 1. Remove all of the gears' "enterFrame" listeners.
	--
	for i = 1, #gears do
		local gear = gears[i]
		Runtime:removeEventListener( "enterFrame", gear )
	end

	-- 2. Create a blank table to store gears in the next time we build a level.
	--
	gears = {}

	-- 3. Remove all fo the gems' "collision" listeners.
	-- 
	for k,v in pairs(gems) do
		local gem = v
		gem:removeEventListener( "collision", gem )
	end

	-- 4. Create a blank table to store gems in the next time we build a level.
	--
	gems = {}

	-- 5. Remove the "collision" listeners from the pit and win triggers.
	--
	theWinTrigger:removeEventListener( "collision", theWinTrigger )
	thePit:removeEventListener( "collision", thePit )

	-- 6. Clear the local references to the two triggers so they can be garbage collected
	-- after being deleted.
	--
	-- Tip: These are automatically deleted/removed when we destroy the layers in destroyLayers() (found in main.lua),
	-- but if we did not clear these local references they wouldn't get garbage collected.
	--
	theWinTrigger = nil
	thePit = nil

	-- 7. Some debug code.
	--
	-- Uncomment this line and every time the scene is built it will be the same.
	-- This is good for testing, but not so much for making the game interesting.
	--pRandModule:seed(gameSeed)
end


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createLevel
public.destroy = destroyLevel
public.reHangGears = reHangGears

return public