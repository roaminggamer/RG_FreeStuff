-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Globals 
--
-- Tip: Declared before require() calls because these global may 
--      be used to initialize values in the required files.
----------------------------------------------------------------------

-- Helper measurements used all over the place:
--
w       = display.contentWidth		
h       = display.contentHeight
centerX = display.contentWidth/2 
centerY = display.contentHeight/2

-- Globals that can be used to adjust the default
-- settings in the various modules used to make this game
--

-- This variable is used to see the random number generator.
-- By using a seed you will always get the same 'first' sequence.
--
gameSeed			= 4	          -- Used in main.lua and level.lua (optionally)

-- Variables to modify the player visual and interactive settings.
--
playerSize			= 15		  -- Used in player.lua
impulseForce		= 1.5		  -- Used in player.lua

-- This variable controls how far the player and gems will be 'mounted'
-- from the edge of a gear.
mountOffset			= 6			  -- Used in player.lua and level.lua

-- The size of gems
--
gemSize             = 10		  -- Used in level.lua	

-- Size of individual textures used to make the wall
wallBlockSize		= 40		  -- Used in world.lua and level.lua

-- This variable controls the height of the level
-- 12 rows per screen, so 36 rows == 3 screens
--
maxRows             = 36          -- Number of rows in world/level
                                  -- Used in world.lua and level.lua

-- These are actually the color of the 'light' bars on the wall
-- "blue" - Has a white-ish background,
-- "red"  - Has a black-ish background
--
wallColor			= "blue"	  -- Used in world.lua and level.lua
--wallColor			= "red"		  -- Used in world.lua and level.lua

-- These variables control the behavior of the camera algorithm
--
--       cameraTime  - Small values are fast, large values are slow
--       easingStyle - Use whatever transition easing you like: http://docs.coronalabs.com/api/library/easing/index.html
-- maxTransitionTime - Maximum time allowed for transitions. 
--                     (Comes into play when you fall below the screen edge to a gear off-screen.)
--
cameraTime			= 50		  -- Used in camera.lua								  
easingStyle			= easingStyle -- Used in camera.lua
maxTransitionTime   = 1000		  -- Used in camera.lua

-- Enable this feature to see how your level turned out
-- Does not enable the camera or create a player.
-- Only draws level.
--
debugEn				= false       -- Used in world.lua, level.lua, camera.lua                                  

-- This variable controls how fast the scene preview occurs in debug mode
--
debugTime           = maxRows * 350

-- Sound
--
musicEnabled		= true  -- Used in player.lua
musicVolume			= 0.8   -- Used in player.lua 
sfxEnabled			= true  -- Used in player.lua 
sfxVolume			= 0.5   -- Used in player.lua 

----------------------------------------------------------------------
--	2. Requires
----------------------------------------------------------------------
physics = require "physics"

-- The different parts of the game are kept separated as modules for cleaner coding.
--
-- However, notice that we are only loading them once and keeping them 
-- globally visible.  Why?  These modules make calls to other modules
-- and are inter-dependent  (Isn't Lua great!)
--
cameraModule  = require("modules.camera")
filtersModule    = require("modules.filters")
playguisModule   = require("modules.playguis")
playerModule     = require("modules.player")
pRandModule		 = require("modules.portableRandom")
mathModule       = require("modules.math")
levelModule      = require("modules.level")
soundsModule     = require("modules.sounds")
worldModule      = require("modules.world")


----------------------------------------------------------------------
--	3. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no")						-- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)	-- Hide that pesky bar

physics.start()
physics.setGravity(0,0)						    -- Turn 'off' gravity
--physics.setDrawMode("debug")					-- Debug 'debug' draw mode
--physics.setDrawMode("hybrid")					-- Debug 'hybrid' draw mode

-- Initialize the game sounds and start the music (if enabled)
soundsModule.init()
soundsModule.playMusic()

system.activate("multitouch") 


pRandModule:seed(gameSeed)

----------------------------------------------------------------------
-- 4. Local Variables and Functions
----------------------------------------------------------------------
local layers				-- Variable to hold our display/rendering layers

local thePlayer				-- A variable to hold a reference to the player.
							-- Passed to camera module.

-- Some function pre-declarations
--
local createLayers 
local destroyLayers 
local restartTest 

-- ==
--    createLayers() - A function to create and sort the display/rendering layers.
-- ==
createLayers = function()
	layers = display.newGroup()
	layers.background = display.newGroup()	-- Background and Walls
	layers.content     = display.newGroup()	-- Player, Gears, Gems, Triggers
	layers.guis        = display.newGroup()	-- Counters, HUDs, etc.
	--
	-- Tips: 
	--       1. Insert the above groups into our master group for easy removal later.
	--       2. Insertion order controls layering order. 1st is bottom, 2nd above that, etc...
	--
	layers:insert(layers.background) -- Bottom-most layer
	layers:insert(layers.content)	  -- Next layer up ...
	layers:insert(layers.guis)	      -- Top-most Layer
end

-- ==
--    destroyLayers() - A function to destroy and cleanup the display/rendering layers.
-- ==
destroyLayers =  function()
	if(layers) then
		layers:removeSelf()
	end
	layers = nil
end

-- ==
--    playGame() - A function that creates a single game level and starts checking for game over.
--
-- Tip: This has been made global so that it can be called from level.lua
--
-- ==
-- BUD_RESPAWN 1 BEGIN
--
-- Hi! The easiest way to make the game build the same level over and over is to do the following.
--
-- 1. Set the random seed at the beginning of createLevel.
-- 2. Keep track of the seed used.
-- 3. If you are rebuilding a level and you want it the same as the last, tell createLevel() to use the last seed.
--
-- BUD_RESPAWN 1 END

local lastSeed -- BUD_RESPAWN END

--_G.playGame = function ( rebuildLast ) -- OLD BUD_RESPAWN
_G.playGame = function ( rebuildLast ) -- NEW BUD_RESPAWN

	-- BUD_RESPAWN 2 BEGIN

	if( rebuildLast == true and lastSeed ~= nil ) then
	   -- Do nothing, we'll use the seed we have
	else
		-- Set a new seed
		lastSeed = os.time()
	end
	-- Now apply the seed:
	print("\nUsing random seed: " .. lastSeed )
	pRandModule:seed(lastSeed)


	-- BUD_RESPAWN 2 END

	-- Create the rendering layers
	createLayers()

	-- Create the world and other game  objects
	--
	worldModule.create( layers.background)
	levelModule.create( layers.content )

	if( not debugEn	) then
		thePlayer = playerModule.create( layers.content )
		cameraModule.create( thePlayer, layers.background, layers.content )
	end
	playguisModule.create( layers.guis )

	physics.setGravity(0,9.8)						-- Turn 'on' gravity

end

-- ==
--	endGame() - A nice function that destroys all game objects and stops checking for game over.
--
-- Tip: This has been made global so that it can be called from level.lua
--
-- ==
_G.endGame =  function()

	-- Cleanup the world and other game objects	(generally in reverse order)
	--
	playguisModule.destroy()	

	if( not debugEn	) then		
		cameraModule.destroy()
		playerModule.destroy()
		thePlayer = nil
	end

	levelModule.destroy()
	worldModule.destroy()

	-- Remove all rendering layers (and thus all objects)	
	destroyLayers()
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
playGame()

