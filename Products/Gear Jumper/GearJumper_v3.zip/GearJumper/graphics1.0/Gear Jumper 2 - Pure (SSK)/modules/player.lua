-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- player.lua - A module for creating, destroying, and 
--              maintaining the player.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None 

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Localize the global 'playerSize' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from main.lua.  This is a nice debugging technique.
--
local playerSize   = playerSize or 30
local impulseForce = impulseForce or 3
local mountOffset  =  mountOffset or 6

local thePlayer	

local firstMount = true  -- If this is true, mountGear() will initialze the players
                         -- height counter on the first mounting.
                              

-- ==
--	mountToGear() - A function to 'temporarily' mount the player to a gear on preCollision
-- ==
mountToGear = function( player, gear ) 

	-- 1. Move the camera if necessary
	--
	cameraModule.update()

	-- 2. Do some math magic to figure out where the player is relative to the
	--    gear, and to then mount it near that point.
	--
	local tweenX, tweenY = mathModule.sub( gear.x, gear.y, player.x, player.y )
	local angle = mathModule.vector2Angle( tweenX, tweenY )
	
	local mountPointX, mountPointY = mathModule.normalize( tweenX, tweenY )
	mountPointX, mountPointY = mathModule.scale( mountPointX,  mountPointY, gear.radius + mountOffset)
	mountPointX, mountPointY = mathModule.add( gear.x, gear.y, mountPointX, mountPointY )

	player.rotation = angle -- This sets the player rotation to it is facing out from the center of the gear
	player.x = mountPointX
	player.y = mountPointY
	player.joint = physics.newJoint( "weld", player, gear, player.x, player.y )

	-- 3. Clear the isJumping flag so that jumps can occur
	--
	thePlayer.isJumping = false

	-- 4. Is this the first mount?  If so, initialize the player height counter.
	if( firstMount ) then
		firstMount = false
		thePlayer.startY = thePlayer.y
		playguisModule.setFeet(0)
	end

end


-- ==
--	createPlayer() - A 'builder' function to create the player.
-- ==
local function createPlayer( layer  )
	local layer = layer or display.currentStage -- Default to top display group

	-- 1. Create the Display Object w/ body and isJumping flag
	-- 
	--  The flag is used by the jump listener to ignore touches while jumping (in the air)
	--
	thePlayer = ssk.display.imageRect(layer, centerX, centerY, "images/player.png", 
	                                 { size = playerSize, isJumping = false },
									 { isBullet = true, radius = playerSize/2, 
	                                   calculator = filtersModule.myCC, colliderName = "player",
									   density = 1, bounce = 1, friction = 0} )

	
	-- 2. Define a 'private' precollision callback right on the player object, then
	--    attach it to the player.
	function thePlayer:preCollision( event )
		local target  = event.target  -- The player
		local other   = event.other   -- The object it is about to collide with

		-- If this is a gear, remove the precollision listener and mount to the gear,
		-- otherwise ignore it.
		--
		if(other.type == "gear") then
			thePlayer:removeEventListener( "preCollision", thePlayer )
			timer.performWithDelay( 1,  function() mountToGear( target, other ) end )
		end

		return true
	end
	thePlayer:addEventListener( "preCollision", thePlayer )

	-- 5. Define a touch runtime touch listener that will be processed by the player
	--    object.  
	function thePlayer:touch( event ) 

		-- If the player is already jumping, do nothing (no air jumping)
		-- 
		if(thePlayer.isJumping) then  
			return true 
		end

		-- Do our work as soon as the touch starts.
		--
		if(event.phase == "began") then
			
			-- Remove the preCollision listener (temporarily) so it doesn't trigger
			-- as we jump away from the current gear
			-- 
			thePlayer:removeEventListener( "preCollision", thePlayer )

			-- Mark the player as 'jumping'
			--
			thePlayer.isJumping = true
			
			-- Remove the joint before jumping.
			--
			if(self.joint) then
				self.joint:removeSelf()
				self.joint = nil
			end

			-- Attach a generic timer function to apply an impulse in the current player orientation,
			-- and to re-orient the player to 0-degrees
			--
			-- Call it after a very short delay.  We can't do any of this durring the touch event, because
			-- the joint won't 'let go' till the end of this processing cycle.
			--
			self.timer = function() 
				local impulseVecX, impulseVecY = mathModule.angle2Vector( self.rotation, true )
				impulseVecX, impulseVecY = mathModule.scale( impulseVecX, impulseVecY, impulseForce )
				self:applyLinearImpulse( impulseVecX, impulseVecY, self.x, self.y )
				self.rotation = 0

				-- Play a sound if enabled
				--
				soundsModule.playEffect("jump")				

				-- Re-attach the precollision listener now that we've jumped away from the last gear
				--
				self.timer = function()
					self:addEventListener( "preCollision", self )
				end
				timer.performWithDelay( 1, self )

			end
			timer.performWithDelay(1, self)
		end
		return true
	end
	Runtime:addEventListener( "touch", thePlayer )	
	

	-- 6. Return a reference to the player
	--	
	return thePlayer							
end


-- ==
--	destroyPlayer() - Do some local cleanup.
-- ==
local function destroyPlayer()


	Runtime:removeEventListener( "touch", thePlayer )	

	-- 1. We should stop the event listener for "enterFrame"
	--
	Runtime:removeEventListener( "enterFrame", playerMover )

	-- 2. Clear the local variables.
	--
	-- Tip: The player will get removed when you remove the group
	--      it is stored in, but the local reference will still be around.
	--      If you don't clear the local variable too, Lua can't garbage collect,
	--      and you will get a small memory leak.
	--
	--      This function fixes that problem neatly.
	thePlayer = nil


	-- 3. Reset the firstMount flag for the next time we start the game.
	--
	firstMount = true
end


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createPlayer
public.destroy = destroyPlayer

-- Provide some extra functions on the module.
--

-- ==
--	hidePlayer() - Hide the player after a short transition to 0 alpha.
-- ==
public.hidePlayer = function()
	transition.to( thePlayer, { alpha = 0, time = 300 } )
	timer.performWithDelay( 350, function() thePlayer.isVisible = false end )
end

return public