-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- playguis.lua - A module for creating and destroying the play GUI interface.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Localize the global 'wallColor' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from main.lua.  This is a nice debugging technique.
--
local wallColor		 = wallColor or "blue"


-- == Labels & Buttons
local heightCounter
local gemCounter

-- ==
--	createHUDs() - Add some counters to the screen.
-- ==
local function createHUDs( layer )

	local layer = layer or display.currentStage -- Default to top display group

	-- 1. Create an overlay to make different screen sizes look nice.
	--
	-- Tip: I am using the magic screen size recipe: http://www.coronalabs.com/blog/2010/11/20/content-scaling-made-easy/
	--
	-- This overlay image hides the edges on devices with different design ratios from 480:320 (3:2)
	--
	--local overlay = ssk.display.imageRect( layer, centerX, centerY, "images/magicOverlayDebug.png", { w = 570, h = 380, rotation = 90 } )
	local overlay = ssk.display.imageRect( layer, centerX, centerY, "images/magicOverlay.png", { w = 570, h = 380, rotation = 90 } )

	-- 2. Add two images as backgrounds for our height and gems counters
	--
	--
	local width  = 145
	local height = 38
	local heightBack
	heightBack = ssk.display.imageRect( layer, width/2 + 10, height/2  + 5,
	                                    "images/" .. wallColor .. "Back.png", { w = width, h = height } )

	local gemsBack
	gemsBack = ssk.display.imageRect( layer, w - width/2 - 10, height/2  + 5,
	                                    "images/" .. wallColor .. "Back.png", { w = width, h = height } )

	
	-- 3. Create a Feet counter and a Gems counter.
	--
	heightCounter = display.newText( layer, "0 feet", 0, 0, "Harrowprint", 22 )
	heightCounter.x = heightBack.x
	heightCounter.y = heightBack.y

	gemCounter = display.newText( layer, "0 gems", 0, 0, "Harrowprint", 22 )
	gemCounter.x = gemsBack.x
	gemCounter.y = gemsBack.y

	gemCounter.totalGems = 0 -- Store gem count in the counter


	if( wallColor == "blue") then
		heightCounter:setTextColor(255)
		gemCounter:setTextColor(255)
	else
		heightCounter:setTextColor(0)
		gemCounter:setTextColor(0)
	end

end

-- ==
--	destroyHUDs() - Do some local cleanup.
-- ==
local function destroyHUDs()

	-- Tip: The counters will get removed when you remove the group
	--      they are stored in, but the local references will still be around.
	--      If you don't clear the local variables too, Lua can't garbage collect,
	--      and you will get a small memory leak.
	--
	--      This function fixes that problem neatly.
	heightCounter = nil
	gemCounter = nil
end

----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createHUDs
public.destroy = destroyHUDs

-- Provide some extra functions on the module to get and set the counters.
--

-- ==
--	setFeet() - Set Feet counter to 'newFeet'
-- ==
public.setFeet = function( newFeet )
	heightCounter.text = mathModule.round(newFeet/5,1) .. " feet"
end

-- ==
--	addGem() - Add one gem to the gem counter
-- ==
public.addGem = function( )
	gemCounter.totalGems = gemCounter.totalGems + 1
	gemCounter.text = gemCounter.totalGems .. " gems"
end

return public