-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- filters.lua - A module showing how the collision filters are calulated.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

local myCC = ssk.ccmgr:newCalculator()

myCC:addName("player")
myCC:addName("wall")
myCC:addName("gear")
myCC:addName("gear hanger")
myCC:addName("gem")
myCC:addName("trigger")

myCC:collidesWith( "player", "wall", "gear", "gem", "trigger" ) -- Player collides with wall, gear, gem, and trigger

-- Tip: The calculator is smart enough to automatically configure reciprocal collisions.
--
-- i.e. We don't need to do this too:
--
-- myCC:collidesWith( "wall", "player" )
-- myCC:collidesWith( "gear", "player" )
-- myCC:collidesWith( "gem", "player" )
-- myCC:collidesWith( "trigger", "player" )
--
-- The above calls are implied.
--

myCC:dump()  -- This prints the collision setting to the screen 
             -- Notice that they match our calculated values!


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Finally, attach them to our module
--
public.myCC =  myCC

return public
