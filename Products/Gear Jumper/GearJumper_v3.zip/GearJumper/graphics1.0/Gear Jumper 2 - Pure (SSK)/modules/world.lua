-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- world.lua- A module for creating, destroying, the background and walls.  (This is a simple world.)
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Localize the global 'wallBlockSize' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from main.lua.  This is a nice debugging technique.
--
local wallBlockSize  = wallBlockSize or 40
local wallColor		 = wallColor or "blue"
local maxRows        = maxRows or 48
local debugTime      = debugTime or maxRows * 500

local halfBlockSize = wallBlockSize/2

-- I predefined 12 rows that can be used over and over to create unique backgrounds.
--
local wallPattern = {}
wallPattern[12] = { "24", "44", "44", "44", "14", "44", "44", "44" }
wallPattern[11] = { "44", "11", "31", "41", "44", "11", "31", "41" }
wallPattern[10] = { "44", "12", "43", "13", "33", "43", "42", "44" }
wallPattern[9]  = { "12", "22", "22", "22", "22", "22", "22", "42" }
wallPattern[8]  = { "44", "24", "44", "11", "13", "32", "33", "41" }
wallPattern[7]  = { "11", "13", "32", "33", "41", "44", "14", "44" }
wallPattern[6]  = { "44", "44", "34", "44", "44", "34", "44", "44" }
wallPattern[5]  = { "14", "44", "11", "31", "31", "41", "44", "14" }
wallPattern[4]  = { "44", "12", "33", "43", "43", "13", "42", "44" }
wallPattern[3]  = { "12", "32", "32", "32", "32", "32", "32", "42" }
wallPattern[2]  = { "34", "44", "24", "44", "44", "24", "44", "34" }
wallPattern[1]  = { "11", "21", "21", "21", "21", "21", "21", "41" }


-- ==
--	createWorld() - This function creates a background layer and the walls
--                   has left the screen or not.
-- ==
function createWorld( layer  )

	local layer = layer or display.currentStage -- Default to top display group

	-- 1. Create background 
	--
	local tmp
	local x = -halfBlockSize
	local y = h+halfBlockSize
	local blockNum 
	
	for rows = 1, maxRows do	

		--local randomRow = 12 - (rows % 12)
		local randomRow = pRandModule:randInt(1,12)
		
		for cols = 1, 8 do
			blockNum = wallPattern[randomRow][cols]
			tmp = ssk.display.imageRect( layer, x + cols * wallBlockSize, y - rows * wallBlockSize,
							 			 "images/walls/" .. wallColor .. "/strip_" .. blockNum .. ".png", 
										 { size = wallBlockSize } )
		end
	end

	-- 2. Create walls with bodies and add a 'type' field for use in the 
	--    player preCollision listener.
	--
	local tmp
	local y = h+halfBlockSize

	-- Tip: Notice the use of custom shapes for the walls.
	-- Turn on "hybrid" or "debug" rendering in main.lua to see these shapes.
	-- 
	local leftRect = { -halfBlockSize,   -halfBlockSize, 
	                    -halfBlockSize + wallBlockSize/8, -halfBlockSize, 
						-halfBlockSize + wallBlockSize/8, halfBlockSize, 
						-halfBlockSize,  halfBlockSize }
	
	local rightRect = {  halfBlockSize - wallBlockSize/8,   -halfBlockSize, 
	                    halfBlockSize, -halfBlockSize, 
						halfBlockSize, halfBlockSize, 
						halfBlockSize - wallBlockSize/8,  halfBlockSize }
	for rows = 1, maxRows do
		-- Left Edge
		tmp = ssk.display.imageRect( layer, halfBlockSize, y - rows * wallBlockSize, 
		                             "images/walls/" .. wallColor .. "/left.png", 
									{ size = wallBlockSize, type = "wall" },
									{ bodyType = "static", shape = leftRect,
									  calculator = filtersModule.myCC, colliderName = "wall" } )

		-- Right Edge
		tmp = ssk.display.imageRect( layer, w-halfBlockSize, y - rows * wallBlockSize, 
		                             "images/walls/" .. wallColor .. "/right.png", 
									{ size = wallBlockSize, type = "wall" },
									{ bodyType = "static", shape = rightRect,
									  calculator = filtersModule.myCC, colliderName = "wall" } )
	end

	-- 3. Debug code.
	--
	-- If debug is enabled, move the layer slowly to the top.  This lets us see how it turned out 
	-- without having to play it.
	-- 
	if( debugEn ) then
		transition.to( layer, { y = layer.contentHeight - h, time = debugTime } )
	end

end

-- ==
--	destroyWorld() - Do some local cleanup.
-- ==
local function destroyWorld()

		-- Nothing special needs to be done, but lets keep this in case we need it in more 
		-- advanced designs.
end



----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createWorld
public.destroy = destroyWorld

return public