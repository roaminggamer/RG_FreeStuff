-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- math.lua - A module containing math functions you will need
--            for this game.
-- =============================================================

-- Note: Not all of these functions will be used in the game, but
-- I didn't see any reason to remove them.  They are all useful.

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Tip: Localize math library functions to make them run faster!
--
local mRad   = math.rad
local mCos   = math.cos
local mSin   = math.sin
local mPi    = math.pi
local mCeil  = math.ceil
local mAtan2 = math.atan2
local mSqrt  = math.sqrt

-- ==
--    sub() - A helper function to subtract vector 1 from vector 2
-- ==
local function sub( x1, y1, x2, y2 )
	return x2-x1, y2-y1
end

-- ==
--    add() - A helper function to add vector 1 to vector 2
-- ==
local function add( x1, y1, x2, y2 )
	return x1+x2, y1+y2
end

-- ==
--    normalize() - A helper function to convert a vector to a unit-vector (length 1).
-- ==
local function normalize( x, y )
	local len = mSqrt( x * x + y * y )
	return x/len, y/len
end

-- ==
--    scale() - A helper function to modify the length of a vector by 'scale'.
-- ==
local function scale( x, y, scale )
	return x*scale, y*scale
end


-- ==
--    angle2Vector() - A helper function to convert a screen angle into a unit-length (1-pixel) screen vector.
-- ==
local function angle2Vector( angle )
	local screenAngle = mRad(-(angle+90))
	local x = mCos(screenAngle) 
	local y = mSin(screenAngle) 
	return -x,y
end

-- ==
--    vector2Angle() - A helper function to convert a screen angle into a unit-length (1-pixel) screen vector.
-- ==
local function vector2Angle( x, y )
	local angle
	angle = mCeil(mAtan2( y, x ) * 180 / mPi) + 90
	return angle
end

-- ==
--    scaleVector() - A helper function to change the length of a vector
-- ==
local function scaleVector( scale, x, y )
	return scale * x, scale * y
end

-- ==
--	pointInRect() - A helper function to see if an <x,y> point is inside the 
--	bounds of a rectangle.  Returns true if the point is in the specified rectangle, 
--  false otherwise.
-- ==
local function pointInRect( pointX, pointY, left, top, width, height )
	if( pointX >= left          and 
	    pointX <= left + width  and 
	    pointY >= top           and 
		pointY <= top + height ) then 
	   
	   return true
	
	else	
		return false	
	end
end

-- ==
--    round(val, n) - Rounds a number to the nearest decimal places. (http://lua-users.org/wiki/FormattingNumbers)
--    val - The value to round.
--    n - Number of decimal places to round to.
-- ==
function round(val, n)
  if (n) then
    return math.floor( (val * 10^n) + 0.5) / (10^n)
  else
    return math.floor(val+0.5)
  end
end


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.add          = add
public.sub          = sub
public.scale        = scale
public.normalize    = normalize
public.angle2Vector = angle2Vector
public.vector2Angle = vector2Angle
public.scaleVector  = scaleVector
public.pointInRect  = pointInRect
public.round = round

return public
