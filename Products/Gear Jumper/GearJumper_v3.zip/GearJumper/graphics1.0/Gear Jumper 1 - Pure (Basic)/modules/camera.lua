-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- camera.lua - A module for creating a simple camera that keeps the
-- player in same vertical position (based on initial placement).
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None 

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- Localize the global 'playerSize' and give it a default value if it isn't found
-- Tip: Doing this ensures you have a value, but allows you to control the value 
-- from main.lua.  This is a nice debugging technique.
--
local playerSize        = playerSize or 30
local impulseForce      = impulseForce or 3
local cameraTime        = cameraTime or 20
local easingStyle       = easingStyle or easing.inOutQuad
local maxTransitionTime = maxTransitionTime or 1000

local thePlayer	
local theBackground
local theContent

local cameraTracker -- Pre-declaration of cameraTracker() function
local cameraUpdate  -- Pre-declaration of cameraUpdate() function

-- ==
--	createCamera() - A 'builder' function to create the player's ship.
-- ==
local function createCamera( player, background, content )

	-- 1. Start tracking the player, backround, and content in local variables
	-- 
	thePlayer		= player
	theBackground	= background
	theContent		= content

	-- 2. Initialize player's last y-position
	--
	player.lastY = player.y

	-- 3. Create an initialize 'newY' fields on background and content layers
	--
	background.newY = 0
	content.newY = 0

	-- 4. Start a Runtime "enterFrame" listener to handle camera updates
	--
	Runtime:addEventListener( "enterFrame", cameraTracker )

end

-- ==
--	destroyCamera() - Do some local cleanup.
-- ==
local function destroyCamera()

	-- 1. Stop the Runtime "enterFrame" listener
	--
	Runtime:removeEventListener( "enterFrame", cameraTracker )

	-- 2. Stop tracking the player, backround, and content in local variables
	-- 
	thePlayer		= nil
	theBackground	= nil
	theContent		= nil
end


-- ==
--	cameraTracker() - This function is used to track the player's movement and calculate the
--                    correct placement of the camera.  The basic algorithm works like this:
--
--  While the player is jumping (i.e. not mounted to a gear)...
---
--  A. Calculate the player object's delta (change in position) from the last frame.
--  B. Subtract the delta from the background and content layer's current y-positions.
--     This value is maintained in a new variable (on each object) called 'newY'.
--
--  Later, when the player is mounted to a gear (i.e. the jump comes to an end) ...
--
--  C. Apply the delta (see cameraUpdate function below).
-- ==
cameraTracker = function( self )

	-- 1. Do nothing if the player, background, or content objects are not available.
	if( not thePlayer or not theBackground or not theContent  ) then
		return true
	end

	-- 2. Only do updates while the player is in the air (i.e. is jumping)
	--
	if( not thePlayer.isJumping ) then
		return true
	end
	
	-- 2. If the player (thePlayer) has moved, calculate a delta (step A from above)
	--
	local delta = thePlayer.y - thePlayer.lastY

	-- 3. Record new last y-position
	--
	thePlayer.lastY = thePlayer.y

	-- 4. Update the position of the background and content layers
	--
	if( not theContent.newY ) then
		theContent.newY = theContent.y - delta
	else
		theContent.newY = theContent.newY - delta
	end

	if( not theBackground.newY ) then
		theBackground.newY = theBackground.y - delta
	else
		theBackground.newY = theBackground.newY - delta
	end

	-- 5. Update the 'feet counter'
	--
	if( thePlayer and thePlayer.startY ) then
		playguisModule.setFeet( -1 * (thePlayer.y - thePlayer.startY))
	end

	return true
end

-- ==
--	cameraUpdate() - This function applys the accumulated camera movement deltas.
-- ==
cameraUpdate = function ( )

	-- 1. Calculate the time it will take to move the 'camera'
	-- 
	local transitionTime = cameraTime * math.abs( theContent.y - theContent.newY )
	
	-- 2. Don't allow transitions to take longer than
	if( transitionTime > maxTransitionTime) then 
		transitionTime = maxTransitionTime
	end
	
	-- 3. Cancel any oustanding transitions (just in case)
	--
	if(theContent.lastTransition) then 
		transition.cancel(theContent.lastTransition)
	end
	if(theBackground.lastTransition) then 
		transition.cancel(theBackground.lastTransition)
	end 

	-- 4. Move the background and content layers
	--
	theContent.lastTransition = transition.to( theContent, { y = theContent.newY, time = transitionTime,  transition=easingStyle } )
	theBackground.lastTransition = transition.to( theBackground, { y = theBackground.newY, time = transitionTime,  transition=easingStyle } )

end


----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.create  = createCamera
public.destroy = destroyCamera
public.update  = cameraUpdate

return public