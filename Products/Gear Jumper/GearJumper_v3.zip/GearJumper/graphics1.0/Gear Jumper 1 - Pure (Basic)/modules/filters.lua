-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- filters.lua - A module showing how the collision filters are calulated.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

-- The following collision filters were calulated by hand using the technique
-- outlined here: http://developer.coronalabs.com/forum/2010/10/25/collision-filters-helper-chart 
--
-- The chart for this game looks like this:
--
--                        | 1 | 2 | 4 | 8 | 16 | 32 | sum
--  ---------------------------------------------------------------------
--  player          catg. | X |   |   |   |    |    | 1  (categoryBits)
--                  cl.w/ |   | X | X |   | X  | X  | 54 (maskBits)
--  ---------------------------------------------------------------------
--  wall            catg. |   | X |   |   |    |    | 2  (categoryBits)
--                  cl.w/ | X |   |   |   |    |    | 1  (maskBits)
--  ---------------------------------------------------------------------
--  gear            catg. |   |   | X |   |    |    | 4  (categoryBits)
--                  cl.w/ | X |   |   |   |    |    | 1  (maskBits)
--  ---------------------------------------------------------------------
--  gearhanger      catg. |   |   |   | X |    |    | 8  (categoryBits)
--                  cl.w/ |   |   |   |   |    |    | 0  (maskBits)
--  ---------------------------------------------------------------------
--  gem             catg. |   |   |   |   | X  |    | 16 (categoryBits)
--                  cl.w/ | 1 |   |   |   |    |    | 1  (maskBits)
--  ---------------------------------------------------------------------
--  trigger         catg. |   |   |   |   | X  |    | 32 (categoryBits)
--                  cl.w/ | 1 |   |   |   |    |    | 1  (maskBits)
--  ---------------------------------------------------------------------

-- Now, create the filter tables...

local playerFilter      = { categoryBits = 1, maskBits = 54 }
local wallFilter        = { categoryBits = 2, maskBits = 1  }
local gearFilter        = { categoryBits = 4, maskBits = 1 }
local gearHangerFilter  = { categoryBits = 8, maskBits = 0 }
local gemFilter         = { categoryBits = 16, maskBits = 1 }
local triggerFilter     = { categoryBits = 32, maskBits = 1 }

----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Finally, attach them to our module
--
public.player      = playerFilter
public.wall        = wallFilter
public.gear        = gearFilter
public.hanger      = gearHangerFilter
public.gem         = gemFilter
public.trigger     = triggerFilter

return public
