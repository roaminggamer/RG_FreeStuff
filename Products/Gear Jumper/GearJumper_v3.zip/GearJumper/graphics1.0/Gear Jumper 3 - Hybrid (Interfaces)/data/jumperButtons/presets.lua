-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- Buttons Presets
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================

local mgr = ssk.buttons 

local imagePath = "data/jumperButtons/"

local gameFont = gameFont or native.systemFont

-- ============================
-- ============= Blue Button
-- ============================
local params = 
{
	buttonOverlayRectColor = nil,
	unselImgSrc = imagePath .. "blueButton.png",
	selImgSrc   = imagePath .. "blueButtonOver.png",
	textColor   = _BLACK_,
	emboss      = true,
	textFont	= gameFont,
	fontSize	= 24,
	textOffset  = {0,1},
}
mgr:addPreset( "blueButton", params )

-- ============================
-- ============= Green Button
-- ============================
local params = 
{
	buttonOverlayRectColor = nil,
	unselImgSrc = imagePath .. "greenButton.png",
	selImgSrc   = imagePath .. "greenButtonOver.png",
	textColor   = _BLACK_,
	emboss      = true,
	textFont	= gameFont,
	fontSize	= 24,
	textOffset  = {0,1},
}
mgr:addPreset( "greenButton", params )

-- ============================
-- ============= Yellow Button
-- ============================
local params = 
{
	buttonOverlayRectColor = nil,
	unselImgSrc = imagePath .. "yellowButton.png",
	selImgSrc   = imagePath .. "yellowButtonOver.png",
	textColor   = _BLACK_,
	emboss      = true,
	textFont	= gameFont,
	fontSize	= 24,
	textOffset  = {0,1},
}
mgr:addPreset( "yellowButton", params )

-- ============================
-- ======= Gel Check/Radio Box
-- ============================
local params = 
{ 
	unselImgSrc  = imagesDir .. "interface/checkGel.png",
	selImgSrc    = imagesDir .. "interface/checkGelOver.png",
}
mgr:addPreset( "checkGel", params )

-- ============================
-- ================== SSK Corona button
-- ============================
local params = 
{ 
	unselImgSrc  = imagePath .. "home.png",
	selImgSrc    = imagePath .. "home.png",
}
mgr:addPreset( "homeButton", params )


-- ============================
-- ================== Game Templates button
-- ============================
local params = 
{ 
	unselImgSrc  = imagesDir .. "badges/gametemplates.png",
	selImgSrc    = imagesDir .. "badges/gametemplates.png",
}
mgr:addPreset( "GTButton", params )

-- ============================
-- ================== SSK Corona button
-- ============================
local params = 
{ 
	unselImgSrc  = imagesDir .. "badges/sskcorona.png",
	selImgSrc    = imagesDir .. "badges/sskcorona.png",
}
mgr:addPreset( "SSKButton", params )
