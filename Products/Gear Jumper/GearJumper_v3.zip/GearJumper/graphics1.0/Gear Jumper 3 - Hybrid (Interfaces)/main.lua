-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================

print("\n\n\n****************************************************************")
print("*********************** \\/\\/ main.cs \\/\\/ **********************")
print("****************************************************************\n\n")
io.output():setvbuf("no") -- Don't use buffer for console messages

----------------------------------------------------------------------
--	1.							GLOBALS								--
----------------------------------------------------------------------
require( "ssk.globals" ) -- Load Standard Globals (DO NOT MODIFY)
require( "data.globals" ) -- Override settings  from ssk.globals here.

-- These that can be used to adjust the default
-- settings in the various modules used to make this game
--

-- This variable is used to see the random number generator.
-- By using a seed you will always get the same 'first' sequence.
--
gameSeed			= 4	          -- Used in main.lua and level.lua (optionally)

-- Variables to modify the player visual and interactive settings.
--
playerSize			= 15		  -- Used in player.lua
impulseForce		= 1.5		  -- Used in player.lua

-- This variable controls how far the player and gems will be 'mounted'
-- from the edge of a gear.
mountOffset			= 6			  -- Used in player.lua and level.lua

-- The size of gems
--
gemSize             = 10		  -- Used in level.lua	

-- Size of individual textures used to make the wall
wallBlockSize		= 40		  -- Used in world.lua and level.lua

-- This variable controls the height of the level
-- 12 rows per screen, so 36 rows == 3 screens
--
maxRows             = 36         -- Number of rows in world/level
                                  -- Used in world.lua and level.lua

-- These are actually the color of the 'light' bars on the wall
-- "blue" - Has a white-ish background,
-- "red"  - Has a black-ish background
--
wallColor			= "blue"	  -- Used in world.lua and level.lua
--wallColor			= "red"		  -- Used in world.lua and level.lua

-- These variables control the behavior of the camera algorithm
--
--       cameraTime  - Small values are fast, large values are slow
--       easingStyle - Use whatever transition easing you like: http://docs.coronalabs.com/api/library/easing/index.html
-- maxTransitionTime - Maximum time allowed for transitions. 
--                     (Comes into play when you fall below the screen edge to a gear off-screen.)
--
cameraTime			= 50		  -- Used in camera.lua								  
easingStyle			= easingStyle -- Used in camera.lua
maxTransitionTime   = 1000		  -- Used in camera.lua

-- Enable this feature to see how your level turned out
-- Does not enable the camera or create a player.
-- Only draws level.
--
debugEn				= false       -- Used in world.lua, level.lua, camera.lua                                  

-- This variable controls how fast the scene preview occurs in debug mode
--
debugTime           = maxRows * 350

----------------------------------------------------------------------
-- 2. LOAD MODULES													--
----------------------------------------------------------------------
local storyboard = require "storyboard"
local physics = require("physics")

require("ssk.loadSSK")

-- The different parts of the game are kept separated as modules for cleaner coding.
--
-- However, notice that we are only loading them once and keeping them 
-- globally visible.  Why?  These modules make calls to other modules
-- and are inter-dependent  (Isn't Lua great!)
--
cameraModule  = require("modules.camera")
filtersModule    = require("modules.filters")
playguisModule   = require("modules.playguis")
playerModule     = require("modules.player")
pRandModule		 = require("modules.portableRandom")
mathModule       = require("modules.math")
levelModule      = require("modules.level")
soundsModule     = require("modules.sounds")
worldModule      = require("modules.world")

gameLogicModule  = require("modules.gameLogic")


----------------------------------------------------------------------
-- 3. ONE-TIME INITIALIZATION										--
----------------------------------------------------------------------
-- == 
--    SET 'FIRST LOADED' SCENE
-- ==
local firstScene =  "interfaces.splashLoading"
--local firstScene =  "interfaces.mainMenu" 
--local firstScene =  "interfaces.credits" 
--local firstScene =  "interfaces.options"
--local firstScene =  "interfaces.playGUI"

-- Initialize The Random Number Generator
-- 
pRandModule:seed(gameSeed)


-- Configure physics 
--
physics.start()
physics.setGravity(0,0)
--physics.setDrawMode("debug")					-- Debug 'debug' draw mode
--physics.setDrawMode("hybrid")					-- Debug 'hybrid' draw mode


-- == 
--    STATUS BAR 
-- ==
display.setStatusBar(display.HiddenStatusBar)

-- == 
--    MULTITOUCH
-- ==
system.activate("multitouch")

-- == 
--    FONTS
-- ==
--
-- Note: Names may be different on simulator and on device due to way
-- Windows/OS X/iOS/Android differ in loading fonts
--
-- Note: You may need to extend this section, depending on how you use
-- fonts in your game.
--

if(onSimulator) then
	gameFont = "Harrowprint" -- native.systemFontBold
	helpFont = native.systemFont
else
	gameFont = "Harrowprint" -- native.systemFontBold
	helpFont = native.systemFont
end

-- == 
--    USER PRESETS
-- ==
require("data.jumperButtons.presets")

-- == 
--    DEFAULT PRESETS
-- ==
require("data.buttons")
require("data.labels")


-- Load SSK Presets (Buttons and Labels)
-- 
-- Note: Do not modify these files.  Add custom settings in the user files above instead.
--
local labelsInit = require("ssk.presets.labels")
local buttonsInit = require("ssk.presets.buttons")

local player require("data.player")


-- Initialize the game sounds and start the music (if enabled)
--
-- Note: We will continue to use the sound module for two reasons:
--
-- 1. It is already written and ready to go, 
-- 2. As of the time of this writing, the SSK sound manager cannot play simultaneous 
--    special effect sounds.  (That will be added to a future version of SSK.)
--
soundsModule.init()
soundsModule.playMusic()


----------------------------------------------------------------------
-- 4. DEBUG STUFF													--
----------------------------------------------------------------------
-- Print the collision matrix data
--ssk.debug.dumpScreenMetrics()
--ssk.debug.dumpFonts()
--ssk.debug.printLuaVersion()
--ssk.debug.monitorMem()


print("\n****************************************************************")
print("*********************** /\\/\\ main.cs /\\/\\ **********************")
print("****************************************************************")
----------------------------------------------------------------------
--								LOAD FIRST SCENE					--
----------------------------------------------------------------------
storyboard.gotoScene( firstScene )
