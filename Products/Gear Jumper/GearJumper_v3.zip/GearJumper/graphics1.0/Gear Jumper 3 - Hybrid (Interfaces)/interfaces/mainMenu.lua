-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- SSKCorona Sampler Main Menu
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================
local storyboard = require( "storyboard" )
local scene      = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local screenGroup

-- Callbacks/Functions

local onPlay
local onCredits
local onOptions
local onGameTemplates
local onSSKCorona

----------------------------------------------------------------------
--	Scene Methods:
-- scene:createScene( event )  - Called when the scene's view does not exist
-- scene:destroyScene( event ) - Called prior to the removal of scene's "view" (display group)
----------------------------------------------------------------------

----------------------------------------------------------------------
function scene:createScene( event )
	screenGroup = self.view

	-- Background Image
	ssk.display.backImage( screenGroup, "backImage.png" ) 

	-- ==========================================
	-- Buttons and Labels
	-- ==========================================
	local curY          = 60
	local buttonSpacing = 75
	local buttonWidth   = 300
	local buttonHeight  = 60
	local tmpButton
	local tmpLabel

	-- Game Label / Name
	local titleBack
	titleBack = ssk.display.imageRect( screenGroup,  centerX, curY, "images/blueBack.png", { w = 300, h = 96 } )
	ssk.labels:quickEmbossedLabel( screenGroup, "  Gear Jumper\nGame Template", titleBack.x, titleBack.y, 
	                               "Harrowprint", 38, _BRIGHTORANGE_, _WHITE_, _DARKERGREY_ )


	-- PLAY 
	curY = curY + 130
	ssk.buttons:presetPush( screenGroup, "greenButton", centerX, curY, buttonWidth, buttonHeight,  "Play", onPlay )

	-- OPTIONS
	curY = curY + buttonSpacing 
	ssk.buttons:presetPush( screenGroup, "blueButton", centerX, curY, buttonWidth, buttonHeight,  "Options", onOptions ) 

	-- CREDITS
	curY = curY + buttonSpacing 
	ssk.buttons:presetPush( screenGroup, "blueButton", centerX, curY, buttonWidth, buttonHeight,  "Credits", onCredits ) 

	-- Game Templates Badge
	local badgeBack1
	badgeBac1k = ssk.display.imageRect( screenGroup,  145/2 + 5, h - 30, "images/blueBack.png", { w = 145, h = 48 } )
	ssk.buttons:presetPush( screenGroup, "GTButton", badgeBac1k.x, badgeBac1k.y + 2, 130, 40, "", onGameTemplates  )

	-- SSKCorona Badge
	local badgeBack2
	badgeBack2 = ssk.display.imageRect( screenGroup,  w - 145/2 - 5, h - 30, "images/blueBack.png", { w = 145, h = 48 } )
	ssk.buttons:presetPush( screenGroup, "SSKButton",badgeBack2.x - 10, badgeBack2.y + 2, 130, 40, "", onSSKCorona  )

end

----------------------------------------------------------------------
function scene:destroyScene( event )
	screenGroup = self.view

	previewPiece = nil
end


----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------


onPlay = function ( event ) 
	local options =
	{
		effect = "slideLeft",
		time = 300,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.playGUI", options  )	

	return true
end


onOptions = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 200,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.options", options  )	

	return true
end

onCredits = function ( event ) 
	local options =
	{
		effect = "fade",
		time = 400,
		params =
		{
			logicSource = nil
		}
	}

	storyboard.gotoScene( "interfaces.credits", options  )	

	return true
end


onGameTemplates = function ( event ) 
	system.openURL( "http://roaminggamer.com/makegames"  )
	return true
end

onSSKCorona = function ( event ) 
	system.openURL( "http://roaminggamer.com/sskcorona"  )
	return true
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "willEnterScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
scene:addEventListener( "destroyScene", scene )
scene:addEventListener( "overlayBegan", scene )
scene:addEventListener( "overlayEnded", scene )
---------------------------------------------------------------------------------

return scene
