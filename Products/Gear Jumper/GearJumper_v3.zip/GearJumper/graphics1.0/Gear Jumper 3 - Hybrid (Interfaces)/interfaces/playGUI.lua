-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- SSKCorona Sampler Main Menu
-- =============================================================
-- Short and Sweet License: 
-- 1. You may use anything you find in the SSKCorona library and sampler to make apps and games for free or $$.
-- 2. You may not sell or distribute SSKCorona or the sampler as your own work.
-- 3. If you intend to use the art or external code assets, you must read and follow the licenses found in the
--    various associated readMe.txt files near those assets.
--
-- Credit?:  Mentioning SSKCorona and/or Roaming Gamer, LLC. in your credits is not required, but it would be nice.  Thanks!
--
-- =============================================================
--
-- =============================================================

local storyboard = require( "storyboard" )
local scene      = storyboard.newScene()

----------------------------------------------------------------------
--								LOCALS								--
----------------------------------------------------------------------
-- Variables
local screenGroup
local gameGroup


-- Callbacks/Functions
local onBack

----------------------------------------------------------------------
--	Scene Methods:
-- scene:willEnterScene( event ) -- Called BEFORE scene has moved onscreen
-- scene:didExitScene( event ) - Called AFTER scene has finished moving offscreen
----------------------------------------------------------------------

----------------------------------------------------------------------
function scene:willEnterScene( event )
	screenGroup = self.view

	-- 1. Create a group to contain the layers the game will create and
	-- let screenGroup own (contain) this group)
	--
	gameGroup = display.newGroup()
	screenGroup:insert(gameGroup)

	-- 2. Provide 'gameGroup' to the gameLogic module so it can insert all of
	-- its content (layers) into 'gameGroup'.  Why? 
	--
	-- a. The scene provides a top group 'screenGroup' (see above).
	-- b. We make another group 'gameGroup' and insert it into 'screenGroup'
	-- c. Then, we pass 'gameGroup' to our game logic, and that logic inserts its layering
	--    groups into 'gameGroup'
	--
	-- At the end of this circuitous route, we've managed to make all of our game objects and layers
	-- owned by the scene (top) group 'screenGroup'.  This only took a little extra code, but now
	-- the scene can fade, rotate, swipe, etc. the created level on and off the screen.  
	--
	-- In short, we did this to insert our game content into a group that the scene manager can
	-- control and manipulate.
	-- 
	gameLogicModule.setGameGroup( gameGroup )

	-- 3. Set the random seed to we always get the same first level
	--
	pRandModule:seed(gameSeed)
	
	-- 4. Run the game
	--
	gameLogicModule.playGame()

	-- 5. Add a button for quitting (Uses SSK)
	--
	ssk.buttons:presetPush( screenGroup, "homeButton", w-15 , 18, 30, 30,  "", onBack )

end

----------------------------------------------------------------------
----------------------------------------------------------------------
function scene:didExitScene( event )
	screenGroup = self.view

	-- Destroy the game logic and gameGroup just after we leave the scene
	gameLogicModule.setGameGroup( nil )
	gameLogicModule.endGame()
	gameGroup:removeSelf()
	gameGroup = nil	
end


----------------------------------------------------------------------
--				FUNCTION/CALLBACK DEFINITIONS						--
----------------------------------------------------------------------

onBack = function ( event ) 
	local options =
	{
		effect = "slideRight",
		time = 300,
		params =
		{
			dummy = nil
		}
	}

	storyboard.gotoScene( "interfaces.mainMenu", options  )	

	return true
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------
scene:addEventListener( "createScene", scene )
scene:addEventListener( "willEnterScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "didExitScene", scene )
scene:addEventListener( "destroyScene", scene )
scene:addEventListener( "overlayBegan", scene )
scene:addEventListener( "overlayEnded", scene )
---------------------------------------------------------------------------------

return scene
