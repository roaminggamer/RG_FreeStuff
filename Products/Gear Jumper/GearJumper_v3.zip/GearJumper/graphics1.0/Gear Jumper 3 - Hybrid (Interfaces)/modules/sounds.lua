-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- sounds.lua - A module for creating, destroying, and 
--              maintaining the sound.
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------

-- None

----------------------------------------------------------------------
-- 3. Local Variables and Functions
----------------------------------------------------------------------

local musicChannel	= -1 -- Assume unavailable
local sfxChannels	= {}
sfxChannels.jump	= -1 -- Assume unavailable
sfxChannels.gem		= -1 -- Assume unavailable
sfxChannels.win		= -1 -- Assume unavailable
sfxChannels.lose	= -1 -- Assume unavailable

local musicHandle	= -1 -- Assume no handle
local sfxHandles	= {}
sfxHandles.jump		= -1 -- Assume no handle
sfxHandles.gem		= -1 -- Assume no handle
sfxHandles.win		= -1 -- Assume no handle
sfxHandles.lose		= -1 -- Assume no handle

local musicFile		= "ElectroDoodle.mp3"
local sfxSoundFiles	= {}
sfxSoundFiles.jump	= { "jump1.wav", "jump2.wav", "jump3.wav" }
sfxSoundFiles.gem	= { "gem1.wav", "gem2.wav", "gem3.wav" }
sfxSoundFiles.win	= "win.wav"
sfxSoundFiles.lose	= "lose.wav"

-- ==
--	initSound() - Initialize sound settings and load sound files.
-- ==
local function initSound()

	-- Set up the channels first
	--

	-- We need several distinct channels because these sounds can overlap, but 
	-- there is no assurance we have enough, so let's acquire the in priority order
	--

	-- Music channel gets first dibs
	musicChannel = audio.findFreeChannel() -- Get first free channel

	-- Player jumping gets next priority
	if( musicChannel >=  0 ) then
		sfxChannels.jump = audio.findFreeChannel( musicChannel + 1 ) -- Get next free channel
	end

	-- Gem sounds sound gets next priority
	if( sfxChannels.jump >=  0 ) then
		sfxChannels.gem = audio.findFreeChannel( sfxChannels.jump + 1 ) -- Get next free channel
	end

	-- Win sound gets next priority
	if( sfxChannels.gem >=  0 ) then
		sfxChannels.win = audio.findFreeChannel( sfxChannels.gem + 1 ) -- Get next free channel
	end

	-- Lose sound next priority
	if( sfxChannels.win >=  0 ) then
		sfxChannels.lose = audio.findFreeChannel( sfxChannels.win + 1 ) -- Get next free channel
	end

	-- Set the volumes
	--
	if( musicChannel >= 0 ) then
		print("Setting volume for music on channel ", musicChannel )
		audio.setVolume( currentPlayer.musicVolume , {channel = musicChannel} )
	end

	if( sfxEnabled ) then
		for name,channelNum in pairs( sfxChannels ) do
			if( channelNum >= 0 ) then
				print("Setting volume for sound effect ", name, " on channel ", channelNum )
				audio.setVolume( currentPlayer.sfxVolume , {channel = channelNum} )
			end
		end
	end

	-- Now that we know how many channels are available, lets load the sounds we need
	--
	if( musicChannel >= 0 ) then
		print("Loading sound file for music" )
		musicHandle = audio.loadStream( "sounds/music/" .. musicFile ) -- Load music as stream to save memory
	end

	-- Load sounds into memory because we need them to play immediately and often
	--
	for name,channelNum in pairs( sfxChannels ) do

		if( channelNum >= 0 ) then

			local fileName = sfxSoundFiles[name]

			sfxHandles[name] = {}

			-- Just a single file for this sound effect
			--
			if( type( fileName ) == "string" ) then
				print("Loading SINGLE sound file ", sfxSoundFiles[name], " for sound effect ", name )
				sfxHandles[name][1] = audio.loadSound( "sounds/sfx/" .. sfxSoundFiles[name] ) 

			-- Multiple files for this sound effect
			--
			else
				for k,v in ipairs( fileName ) do
					print("Loading MULTI sound file ", v, " for sound effect ", name )
					sfxHandles[name][k] = audio.loadSound( "sounds/sfx/" .. v ) 				
				end
			end
		end
	end
end

----------------------------------------------------------------------
-- 4. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.init  = initSound


-- Provide some extra functions on the module to get and set the counters.
--

-- ==
--	playEffect() - Plays the named sound effect. (Loops 'loop' times; -1 == loop till stopped)
-- ==
public.playEffect = function( name, loops, specificHandleNum )

	local loops = loops or 0

	-- If sound effects are not enabled, don't play sound effect
	--
	if( not currentPlayer.sfxEnabled ) then 
		return  
	end
	
	-- If the channel and handle are valid, play the sound effect
	--
	if( sfxChannels[name] ~= nil and 
	    sfxHandles[name]  ~= nil and 
		sfxChannels[name] >= 0 ) then

		--print("Play Sound Effect:", name)
		audio.setVolume( currentPlayer.sfxVolume , { channel = sfxChannels[name] } )

		local handleNum = 1

		-- Use requested handle num if supplied
		if( specificHandleNum ) then
			handleNum = specificHandleNum
		else
			-- Multiple handles, so select one randomly
			--
			if( #sfxHandles[name] > 1 ) then
				handleNum = pRandModule:randInt( 1, #sfxHandles[name] )
			end
		end



		audio.play( sfxHandles[name][handleNum] , { channel = sfxChannels[name], loops = loops } )

		--print("Play Sound Effect:", name, handleNum)
	end

end

-- ==
--	stopEffect() - Plays the named sound effect.
-- ==
public.stopEffect = function( name )
	-- If the channel and handle are valid, stop the sound effect
	--
	if( sfxChannels[name] ~= nil and 
	    sfxHandles[name]  ~= nil and 
		sfxChannels[name] >= 0 ) then

		--print("Stop Sound Effect:", name)
		audio.stop( sfxChannels[name] )

	end
end

-- ==
--	playMusic() - Plays the sound track music.
-- ==
public.playMusic = function( )

	-- If music is not enabled, don't play sound track
	--
	if( not currentPlayer.musicEnabled ) then 
		return  
	end

	-- If the music channel and handle are valid, then play the sound track
	--
	if( musicHandle ~= nil  and 
	    musicChannel ~= nil and 
		musicChannel >= 0 ) then

		--print("Play Sound Track")
		audio.play( musicHandle , {channel = musicChannel, loops=-1, fadein = 1000} )

	end
end

-- ==
--	stopMusic() - Plays the sound track music.
-- ==
public.stopMusic = function( )
	-- If the music channel and handle are valid, then play the sound track
	--
	if( musicHandle ~= nil  and 
	    musicChannel ~= nil and 
		musicChannel >= 0 ) then
		
		--print("Stop Sound Track")
		audio.stop( musicChannel )

	end
end


return public
