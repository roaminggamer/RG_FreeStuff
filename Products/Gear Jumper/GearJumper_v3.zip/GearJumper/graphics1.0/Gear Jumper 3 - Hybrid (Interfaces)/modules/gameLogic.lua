-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================
----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------
local layers				-- Variable to hold our display/rendering layers

local thePlayer				-- A variable to hold a reference to the player.
							-- Passed to camera module.

-- Some function pre-declarations
--
local createLayers 
local destroyLayers 
local restartTest 
local playGame 
local endGame  

local gameGroup

-- ==
--    createLayers() - A function to create and sort the display/rendering layers.
-- ==
createLayers = function( )
	
	layers = display.newGroup()
	layers.background = display.newGroup()	-- Background and Walls
	layers.content     = display.newGroup()	-- Player, Gears, Gems, Triggers
	layers.guis        = display.newGroup()	-- Counters, HUDs, etc.
	--
	-- Tips: 
	--       1. Insert the above groups into our master group for easy removal later.
	--       2. Insertion order controls layering order. 1st is bottom, 2nd above that, etc...
	--
	layers:insert(layers.background) -- Bottom-most layer
	layers:insert(layers.content)	  -- Next layer up ...
	layers:insert(layers.guis)	      -- Top-most Layer

	gameGroup:insert( layers )
end

-- ==
--    destroyLayers() - A function to destroy and cleanup the display/rendering layers.
-- ==
destroyLayers =  function()
	if(layers) then
		layers:removeSelf()
	end
	layers = nil
end

-- ==
--    playGame() - A function that creates a single game level and starts checking for game over.
-- ==
playGame = function( )

	-- Create the rendering layers
	createLayers( )

	-- Create the world and other game  objects
	--
	worldModule.create( layers.background)
	levelModule.create( layers.content )

	if( not debugEn	) then
		thePlayer = playerModule.create( layers.content )
		cameraModule.create( thePlayer, layers.background, layers.content )
	end
	playguisModule.create( layers.guis )

	physics.setGravity(0,9.8)						-- Turn 'on' gravity

end

-- ==
--	endGame() - A nice function that destroys all game objects and stops checking for game over.
-- ==
endGame = function( )

	-- Cleanup the world and other game objects	(generally in reverse order)
	--
	playguisModule.destroy()	

	if( not debugEn	) then		
		cameraModule.destroy()
		playerModule.destroy()
		thePlayer = nil
	end

	levelModule.destroy()
	worldModule.destroy()
	-- Remove all rendering layers (and thus all objects)	
	destroyLayers()

end

----------------------------------------------------------------------
-- 2. The module
----------------------------------------------------------------------
local public = {}

public.playGame = playGame
public.endGame  = endGame

-- ==
--	setGameGroup() - This function allows the playGui interface (interfaces/playGui.lua) to 
--  provide a group for the layers to be inserted into.  This group is
--  in turn created and destroyed by the main menu, making it easy to clean up
--  the local (to this file) content.
-- ==
public.setGameGroup = function( group )
	gameGroup = group
end


return public



