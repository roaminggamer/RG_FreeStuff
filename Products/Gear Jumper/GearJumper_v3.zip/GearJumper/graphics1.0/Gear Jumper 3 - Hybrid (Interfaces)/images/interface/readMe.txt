Slider Parts
------------
I modified the slider art from the Corona demos.  Feel free to use in your own games.
I also used http://cooltext.com/ to generate some wide narrow buttons for the track and thumb.


Check Boxes
-----------
I made these and/or generated them using http://cooltext.com/, feel free to use them as you wish.


BUTTONS
---------

I made these buttons with a free web button-generator here: http://cooltext.com/

Feel free to re-use them if you want.