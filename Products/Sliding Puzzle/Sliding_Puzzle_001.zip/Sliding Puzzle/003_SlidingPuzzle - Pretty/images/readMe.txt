
Letter Tiles Art Source: Vicki Wenderlich's site:

http://www.vickiwenderlich.com/2012/12/free-game-art-letter-tiles/

License:

http://www.vickiwenderlich.com/free-art/licensing/