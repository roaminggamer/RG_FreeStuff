-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------

-- Locals
											-- Some helper variables specifying:
local w       = display.contentWidth		-- Design width, height, and center <x,y> positions.
local h       = display.contentHeight
local centerX = display.contentWidth/2 
local centerY = display.contentHeight/2

													-- BOARD SPECS
													--
local pieceSize = 160						-- Width and height of pieces
local maxRows = 3								-- Number of ROWS
local maxCols = 3								-- and COLUMNS.

local minX  = centerX - (maxCols * pieceSize)/2 + pieceSize/2			-- x-Position for left-most pieces
local minY  = centerY - (maxRows * pieceSize)/2 + pieceSize/2 - 15  -- y-Position for right-most pieces

local theBoardPieces = {}					-- Table used to store the board (puzzle) pieces (the rectangles we make in 'drawBoard()').
local gameIsRunning  = true				-- Boolean variable used to track whether game is running or over.

local solutionString1 = ""					-- File level globals storing the solved position of the pieces.  
local solutionString2 = ""					-- The first with a space at the front and the second at the end.

local pieceNumbers = {}						-- A table to store the 'number' of individual pieces.  
                                       -- By using simple numbers to mark the pieces we can easily
													-- check to see if they are in order.

-- Labels & Buttons
local gameStatusMsg							-- Empty variable that will be used to store the handle to a text object 
													-- representing the game status message.

-- Function Declarations
local prepData									-- Create the solution strings and build a random list of tile numbers

local drawBoard								-- Function to draw the game board.

local checkIfSolved							-- Function to check the board data to see if it has been solved

local shuffle									-- Function to shuffle (randomize) a table.

-- Listener Declarations
local onTouchPiece							-- Listener to handle touches on board pieces.

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--    prepData() - Initializes the solution strings and the data table for the board.
-- ==

prepData = function()

	--
	-- 1. Clear out the solution strings and the pieceNumbers tracking table.
	--		
	solutionString1 = ""
	solutionString2 = ""
	pieceNumbers = {}

	--
	-- 2. Create the first solution string AND
	--    Initialize the pieceNumbers table with in order tile numbers
	local count = 1  -- A local for counting the current piece number.
	for row = 1, maxRows do
		for col = 1, maxCols do
			if not (row == 1 and col == 1) then
				solutionString1 = solutionString1 .. count
				pieceNumbers[count] = count
				count = count + 1
			end
		end
	end

	--
	-- 3. Finish initializing the solution strings.
	--		

	-- Add the blank tiles (space) to soltion strings #1 asnd #2
	-- We will consider the puzzle solved if the tiles are all in
	-- numerical order with a blank tile in the first or last position.
	solutionString2 = solutionString1 .. " "
	solutionString1 = " " .. solutionString1

	--
	-- 4. Shuffle (randomize) the order of the tile numbers
	--		
	--    This is how we get out of order tiles.
	
	--
	-- TIP: You can comment this out and get a solved board to start with.
	--      This is how I originally tested the 'checkIfSolved()' function.
	shuffle( pieceNumbers , 10 )
end


-- ==
--    drawBoard() - Draws the sliding puzzle grid
-- ==
drawBoard = function()

	--
	-- 1. Draw the board (3-by-3 grid of text objects over rectangles).
	--		
	local count = 1 -- A local for counting the current piece number.
	for row = 1, maxRows do
		local y = minY + (row - 1) * pieceSize

		for col = 1, maxCols do
			local x = minX + (col - 1) * pieceSize

			if not (row == 1 and col == 1) then

				-- 
				-- A. Create the rectangle first (so it is displayed on the bottom)
				--
				local boardPiece =  display.newRect( 0, 0, pieceSize, pieceSize )

				-- TIP: When we create the rectangle, we place it by its upper-left corner at <0,0>.
				--      However, after the rectangle has been created, the refenence point automatically
				--      changes to the middle of the rectangle.  Below, when we place it,
				--      we are specifying where the CENTER of the rectangle should be.
			
				-- Move the piece to the correct row (y) and column (x) position
				boardPiece.x = x
				boardPiece.y = y

				-- Change the color of this 'piece' to be dark grey with a 2-pixel wide light grey border
				boardPiece:setFillColor( 0.125,0.125,0.125,1 )
				boardPiece:setStrokeColor( 0.5,0.5,0.5,1 )
				boardPiece.strokeWidth = 2

				-- 
				-- B. Create the text object 'marker' second so it is displayed on top of the rectangle
				--
				-- TIP: Uncomment the shuffle code in prepData() for a fully sorted board.				
				local gridMarker =  display.newText( pieceNumbers[count], 0, 0, native.systemFont, 40 ) 
				gridMarker.x = x
				gridMarker.y = y

				-- TIP: I created the above text object at position <0,0> and then positioned it.  Why?  Because you have no way of knowing the exact width/height
				-- of a text object till it is created.  So, trying to position it during creation will end up placing it by the upper-left coordinates, and may not be what you wanted.
				-- However, after the text object is created, it changes to a center reference point.  So, by waiting to set the position, we get the result we really wanted.

				-- Change the text color to light grey
				gridMarker:setFillColor( 0.5,0.5,0.5,1 )

				-- Attach the marker to the grid piece (rectangle object).  This is an easy way to track which text object goes with which rectangle.
				-- We do this so the touch handler (below) knows what text object to move when it moves a piece.  The 'checkIfSolved()' also needs to know this.
				boardPiece.myMarker = gridMarker

				-- Tell the grid piece its row/column location.
				-- This is used later in the touch listener to allow us to mark the right entry in our data table.
				boardPiece.row = row
				boardPiece.col = col

				-- Add a "touch" listener to the grid piece (rectangle object). 
				boardPiece:addEventListener( "touch", onTouchPiece )


				-- 
				-- C. Store this piece in the boardPiece table.
				--
				--				
				--
				-- Notes:
				--
				-- 1. boardPiece is a table containing a sub-table for each column. 
				-- 2. The sub-tables (columns) contain a tile for each row.
				-- 3. Notice that I organized boardPiece by column and then row (i.e. x then y)
				--    I could have done the opposite (row, then column; i.e. y then x) and the 
				--    solution would still be the same.  The key is being consistent, and later in 'checkIfSolved()' 
				--    one must keep in mind the organization of the table.  If it gets too confusing, draw a picture. :)
				-- 4. Remember, we initialized theBoardPieces at the start of this function.  So, we
				--    need to add the extra sub-tables each time we come to a new column.
				-- 
				if(not theBoardPieces[col]) then
					-- This column has no sub-table yet.  So, we need to add one
					-- Again, this sub-table will store the tiles for each row in this column ONLY.
					theBoardPieces[col] = {}
				end

				theBoardPieces[col][row] = boardPiece

				count = count + 1  --  Don't forget to increment our tile counter

			end

		end
	end		
	
	--
	-- 2. Add a winner indicator (text object).
	--
	gameStatusMsg = display.newText( "Not solved yet." , 0, 0, native.systemFont, 48 )
	gameStatusMsg.x = centerX
	gameStatusMsg.y = h - 20

end

-- ==
--    checkIfSolved() - This function checks to see if the tiles are currently in the right order.
--
--		We do this by:
--						1. Traversing the board (boardPieces) left-to-right, top-to-bottom (i.e. row by row).
--                2. As we traverse the board, we get the number stored in that piece's text object and 
--						   store it in a temporary string.
--						3. After the traversal, we compare that string to our two solution strings.
--						   If it matches one of them, the board is solved!
-- ==
checkIfSolved = function()

	local puzzleString = "" -- Our temporary string to contain the current order of pieces
	
	--
	-- 1. Traverse the board
	--
	for row = 1, maxRows do
		for col = 1, maxCols do
			if( theBoardPieces[col][row] == nil ) then
				puzzleString = puzzleString .. " "
			else
				--
				-- 2. Get the piece number.
				--
				puzzleString = puzzleString .. theBoardPieces[col][row].myMarker.text
			end
		end
	end

	-- Some debug code to print our string and the two solutions (see the console)
	print( "|" .. puzzleString .. "|" )
	print( "|" .. solutionString1 .. "|" )
	print( "|" .. solutionString2 .. "|" )

	--
	-- 3. Is it solved?
	--
	if( puzzleString == solutionString1 ) then
		return true
	end
	if( puzzleString == solutionString2 ) then
		return true
	end

	-- Darn, I guess not.
	return false
end

-- ==
--    shuffle() - A simple function to randomly swap the values for two entries in a table.
--
--         t - The table
--    passes - Number of times to shuffle the table
-- ==
shuffle = function( t, passes )
	local passes = passes or 1
	for i = 1, passes do
		local n = #t 
		while n >= 2 do
			-- n is now the last pertinent index
			local k = math.random(n) -- 1 <= k <= n
			-- Quick swap
			t[n], t[k] = t[k], t[n]
			n = n - 1
		end
	end 
	return t
end


--==
-- ================================= LISTENER DEFINITIONS
--==

-- ==
--    isEmpty() - A short function to test if a position on the board is empty.
--                This is used by 'onTouchPiece()' below.
-- ==
function isEmpty(row,col)
	return theBoardPieces[col][row] == nil
end

-- ==
--    onTouchPiece() - Touch listener function.  The function that gets called when we touch a puzzle piece.
--
--    Note: This is the improved 'onTouchPiece()' function mentioned in the last version of this game 'SlidingPuzzle - Pure'.
--    This version will attempt to move an entire row or column to 'fill' an empty gap.  This is much nicer for puzzles larger than 2x2.
--    
-- ==
onTouchPiece = function( event )
	
	-- TIP: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	local phase  = event.phase  
	local target = event.target

	local row    = target.row
	local col    = target.col


	-- If the game is over, then ignore this touch
	if( not gameIsRunning ) then
		return true
	end

	-- Don't do anything unless this is the "ended" phase, 
	-- meaning the player touched a piece and then lifted their finger.
	if( phase == "ended" ) then
	
		local movedPieces = false

		for i = col, 1, -1 do
			--print(i)
			if( (i-1) > 0 and isEmpty( row, i-1 ) ) then  -- TO THE LEFT
				print("Is empty to the left")
				for j = i, col do 					
					local curPiece = theBoardPieces[j][row]
					curPiece.x = curPiece.x - pieceSize
					curPiece.myMarker.x = curPiece.x

					theBoardPieces[j][target.row] = nil
					curPiece.col = j - 1
					theBoardPieces[curPiece.col][target.row] = curPiece
				end
				movedPieces = true
				break
			end
		end

		if( not movedPieces ) then
			for i = col, maxCols do
				--print(i)
				if( (i+1) <= maxCols and isEmpty( row, i+1 ) ) then  -- TO THE RIGHT
					print("Is empty to the right")
					for j = i, col, -1 do 						
						local curPiece = theBoardPieces[j][row]
						curPiece.x = curPiece.x + pieceSize
						curPiece.myMarker.x = curPiece.x

						theBoardPieces[j][target.row] = nil
						curPiece.col = j + 1
						theBoardPieces[curPiece.col][target.row] = curPiece
					end
					movedPieces = true
					break
				end
			end
		end

		if( not movedPieces ) then
			for i = row, 1, -1 do
				--print(i)
				if( (i-1) > 0 and isEmpty( i-1, col ) ) then  -- UP
					print("Is empty above")
					for j = i, row do 						
						local curPiece = theBoardPieces[col][j]
						curPiece.y = curPiece.y - pieceSize
						curPiece.myMarker.y = curPiece.y

						theBoardPieces[target.col][j] = nil
						curPiece.row = j - 1
						theBoardPieces[target.col][curPiece.row] = curPiece
					end
					movedPieces = true
					break
				end
			end
		end		

		if( not movedPieces ) then
			for i = row, maxRows do
				print(i)
				if( (i+1) <= maxRows and isEmpty( i+1, col ) ) then  -- DOWN
					print("Is empty below")
					for j = i, row, -1 do 
						local curPiece = theBoardPieces[col][j]
						curPiece.y = curPiece.y + pieceSize
						curPiece.myMarker.y = curPiece.y

						theBoardPieces[target.col][j] = nil
						curPiece.row = j + 1
						theBoardPieces[target.col][curPiece.row] = curPiece
					end
					movedPieces = true
					break
				end
			end
		end		

		if( movedPieces ) then
			-- Check to see if the puzzle has been solved and if so
			-- update the status message and 'lock' the game pieces.
			if( checkIfSolved( ) ) then
				gameStatusMsg.text = "You solved it!"
				gameIsRunning = false
			end
		end		
	end

	return true
end

----------------------------------------------------------------------
-- 5. Execution  - Now that we have written all the code, let's call
--                 our functions and run the game!
----------------------------------------------------------------------
prepData()
drawBoard()

