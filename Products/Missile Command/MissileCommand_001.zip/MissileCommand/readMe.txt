==============================================================================

Roaming Gamer: Missile Command (Game Template)

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Reporting Bugs - How to report bugs with this template.

==============================================================================


A. Short and Sweet License 

==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.  
     (I don't want to see this show up on Chupamobile or any other website that sells templates!)


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.



B. What's in the template package?
==================================
This is a simple version of the game Missile Command.

* 001_MissileCommand - Basic - Simple artless version of game.  Great staring point for new developers.
* 002_MissileCommand - Pretty - Beautified version of game with art and sound.
* 003_MissileCommand - Modular - Game with game over logic, difficulty progression, and code separated into modules.
* 004_MissileCommand - Framed - Modules integrated with composer.* framework for complete package.



C. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please file a bug in the forums.  
Direct emails will be ignored.  It is better to share bugs where everyone can see them and see they are fixed.


>> Please report to this forum: https://forums.coronalabs.com/forum/659-marketplace-assets/

>> Please use this post title format: RG Missile Command: VERY-SHORT BUG DESCRIPTION

>> In the body of your post, please: Give a clear, concise, and precise description of the bug.


If you do not follow these directions it may take longer for me to notice and then resolve the bug.


Thanks,

The Roaming Gamer



