-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- Example Begins Here
-- ==========================================================================
--[[
   In this version of the game, an 'enemy' AI continuosly fires till there 
   are no targets left.  

   You have 1000 missiles to defent 40 buildings (split evenly between
   four cities) and your missle battery.

   Click anywhere on the screen to fire a missile.  When the missil reaches 
   that point, it 'explode' by expanding and collapsing a circle.  While 
   the expand/collapse is on-going, logic will check whether the circle 
   overlaps any missiles.  If so those missles are destroyed.  You can destroy 
   your own missiles through friendly fire.

   This version of the 'game' demonstrates:
   - Creation of cities.
   - Creation of a single missile battery.
   - Firing enemy missiles.
   - Basic enemy game loop.
   - Random target selection.
   - Firing player missiles.
   - Drawing missile trails.
   - Updating counters and other visual elements to indicate progress as well 
     as scoring.    
   - Calculation of transition.to() time based on distance and desired speed. 
]]

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************


-- **************************************************************************
-- Initialization
-- **************************************************************************


-- **************************************************************************
-- Local Variables
-- **************************************************************************
--
-- 1. Frequently used 'concepts' pre-calculated and stored in easy to 
--    type & remember variable.
--
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

--
-- 2. (Game) Variables specific to this game and its logic.
--
local layers                              -- Top group containing all child groups
local gameIsRunning           = false     -- Flag to help track if game is running
local gameTimer                           -- Handle to store timer id

local missileValue            = 10        -- Value for destroying a missile

local score                               -- Current score

local missileMinTime          = 1000       -- Minimum time (in millseconds) between missile firing
local missileMaxTime          = 3000      -- Maximum time (in millseconds) between missile firing

local missiles                = {}
local cities                  = {}        -- Table to store city object references in
local batteries               = {}        -- Table to store silo object references in

local currentBattery                      -- Selected battery (to fire from)
                                          -- This version of the game only has one battery, so
                                          -- consider this a placeholder for future logic.

local missileWidth            = 20        -- missile width
local missileHeight           = 20        -- missile height
local missileTrailThickness   = 4         -- Thickness of trail behind missiles

local explosionMinRadius      = 40        -- Minimum radius for explosion (used to vary explosions)
local explosionMaxRadius      = 60       -- Maximum radius for explosion (used to vary explosions)

local explosionMinTime        = 1000      -- Minimum time for expansion and contraction effect (used to vary explosions)
local explosionMaxTime        = 2000      -- Maximum time for expansion and contraction effect (used to vary explosions)

local playerMissileSpeed      = 150       -- Player missile speed in pixels-per-second
local enemyMissileSpeed       = 60        -- Enemy missile speed in pixels-per-second

local enemyColor              = {1,0,0}
local playerColor             = {1,1,0}

local citySize                = 80
local batterySize             = 80

local cityColor               = { 0, 1, 0 }
local batteryColor            = { 1, 1, 0 }

local groundHeight            = 100
                                       
local labelBarHeight          = 60        -- Height label background bar
local labelFont               = native.systemFontBold
local labelSize               = 40

local tapToStartLabel
local scoreLabel

-- **************************************************************************
-- Localize Commonly Used Functions 
--
-- Why Do This?: It gives small execution speedup, but mostly I do it 
-- to simplify typing.  I may not use them all, bit it is handy to have
-- them ready if I need them.
--
--  !!Warning!!: Don't take this too far.  Lua has a limit of 200 
--               local variables in scope at any time.
--
--     Pro Tip:  Be a DRY coder, not a WET coder.
--               WET ==> Write Everything Twice; We Enjoy Typing; ...
--               DRY ==> Don't Repeat Yourself
--
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Forward Declarations
--
-- Tip: This makes the following function names VISIBLE for the rest of the file.
--      They can be called anywhere below as long as they have been defined before
--      the are called. (As soon as this file 'loads', all of the functions will 
--      be defined.)
-- 
-- Note: I split game logic into create, destroy, start, stop... etc. because:
--
-- 1. It makes reading these parts of the code easier.
--
-- 2. It promotes the concepts associated with these function to you.
--
-- 3. Having this functionality broken up discretely helps you prepare for
--    writing game modules, and then for using composer.*.
-- 
-- **************************************************************************
local destroyGame
local createGame
local startGame
local stopGame

local fireMissile
local explodeMissile
local calculateFlightTime

-- **************************************************************************
-- Function Definitions
-- **************************************************************************

--
-- destroyGame( ) - Create the game content
--
destroyGame = function( group )
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   display.remove( layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear current battery variable
   --
   currentBattery = nil   

   -- Clear the tracking table by setting them to nil.
   --
   cities = nil
   batteries = nil

   -- Clear label references so they can be garbage collected
   --
   scoreLabel = nil
   tapToStartLabel = nil

   -- Reset the score
   score = 0
   
end


--
-- createGame( group ) - Create the game content
--
createGame = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   destroyGame()


   -- Create fresh cities batteries tables
   --
   cities = {}
   batteries = {}


   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.trails     = display.newGroup()
   layers.content    = display.newGroup()
   layers.explosions = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.trails )
   layers:insert( layers.content )
   layers:insert( layers.explosions )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( layers.background, "images/protoBack.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 90

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      --for k,v in pairs( event ) do
         --print(k,v)      
      --end

      -- If game is not running yet, exit early
      --
      if( not gameIsRunning ) then return false end


      -- Game is running and player has tapped screen to clear 'tap to begin' message
      -- That is, the enemy missiles are flying and you can now fire back...
      --
      if( event.phase == "ended") then

         -- Fire one of our missiles.
         --

         -- Is a battery selected?  (Always true in this example)
         if( currentBattery ) then

            -- Does this battery have missiles?
            --
            if( currentBattery.missiles > 0 ) then

               -- Subtract one missile and update battery label
               --
               currentBattery.missiles = currentBattery.missiles - 1
               currentBattery.label.text = currentBattery.missiles

               -- Fire the missile
               --
               -- Tips:
               -- > 'currentBattery' has the x,y starting position values.
               -- > 'event' has the target x,y position values.
               --
               fireMissile( currentBattery, event, true )
            end

         end

      end
      return true
   end
   back:addEventListener( "touch" )

   -- Enemy Fire Missile Logic
   --
   local function enemyFires( )
      -- Find target
      --
      -- Create empty targets table      
      local targets = {}
      -- Add all cities that still have buildings
      for k,v in pairs( cities ) do
         if(v.buildings > 0 ) then
            targets[#targets+1] = v
         end
      end
      -- Add all batteries that still have missiles
      for k,v in pairs( batteries ) do
         if( v.missiles > 0 ) then
            targets[#targets+1] = v
         end
      end
      
      -- Game over if no targets
      --
      if( #targets == 0 ) then
         stopGame()
         return
      end
      
      -- Choose random target from table
      --
      local target = targets[mRand(1,#targets)]

      -- Select a random drop point
      local x = mRand( left, right )
      local y = top - missileHeight * 2


      -- Make table containing the point data for this
      --
      local startPoint = { x = x, y = y }

      -- Boom, fire a missile
      --
      local startPoint = { x = x, y = y }
      fireMissile( startPoint, target, false )

      -- Call the 'enemyFires' logic again after a delay
      --
      gameTimer = timer.performWithDelay( mRand( missileMinTime, missileMaxTime ), enemyFires )

      -- Return reference to missile
      return missile          
   end

   -- City Builder Function
   --
   local function newCity( x, y )

      -- Draw a 'city'
      --
      local city = newRect( layers.content,  x, y, citySize, citySize )
      city:setFillColor( unpack( cityColor ) )

      -- Start with 10 buildings per city
      --
      city.buildings = 10

      -- Add a label to represent the city's building count
      city.label = newText( layers.content, city.buildings, x, y, labelFont, mFloor(citySize/3) )
      city.label:setFillColor(0,0,0)

      -- Add city to cities table
      --
      cities[city] = city

      -- Return reference to city
      return city      
   end

   -- Battery Builder Function
   --
   local function newBattery( x, y )
      -- Draw a 'battery'
      --
      local battery = newRect( layers.content,  x, y, batterySize, batterySize )
      battery:setFillColor( unpack( batteryColor ) )

      -- Start with 1000 missiles per battery
      --
      battery.missiles = 1000

      -- Add a label to represent the battery's building count
      battery.label = newText( layers.content, battery.missiles, x, y, labelFont, mFloor(batterySize/3) )
      battery.label:setFillColor(0,0,0)

      -- Add battery to batteries table
      --
      batteries[battery] = battery

      -- If no 'current battery' is selected, select this one
      --
      currentBattery = currentBattery or battery

      -- Return reference to city
      return battery      
   end


   -- Draw Score Label Background and Label
   --
   local scoreBack = newRect( layers.interface, centerX, top + labelBarHeight/2, fullw, labelBarHeight )
   scoreBack:setFillColor( 0.5, 0.5, 0.5 )

   local scoreLabelPrefix = newText( layers.interface, "Score: ", centerX , scoreBack.y, labelFont, labelSize )
   scoreLabelPrefix.anchorX = 1
   scoreLabelPrefix:setFillColor(0,0,0)
   scoreLabel = newText( layers.interface, 0, centerX , scoreBack.y, labelFont, labelSize )
   scoreLabel.anchorX = 0
   scoreLabel:setFillColor(0,0,0)

   -- Tap To Start Label
   --
   tapToStartLabel = newText( layers.interface, "Tap To Start", centerX, centerY, labelFont, labelSize )
   tapToStartLabel:setFillColor(0,0,1)


   -- Draw Ground
   --
   local ground = newRect( layers.background, centerX, bottom, fullw, groundHeight )
   ground.anchorY = 1
   ground:setFillColor( 0.25, 0.25, 0.25 )

   -- Draw Cities
   --
   newCity( centerX - 2 * fullw/5, ground.y - groundHeight/2 )
   newCity( centerX - 1 * fullw/5, ground.y - groundHeight/2 )
   newCity( centerX + 1 * fullw/5, ground.y - groundHeight/2 )
   newCity( centerX + 2 * fullw/5, ground.y - groundHeight/2 )

   -- Draw Battery
   --
   newBattery( centerX, ground.y - groundHeight/2 )

   -- Start the game timer, then pause it immediately
   gameTimer = timer.performWithDelay( 1000, enemyFires )
   timer.pause( gameTimer )  

   -- Mark game as running
   --
   gameIsRunning = true
end   

--
-- startGame( ) - Start the game running
--
startGame = function( )
   
   -- Hide 'tap to start' message
   --
   tapToStartLabel.isVisible = false
   
   -- Resume the timer
   --
   timer.resume( gameTimer )

end

--
-- stopGame( ) - Stop the game running
--
stopGame = function( )   
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.cancel( gameTimer )
      gameTimer = nil
   end

   -- Show 'Game Over' message
   --
   tapToStartLabel.text = "Game Over"
   tapToStartLabel.isVisible = true
   tapToStartLabel:setFillColor( 1, 0, 0 )
end

--
-- fireMissile( startPoint, target, isPlayerMissile )
--
-- startPoint - Table or object with x,y position to start missile from.
--     target - Table or object with x,y position for missile to move towards.
-- isPlayerMissile - Is this a player missile or enemy missile
--
fireMissile = function( startPoint, target, isPlayerMissile )

   -- Draw a 'missile'
   --
   local missile = newRect( layers.content,  startPoint.x, startPoint.y, missileWidth, missileHeight )

   -- Tag the missile with a type for our scoring logic
   --
   missile.isPlayerMissile = isPlayerMissile 

   -- Set appropriate color for missile
   --
   if( isPlayerMissile ) then
      missile:setFillColor( unpack( playerColor ) )
   else
      missile:setFillColor( unpack( enemyColor ) )
   end

   -- Add missile to missiles table
   --
   missiles[missile] = missile

   -- Assign target to missile
   --
   missile.target = target

   -- 'enterFrame' listener
   --
   function missile.enterFrame( self )
      -- Destroy last 'trail' line
      --
      display.remove( self.trail )

      -- Draw new 'trail' line
      --
      self.trail = display.newLine( layers.trails, startPoint.x, startPoint.y, self.x, self.y )
      self.trail.strokeWidth = missileTrailThickness

      -- Set appropriate color for missile trail
      --
      if( isPlayerMissile ) then
         self.trail:setStrokeColor( unpack( playerColor ) )
      else
         self.trail:setStrokeColor( unpack( enemyColor ) )
      end

   end
   Runtime:addEventListener("enterFrame", missile)


   -- 'finalize' listener
   function missile.finalize( self )  
      Runtime:removeEventListener( "enterFrame", self )
      display.remove( self.trail )
   end
   missile:addEventListener( "finalize" )      


   -- 'onComplete' listener - Called when transition is done (target reached).
   --
   function missile.onComplete( self )
      local target = self.target

      -- Call explode function to create an explosion an do some damage
      --
      explodeMissile( missile, target, isPlayerMissile )

   end

   -- Move missile to target
   -- 
   -- Calculate time
   local time = calculateFlightTime( missile, target, isPlayerMissile )

   -- transition.to() target
   transition.to( missile, { x = target.x, y = target.y, time = time, onComplete = missile } )

   -- Return reference to missile
   return missile          
end

--
-- explodeMissile( missile, target, isPlayerMissile ) - Do explosion for this missile
--
--     target - Table or object with x,y position for missile to move towards.
-- isPlayerMissile - Is this a player missile or enemy missile
--
explodeMissile = function( missile, target, isPlayerMissile ) 

   -- Remove missile from the tracking table
   missiles[missile] = nil

   -- Hide the missile
   -- 
   missile.isVisible = false

   -- Choose a maximum radius for this explosion
   --
   local maxRadius = mRand( explosionMinRadius, explosionMaxRadius )

   -- Draw circle 
   --
   local explosion = display.newCircle( layers.explosions, missile.x, missile.y, maxRadius )


   -- Set appropriate color for explosion cloud
   --
   if( isPlayerMissile ) then
      explosion:setFillColor( unpack( playerColor ) )
   else
      explosion:setFillColor( unpack( enemyColor ) )
   end

   -- Forward delcare two helper functions
   --
   local contract
   local boom

   -- Select a time (duration) for expand, contract effects.
   --
   local time = mRand( explosionMinTime, explosionMaxTime )


   -- Helper functions to expand explosion
   --
   local function expand( self )

      -- Start scaled down
      self.xScale = 0.01
      self.yScale = 0.01

      -- Trick: Use 'contract()' function as following transition 'onComplete' listener
      --
      self.onComplete = contract
      
      -- Use transition.to() to do work of expansion
      transition.to( self, { xScale = 1, yScale = 1, time = time/2, 
                             onComplete = self, transition = easing.outCirc } )
   end

   -- Define 'contract()' helper function that shrinks the explosion after it finishes expanding
   --
   contract = function( self )

      -- Trick: Use 'boom()' function as following transition 'onComplete' listener
      --
      self.onComplete = boom

      -- Use transition.to() to do work of contracting (shrinking)
      transition.to( self, { xScale = 0.01, yScale = 0.01, delay = 250, time = time/2, 
                            onComplete = self, transition = easing.inCirc } )

   end


   -- Define 'boom()' function.  This does last minute work associated with the missile type.
   --
   boom = function( self )

      -- Stop listening for 'enterFrame' event
      --
      Runtime:removeEventListener( "enterFrame", self )

      -- Destroy the explosion
      --
      display.remove( self )

      -- Player Missile Actions
      --
      if( isPlayerMissile ) then



      -- Enemy Missile Actions
      --
      else
         if( target.buildings ) then
            target.buildings = ( target.buildings > 0 ) and (target.buildings - 1) or 0
            target.label.text = target.buildings

         elseif( target.missiles ) then
            target.missiles = ( target.missiles > 0 ) and (target.missiles - 1) or 0
            target.label.text = target.missiles
         end
      end

      -- Destroy the missile 
      --
      display.remove( missile )

   end


   -- 'enterFrame' listner 
   --
   -- Every frame, check to see if any of the other missiles is within our current radius
   -- and if so, destroy that missile.
   --
   function explosion.enterFrame( self )

      -- Iterate over missiles table
      --
      for k, v in pairs( missiles ) do

         -- Calculate how far the 'found' missile is from this missile
         --
         local vx = missile.x - v.x
         local vy = missile.y - v.y

         -- Tip: We are using the squared length to save costly square root calculations
         --
         local squared_len = vx * vx + vy * vy 

         -- Determine current 'explosion radius'
         --
         -- Calculatd from current width scale multiplied against max radius we selected 
         -- randomly near beginning of 'explodeMissile()'' function.
         --
         local curRadius = self.xScale * maxRadius

         -- Now compare the squared length and radius
         --
         if( squared_len <= (curRadius * curRadius) ) then
            
            -- Get points for destroying enemy missiles
            --
            if( not self.isPlayerMissile ) then
               score = score + missileValue
               scoreLabel.text = score 
            end

            -- Cancel the missiles transition
            -- 
            transition.cancel( v )

            -- Remove the missile from the list
            -- 
            missiles[k] = nil

            -- Destroy the missile
            -- 
            display.remove( v )
         end

      end

   end
   Runtime:addEventListener( "enterFrame", explosion )   

   -- Start expansion
   --
   expand( explosion )

   
end

--
-- calculateFlightTime( ) - Calculate time needed to fly from A to B at rate.
--
calculateFlightTime = function( pointA, pointB, isPlayerMissile )   
   local vx = pointA.x - pointB.x
   local vy = pointA.y - pointB.y

   local rate = isPlayerMissile and playerMissileSpeed or enemyMissileSpeed

   local len = mSqrt( vx * vx + vy * vy )

   local time = mFloor(1000 * len / rate)

   return time
end


-- **************************************************************************
-- Create The Game
-- **************************************************************************
createGame()

startGame()