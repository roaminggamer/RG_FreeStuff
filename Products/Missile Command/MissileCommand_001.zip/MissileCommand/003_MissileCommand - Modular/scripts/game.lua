-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- game.lua
-- ==========================================================================
local common      = require "scripts.common"
local enemyM      = require "scripts.enemy"
local batteryM    = require "scripts.batteries"
local cityM       = require "scripts.cities"
local missileM    = require "scripts.missiles"
local util        = require "scripts.util"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local game = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
local layers

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

--
-- destroy( ) - Create the game content
--
game.destroy = function( )
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   display.remove( layers )   

	-- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear reference to 'onGameOver' function in common
   --
   common.onGameOver = nil


   -- Clear current battery variable
   --
   common.currentBattery = nil   

   -- Clear the tracking table by setting them to nil.
   --
   common.missiles = nil
   common.cities = nil
   common.batteries = nil

   -- Clear label references so they can be garbage collected
   --
   common.scoreLabel = nil
   common.levelLabel = nil
   common.tapToStartLabel = nil

   -- Reset destroy count
   common.destroyCount = 0

   -- Reset the score
   common.score = 0

   -- Reset level
   common.level = 1

   -- Reset difficulty
   util.updateDifficulty( )

   -- Want to start at a high level to test your settings?
   -- Uncomment this and choose a level
   --
   --[[
   local startLevel = 100
   for i = 1, startLevel do
      common.level = i
      util.updateDifficulty( )
   end
   --]]

end

--
-- create( group ) - Create the game content
--
game.create = function( group, onGameOver )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   game.destroy()

   -- Add reference to 'onGameOver' function in common if provided
   --
   common.onGameOver = onGameOver

   -- Create fresh cities batteries tables
   --
   common.missiles = {}
   common.cities = {}
   common.batteries = {}


   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.trails     = display.newGroup()
   layers.content    = display.newGroup()
   layers.explosions = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.trails )
   layers:insert( layers.content )
   layers:insert( layers.explosions )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( layers.background, "images/background.png", 1140, 760 )
   back.x = centerX
   back.y = bottom
   back.anchorY = 1

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      -- If game is not running yet, exit early
      --
      if( not common.gameIsRunning ) then return false end

      -- Are we waiting to start game logic
      --
      if( common.waitingToBegin and event.phase == "ended" ) then

         game.start()

      -- Game is running and player has tapped screen to clear 'tap to begin' message
      -- That is, the enemy missiles are flying and you can now fire back...
      --
      elseif( event.phase == "ended") then

         -- Fire one of our missiles.
         --

         -- Is a battery selected?  (Always true in this example)
         if( common.currentBattery ) then

            -- Does this battery have missiles?
            --
            if( common.currentBattery:count() > 0 ) then

               -- Remove one missile and update battery label
               --
               common.currentBattery:useMissile()

               -- Fire the missile
               --
               -- Tips:
               -- > 'currentBattery' has the x,y starting position values.
               -- > 'event' has the target x,y position values.
               --
               missileM.create( layers.content, layers.trails, common.currentBattery, event, true )

               -- Play "Woosh" sound
               audio.play( common.sounds.woosh )
            end

         end

      end
      return true
   end
   back:addEventListener( "touch" )


   -- Label Background and Labels
   --
   local labelBack = newRect( layers.interface, centerX, top + common.labelBarHeight/2, fullw, common.labelBarHeight )
   labelBack:setFillColor( 0.5, 0.5, 0.5 )

   local levelLabelPrefix = newText( layers.interface, "Level: ", centerX - 140, labelBack.y, common.labelFont, common.labelSize )
   levelLabelPrefix.anchorX = 1
   levelLabelPrefix:setFillColor(0,0,0)
   common.levelLabel = newText( layers.interface, common.level, centerX - 140, labelBack.y, common.labelFont, common.labelSize )
   common.levelLabel.anchorX = 0
   common.levelLabel:setFillColor(0,0,0)

   local scoreLabelPrefix = newText( layers.interface, "Score: ", centerX + 200, labelBack.y, common.labelFont, common.labelSize )
   scoreLabelPrefix.anchorX = 1
   scoreLabelPrefix:setFillColor(0,0,0)
   common.scoreLabel = newText( layers.interface, 0, centerX + 200, labelBack.y, common.labelFont, common.labelSize )
   common.scoreLabel.anchorX = 0
   common.scoreLabel:setFillColor(0,0,0)




   -- Tap To Start Label
   --
   common.tapToStartLabel = newText( layers.interface, "Tap To Start", centerX, centerY, common.labelFont, common.labelSize )
   common.tapToStartLabel:setFillColor(0,0,1)

   -- Draw Cities
   --
   cityM.create( layers.content, centerX - 2 * fullw/5, common.cityY )
   cityM.create( layers.content, centerX - 1 * fullw/5, common.cityY )
   cityM.create( layers.content, centerX + 1 * fullw/5, common.cityY )
   cityM.create( layers.content, centerX + 2 * fullw/5, common.cityY )

   -- Draw Battery
   --
   batteryM.create( layers.content, centerX, common.cityY )

   -- Start the game timer, then pause it immediately
   gameTimer = performWithDelay( 1000, 
      function() 
         enemyM.fire( layers.content, layers.trails ) 
      end )
   timer.pause( gameTimer )  

   -- Mark 'waiting' flag as true
   --
   common.waitingToBegin = true

   -- Play "Ready To Start" sound
   audio.play( common.sounds.ready )

   -- Mark game as running
   --
   common.gameIsRunning = true
end   

--
-- start( ) - Start the game running
--
game.start = function( )


   -- Play "Start Game" sound
   audio.play( common.sounds.go )

   -- Clear the flag
   --
   common.waitingToBegin = false

   -- Update label with temporary 'go' message
   common.tapToStartLabel.text = "Incoming!"
   performWithDelay( 1000,
      function() 
         if( common.gameIsRunning )  then
            common.tapToStartLabel.isVisible = false
         end
      end )

   
   -- Resume the timer
   --
   timer.resume( gameTimer )
end

--
-- stop( ) - Stop the game running
--
game.stop = function( )   

   -- Exit early if game is not longer running
   --
   if( not common.gameIsRunning  ) then return end


   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- Pause all transitions tagged with "missilecommand"
   --
   transition.pause( "missilecommand" )


   -- If game timer is running, cancel it
   if( gameTimer ) then
      timer.cancel( gameTimer )
      gameTimer = nil
   end

   -- Show 'Game Over' message
   --
   common.tapToStartLabel.text = "Game Over"
   common.tapToStartLabel.isVisible = true
   common.tapToStartLabel:setFillColor( 1, 0, 0 )

	-- Play "Game Over" sound
   audio.play( common.sounds.gameOver )   


   -- If onGameOver function was provided, call it.
   --
   if( common.onGameOver ) then
      common.onGameOver()
   end


end

--
-- pause( ) - Like stopping, but non-destructive.
--
game.pause = function( )
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- Pause all transitions tagged with "missilecommand"
   transition.pause( "missilecommand" )

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end
end

--
-- resume( ) - Start the game running
--
game.resume = function( )   
   -- Mark game as 'running'
   common.gameIsRunning = true

   -- Resume all transitions tagged with "missilecommand"
   transition.resume( "missilecommand" )

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.resume( gameTimer )
   end
end





return game