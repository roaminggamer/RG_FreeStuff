-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- enemy.lua
-- ==========================================================================
local common      = require "scripts.common"
local missileM    = require "scripts.missiles"
local util        = require "scripts.util"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local enemyM = {}

-- Enemy Fire Missile Logic
--
function enemyM.fire( missilesGroup, trailsGroup )
   -- Find target
   --
   -- Create empty targets table      
   local targets = {}
   -- Add all cities that still have buildings
   for k,v in pairs( common.cities ) do
      if(#v.buildings > 0 ) then
         targets[#targets+1] = v
      end
   end

   -- Game over if no targets (out of cities equal 'dead')
   --
   if( #targets == 0 ) then
      local game = require "scripts.game"
      game.stop()
      return
   end

   -- Add all batteries that still have missiles
   for k,v in pairs( common.batteries ) do
      if( #v.activeMissiles > 0 ) then
         targets[#targets+1] = v
      end
   end
      
   -- Choose random target from table
   --
   local target = targets[mRand(1,#targets)]

   -- Select a random drop point
   local x = mRand( left, right )
   local y = top - common.missileHeight * 2


   -- Make table containing the point data for this
   --
   local startPoint = { x = x, y = y }

   -- Boom, fire a missile
   --
   local startPoint = { x = x, y = y }
   missileM.create( missilesGroup, trailsGroup, startPoint, target, false )

   -- Call the 'enemyFires' logic again after a delay
   --
   local nextFireTime = mRand( common.missileMinTime, common.missileMaxTime ) * common.timeMultiple
   --print( "nextFireTime == " .. nextFireTime )
   gameTimer = performWithDelay( nextFireTime,
      function()
         enemyM.fire( missilesGroup, trailsGroup )
      end )

   -- Return reference to missile
   return missile          
end



return enemyM