-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- util.lua
-- ==========================================================================
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local util = {}

-- This function sets various values to account for the
-- selected current game/difficulty level
function util.updateDifficulty( )

   -- Reset at level 1
   if( common.level == 1 ) then
      common.speedMultiple = 1
      common.timeMultiple = 1
   
   -- Adjust accordingly at other levels
   else

      common.speedMultiple = common.speedMultiple * 1.05
      common.timeMultiple = common.timeMultiple * 0.95

      -- Cap values
      common.speedMultiple  = ( common.speedMultiple > 5 ) and 5 or common.speedMultiple 
      common.timeMultiple  = ( common.timeMultiple < 0.1  ) and 0.1 or common.timeMultiple 
   end
end

-- This function returns true if point is somewhere within the 
-- bounds of object.
function util.isInBounds( point, object )
   if(not object) then return false end
   local bounds = object.contentBounds
   if( point.x > bounds.xMax ) then return false end
   if( point.x < bounds.xMin ) then return false end
   if( point.y > bounds.yMax ) then return false end
   if( point.y < bounds.yMin ) then return false end
   return true
end




return util