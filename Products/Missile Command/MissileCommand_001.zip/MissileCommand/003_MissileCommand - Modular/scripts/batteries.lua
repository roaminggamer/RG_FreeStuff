-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- batteries.lua
-- ==========================================================================
local common      = require "scripts.common"
local util        = require "scripts.util"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local batteryM = {}

-- Battery Builder Function
--
function batteryM.create( group, x, y )
   -- Draw a 'battery'
   --
   local battery = newRect( group, x, y, common.batterySize, common.batterySize )
   battery.isVisible = false


   -- Create this battery's missiles
   --
   battery.activeMissiles = {}
   battery.usedMissiles = {}
   -- Attempt to place them in a nice distribution if possible
   for i = 1, common.missilesPerBattery do
      local missile = newImageRect( group, "images/pmissile.png", 16, 16 )
      local attempts = 0
      local canPlace = false
      local px, py
      while( not canPlace and attempts < 10 ) do
         if( #battery.activeMissiles > 0 ) then
            px = x + mRand(  -common.batterySize/2, common.batterySize/2 )
            py = y + mRand(  -common.batterySize/2, common.batterySize/2 )
            local hit = false
            for j = 1, i-1 do
               hit = hit or  util.isInBounds( { x = px, y = py }, battery.activeMissiles[j])
            end
            canPlace = not hit               
         else
            px = x
            py = y
            canPlace = true
         end
         attempts = attempts + 1
      end
      missile.x = px
      missile.y = py
      battery.activeMissiles[i] = missile
   end

   -- Add method to return active missile count
   -- 
   function battery.count( self )
      return #self.activeMissiles
   end

   -- Add method to move active missiles to used 'status'
   -- 
   function battery.useMissile( self )
      -- Copy missile reference from last slto in active table to next available slot
      -- in used table.
      self.usedMissiles[#self.usedMissiles+1] = self.activeMissiles[#self.activeMissiles]

      -- Hide the missile
      self.activeMissiles[#self.activeMissiles].isVisible = false

      -- Clear last slot in active table
      self.activeMissiles[#self.activeMissiles] = nil
   end

   -- Add method to move all 'used' missiles back to active status
   -- 
   function battery.restoreMissiles( self )
      while( #self.usedMissiles > 0 ) do
         self.usedMissiles[#self.usedMissiles].isVisible = true
         self.activeMissiles[#self.activeMissiles+1] = self.usedMissiles[#self.usedMissiles]
         self.usedMissiles[#self.usedMissiles] = nil
      end
   end


   -- Add battery to batteries table
   --
   common.batteries[battery] = battery

   -- If no 'current battery' is selected, select this one
   --
   common.currentBattery = common.currentBattery or battery

   -- Return reference to city
   return battery      
end


return batteryM