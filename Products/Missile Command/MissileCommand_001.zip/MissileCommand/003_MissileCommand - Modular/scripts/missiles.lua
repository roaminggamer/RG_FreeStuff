-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- missiles.lua
-- ==========================================================================
local common      = require "scripts.common"
local util        = require "scripts.util"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local missileM = {}

--
-- fireMissile( startPoint, target, isPlayerMissile )
--
-- startPoint - Table or object with x,y position to start missile from.
--     target - Table or object with x,y position for missile to move towards.
-- isPlayerMissile - Is this a player missile or enemy missile
--
function missileM.create( missileGroup, trailGroup, startPoint, target, isPlayerMissile )

   -- Draw a 'missile'
   --
   local missile 
   if( isPlayerMissile ) then
      missile = newImageRect( missileGroup, "images/pmissile.png", common.missileWidth, common.missileHeight )
      missile.isPlayerMissile = isPlayerMissile

   else
      missile = newImageRect( missileGroup, "images/emissile.png", common.missileWidth, common.missileHeight )
      missile.isPlayerMissile = false
   end
   missile.x = startPoint.x
   missile.y = startPoint.y


   -- Add missile to missiles table
   --
   common.missiles[missile] = missile

   -- Assign target to missile
   --
   missile.target = target

   -- Rotate missile to face movent direction
   --

   local vx = target.x - missile.x
   local vy = target.y - missile.y
   missile.rotation = mCeil(mAtan2(vy,vx)*180/mPi)+90

   -- 'enterFrame' listener
   --
   function missile.enterFrame( self )
      -- Destroy last 'trail' line
      --
      display.remove( self.trail )

      -- Draw new 'trail' line
      --
      self.trail = display.newLine( trailGroup, startPoint.x, startPoint.y, self.x, self.y )
      self.trail.strokeWidth = common.missileTrailThickness

      -- Set appropriate color for missile trail
      --
      if( isPlayerMissile ) then
         self.trail:setStrokeColor( unpack( common.playerColor ) )
      else
         self.trail:setStrokeColor( unpack( common.enemyColor ) )
      end

   end
   Runtime:addEventListener("enterFrame", missile)


   -- 'finalize' listener
   function missile.finalize( self )  
      Runtime:removeEventListener( "enterFrame", self )
      display.remove( self.trail )
   end
   missile:addEventListener( "finalize" )      


   -- 'onComplete' listener - Called when transition is done (target reached).
   --
   function missile.onComplete( self )
      local target = self.target

      -- Call explode function to create an explosion an do some damage
      --
      missileM.explodeMissile( missile, target, isPlayerMissile )

   end

   -- Move missile to target
   -- 
   -- Calculate time
   local time = missileM.calculateFlightTime( missile, target, isPlayerMissile )

   -- transition.to() target
   transition.to( missile, { x = target.x, y = target.y, time = time, 
                             onComplete = missile, tag = "missilecommand" } )

   -- Return reference to missile
   return missile          
end

--
-- explodeMissile( missile, target, isPlayerMissile ) - Do explosion for this missile
--
--     target - Table or object with x,y position for missile to move towards.
-- isPlayerMissile - Is this a player missile or enemy missile
--
function missileM.explodeMissile( missile, target, isPlayerMissile ) 
   -- If game is not running yet, exit early
   --
   if( not common.gameIsRunning ) then return false end
   

   -- Play explosion sound
   audio.play( common.sounds["explosion" .. mRand(1,3)] )

   -- Remove missile from the tracking table
   common.missiles[missile] = nil

   -- Hide the missile
   -- 
   missile.isVisible = false

   -- Choose a maximum radius for this explosion
   --
   local maxRadius = mRand( common.explosionMinRadius, common.explosionMaxRadius )

   -- Draw Image 
   --
   local explosion 
   if( isPlayerMissile ) then
      explosion = newImageRect( missile.parent, "images/pexp.png", maxRadius, maxRadius )
      explosion.rotation = mRand(0,360)
   else
      --explosion = newImageRect( missile.parent, "images/eexp.png", maxRadius, maxRadius )
      --explosion.rotation = mRand(0,360)
      explosion = newImageRect( missile.parent, "images/groundexp.png", maxRadius, maxRadius )
   end
   explosion.x = missile.x
   explosion.y = missile.y
   

   -- Forward delcare two helper functions
   --
   local contract
   local boom

   -- Select a time (duration) for expand, contract effects.
   --
   local time = mRand( common.explosionMinTime, common.explosionMaxTime )


   -- Helper functions to expand explosion
   --
   local function expand( self )
      -- If game is not running yet, exit early
      --
      if( not common.gameIsRunning ) then return false end

      -- Start scaled down
      self.xScale = 0.01
      self.yScale = 0.01

      -- Trick: Use 'contract()' function as following transition 'onComplete' listener
      --
      self.onComplete = contract
      
      -- Use transition.to() to do work of expansion
      transition.to( self, { xScale = 1, yScale = 1, time = time/2, 
                             onComplete = self, transition = easing.outCirc,
                             tag = "missilecommand" } )
   end

   -- Define 'contract()' helper function that shrinks the explosion after it finishes expanding
   --
   contract = function( self )

      -- Trick: Use 'boom()' function as following transition 'onComplete' listener
      --
      boom(self)


      -- Use transition.to() to do work of contracting (shrinking)
      transition.to( self, { xScale = 0.01, yScale = 0.01, delay = 250, time = time/2, 
                            transition = easing.inCirc,
                            tag = "missilecommand" } )

   end


   -- Define 'boom()' function.  This does last minute work associated with the missile type.
   --
   boom = function( self )
      -- If game is not running yet, exit early
      --
      if( not common.gameIsRunning ) then return false end


      -- Stop listening for 'enterFrame' event
      --
      Runtime:removeEventListener( "enterFrame", self )

      -- Destroy the explosion
      --
      display.remove( self )

      -- Player Missile Actions
      --
      if( missile.isPlayerMissile ) then


      -- Enemy Missile Actions
      --
      else
         if( target.buildings ) then
            if( #target.buildings > 0 ) then
               display.remove( target.buildings[#target.buildings] )
               target.buildings[#target.buildings] = nil 
               
               -- Play kill building/battery sound
               audio.play( common.sounds.buildingkill )
          
            end            

         elseif( target.activeMissiles ) then
            if( #target.activeMissiles > 0 ) then

               -- Use battery's built-in 'useMissile' function to hide a missile
               --
               target:useMissile()
               
               -- Play kill building/battery sound
               audio.play( common.sounds.buildingkill )

            end            
         end
      end

      -- Destroy the missile 
      --
      display.remove( missile )

   end


   -- 'enterFrame' listner 
   --
   -- Every frame, check to see if any of the other missiles is within our current radius
   -- and if so, destroy that missile.
   --
   function explosion.enterFrame( self )
      -- Exit early if game is not longer running
      --
      if( not common.gameIsRunning  ) then return end
      
      -- Iterate over missiles table
      --
      for k, v in pairs( common.missiles ) do

         -- Calculate how far the 'found' missile is from this missile
         --
         local vx = missile.x - v.x
         local vy = missile.y - v.y

         -- Tip: We are using the squared length to save costly square root calculations
         --
         local squared_len = vx * vx + vy * vy 

         -- Determine current 'explosion radius'
         --
         -- Calculatd from current width scale multiplied against max radius we selected 
         -- randomly near beginning of 'explodeMissile()'' function.
         --
         local curRadius = self.xScale * maxRadius

         -- Now compare the squared length and radius
         --
         if( squared_len <= (curRadius * curRadius) ) then
            
            -- Get points for destroying enemy missiles
            --
            if( not v.isPlayerMissile  ) then
               common.score = common.score + common.missileValue
               common.scoreLabel.text = common.score 

               -- Play missile (mid-air) kill sound
               audio.play( common.sounds.missilekill )               

               -- Increment destroy count
               --
               common.destroyCount = common.destroyCount + 1
            end

            -- Cancel the missiles transition
            -- 
            transition.cancel( v )

            -- Remove the missile from the list
            -- 
            common.missiles[k] = nil

            -- Destroy the missile
            -- 
            display.remove( v )

         end

      end

      -- Check to see if it is time to level up
      if(  common.gameIsRunning and 
           missile.isPlayerMissile and
           common.destroyCount >= common.levelUpDestroyCount ) then

         -- Clear destroy count
         common.destroyCount = 0

         -- increment level
         common.level = common.level  + 1

         -- Update level label
         common.levelLabel.text = common.level

         -- calculate new difficulty settings
         util.updateDifficulty( )         

         -- restore used missiles
         for k,v in pairs(common.batteries) do
            v:restoreMissiles()
         end

         -- Play "Level up" sound
         audio.play( common.sounds.levelUp )
      end

   end
   Runtime:addEventListener( "enterFrame", explosion )   


   -- Add finalize listener to 'explosion' to clean up if object is deleted mid-explosion
   --
   function explosion.finalize( self )
      Runtime:removeEventListener("enterFrame", self)
   end
   explosion:addEventListener("finalize")



   -- Start expansion
   --
   expand( explosion )
   
end

--
-- calculateFlightTime( ) - Calculate time needed to fly from A to B at rate.
--
function missileM.calculateFlightTime( pointA, pointB, isPlayerMissile )   
   local vx = pointA.x - pointB.x
   local vy = pointA.y - pointB.y

   local rate = isPlayerMissile and common.playerMissileSpeed or common.enemyMissileSpeed

   rate = rate * common.speedMultiple

   local len = mSqrt( vx * vx + vy * vy )

   local time = mFloor(1000 * len / rate)

   return time
end




return missileM