-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- cities.lua
-- ==========================================================================
local common      = require "scripts.common"
local util        = require "scripts.util"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.ceil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local cityM = {}

-- City Builder Function
--
function cityM.create( group, x, y )

   -- Draw a 'city'
   --
   local city = newRect( group,  x, y, common.citySize, common.citySize )
   city.isVisible = false

   -- Create this city's buildings
   --
   city.buildings = {}
   -- Attempt to place them in a nice distribution if possible
   for i = 1, common.buildingsPerCity do
      local building = newImageRect( group, "images/building.png", 32, 32 )
      local attempts = 0
      local canPlace = false
      local px, py
      while( not canPlace and attempts < 10 ) do
         if( #city.buildings > 0 ) then
            px = x + mRand(  -common.citySize/2, common.citySize/2 )
            py = y + mRand(  -common.citySize/2, common.citySize/2 )
            local hit = false
            for j = 1, i-1 do
               hit = hit or  util.isInBounds( { x = px, y = py }, city.buildings[j])
            end
            canPlace = not hit               
         else
            px = x
            py = y
            canPlace = true
         end
         attempts = attempts + 1
      end
      building.x = px
      building.y = py
      city.buildings[i] = building
   end

   -- Add city to cities table
   --
   common.cities[city] = city

   -- Return reference to city
   return city      
end


return cityM