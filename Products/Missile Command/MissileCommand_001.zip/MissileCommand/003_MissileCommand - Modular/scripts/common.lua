-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- This module contains common settings and is also used by the
-- other modules as a 'scratch-pad' for sharing references and
-- values between modules instead of using globals.
--
-- =============================================================


common = {}

common.level 						 = 1			-- Current game/difficulty level
common.speedMultiple				 = 1			-- General variable used to increase speeds of various logic at higher levels
common.timeMultiple				 = 1			-- General variable used to decrease timer delays  of various logic at higher levels

common.levelUpDestroyCount 	 = 3			-- Level up after destroying 3 missiles
common.destroyCount 				 = 0        -- Missiles destroyed since last level up

common.gameIsRunning           = false    -- Flag to help track if game is running
common.waitingToBegin          = true

common.missileValue            = 10       -- Value for destroying a missile

common.missileMinTime          = 1000     -- Minimum time (in millseconds) between missile firing
common.missileMaxTime          = 3000     -- Maximum time (in millseconds) between missile firing

common.missiles                = {}			
common.cities                  = {}       -- Table to store city object references in
common.batteries               = {}       -- Table to store silo object references in

common.missileWidth            = 20       -- missile width
common.missileHeight           = 20       -- missile height
common.missileTrailThickness   = 4        -- Thickness of trail behind missiles

common.explosionMinRadius      = 80       -- Minimum radius for explosion (used to vary explosions)
common.explosionMaxRadius      = 120      -- Maximum radius for explosion (used to vary explosions)

common.explosionMinTime        = 1000     -- Minimum time for expansion and contraction effect (used to vary explosions)
common.explosionMaxTime        = 2000     -- Maximum time for expansion and contraction effect (used to vary explosions)

common.playerMissileSpeed      = 150      -- Player missile speed in pixels-per-second
common.enemyMissileSpeed       = 60       -- Enemy missile speed in pixels-per-second

common.enemyColor              = { 0xac/255, 0x39/255, 0x39/255, 0.5 }

common.playerColor             = { 0x36/255, 0xbb/255, 0xf5/255, 0.5 }

common.buildingsPerCity        = 5
common.citySize                = 100

common.missilesPerBattery      = 20
common.batterySize             = 100

common.cityY                   = bottom - 60
common.cityColor               = { 0, 1, 0 }
common.batteryColor            = { 1, 1, 0 }
                                       
common.labelBarHeight          = 80        -- Height label background bar
common.labelFont               = "Nasalization 3D.ttf"
common.labelSize               = 40


-- (Pre-) Load some sounds for use in our game
--
common.sounds = {}
common.sounds.ready = audio.loadSound( "sounds/ready.ogg" )
common.sounds.go = audio.loadSound( "sounds/go.ogg" )
common.sounds.gameOver = audio.loadSound( "sounds/gameOver.ogg" )

common.sounds.explosion1 = audio.loadSound( "sounds/explosion1.ogg" )
common.sounds.explosion2 = audio.loadSound( "sounds/explosion2.ogg" )
common.sounds.explosion3 = audio.loadSound( "sounds/explosion3.ogg" )

common.sounds.missilekill = audio.loadSound( "sounds/coin4.ogg" )
common.sounds.buildingkill = audio.loadSound( "sounds/hurt5.ogg" )

common.sounds.woosh = audio.loadSound( "sounds/woosh.wav" )

common.sounds.levelUp = audio.loadSound( "sounds/levelUp.ogg" )

--common.sounds.test = audio.loadSound( "sounds/levelUp.ogg" )
--audio.play( common.sounds.test )


return common