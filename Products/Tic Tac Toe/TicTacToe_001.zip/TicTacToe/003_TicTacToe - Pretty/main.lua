-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------

-- Locals
local pieceSize		= 130	
local currentTurn		= "X"   -- String variable used to track whose turn it is.  X always starts.
local theBoard			= {}	-- Table used to store the board pieces
local gameIsRunning	= true  -- Boolean variable used to track whether game is running or over.

-- Screen Centers
local centerX = display.contentWidth/2  
local centerY = display.contentHeight/2

-- Labels & Buttons
local currentTurnMsg        -- Empty variable that will be used to store the handle to a text object 
                            -- representing the �whose turn� marker.

local currentTurnImg			 -- Image for current turn.

local gameStatusMsg         -- Empty variable that will be used to store the handle to a text object 
                            -- representing the game status message.

local gameWinnerImg         -- Image shown for game winner if there is one

local resetGameButton       -- Empty variable that will be used to store the handle to a rectangle 
                            -- object that will be used as the game reset button.
							  
local resetGameButtonText   -- Empty variable that will be used to store the handle to a text object 
                            -- that will be used as the game reset button label. 


-- Function Declarations
local createPiece
local createBoard             -- Function to draw the game board.

local checkForWinner        -- Function to check the board data (theBoard) grid for a winner.
local boardIsFull           -- Function to check if board is completely full (no blank spaces).  Used for stalemate testing.

-- Listener Declarations
local onTouchPiece          -- Listener to handle touches on board pieces.
local onTouchResetButton    -- Listener to handle touches on the reset button (resetGameButton).

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--    createPiece() - Draws a single tic-tac-toe game piece (tile).
-- ==
createPiece = function( x , y, size )
	-- 
	-- A. Create the rectangle first (so it is displayed on the bottom)
	--
	local piece =  display.newImageRect( "images/blanktile.png", size, size )
			
	-- Move the piece (The default position was <0,0>)			
	piece.x = x
	piece.y = y

	-- Initialize piece value as 'blank'
	piece.value = ""

	-- Add a "touch" listener to the grid piece (rectangle object). 
	piece:addEventListener( "touch", onTouchPiece )

	return piece
end


-- ==
--    createBoard() - Draws the tic-tac-toe game board.
-- ==
createBoard = function()

	local startX    = centerX - pieceSize  -- Column 1 starts once-piece width left of center
	local startY    = centerY - pieceSize  -- Row 1 starts once-piece height above center

	-- 0. Add a background image that will display nicely on ALL devices.
	--
	-- This works nicely with the currently selected resolution in config.lua for all devices.
	--
	local back = display.newImageRect( "images/interface/backImage.png", 1140, 760 )
	back.x = centerX
	back.y = centerY

	--
	-- 1. Draw the board (3-by-3 grid of text objects over rectangles).
	--
	for row = 1, 3 do
		local y = startY + (row - 1) * pieceSize
		theBoard[row] = { {}, {}, {} } 

		for col = 1, 3 do
			local x = startX + (col - 1) * pieceSize

			local piece =  createPiece( x, y, pieceSize )

			-- Store this boardPiece in our generic table of pieces
			theBoard[row][col] = piece

		end
	end		

	--
	-- 2. Add a current turn label and image.
	--
	currentTurnMsg = display.newText( "Turn: " , 0, 0, "Prime.ttf", 48 )
	currentTurnMsg.x = centerX
	currentTurnMsg.y = centerY - 2 * pieceSize
	currentTurnMsg.anchorX = 1

	currentTurnImg = display.newImageRect( "images/boymarker.png", 96, 96 )
	currentTurnImg.x = centerX
	currentTurnImg.y = currentTurnMsg.y
	currentTurnImg.anchorX = 0


	--
	-- 3. Add a winner indicator (text object).
	--
	gameStatusMsg = display.newText( "No winner yet..." , 0, 0, "Prime.ttf", 48 )
	gameStatusMsg.x = centerX
	gameStatusMsg.y = centerY + 2 * pieceSize -- Spaced two piece heights below center.

	--
	-- 4. Add a button to reset the game (text object over a rectangle).
	--

	--
	-- A. Create the rectangle base first.
	-- 
	resetGameButton = display.newImageRect( "images/buttonBack.png", 400, 80 ) 

	-- Again, change reference point of rectangle, then position it.
	resetGameButton.x = centerX
	resetGameButton.y = centerY - 2 * pieceSize -- Spaced two piece heights above center.

	-- Add a different listener unique to just this button (rectangle)
	resetGameButton:addEventListener( "touch", onTouchResetButton )

	-- Hide the button (rectangle) for now.
	resetGameButton.isVisible = false

	--
	-- B. Create the text label second.
	--
	-- Again, create the text object, then position it to get the results we want.
	resetGameButtonText =  display.newText( "Reset Game", 0, 0, "Prime.ttf", 48 )
	resetGameButtonText.x = centerX
	resetGameButtonText.y = centerY - 2 * pieceSize -- Spaced two piece heights above center.

	-- Hide the label (text object)
	resetGameButtonText.isVisible = false	
			
end

-- Naive/Brute Force way to testing for a winner.
-- ==
--    checkForWinner() - This function checks to see if either "X" or "O" has won the game.
--                       It does this using a naive/brute force approach. i.e. It explicitly checks
--                       each win cases.  This is OK for a 3-by-3 grid, but if the game and board
--                       used more grids, we would need to come up with an algorithmic check.
--
-- ==
checkForWinner = function( turn )

	local bd = theBoard

	if(bd[1][1].value == turn and  bd[1][2].value == turn and bd[1][3].value == turn) then -- COL 1
		return true
	
	elseif(bd[2][1].value == turn and  bd[2][2].value == turn and bd[2][3].value == turn) then -- COL 2
		return true
	
	elseif(bd[3][1].value == turn and  bd[3][2].value == turn and bd[3][3].value == turn) then -- COL 3
		return true

	elseif(bd[1][1].value == turn and  bd[2][1].value == turn and bd[3][1].value == turn) then -- ROW 1
		return true
	
	elseif(bd[1][2].value == turn and  bd[2][2].value == turn and bd[3][2].value == turn) then -- ROW 2
		return true
	
	elseif(bd[1][3].value == turn and  bd[2][3].value == turn and bd[3][3].value == turn) then -- ROW 3
		return true

	elseif(bd[1][1].value == turn and  bd[2][2].value == turn and bd[3][3].value == turn) then -- DIAGONAL 1 (top-to-bottom)
		return true

	elseif(bd[1][3].value == turn and  bd[2][2].value == turn and bd[3][1].value == turn) then -- DIAGONAL 2 (bottom-to-top)
		return true
	
	end 

	return false
end


-- ==
--    boardIsFull() - Checks to see if all grids are marked.  Returns false if one or more grids are blank.
-- ==
boardIsFull = function( )

	local bd = theBoard

	for i = 1, 3 do
		for j = 1, 3 do
			-- Is the grid entry empty?
			if( bd[i][j].value == "" ) then 
				return false 
			end
		end
	end

	return true
end


--==
-- ================================= LISTENER DEFINITIONS
--==


-- ==
--    onTouchPiece() - Touch listener function.  
-- ==
onTouchPiece = function( event )
	
	-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	local phase  = event.phase  
	local target = event.target

	-- If the game is over, then ignore this touch
	if( not gameIsRunning ) then
		return true
	end

	-- Don't do anything unless this is the "ended" phase, 
	-- meaning the player touched a piece and then lifted their finger.
	if( phase == "ended" ) then
		
		-- Is the marker for this piece empty?
		-- Tip: Remember, when we created the board piece, we added a reference to the text object
		--      to our rectangle.  That allowed us to use the rectangle as the touch object, and 
		--      yet still know the proper text object to check.
		-- 

		if( target.value == "" ) then

			-- The marker was empty, so set it to "X" or "O" (whoever's turn it is now).
			target.value = currentTurn

			print( currentTurn )

			-- Set the marker to the appropriate graphic
			if( currentTurn == "X" ) then
				target.fill = { type = "image", filename = "images/boytile.png" }
			else
				target.fill = { type = "image", filename = "images/girltile.png" }
			end

			-- Now that we've updated the data table, check to see if we have a winner
			-- or a stalemate (no winner with full board).

			if( checkForWinner( currentTurn ) ) then
				print("Winner is: " .. currentTurn )

				-- We have a winner.  Update the message, set the game as 'over', and
				-- reveal the reset button and its label.
				--
				gameStatusMsg.text = "wins!"
				currentTurnMsg.isVisible = false
				currentTurnImg.isVisible = false
				gameIsRunning = false

				-- Show image for winner
				if( currentTurn == "X" ) then
					gameWinnerImg = display.newImageRect( "images/boymarker.png", 96, 96 )
				else
					gameWinnerImg = display.newImageRect( "images/girlmarker.png", 96, 96 )
				end
				gameWinnerImg.x = gameStatusMsg.x - gameWinnerImg.contentWidth/2 - gameStatusMsg.contentWidth/2
				gameWinnerImg.y = gameStatusMsg.y

				resetGameButton.isVisible = true
				resetGameButtonText.isVisible = true


			elseif( boardIsFull() ) then
				print("No winner!  We have a stalemate")

				-- We have a stalemate.  Update the message, set the game as 'over', and
				-- reveal the reset button and its label.
				--
				gameStatusMsg.text = "Stalemate!"
				currentTurnMsg.isVisible = false
				currentTurnImg.isVisible = false
				gameIsRunning = false

				resetGameButton.isVisible = true
				resetGameButtonText.isVisible = true

			end
			
			if( currentTurn == "X" ) then
				currentTurn = "O"
				currentTurnImg.fill = { type = "image", filename = "images/girlmarker.png" }
			else
				currentTurn = "X"
				currentTurnImg.fill = { type = "image", filename = "images/boymarker.png" }
			end

			currentTurnMsg.text = "Turn:"


		end
	end

	return true
end

-- ==
--    onTouchResetButton() - Touch handler function for the reset button.
-- ==
onTouchResetButton = function( event )
	local phase  = event.phase
	local target = event.target

	-- Reset the board markers and board data. i.e. Clear them.
	for row = 1, 3 do
		for col = 1, 3 do
			-- Clear the board text for this piece
			theBoard[row][col].value = ""

			-- Reset the image too
			theBoard[row][col].fill = { type = "image", filename = "images/blanktile.png" }
		end
	end

	-- Destroy the winner image 
	display.remove( gameWinnerImg )
	gameWinnerImg = nil

	-- Reset the current turn to "X"
	currentTurn = "X"

	-- Reset the messages to their initial values.
	currentTurnMsg.text = "Turn:"
	currentTurnMsg.isVisible = true
	currentTurnImg.fill = { type = "image", filename = "images/boymarker.png" }
	currentTurnImg.isVisible = true
	gameStatusMsg.text = "No winner yet..."

	-- Enable the game
	gameIsRunning = true

	-- Hide the reset button
	resetGameButton.isVisible = false
	resetGameButtonText.isVisible = false

	return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
createBoard( )
