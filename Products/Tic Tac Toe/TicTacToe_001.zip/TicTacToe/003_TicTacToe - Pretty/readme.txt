Pretty
------

This version of the game adds some basic art work to beautify the game.
