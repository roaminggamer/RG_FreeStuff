-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- This module contains common settings and is also used by the
-- other modules as a 'scratch-pad' for sharing references and
-- values between modules instead of using globals.
--
-- =============================================================

local common = {}



return common