-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
local ttt = require "scripts.tictactoe"

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar


----------------------------------------------------------------------
--	3. Create Game
----------------------------------------------------------------------

-- Create two simulataneous games as a test of the module

-- Game #1
local container1 = display.newContainer( 640, 480 )
container1.x = display.contentCenterX
container1.y = display.contentCenterY - 240

local game1 = ttt.new( container1, { scale = 0.65  } )
game1.createBoard( 0, 0 )



-- Game #2
local container2 = display.newContainer( 640, 480 )
container2.x = display.contentCenterX
container2.y = display.contentCenterY + 240

local game2 = ttt.new( container2, { scale = 0.65, images = "images/alt/"  } )
game2.createBoard( 0, 0 )
