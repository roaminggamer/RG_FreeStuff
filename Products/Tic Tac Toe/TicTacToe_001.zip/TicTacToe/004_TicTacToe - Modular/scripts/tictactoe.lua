-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- tictactoe.lua  - Game Module
-- =============================================================

-- Locals
local centerX = display.contentWidth/2  
local centerY = display.contentHeight/2

----------------------------------------------------------------------
-- Module Begins
----------------------------------------------------------------------
local ttt = {}

-- create( sceneGroup, params )
--
-- sceneGroup - displayGroup to place all game content in when we create it.
-- params - Table of (optional) named parameters:
--  >> pieceSize (130)  - Size of individual pieces
--  >> enableBackground (true) - If 'false', no background image is created.
--  >> images ('images/default') - Path to game art.
--
function ttt.new( sceneGroup, params )

	-- Provide defaults if no values are supplied
	sceneGroup = sceneGroup or display.currentStage
	params = params or {}

	-- Game Instance
	local game = {}
	
	-- =============================================================
	-- Locals & Forward Declarations
	-- =============================================================
	local scale 				= params.scale or 1 
	local images 				= params.images or "images/default/"

	local pieceSize 			= 130 * scale					-- Size of board pieces
	local currentTurn			= "X" 							-- String variable used to track whose turn it is.  X always starts.
	local theBoard				= {}								-- Table used to store the board pieces
	local gameIsRunning		= true 							-- Boolean variable used to track whether game is running or over.

	local enableBackground 	= params.enableBackground
	
	local boardGroup			   -- Display group for all game objects.

	local currentTurnMsg    	-- Empty variable that will be used to store the handle to a text object 
	                     		-- representing the �whose turn� marker.
	local currentTurnImg			-- Image for current turn.
	local gameStatusMsg     	-- Empty variable that will be used to store the handle to a text object 
	                     		-- representing the game status message.
	local gameWinnerImg 			-- Image shown for game winner if there is one
	local resetGameButton 		-- Empty variable that will be used to store the handle to a rectangle 
	                     		-- object that will be used as the game reset button.								  
	local resetGameButtonText  -- Empty variable that will be used to store the handle to a text object 
	                     		-- that will be used as the game reset button label. 


	-- Tip: To allow these functions to call eachother, we forward
	-- declare them before defining them.  This gives each function
	-- visibility to the other functions.
	--

	-- Functions Forward Declarations
	local createPiece
	local checkForWinner        -- Function to check the board data (theBoard) grid for a winner.
	local boardIsFull           -- Function to check if board is completely full (no blank spaces).  Used for stalemate testing.

	-- Listener Forward Declarations
	local onTouchPiece          -- Listener to handle touches on board pieces.
	local onTouchResetButton    -- Listener to handle touches on the reset button (resetGameButton).

	-- ==
	--    createPiece() - Draws a single tic-tac-toe game piece (tile).
	-- ==
	createPiece = function( x, y, size )

		-- Create the rectangle first (so it is displayed on the bottom)
		local piece =  display.newImageRect( boardGroup, images .. "blanktile.png", size, size )
				
		-- Move the piece (The default position was <0,0>)			
		piece.x = x
		piece.y = y

		-- Initialize piece value as 'blank'
		piece.value = ""

		-- Add a "touch" listener to the grid piece (rectangle object). 
		piece:addEventListener( "touch", onTouchPiece )

		return piece
	end

	-- ==
	--    checkForWinner() - This function checks to see if either "X" or "O" has won the game.
	--                       It does this using a naive/brute force approach. i.e. It explicitly checks
	--                       each win cases.  This is OK for a 3-by-3 grid, but if the game and board
	--                       used more grids, we would need to come up with an algorithmic check.
	-- ==
	checkForWinner = function( turn )

		local bd = theBoard

		if(bd[1][1].value == turn and  bd[1][2].value == turn and bd[1][3].value == turn) then -- COL 1
			return true
		
		elseif(bd[2][1].value == turn and  bd[2][2].value == turn and bd[2][3].value == turn) then -- COL 2
			return true
		
		elseif(bd[3][1].value == turn and  bd[3][2].value == turn and bd[3][3].value == turn) then -- COL 3
			return true

		elseif(bd[1][1].value == turn and  bd[2][1].value == turn and bd[3][1].value == turn) then -- ROW 1
			return true
		
		elseif(bd[1][2].value == turn and  bd[2][2].value == turn and bd[3][2].value == turn) then -- ROW 2
			return true
		
		elseif(bd[1][3].value == turn and  bd[2][3].value == turn and bd[3][3].value == turn) then -- ROW 3
			return true

		elseif(bd[1][1].value == turn and  bd[2][2].value == turn and bd[3][3].value == turn) then -- DIAGONAL 1 (top-to-bottom)
			return true

		elseif(bd[1][3].value == turn and  bd[2][2].value == turn and bd[3][1].value == turn) then -- DIAGONAL 2 (bottom-to-top)
			return true

		end 

		return false
	end

	-- ==
	--    boardIsFull() - Checks to see if all grids are marked.  Returns false if one or more grids are blank.
	-- ==
	boardIsFull = function( )

		local bd = theBoard

		for i = 1, 3 do
			for j = 1, 3 do
				-- Is the grid entry empty?
				if( bd[i][j].value == "" ) then 
					return false 
				end
			end
		end

		return true
	end

	-- ==
	--    onTouchPiece() - Touch listener function.  
	-- ==
	onTouchPiece = function( event )
		
		-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
		local phase  = event.phase  
		local target = event.target

		-- If the game is over, then ignore this touch
		if( not gameIsRunning ) then
			return true
		end

		-- Don't do anything unless this is the "ended" phase, 
		-- meaning the player touched a piece and then lifted their finger.
		if( phase == "ended" ) then
			
			-- Is the marker for this piece empty?
			-- Tip: Remember, when we created the board piece, we added a reference to the text object
			--      to our rectangle.  That allowed us to use the rectangle as the touch object, and 
			--      yet still know the proper text object to check.
			-- 

			if( target.value == "" ) then

				-- The marker was empty, so set it to "X" or "O" (whoever's turn it is now).
				target.value = currentTurn

				-- Set the marker to the appropriate graphic
				if( currentTurn == "X" ) then
					target.fill = { type = "image", filename = images .. "xtile.png" }
				else
					target.fill = { type = "image", filename = images .. "otile.png" }
				end

				-- Now that we've updated the data table, check to see if we have a winner
				-- or a stalemate (no winner with full board).

				if( checkForWinner( currentTurn ) ) then

					print("Winner is: " .. currentTurn )

					-- We have a winner.  Update the message, set the game as 'over', and
					-- reveal the reset button and its label.
					--
					gameStatusMsg.text = "wins!"
					currentTurnMsg.isVisible = false
					currentTurnImg.isVisible = false
					gameIsRunning = false

					-- Show image for winner
					if( currentTurn == "X" ) then
						gameWinnerImg = display.newImageRect( boardGroup, images .. "xmarker.png", 80 * scale, 80 * scale )
					else
						gameWinnerImg = display.newImageRect( boardGroup, images .. "omarker.png", 80 * scale, 80 * scale )
					end
					gameWinnerImg.x = gameStatusMsg.x - gameWinnerImg.contentWidth/2 - gameStatusMsg.contentWidth/2 - 20 * scale
					gameWinnerImg.y = gameStatusMsg.y

					-- If user supplied gameOver action call that,
					---
					if( params.onGameOver ) then
						params.onGameOver()
					else

					-- Otherwise allow game reset
					--
						resetGameButton.isVisible = true
						resetGameButtonText.isVisible = true

					end

				elseif( boardIsFull() ) then
					print("No winner!  We have a stalemate")

					-- We have a stalemate.  Update the message, set the game as 'over', and
					-- reveal the reset button and its label.
					--
					gameStatusMsg.text = "Stalemate!"
					currentTurnMsg.isVisible = false
					currentTurnImg.isVisible = false
					gameIsRunning = false

					-- If user supplied gameOver action call that,
					---
					if( params.onGameOver ) then
						params.onGameOver()
					else

					-- Otherwise allow game reset
					--
						resetGameButton.isVisible = true
						resetGameButtonText.isVisible = true

					end

				end
				
				if( currentTurn == "X" ) then
					currentTurn = "O"
					currentTurnImg.fill = { type = "image", filename = images .. "omarker.png" }
				else
					currentTurn = "X"
					currentTurnImg.fill = { type = "image", filename = images .. "xmarker.png" }
				end

				currentTurnMsg.text = "Turn:"
			end
		end

		return true
	end

	-- ==
	--    onTouchResetButton() - Touch handler function for the reset button.
	-- ==
	onTouchResetButton = function( event )
		local phase  = event.phase
		local target = event.target

		local bd = theBoard

		-- Reset the board markers and board  i.e. Clear them.
		for row = 1, 3 do
			for col = 1, 3 do
				-- Clear the board text for this piece
				bd[row][col].value = ""

				-- Reset the image too
				bd[row][col].fill = { type = "image", filename = images .. "blanktile.png" }
			end
		end

		-- Destroy the winner image 
		display.remove( gameWinnerImg )
		gameWinnerImg = nil

		-- Reset the current turn to "X"
		currentTurn = "X"

		-- Reset the messages to their initial values.
		currentTurnMsg.text = "Turn:"
		currentTurnMsg.isVisible = true
		currentTurnImg.fill = { type = "image", filename = images .. "xmarker.png" }
		currentTurnImg.isVisible = true
		gameStatusMsg.text = "No winner yet..."

		-- Enable the game
		gameIsRunning = true

		-- Hide the reset button
		resetGameButton.isVisible = false
		resetGameButtonText.isVisible = false

		return true
	end


	-- ==
	--    game.createBoard() - Draws the tic-tac-toe game board and starts the game.
	-- ==
	function game.createBoard( x, y )

		-- Provide default values if none is supplied when users call function
		--
		x = x or centerX
		y = y or centerY

		-- Create a display group called boardGroup to place our background, pieces, etc. in
		-- 
		boardGroup = display.newGroup()

		-- Insert new boardGroup as child of group (passed in ttt.create()).
		--
		sceneGroup:insert( boardGroup )

		-- Position the boardGroup
		--
		boardGroup.x = x
		boardGroup.y = y

		-- Layout board
		--
		local startX = -pieceSize  -- Column 1 starts once-piece width left of center
		local startY = -pieceSize  -- Row 1 starts once-piece height above center


		-- 0. (Optionally) Add a background image that will display nicely on ALL devices.
		--
		-- This works nicely with the currently selected resolution in config.lua for all devices.
		--
		if( enableBackground ~= false ) then
			local back = display.newImageRect( boardGroup, images .. "interface/backImage.png", 1140, 760 )
		end

		--
		-- 1. Draw the board (3-by-3 grid of text objects over rectangles).
		--
		local bd = theBoard

		for row = 1, 3 do
			local y = startY + (row - 1) * pieceSize
			bd[row] = { {}, {}, {} } 

			for col = 1, 3 do
				local x = startX + (col - 1) * pieceSize

				local piece =  createPiece( x, y, pieceSize )

				-- Store this boardPiece in our generic table of pieces
				bd[row][col] = piece

			end
		end		

		--
		-- 2. Add a current turn label and image.
		--
		currentTurnMsg = display.newText( boardGroup, "Turn: " , 0, 0, "Prime.ttf", 48 *  scale )
		currentTurnMsg.x = 0
		currentTurnMsg.y = -2 * pieceSize
		currentTurnMsg.anchorX = 1

		currentTurnImg = display.newImageRect( boardGroup, images .. "xmarker.png", 80 *  scale, 80 *  scale )
		currentTurnImg.x = 0
		currentTurnImg.y = currentTurnMsg.y
		currentTurnImg.anchorX = 0


		--
		-- 3. Add a winner indicator (text object).
		--
		gameStatusMsg = display.newText( boardGroup, "No winner yet..." , 0, 0, "Prime.ttf", 48 *  scale )
		gameStatusMsg.x = 0
		gameStatusMsg.y = 2 * pieceSize -- Spaced two piece heights below center.

		--
		-- 4. Add a button to reset the game (text object over a rectangle).
		--

		--
		-- A. Create the rectangle base first.
		-- 
		resetGameButton = display.newImageRect( boardGroup, images .. "buttonBack.png", 3 * pieceSize , pieceSize/2 ) 

		-- Again, change reference point of rectangle, then position it.
		resetGameButton.x = 0
		resetGameButton.y = -2 * pieceSize -- Spaced two piece heights above center.

		-- Add a different listener unique to just this button (rectangle)
		resetGameButton:addEventListener( "touch", onTouchResetButton )

		-- Hide the button (rectangle) for now.
		resetGameButton.isVisible = false

		--
		-- B. Create the text label second.
		--
		-- Again, create the text object, then position it to get the results we want.
		resetGameButtonText =  display.newText( boardGroup, "Reset Game", 0, 0, "Prime.ttf", 48 *  scale )
		resetGameButtonText.x = 0
		resetGameButtonText.y = -2 * pieceSize -- Spaced two piece heights above center.

		-- Hide the label (text object)
		resetGameButtonText.isVisible = false	

		--
		--  5.  Return refernce to boardGroup
		--
		return boardGroup						
	end


	-- game.destroy() - Destroy game and clean up.
	--
	function game.destroy()
		display.remove( boardGroup )
	end



	-- Return reference game instance
	return game
end



-- Return reference to module
return ttt