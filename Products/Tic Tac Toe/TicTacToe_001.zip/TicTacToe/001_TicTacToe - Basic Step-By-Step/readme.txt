Step-By-Step
------------

In this folder you will find a step-by-step implementation of the game: Tic-Tac-Toe.

* step1 - Skeleton starter main.lua.
* step2 - Implenting a single-grid block.
* step3 - A row of blocks and the ability to click them to set the 'current' turn marker.
* step4 - Step 3 + swapping turns X, O, X.
* step5 - 3x3 grid with swapping of turns.
* step6 - Start tracking grid blocks in a table of tables.
* step7 - Check for winner and print result to console.
* step8 - Check for board full (no moves remaining condition).  No win + full board == draw.
* step9 - Add labels showing current turn and winner status.
* step10 - Add ability to restart game after win or draw.