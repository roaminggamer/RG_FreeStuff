-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- Player public
-- =============================================================
local composer    = require "composer"
local common 		= require "scripts.common"
local physics 		= require "physics"
local trail 		= require "scripts.particleTrail"
-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua & Corona Functions
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs; local mFloor = math.floor; local mCeil = math.ceil
local strGSub = string.gsub; local strSub = string.sub
-- Common SSK Features
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
local RGTiled = ssk.tiled; local files = ssk.files
local factoryMgr = ssk.factoryMgr; local soundMgr = ssk.soundMgr
--if( ssk.misc.countLocals ) then ssk.misc.countLocals(1) end

local public = {}

-- ==
--    new() - Create new player object.
-- ==
function public.new( layers, x, y, params )
	x, y = x or centerX, y or centerY
	params = params or { }

	-- 
	-- The player object
	--
	local player = newImageRect( layers.content, x, y, "images/" .. common.theme .. "/player.png",
		{ 	w = common.playerSize, h = common.playerSize, alpha = 1, fill = common.fill2 }, 
		{	radius = common.playerSize/2  } )
	player.isSteering = false

	-- 
	-- Track player's initial y-position and 
	-- Randomly set initial movment direction (-1 == left; 1 == right)
	player.y0 = player.y	
	player.dir = (mRand(1,2) == 1) and -1 or 1 
	
	--
	-- Place reference to player in common.* scratchpad for all modules to see.
	--
	common.player = player

	-- 
	-- Create player shadown
	--
	local shadow = newImageRect( layers.shadows,  
											player.x, player.y + player.contentHeight/2 - 5,
											"images/" .. common.theme .. "/circle.png",
		                    			{ size = common.playerSize, alpha = 0.2,
		                    		  	  anchorY = 1, fill = _K_, rotation = 45 } )
	player.shadow = shadow
	local offset = 5
	shadow.path.x1 = shadow.path.x1 + offset 
	shadow.path.x2 = shadow.path.x2 + offset 
	
	--
	-- Use enterFrame listener to:
	--
	-- >> Wrap player around world or kill it on edge-collision
	-- >> Move player at right speed in right direction
	-- >> Ensure shadow follows player.
	-- >> Update distance portion of score.
	-- >> Draw 'snow' particle trail.
	-- >> Check for and award overlaps/near passes.
	-- >> Check for and penalize collisions with trees.
	--
	player.enterFrame = function( self )
		--
		-- Don't do any work if the game is not running, is paused, or if the player is 'dead'.
		--
		if( not common.gameIsRunning ) then return end
		if( common.gameIsPaused ) then return end
		if( self.isDead ) then return end

		--
		-- Edge-collision: Wrap or die?
		--
		if( common.playerCanWrap ) then
			if( self.x < left ) then
				local ox = left - self.x
				self.x = right - ox
			elseif( self.x > right ) then
				local ox = self.x - right
				self.x = left + ox
			end			
		else
			if( self.x < left or self.x > right ) then
				timer.performWithDelay( 1, function() player:die() end )
				return
			end
		end

		--
		-- Slow down if steering or speed up if not
		--
		if( self.isSteering ) then
			common.playerVelocity = common.playerVelocity * common.playerSlowdownFactor
			if( common.playerVelocity < common.playerVelocityMin) then
				common.playerVelocity = common.playerVelocityMin
			end
		else
			common.playerVelocity = common.playerVelocity * common.playerSpeedupFactor
			if( common.playerVelocity > common.playerVelocityMax) then
				common.playerVelocity = common.playerVelocityMax
			end
		end

		--
		-- Maintain forward velocity
		--
		local vx, vy = self:getLinearVelocity()
		local dt = ssk.getDT()
		local dx = common.vxMax/common.accelerationTime
		vx = vx + self.dir * (dt) * dx
		if( mAbs(vx) > common.vxMax ) then
			if( vx > 0) then
				vx = common.vxMax
			else
				vx = -common.vxMax
			end
		end

		--
		-- Total velocity
		--
		common.totalVelocity = mAbs(common.playerVelocity) + mAbs(vx)
		local bestVelocity = ssk.persist.get( "settings.json", "bestSpeed" )
		if( common.totalVelocity > bestVelocity ) then
			ssk.persist.set( "settings.json", "bestSpeed", common.totalVelocity )
		end

		--
		-- You can disable steering for testing purposes, but normally it is on.
		--
		if( common.enableSteering ) then
			self:setLinearVelocity( vx, common.playerVelocity )			
		else
			player:setLinearVelocity( 0, common.playerVelocity )				
		end

		--
		-- (Optionally) rotate player to face direction of movement
		--
		--self.rotation = vector2Angle(vx, vy) + 180

		--
		-- Move player shadow
		--
		self.shadow.x = self.x
		self.shadow.y = self.y + self.contentHeight/2 - 5

		--
		-- Update distance counter if we are tracking distance
		--
		local dy = self.y - self.y0
		if( dy > 0 ) then
			common.distance = mFloor( dy/common.pixelsToDistance )
			common.score = common.distance + common.accumulatedBonus

			if( common.score > common.bestScore ) then
				common.bestScore = common.score
				ssk.persist.set( "settings.json","bestScore", common.bestScore)
			end
		end

		--
		-- Draw a particle trail, randomly swithching between trail colors.
		--
		if( common.player.isSteering ) then
			trail.render( self, { style = 1, time = 6000, size = mRand(5,8), xJiggle = mRand(5,8),
				                    trail = "_trail3", fill = common.snow1, tag = "trail",
				                    fromAlpha = 0.7 })
		
		else
			if( mRand(1,2) == 1) then
				trail.render( self, { style = 1, time = 4000, size = 3, xJiggle = 5,
					                    trail = "_trail1", fill = common.snow1a, tag = "trail",
					                    fromAlpha = 0.7 })
			else
				trail.render( self, { style = 1, time = 4000, size = 3, xJiggle = 5, 
					                    trail = "_trail", fill = common.snow2a, takg = "trail",
					                    fromAlpha = 0.7 })
			end
		end

		--
		-- Check for overlaps and collisions and act accordingly.
		--
		for k,v in pairs( common.trees or {} ) do
			
			-- Overlap test
			if( not v.overlapped and not self.isDead and
				self.x >= v._l and self.x <= v._r and 
				self.y >= v._t and self.y <= v._b ) then

				v.overlapped = true			
			end

			-- Hit?
			if( not v.hit and not self.isDead and  common.enableCollisions) then
				-- Limit test to tree hit circles in a narrow range
				local oy = v.hitSemiCircle.y - self.y
				local ox = v.hitSemiCircle.x - self.x
				if( oy >= 0 and oy < 100 and mAbs( ox ) < 100 ) then
					-- Showing trees we are testing?
					if( common.showHitTestTrees ) then
						v:setFillColor(unpack(_PURPLE_))
						timer.performWithDelay( 1000, function() v:setFillColor(1,1,1) end )
					end
					local vec = subVec( self, v.hitSemiCircle )
					local distSquared = len2Vec( vec )
					if(  distSquared <= v.hitSemiCircle.hitDistSquared ) then						
						v.hit = true				
						timer.performWithDelay( 1, function() player:die() end )
						return
					end
				end			
			end

			-- Scored Bonus?
			if( not self.isDead and   -- Stop if already dead
				 v.overlapped and
				 not v.scored and 
				 not v.hit and 
				 self.y > (v.y + v.contentHeight/2 + common.playerSize/2) ) then
				common.bonus = common.bonus + common.bonusIncrement
				common.accumulatedBonus = common.accumulatedBonus + common.bonus
				local x = (mRand(1,2) == 1) and (v.x - 100) or (v.x + 100)
				x = v.x
				local bonusHover = display.newText( v.parent, "+" .. tostring(common.bonus), 
													  v.x + mRand(-v.contentWidth, v.contentWidth), 
													  v.y - v.contentHeight/2 - 10, _G.fontB, 32)			
				bonusHover:setFillColor(unpack(common.bonusFill))
				post( "onSound", { sound = "skipoints1" } )

				v.scored  = true
				transition.to( bonusHover, { x = bonusHover.x + mRand(-25, 25), 
					                   y = bonusHover.y + mRand(-50, -25),
					                   alpha = 0,
					                   delay = 100, time = 750,
					                   onComplete = display.remove  } )

				local xScale = v.xScale
				transition.to( v, { xScale = xScale * 1.1, yScale = 1.1, time = 250 } )
				transition.to( v, { xScale = xScale * 1, yScale = 1, delay = 500, time = 250 } )
				transition.to( v.shadow, { xScale = xScale * 1.1, yScale = 1.1, time = 250 } )
				transition.to( v.shadow, { xScale = xScale * 1, yScale = 1, delay = 500, time = 250 } )
				-- (optionally) also play a gate sound
				--post( "onSound", { sound = "gate" } )
			end

		end

	end; listen("enterFrame",player)


	function player.die(self)		
		if( self.isDead ) then return end
		--
		self.isDead = true
		--
		common.totalVelocity = 0
		--
		--print("PLAYER DIED @ " .. tostring(getTimer()))
		post( "onSound", { sound = "died" } )
		ignoreList( { "onOneTouch", "enterFrame" }, self )
		self:setLinearVelocity(0,0)
		--
		-- Normally we would do this:
		----[[
		local game = require "scripts.game"
		game.stop()
		--timer.performWithDelay( 1500, function() game.recreate() end )
      timer.performWithDelay( 500,
         function()
            local params = { showBestScore = true }
            composer.gotoScene( "scenes.home", { time = 500, effect = "crossFade", params = params } )
         end )
		--]]
	end

	-- ==
	--    onOneTouch
	-- ==
	local lastMoveTimer
	player.onOneTouch = function( self, event )
		if( not common.gameIsRunning	) then return false end
		if( common.gameIsPaused ) then return end
		if( event.phase == "began" ) then 
			post( "onSound", { sound = "carve" .. mRand(1,2) } )

			self.isSteering = true
			self.dir = -self.dir
			common.vxMax = common.vxMaxBase
			-- Using TIMER 2: http://www.jasonschroeder.com/2015/02/25/timer-2-0-library-for-corona-sdk/
			lastMoveTimer = timer.performWithDelay( common.turnTime2Delay, 
				function() 
					lastMoveTimer = nil
					common.vxMax = common.vxMaxSuper
				end, 1, "moveTimer" )
		elseif( event.phase == "ended" ) then
			self.isSteering = false
			if( lastMoveTimer ) then
				timer.cancel(lastMoveTimer)
				lastMoveTimer = nil				
			end
		end
		return true
	end; listen( "onOneTouch", player )

	-- 
	ssk.camera.tracking( player, params.world, { lockX = true } )		

	--	
	player.finalize = function( self )
		display.remove(self.shadow)
		ignoreList( { "onOneTouch", "enterFrame" }, self )		
	end; player:addEventListener( "finalize" )

	--
	player:setLinearVelocity( 0, common.playerVelocity )	

	return player
end

return public