-- =============================================================
-- Copyright Roaming publicr, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common 		= require "scripts.common"
local physics 		= require "physics"
local playerM     = require "scripts.player"
-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua & Corona Functions
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs; local mFloor = math.floor; local mCeil = math.ceil
local strGSub = string.gsub; local strSub = string.sub
-- Common SSK Features
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
local RGTiled = ssk.tiled; local files = ssk.files
local factoryMgr = ssk.factoryMgr; local soundMgr = ssk.soundMgr
--if( ssk.misc.countLocals ) then ssk.misc.countLocals(1) end

-- =============================================================
-- Locals
-- =============================================================
local layers

-- =============================================================
-- Module Begins
-- =============================================================
local public = {}

--
-- Single entry point for spawn() call.  This can call an sub-spawners you like.
-- 
-- In this case, we just call the tree spawner, but in debug mode you could print out markers.
--
-- If you expand the gameplay you can create and call other spawners.
--
function public.spawn( layers, startY, endY )
	--public.spawn_markers( layers, startY, endY, stuff )
	return public.spawn_trees( layers, startY, endY, stuff )
end

--
-- Tree spawner.
--
function public.spawn_trees( layers, startY, endY )
	common.trees = common.trees or {}

	-- Count trees made this round
	local count = 0

	local function makeTree( x, y, scale, xScale, treeNum )
			count = count + 1
			-- Randomly select a tree scale (modifies size), tree texture, and tree xScale (horizontal flip)
			local tree = newImageRect( layers.trees, x, y,
												"images/" .. common.theme .. "/trees/" .. treeNum .. ".png",
				                    		{ w = 136 * scale, h = 293 * scale,
				                    		  xScale = xScale  } )
			
			-- Cacluate the space considered an overlap of the tree (for close call bonuses)
			-- 
			tree._l = tree.x - tree.contentWidth/2 - common.playerSize/2
			tree._r = tree.x + tree.contentWidth/2 + common.playerSize/2
			tree._t = tree.y - common.playerSize/2
			tree._b = tree.y + tree.contentHeight/2

			-- Calculate the 'hit' semi-circle (for collisions)
			--
			local hitRadius = (tree.contentWidth/5 + common.playerSize/2)
			tree.hitSemiCircle = { x = tree.x, y = tree.y + tree.contentHeight/2, hitDistSquared = hitRadius^2 }
			if( common.showHitSemiCircle ) then
				local hitSemiCircle = display.newCircle( layers.trees, tree.hitSemiCircle.x, tree.hitSemiCircle.y, hitRadius )
				hitSemiCircle:setFillColor(unpack(_P_))
				common.stuff[hitSemiCircle] = hitSemiCircle
				local mask = graphics.newMask( "images/hitMask.png")
				hitSemiCircle:setMask(mask)
				hitSemiCircle.maskScaleX = hitSemiCircle.contentWidth/122
				hitSemiCircle.maskScaleY = hitSemiCircle.contentHeight/122

			end

			-- Track the tree in two places:
			-- common.stuff - General bin of things we will delete when off-screen.
			-- common.trees - Tree bin.  Used by player for collision/overlap testing.
			common.stuff[tree] = tree
			common.trees[tree] = tree

			-- Create shadow
			local shadow = newImageRect(  layers.shadows,  tree.x, tree.y + tree.contentHeight/2 - 5,
												"images/" .. common.theme .. "/trees/" .. treeNum .. "s.png",
				                    		{ w = 136 * scale, h = 293 * scale, alpha = 0.2,
				                    		  xScale = xScale, anchorY = 1, rotation = 25  } )
			tree.shadow = shadow
			local offset = (xScale > 0) and 5 or -5
			shadow.path.x3 = shadow.path.x3 + offset 
			shadow.path.x4 = shadow.path.x4 + offset 

			--
			-- Add finalize listener to clean up tree and its shadown when 
			-- we remove it.
			function tree.finalize( self )
				display.remove( self.shadow )
				common.stuff[self] = nil
				common.trees[self] =  nil
			end; tree:addEventListener("finalize")

			return tree
	end

	-- Loop until we have spawned enough trees to cover a space between startY and endY.
	-- Place these in random horizontal positions at the current spawnY.
	--
	-- Tip: You can tweak this a bit if you don't like it by randomizing the stepping and changing to a
	-- do-while loop instead.
	--
	local step = 40
	local spawnY	
	for i = startY, endY, step do
		spawnY = i
		local scale = mRand( 20,30 )/100
		local xScale = (mRand(1,2) == 2) and -1 or 1
		local treeNum = mRand(1,3)
		--
		local minDX = -fullw/2
		local maxDX = fullw/2
		local dx = mRand( minDX, maxDX )
		--
		local tree = makeTree( centerX + dx, spawnY, scale, xScale, treeNum )
	end

	--
	-- Debug only
	--
	if( common.printTreesCreated ) then
		print( "Made ", count, " trees @ ", getTimer() )
	end
	--
	-- Return the ending y-position
	--
	return spawnY
end

--
-- Debug Feature - Prints Y markers.
--
function public.spawn_markers( layers, startY, endY, stuff )
	for i = startY, endY, 100 do		
		spawnY = i
		local tmp = display.newText( layers.foreground, spawnY, left + 20, spawnY )
		tmp.anchorX = 0
		tmp.alpha = 0.2
		stuff[tmp] = tmp
		tmp:setFillColor( 0 )
	end
	return spawnY
end


return public



