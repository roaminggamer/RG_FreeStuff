-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
local common 	= require "scripts.common"

-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua & Corona Functions
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs; local mFloor = math.floor; local mCeil = math.ceil
local strGSub = string.gsub; local strSub = string.sub
-- Common SSK Features
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
local RGTiled = ssk.tiled; local files = ssk.files
local factoryMgr = ssk.factoryMgr; local soundMgr = ssk.soundMgr
--if( ssk.misc.countLocals ) then ssk.misc.countLocals(1) end

local public = {}

-- ==
--    new() - Create new instance(s) of this public's object(s).
-- ==
function public.new( group, x, y, params )
	params = params or {}

	local prefix 	= params.prefix
	local suffix 	= params.suffix
	local varName 	= params.varName or "score"
	local digits   = params.digits

	local hud = display.newGroup()
	group:insert(hud)
	hud.x 	= x
	hud.y 	= y

	if( prefix ) then
		hud.leftLabel  = display.newText( hud, prefix, 0, 0, params.font or _G.fontB, params.fontSize or 48 )
		hud.rightLabel = display.newText( hud, "", 0, 0, params.font or _G.fontB, params.fontSize or 48 )
		hud.leftLabel:setFillColor(unpack(params.color or _K_))
		hud.rightLabel:setFillColor(unpack(params.color or _K_))
		hud.leftLabel.anchorX  =  1
		hud.rightLabel.anchorX = 0		
	else
		hud.rightLabel = display.newText( hud, "", 0, 0, params.font or _G.fontB, params.fontSize or 48 )
		hud.rightLabel:setFillColor(unpack(params.color or _K_))
	end
	--
	if( suffix ) then hud.rightLabel.text = hud.rightLabel.text .. suffix end
	--
	hud.lastValue = common[varName]
	hud.rightLabel.text = tostring(round(hud.lastValue))

	-- 
	-- Update distance text every frame 
	--
	function hud.enterFrame( self )
		--
		-- Skip if no change since last frame
		--
		if(hud.lastValue == common[varName]) then return end
		
		-- 
		-- Update the distance text
		--
		if( digits ) then 

			local formatStr = "%" .. digits .. "." .. digits .. "d"
			hud.rightLabel.text = string.format( formatStr, common[varName])
		else
			hud.rightLabel.text = tostring(round(common[varName]))
		end

		if( suffix ) then hud.rightLabel.text = hud.rightLabel.text .. suffix end

		--
		-- Track new distance
		--
		self.lastValue = common[varName]

	end; listen( "enterFrame", hud )

	--
	-- Attach a finalize event to the hud so it cleans it self up
	-- when removed.
	--	
	hud.finalize = function( self )
		ignoreList( { "enterFrame" }, self )
	end; hud:addEventListener( "finalize" )

	return hud
end

return public