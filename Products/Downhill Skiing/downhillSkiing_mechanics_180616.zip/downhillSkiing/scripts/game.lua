-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- game.lua - Game Module
-- =============================================================
local common 		= require "scripts.common"
local playerM     = require "scripts.player"
local levelM 		= require "scripts.level"
local easyHUD 		= require "scripts.easyHUD"
local physics 		= require "physics"
-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua & Corona Functions
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs; local mFloor = math.floor; local mCeil = math.ceil
local strGSub = string.gsub; local strSub = string.sub
-- Common SSK Features
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
local RGTiled = ssk.tiled; local files = ssk.files
local factoryMgr = ssk.factoryMgr; local soundMgr = ssk.soundMgr
--if( ssk.misc.countLocals ) then ssk.misc.countLocals(1) end

-- =============================================================
-- Locals
-- =============================================================
local layers
local lastCreateParams

-- =============================================================
-- Module Begins
-- =============================================================
local game = {}

-- ==
--    destroy() - Remove all game content and reset game state.
-- ==
function game.destroy()
	--
	-- Mark game as not running
	--
	common.gameIsRunning = false
	common.gameIsPaused  = false

	-- Destroy Existing Layers
	ignoreList( { "enterFrame" }, layers )
	display.remove( layers )
	layers = nil

	-- Clear Score, Couins, Distance Counters
	common.bonus 				= 0
	common.accumulatedBonus = 0
	common.score 				= 0
	common.bestScore 			= ssk.persist.get( "settings.json","bestScore")
	common.distance 			= 0
	common.totalVelocity		= 0
	common.playerVelocity 	= common.playerVelocityMin
	--
	common.player           = nil
	common.stuff 				= {}
	--
	lastCreateParams  = nil
end


-- ==
--    create() - Create the game contents.
-- ==
function game.create( group, params )
	--print("CREATED @ " .. tostring(getTimer()))
	params = params or { debugEn = false }
	--
	-- Store aside copy of params for recreate()
	--
	lastCreateParams = params

	--
	-- Calls destroy to ensure a clean state.
	--
	game.destroy() 

	--
	-- Ensure physics is not paused
	--
	physics.start()

	--
	-- Create Layers
	--
	layers = ssk.display.quickLayers( group, 
		"underlay", 
		"world", 
			{ "background", "shadows", "content", "trees", "foreground" },
		"interfaces" )
	--

	function layers.finalize(self)		
		ignoreList( { "enterFrame" }, self )
	end; layers:addEventListener("finalize")
	--

	--
	-- Create Snow Backgrounds - These are cotinuously swapped to 
	-- make it seem like we have a continous series of images.
	--
  	local snowBW = 720
  	local snowBH = 1386

  	local snowImages = {}

   local snow = newImageRect( layers.background, centerX, bottom + 0 * snowBH,
   	                         "images/snow.png", 
   	                         { w = snowBW, h = snowBH, anchorY = 1, id = 1, 
   	                           fill = (common.highlightSnowPanes) and _R_ or _W_ })
   snowImages[#snowImages+1] = snow
   local snow = newImageRect( layers.background, centerX, bottom + 1 * snowBH,
   	                         "images/snow.png", 
   	                         { w = snowBW, h = snowBH, anchorY = 1,  id = 2,
   	                           fill = (common.highlightSnowPanes) and _G_ or _W_ } )
	snowImages[#snowImages+1] = snow   
   local snow = newImageRect( layers.background, centerX, bottom + 2 * snowBH,
   	                         "images/snow.png", 
   	                         { w = snowBW, h = snowBH, anchorY = 1,  id = 3, 
   	                           fill = (common.highlightSnowPanes) and _B_ or _W_ } )
	snowImages[#snowImages+1] = snow

	--
	-- Create One Touch Easy Input
	--
	ssk.easyInputs.oneTouch.create( layers.underlay, { debugEn = params.debugEn, keyboardEn = false } )

	--
	-- Create a player
	--
	playerM.new( layers, centerX, top + math.floor(fullh/2.5), { world = layers.world } )


	-- Create Labels for Best Score, Current Score, and player velocity
	--	
	newRect( layers.interfaces, centerX, top, { w = fullw, h = 100 + common.topInset, fill = common.hudBackColor, anchorY = 0 } )
	local lineY = top + 100 + common.topInset
	local l1 = display.newLine( layers.interfaces, left, lineY, right, lineY )
	l1.strokeWidth = 2
	l1:setStrokeColor(unpack(_LIGHTGREY_))
	local l2 = display.newLine( layers.interfaces, left, lineY, right, lineY )
	l2.strokeWidth = 1
	l2:setStrokeColor(unpack(_DARKGREY_))

	local hud = easyHUD.new( layers.interfaces, right - fullw/5, top + 20 + common.topInset, 
		{ fontSize = 22, color = common.fill3, varName = "bestScore", prefix = "Best: " } )
	local hud = easyHUD.new( layers.interfaces, right - fullw/5, top + 65 + common.topInset, 
		{ fontSize = 64, font = _G.fontN, color = common.fill2, varName = "score" } )
	local hud = easyHUD.new( layers.interfaces, left + fullw/3, top + 50 + common.topInset, 
		{ font = _G.fontN, fontSize = 32, color = common.fill3, varName = "totalVelocity", 
		  prefix = "Speed: ", suffix = " m/s", digits = 4 } )

	--
	-- Spawner - This game uses an enterFrame listener to check whether new content needs to be
	-- spawned every frame.  It decides this by checking the player's y-position relative to
	-- the last spawnY and 
	--
	common.stuff = {}
	local spawnY
	local startY 	= top + math.floor(fullh/2)
	local endY 		= startY + 0.75 * fullh

	spawnY = levelM.spawn( layers, startY, endY )

	layers.enterFrame = function( self )
		if( not common.gameIsRunning ) then return end
		if( not common.player ) then return end
		--
		-- Tree Spawning Code (make just a few trees at a time, but make them frequently )
		--
		local triggerY = spawnY - fullh
		local startY 	= spawnY
		local endY 		= startY + fullh/4
		if( common.player.y >= triggerY ) then
			spawnY = levelM.spawn( layers, startY, endY, common.stuff )
		end
		-- Remove trees (and stuff) that is off screen
		for k,v in pairs( common.stuff ) do
			if( isValid(v) and common.player.y - v.y > fullh ) then 
				common.stuff[k] = nil
				display.remove(v)
			end
		end		

		--
		-- Snow Spawner (really a mover)
		--
		local continueTesting = true
		local count = 1
		while( continueTesting and count <= #snowImages ) do
			local snow = snowImages[count]
			if( snow and common.player ) then
				local dy = common.player.y - snow.y
				if( dy > fullh ) then
					snow.y = snow.y + 3 * snowBH
					continueTesting = false
				end
				count = count + 1
			else
				continueTesting = false
			end
		end
	end; listen("enterFrame", layers)

	--
	-- Mark game as running
	--
	common.gameIsRunning = true

end

-- ==
--    recreate() - Re-create the game
-- ==
function game.recreate()
	--print("RE-CREATED @ " .. tostring(getTimer()))
	game.pause(false)
	game.create( layers.parent, lastCreateParams )
end



-- ==
--    stop() - Stop game if it is running.
-- ==
function game.stop()
	game.pause(true)
 	--
	-- Mark game as not running
	--
	common.gameIsRunning = false
	--
	ignoreList( { "enterFrame" }, layers )
end




-- ==
--    pause( pause ) - Pause/resume game. 
-- ==
function game.pause( pause )
   if( common.gameIsRunning == false ) then return end
   if( common.gameIsPaused == pause ) then return end
   
   -- PAUSE
   if( pause ) then      
      physics.pause()
      transition.pause("trail")
      timer.pause("moveTimer")
   
   -- RESUME
   else 
		physics.start()
		transition.resume("trail")
		timer.resume("moveTimer")

   end

   common.gameIsPaused = pause
end


return game



