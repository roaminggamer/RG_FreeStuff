-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common =  {}

-- =============================================================
-- Game Title
-- =============================================================
common.gameTitle = "Downhill Skiing"

-- ==
-- Color Codes
-- ==
--common.yellow					= hexcolor("#ffcc00")
common.green					= hexcolor("#4bcc5a")
common.pink						= hexcolor("#d272b4")
common.red						= hexcolor("#ff452d")
common.blue 					= hexcolor("#009eea")
common.gold 					= hexcolor("#FFDF00")
--
common.hudBackColor 			= hexcolor("#85929E")
common.fill1 					= hexcolor("#FEFEFE") 	-- off white
common.fill2 					= hexcolor("#67c7bb") 	-- ice blue
common.fill3 					= hexcolor("#404040") 	-- grey
common.snow1a 					= hexcolor("#FEFEFE80") -- off white alpha 0.75
common.snow2a 					= hexcolor("#67c7bb80") -- ice blue alpha 0.75
common.snow1 					= hexcolor("#FEFEFE") -- off white alpha 0.75
common.snow2 					= hexcolor("#67c7bb") -- ice blue alpha 0.75
common.bonusFill				= { 1, 0.598, 0, 1 } 	-- Bright orange

-- On an iPhoneX or another device with a notch at the top? Adjust for that.
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
common.topInset 		= topInset or 0
common.titleOffsetY 	= topInset or 0
common.cornerOffsetX = leftInset --_G.oniPhoneX and 20 or 0
common.cornerOffsetY = topInset -- _G.oniPhoneX and 20 or 0

-- ==
-- Game Settings
-- ==
-- Debug Settings
common.enableSteering 			= true -- Normally 'true'
common.enableCollisions 		= true -- Normally 'true'
common.showHitSemiCircle		= false -- Show graphic representation of hit area.
common.showHitTestTrees			= false  -- Highlights trees we are testing for a hit.
common.highlightSnowPanes		= false
common.printTreesCreated 		= false

-- Various Game Metrics & Settings
common.score 						= 0
common.distance 					= 0
common.pixelsToDistance  		= 10
common.bonusIncrement			= 10

-- World Settings
common.gravityX 					= 0
common.gravityY 					= 0

-- Player Settings
common.playerCanWrap 			= true
common.playerSpeedupFactor    = 1.0035
common.playerSlowdownFactor   = 0.985
common.playerVelocityMin 		= 125
common.playerVelocityMax 		= 750
common.playerVelocity 			= common.playerVelocityMin
common.playerImpulse 			= 13
common.playerSize					= 15
common.accelerationTime			= 600
common.turnTime1 					= 1000
common.turnTime2					= 100
common.turnTime2Delay			= 250
common.vxMaxBase 					= common.playerVelocity * 1.5
common.vxMax 						= common.vxMaxBase
common.vxMaxSuper					= common.vxMaxBase * 2.5

return common