-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common  = require "scripts.common"
local utils   = require "scripts.utils"
-- =============================================================

--
-- Configure physics
--
local physics = require "physics"
physics.start()
physics.setGravity( common.gravityX, common.gravityY )
--physics.setDrawMode("hybrid") 


--
-- Set Persistent Settings' Defaults
--
ssk.persist.setDefault( "settings.json", "sound_enabled", true )
ssk.persist.setDefault( "settings.json", "bestScore", 0 )
ssk.persist.setDefault( "settings.json", "bestSpeed", 0 )


--
-- Configure Sound
--
local soundMgr = ssk.soundMgr
soundMgr.setDebugLevel(0)
soundMgr.addMusic( "soundtrack", "sounds/music/Disco Lounge.mp3")
soundMgr.addEffect( "gate", "sounds/sfx/gate.wav")
soundMgr.addEffect( "click", "sounds/sfx/click.wav")
soundMgr.addEffect( "died", "sounds/sfx/gameOver.wav")
soundMgr.addEffect( "carve1", "sounds/sfx/carve.wav")
soundMgr.addEffect( "carve2", "sounds/sfx/carve2.wav")
soundMgr.addEffect( "skipoints1", "sounds/sfx/skipoints1.wav")
soundMgr.addEffect( "skipoints2", "sounds/sfx/skipoints2.wav")
soundMgr.enableSFX( ssk.persist.get( "settings.json", "sound_enabled" ) )
soundMgr.enableMusic( ssk.persist.get( "settings.json", "sound_enabled" ) )
soundMgr.setVolume( 0.5, "effect" )
soundMgr.setVolume( 0.1, "music" )
--soundMgr.enableSFX(false)
--soundMgr.enableMusic(false)
post("onSound", { sound = "soundtrack", loops = -1})
