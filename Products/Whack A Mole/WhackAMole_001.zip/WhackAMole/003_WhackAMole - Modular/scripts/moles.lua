-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- mole.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local moleM = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
-- None.

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
local onTouch
local hide
local show

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

-- Builder Function
--
function moleM.new (x, y, color )

   -- Draw an 'empty hole'
   local mole = newImageRect( common.layers.content, "images/kenney/noMole.png", common.moleSize, common.moleSize )
   mole.x = x
   mole.y = y

   -- Attach common touch listener and start listening for touches
   mole.touch = onTouch
   mole:addEventListener( "touch" )

   -- Attach common mole methods
   mole.hide = hide
   mole.show = show

   -- Set flag(s) on mole.
   mole.isShowing = false
   mole.color = color

   -- Add to moles list
   common.moles[#common.moles+1] = mole

   -- Return reference to mole
   return mole

end


-- 'touch' event listener - Incremens score for hits on 'showing' moles and
-- plays a sound.
--
-- Tip: This is a single function used repeatedly by different moles.
-- This write-once re-use for multiple instances concept saves memory.
--

onTouch = function( self, event )
   -- Ignore all but 'began' phase
   if( event.phase ~= "began" ) then return false end

   audio.play( common.sounds.hit )
   
   if( self.isShowing ) then
      self:hide()
      common.hits = common.hits + 1
      common.hitsLabel.text = common.hits
   end
end

onTap = function ( self, event )
   if( self.isShowing ) then
      audio.play( common.sounds.hit )
      self:hide()
      common.hits = common.hits + 1
      common.hitsLabel.text = common.hits
   end
end

-- hide() - Hide this mole.
--
-- Tip: This is a single function used repeatedly by different moles.
-- This write-once re-use for multiple instances concept saves memory.
--
hide = function( self )
   -- Mark as 'showing'
   self.isShowing = false
   
   -- Change texture
   self.fill = { type = "image",  filename = "images/kenney/noMole.png" }
end

-- show() - Show this mole.
--
-- Tip: This is a single function used repeatedly by different moles.
-- This write-once re-use for multiple instances concept saves memory.
--
show = function( self )
   -- Mark as 'showing'
   self.isShowing = true
   
   -- Change texture
   self.fill = { type = "image", filename = "images/kenney/" .. self.color .. "3.png" }
end

return moleM