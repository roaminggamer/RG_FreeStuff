-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- This module contains common settings and is also used by the
-- other modules as a 'scratch-pad' for sharing references and
-- values between modules instead of using globals.
--
-- =============================================================

local common = {}


common.gameIsRunning     = false  -- Flag to help track if game is running

common.gameDuration      = 30     -- Game ends after 30 seconds

common.hits              = 0      -- Current Hits
common.misses            = 0      -- Current Misses

common.minMoleTime       = 2000   -- Minimum time (in millseconds) between mole logic runs
common.maxMoleTime       = 3000   -- Maximum time (in millseconds) between mole logic runs
common.minMoles          = 1      -- Minimum number of moles to show per mole logic run
common.maxMoles          = 3      -- Maximum number of moles to show per mole logic run

common.moles             = {}     -- Table to track mole instances
common.moleSize          = 80     -- Mole size
common.moleCols          = 3      -- Columns of moles
common.moleRows          = 3      -- Rows of moles
common.moleTweenH        = 60     -- Horizontal space between moles
common.moleTweenV        = 50     -- Vertical space between moles
common.boardOffsetY      = 20     -- Vertical offset for board

common.labelY            = 80
common.labelFont         = "Airmole Stripe.ttf"
common.labelSize         = 45



-- (Pre-) Load some sounds for use in our game
--
common.sounds = {}
common.sounds.ready = audio.loadSound( "sounds/ready.ogg" )
common.sounds.set = audio.loadSound( "sounds/set.ogg" )
common.sounds.go = audio.loadSound( "sounds/go.ogg" )
common.sounds.miss = audio.loadSound( "sounds/creature3.ogg" )
common.sounds.hit = audio.loadSound( "sounds/hurt1.ogg" )
common.sounds.gameOver = audio.loadSound( "sounds/game_over.ogg" )

return common