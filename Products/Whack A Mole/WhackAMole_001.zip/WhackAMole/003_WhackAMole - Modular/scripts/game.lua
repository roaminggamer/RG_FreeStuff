-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- game.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"
local moleM       = require "scripts.moles"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local game = {}

-- **************************************************************************
-- Locals
-- **************************************************************************

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

--
-- destroy( ) - Create the game content
--
game.destroy = function( )
   -- Do any work to stop the game
   -- 
   game.stop()
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   common.layers = display.remove( common.layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   common.layers = nil

   -- Clear the moles tracking table by setting it to nil.
   --
   common.moles = nil

   -- Clear elapsed time counter
   --
   common.elapsedTime = nil

   -- Stop 'enterFrame' listener on timer label
   --
   Runtime:removeEventListener( 'enterFrame', common.timerLabel ) 

   -- Clear label references so they can be garbage collected
   --
   common.hitsLabel = nil
   common.missesLabel = nil
   common.timerLabel = nil
end

--
-- create( group ) - Create the game content
--
game.create = function( group, onGameOver )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Start with fresh tracking/data varaibles
   --
   common.time = 0
   common.hits = 0
   common.misses = 0

   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   common.layers            = display.newGroup()
   common.layers.background = display.newGroup()
   common.layers.content    = display.newGroup()
   common.layers.interface  = display.newGroup()
   group:insert( common.layers )
   common.layers:insert( common.layers.background )
   common.layers:insert( common.layers.content )
   common.layers:insert( common.layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( common.layers.background, "images/background.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 90

   --
   -- Mole Functions & Methods - Builder function and methods for each mole.
   --   

   -- Shared Mole Methods
   --
   common.moles = {} -- Create fresh table for our moles.

   -- Draw Interface Elements
   --
   local hitsPrefix = newText( common.layers.interface, "Hits: ", centerX - 250, common.labelY, common.labelFont, common.labelSize )
   hitsPrefix.anchorX = 1
   common.hitsLabel = newText( common.layers.interface, common.hits, hitsPrefix.x, common.labelY, common.labelFont, common.labelSize )
   common.hitsLabel.anchorX = 0

   local missesPrefix = newText( common.layers.interface, "Misses: ", centerX + 350, common.labelY, common.labelFont, common.labelSize )
   missesPrefix.anchorX = 1
   common.missesLabel = newText( common.layers.interface, common.misses, missesPrefix.x, common.labelY, common.labelFont, common.labelSize )
   common.missesLabel.anchorX = 0

   common.timerLabel = newText( common.layers.interface, "Whack-a-Mole", centerX, common.labelY, common.labelFont, common.labelSize )
   common.timerLabel:setFillColor( 0, 0, 1 )

   -- Attach an enterFrame listener to the timer label to update it once the game starts
   -- 
   function common.timerLabel.enterFrame( self )


      -- Calculate time since last frame (if first run, capture current time as last time)
      --
      local curTime = getTimer()
      local deltaTime = 0
      if( common.lastTime ) then         
         deltaTime = curTime - common.lastTime
         common.lastTime = curTime
      else
         common.lastTime = curTime
      end



      -- If game is not running or game is paused
      --
      if( not common.gameIsRunning or common.gameIsPaused ) then return end

      -- If this is the first time into the loop, we will have no elapsed time
      -- counter.  
      -- 
      if( common.elapsedTime == nil )  then

         -- Start with zero elapsed time
         common.elapsedTime = 0

         -- Clear delta time
         deltaTime = 0
      end


      -- Accumulate delta time as elapsed time
      common.elapsedTime = common.elapsedTime + deltaTime

      -- Calculate seconds since game started
      --
      local elapsedSeconds = mFloor( common.elapsedTime/1000 )

      -- Update the timer text if at least one second has elapsed
      --
      if( elapsedSeconds > 0 ) then
         self:setFillColor(1,1,1)
         self.text = string.format( "%2.2d", elapsedSeconds )
      end

      -- Stop game once 'gameDuration' time elapses
      --
      if( elapsedSeconds >= common.gameDuration ) then
         audio.play( common.sounds.gameOver )
         self.text = "Game Over"
         self:setFillColor(1,0,0)
         game.stop()

         -- If "Game Over" function was supplied, call it
         --
         if( onGameOver ) then
            onGameOver()
         end
         
      end

   end 
   
   -- Start listening for enterFrame event right away
   --
   Runtime:addEventListener( 'enterFrame', common.timerLabel ) 
      
   --
   -- Draw a grid of moles
   --
   local boardWidth     = ( common.moleCols * common.moleSize + (common.moleCols-1) * common.moleTweenV )
   local boardHeight    = ( common.moleRows * common.moleSize + (common.moleRows-1) * common.moleTweenH )
   local startX         = centerX - boardWidth/2 + common.moleSize/2
   local startY         = centerY - boardHeight/2  + common.boardOffsetY + common.moleSize/2
   local curX           = startX 
   local curY           = startY

   for row = 1, common.moleRows do
      for col = 1, common.moleCols do

         print( row, col, curX, curY)

         local mole = moleM.new( curX, curY, "green" )
      
         curX = curX + common.moleSize + common.moleTweenH
      end

      curX = startX
      curY = curY + common.moleSize + common.moleTweenV
   end
end   

--
-- start( ) - Start the game running
--
game.start = function( )

   -- Start game paused
   --
   common.gameIsPaused = true


   -- Count down over 3 seconds that start game logic
   --
   local message = { "Ready", "Set", "Go" }
   local count = 0
   local function countdown()

      -- Increment count for next message
      --
      count = count + 1
      common.timerLabel:setFillColor(1,1,0)
      common.timerLabel.text = message[count]

      -- Play correct sound for this message
      -- 
      local soundName = string.lower(message[count])
      audio.play( common.sounds[soundName] )

      -- Time to start game logic?
      --
      if( count >= 3 ) then 
         -- Mark game as 'running'
         common.gameIsRunning = true

         -- Unpause the game
         common.gameIsPaused = false

         -- Start showing moles
         game.logic()
      end
   end

   -- Call countdown function three times 
   common.gameTimer = performWithDelay( 1000, countdown, 3 )

end

--
-- stop( ) - Stop the game running
--
game.stop = function( )   
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- If game timer is running, stop it and clear varaible
   if( common.gameTimer ) then
      timer.cancel( common.gameTimer )
      common.gameTimer = nil
   end

   -- Hide any 'showing' moles
   for i = 1, #common.moles do
      common.moles[i]:hide()
   end
end

--
-- pause( ) - Like stopping, but non-destructive.
--
game.pause = function( )
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- Mark game as paused
   common.gameIsPaused = true

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.pause( common.gameTimer )
   end
end

--
-- resume( ) - Start the game running
--
game.resume = function( )   
   -- Mark game as 'running'
   common.gameIsRunning = true

   -- Mark game as not paused
   common.gameIsPaused = false

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.resume( common.gameTimer )
   end
end



--
-- game.logic( ) - This function runs periodically to hide previously shown and show new moles
--
game.logic = function( )   

   -- Only do work if game is running
   if( common.gameIsRunning ) then

      -- Track whether we missed at least one.
      local missedAMole = false

      -- Count 'still showing' moles and update 'misses' label      
      for i = 1, #common.moles do
         if(common.moles[i].isShowing) then
            common.misses = common.misses + 1
            missedAMole = true
         end
      end
      common.missesLabel.text = common.misses

      -- Play missed sound if we missed a mole
      --
      if( missedAMole ) then
         audio.play( common.sounds.miss )
      end

      -- Hide any 'showing' moles
      for i = 1, #common.moles do
         common.moles[i]:hide() 
      end

      -- Select how many moles to show this time
      --
      local toShowCount = mRand( common.minMoles, common.maxMoles )

      -- Randomly select moles and try to show them till we reach our 'toShow' count
      local showCount   = 0
      while( showCount < toShowCount ) do
         local mole = common.moles[ mRand(1,#common.moles) ]
         if( not mole.isShowing ) then
            mole:show()
            showCount = showCount + 1
         end
      end

   end

   -- Run the function again in a little while
   common.gameTimer = performWithDelay( mRand( common.minMoleTime, common.maxMoleTime ), game.logic )
end


return game