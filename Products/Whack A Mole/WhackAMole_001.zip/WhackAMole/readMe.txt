==============================================================================

Roaming Gamer: Whack A Mole (Game Template)

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Reporting Bugs - How to report bugs with this template.

==============================================================================


A. Short and Sweet License 

==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.  
     (I don't want to see this show up on Chupamobile or any other website that sells templates!)


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.



B. What's in the template package?
==================================
This is a simple version of the traditional Whack-A-Mole game, where the goal is to whack moles when 
they pop up and not to miss any.

* 001_WhackAMole - Basic - Simple artless version of game.  Great staring point for new developers.
* 002_WhackAMole - Pretty - Beautified version of game with art and sound, as well as game timer and end of game logic.
* 003_WhackAMole - Modular - Game with logic separated into modules.
* 004_WhackAMole - Framed - Modules integrated with composer.* framework.



C. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please file a bug in the forums.  
Direct emails will be ignored.  It is better to share bugs where everyone can see them and see they are fixed.


>> Please report to this forum: https://forums.coronalabs.com/forum/659-marketplace-assets/

>> Please use this post title format: RG Whack A Mole: VERY-SHORT BUG DESCRIPTION

>> In the body of your post, please: Give a clear, concise, and precise description of the bug.  
>> Also be sure to give the following information:
 >>> Version of Corona SDK you are using (ex: 2017.3032)
 >>> Version of this content you have.  (I release updates on occasion, so be sure you have the latest.)
 >>> Exact content you are having trouble with.  (Many of my templates come with multiple variations of the game/template.)
 >>> OS you are developing on and version.
 >>> Device(s) you are experiencing trouble on and version of their OS.
 >>> Description of problem including:
 >>>> What you saw.
 >>>> What you expected to see.
 >>>> What you tried to debug the problem.


If you do not follow these directions it may take longer for me to notice and then resolve the bug.


Thanks,

The Roaming Gamer



