-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- Simple Push Button Module
--
-- =============================================================
local buttonM = {}

-- This function returns true if point is somewhere within the 
-- bounds of object.
local function isInBounds( point, object )
	if(not object) then return false end
	local bounds = object.contentBounds
	if( point.x > bounds.xMax ) then return false end
	if( point.x < bounds.xMin ) then return false end
	if( point.y > bounds.yMax ) then return false end
	if( point.y < bounds.yMin ) then return false end
	return true
end


-- This function creates a rectangular push button with the bare-minimum
-- set of visual and touch features.
--
function buttonM.newRectButton( group, x, y, width, height, text, action )
	group = group or display.currentStage

	local button = display.newRect( group, x, y, width, height )

	local unselColor = { 0.25, 0.25, 0.25 }
	local selColor = { 0.35, 0.35, 0.35 }
	
	button:setFillColor( unpack( unselColor ) )

	local label = display.newText( group, text, x, y, "Airmole Stripe.ttf", 32 )

	button.touch = function( self, event )
		local phase 	= event.phase
		local id 		= event.id

		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self:setFillColor( unpack( selColor ) ) 

		elseif( self.isFocus ) then
			if( isInBounds( event, self ) ) then
				self:setFillColor( unpack( selColor ) )
			else
				self:setFillColor( unpack( unselColor ) )
			end

			if( phase == "ended" or phase == "cancelled" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				self:setFillColor( unpack( unselColor ) )
				
				if( action ) then
					action()
				end
			end
		end

		return false	
	end

	button:addEventListener( "touch" )

	return button
end

-- This function creates a rectangular image push button with the 
-- bare-minimumset of visual and touch features.
--
function buttonM.newImageButton( group, x, y, width, height, image, text, action )
	group = group or display.currentStage

	local button = display.newImageRect( group, image, width, height )
	button.x = x
	button.y = y

	local unselColor = { 1, 1, 1 }
	local selColor = { 0.8, 0.8, 0.8 }
	
	button:setFillColor( unpack( unselColor ) )

	local label = display.newText( group, text, x, y, "Airmole Stripe.ttf", 32 )

	button.touch = function( self, event )
		local phase 	= event.phase
		local id 		= event.id

		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self:setFillColor( unpack( selColor ) ) 

		elseif( self.isFocus ) then
			if( isInBounds( event, self ) ) then
				self:setFillColor( unpack( selColor ) )
			else
				self:setFillColor( unpack( unselColor ) )
			end

			if( phase == "ended" or phase == "cancelled" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				self:setFillColor( unpack( unselColor ) )
				
				if( action ) then
					action()
				end
			end
		end

		return false	
	end

	button:addEventListener( "touch" )

	return button
end


return buttonM