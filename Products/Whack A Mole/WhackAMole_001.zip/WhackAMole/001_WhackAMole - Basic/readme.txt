


Icons
-----
You may notice, I don't include icons in the root folder of my projects.  I do this because I personally hate clutter during development.  Having icons in the root folder while I'm developing slows me down and you don't need icons until you're ready to publish.  So, why make things icky!?

For your conveniece, I am including sample icons in the `~/icons/` folder.