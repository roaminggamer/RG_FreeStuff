-- ==========================================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- ==========================================================================
-- main.lua
-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- Example Begins Here
-- ==========================================================================

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************
--  None


-- **************************************************************************
-- Local Variables
-- **************************************************************************
--
-- 1. Frequently used 'concepts' pre-calculated and stored in easy to 
--    type & remember variable.
--
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

--
-- 2. (Game) Variables specific to this game and its logic.
--
local layers                     -- Top group containing all child groups
local gameIsRunning     = false  -- Flag to help track if game is running
local gameTimer                  -- Handle to store timer id

local hits              = 0      -- Current Hits
local misses            = 0      -- Current Misses

local moles             = {}     -- Table to track mole instances
local moleSize          = 80     -- Mole size
local moleCols          = 3      -- Columns of moles
local moleRows          = 3      -- Rows of moles
local moleTweenH        = 60     -- Horizontal space between moles
local moleTweenV        = 50     -- Vertical space between moles
local boardOffsetY      = 20     -- Vertical offset for board

local labelY            = 80
local labelFont         = native.systemFont
local labelSize         = 45

local hitsLabel
local missesLabel


-- **************************************************************************
-- Localize Commonly Used Functions 
--
-- Why Do This?: It gives small execution speedup, but mostly I do it 
-- to simplify typing.  I may not use them all, bit it is handy to have
-- them ready if I need them.
--
--  !!Warning!!: Don't take this too far.  Lua has a limit of 200 
--               local variables in scope at any time.
--
--     Pro Tip:  Be a DRY coder, not a WET coder.
--               WET ==> Write Everything Twice; We Enjoy Typing; ...
--               DRY ==> Don't Repeat Yourself
--
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Forward Declarations
--
-- Tip: This makes the following function names VISIBLE for the rest of the file.
--      They can be called anywhere below as long as they have been defined before
--      the are called. (As soon as this file 'loads', all of the functions will 
--      be defined.)
-- 
-- Note: I split game logic into create, destroy, start, stop... etc. because:
--
-- 1. It makes reading these parts of the code easier.
--
-- 2. It promotes the concepts associated with these function to you.
--
-- 3. Having this functionality broken up discretely helps you prepare for
--    writing game modules, and then for using composer.*.
-- 
-- **************************************************************************
local destroyGame
local createGame
local startGame
local stopGame
local gameLogic


-- **************************************************************************
-- Function Definitions
-- **************************************************************************

--
-- destroyGame( ) - Create the game content
--
destroyGame = function( group )

   -- Do any work to stop the game
   -- 
   stopGame()
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   layers = display.remove( layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear the moles tracking table by setting it to nil.
   --
   moles = nil


   -- Clear label references so they can be garbage collected
   --
   hitsLabel = nil
   missesLabel = nil

end


--
-- createGame( group ) - Create the game content
--
createGame = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   destroyGame()

  -- Start with fresh tracking/data varaibles
  --
   time = 0
   hits = 0
   misses = 0

   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.content    = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.content )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( layers.background, "images/protoBack.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 90

   --
   -- Mole Functions & Methods - Builder function and methods for each mole.
   --   

   -- Shared Mole Methods
   --
   moles = {} -- Create fresh table for our moles.

   -- hide
   local function hide( self )
      -- Mark as 'showing'
      self.isShowing = false
      
      -- Change texture
      self.fill = { 
         type = "image", 
         filename = "images/corona256.png"
      }
   end

   -- show
   local function show( self )
      -- Mark as 'showing'
      self.isShowing = true
      
      -- Change texture
      self.fill = { 
         type = "image", 
         filename = "images/rg256.png"
      }
   end

   -- Shared Touch Listener (also a method)
   --
   local function onTouch( self, event )
      -- Ignore all but 'began' phase
      if( event.phase ~= "began" ) then return false end

      if( self.isShowing ) then
         self:hide()
         hits = hits + 1
         hitsLabel.text = hits
      end
   end

   -- Mole Builder Function
   --
   local function newMole( x, y )

      -- Draw an 'empty hole'
      local mole = newImageRect( layers.content, "images/corona256.png", moleSize, moleSize )
      mole.x = x
      mole.y = y

      -- Attach common touch listener and start listening for touches
      mole.touch = onTouch
      mole:addEventListener( "touch" )

      -- Attach common mole methods
      mole.hide = hide
      mole.show = show

      -- Set flag(s) on mole.
      mole.isShowing = false

      -- Add to moles list
      moles[#moles+1] = mole

      -- Return reference to mole
      return mole
   end

   -- Draw Labels Elements
   --
   local hitsPrefix = newText( layers.interface, "Hits: ", centerX - 250, labelY, labelFont, labelSize )
   hitsPrefix.anchorX = 1
   hitsLabel = newText( layers.interface, hits, hitsPrefix.x, labelY, labelFont, labelSize )
   hitsLabel.anchorX = 0

   local missesPrefix = newText( layers.interface, "Misses: ", centerX + 350, labelY, labelFont, labelSize )
   missesPrefix.anchorX = 1
   missesLabel = newText( layers.interface, misses, missesPrefix.x, labelY, labelFont, labelSize )
   missesLabel.anchorX = 0

      
   --
   -- Draw a grid of moles
   --
   local boardWidth     = ( moleCols * moleSize + (moleCols-1) * moleTweenH )
   local boardHeight    = ( moleRows * moleSize + (moleRows-1) * moleTweenH )
   local startX         = centerX - boardWidth/2 + moleSize/2
   local startY         = centerY - boardHeight/2  + boardOffsetY + moleSize/2
   local curX           = startX 
   local curY           = startY

   local last 
   for row = 1, moleRows do
      for col = 1, moleCols do

         print( row, col, curX, curY)

         local mole = newMole( curX, curY, "green" )
      
         curX = curX + moleSize + moleTweenH

         last = mole
      end
      curX = startX
      curY = curY + moleSize + moleTweenV
   end

end

--
-- startGame( ) - Start the game running
--
startGame = function( )


   -- Mark game as 'running'
   gameIsRunning = true

   -- Start showing moles
   gameLogic()

end

--
-- stopGame( ) - Start the game running
--
stopGame = function( )   
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, stop it and clear varaible
   if( gameTimer ) then
      timer.cancel( gameTimer )
      gameTimer = nil
   end

   -- Hide any 'showing' moles
   for i = 1, #moles do
      moles[i]:hide()
   end

end

--
-- gameLogic( ) - This function runs periodically to hide previously shown and show new moles
--
gameLogic = function( )   

   -- Only do work if game is running
   if( gameIsRunning ) then

      -- Track whether we missed at least one.
      local missedAMole = false

      -- Count 'still showing' moles and update 'misses' label      
      for i = 1, #moles do
         if(moles[i].isShowing) then
            misses = misses + 1
            missedAMole = true
         end
      end
      missesLabel.text = misses

      -- Hide any 'showing' moles
      for i = 1, #moles do
         moles[i]:hide() 
      end

      -- Select how many moles to show this time
      --
      local toShowCount = 1

      -- Randomly select moles and try to show them till we reach our 'toShow' count
      local showCount   = 0
      while( showCount < toShowCount ) do
         local mole = moles[ mRand(1,#moles) ]
         if( not mole.isShowing ) then
            mole:show()
            showCount = showCount + 1
         end
      end

   end

   -- Run the function again in a little while
   gameTimer = performWithDelay( 2000, gameLogic )
end


-- **************************************************************************
-- Create and Start The Game
-- **************************************************************************
createGame()

startGame()