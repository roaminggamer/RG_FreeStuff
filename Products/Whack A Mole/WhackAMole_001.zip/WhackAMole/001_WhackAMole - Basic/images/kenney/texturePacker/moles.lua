--
-- created with TexturePacker (http://www.codeandweb.com/texturepacker)
--
-- $TexturePacker:SmartUpdate:e5cd07703dba98ab890c7a38868cb32c:b97ce038ed3bce43aea345c3d11a6636:f80c175a8989100a280c28e044d541e2$
--
-- local sheetInfo = require("mysheet")
-- local myImageSheet = graphics.newImageSheet( "mysheet.png", sheetInfo:getSheet() )
-- local sprite = display.newSprite( myImageSheet , {frames={sheetInfo:getFrameIndex("sprite")}} )
--

local SheetInfo = {}

SheetInfo.sheet =
{
    frames = {
    
        {
            -- blue1
            x=289,
            y=31,
            width=70,
            height=18,

            sourceX = 0,
            sourceY = 52,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- blue2
            x=217,
            y=1,
            width=70,
            height=28,

            sourceX = 0,
            sourceY = 42,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- blue3
            x=1,
            y=1,
            width=70,
            height=48,

            sourceX = 0,
            sourceY = 22,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- green1
            x=289,
            y=31,
            width=70,
            height=18,

            sourceX = 0,
            sourceY = 52,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- green2
            x=217,
            y=31,
            width=70,
            height=28,

            sourceX = 0,
            sourceY = 42,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- green3
            x=73,
            y=1,
            width=70,
            height=48,

            sourceX = 0,
            sourceY = 22,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- noMole
            x=289,
            y=31,
            width=70,
            height=18,

            sourceX = 0,
            sourceY = 52,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- red1
            x=289,
            y=31,
            width=70,
            height=18,

            sourceX = 0,
            sourceY = 52,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- red2
            x=289,
            y=1,
            width=70,
            height=28,

            sourceX = 0,
            sourceY = 42,
            sourceWidth = 70,
            sourceHeight = 70
        },
        {
            -- red3
            x=145,
            y=1,
            width=70,
            height=48,

            sourceX = 0,
            sourceY = 22,
            sourceWidth = 70,
            sourceHeight = 70
        },
    },
    
    sheetContentWidth = 360,
    sheetContentHeight = 60
}

SheetInfo.frameIndex =
{

    ["blue1"] = 1,
    ["blue2"] = 2,
    ["blue3"] = 3,
    ["green1"] = 4,
    ["green2"] = 5,
    ["green3"] = 6,
    ["noMole"] = 7,
    ["red1"] = 8,
    ["red2"] = 9,
    ["red3"] = 10,
}

function SheetInfo:getSheet()
    return self.sheet;
end

function SheetInfo:getFrameIndex(name)
    return self.frameIndex[name];
end

return SheetInfo
