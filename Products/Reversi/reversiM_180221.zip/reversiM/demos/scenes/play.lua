-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onBack
local createBoardAndStartGame

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local layers
local board 
local lastTimer


----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view

   display.remove( layers )
   layers = quickLayers( sceneGroup, 
      "background", 
      "content", 
      "interfaces" )

   local style = event.params.style

   local back = newImageRect( layers.background, centerX, centerY, "images/backImage" .. style .. ".png", { w = 760, h = 1140 } )

   easyIFC:presetPush( layers.interfaces, "default", left + 35, top + 35, 60, 60, "X", onBack, { labelSize = 40 } )

   createBoardAndStartGame( event.params )
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
   if( lastTimer ) then
      timer.cancel(lastTimer)
      lastTimer = nil 
   end
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view
   post( "onAdRequest", { sceneName = "play", type = "didHide" } )
end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
   post( "onAdRequest", { sceneName = "play", type = "destroy" } )
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onBack = function( event )
   composer.gotoScene( "scenes.home", { time = 0, effect = "fade" } )
end

createBoardAndStartGame = function( params )
   --table.dump(params,"createBoardAndStartGame")
   local reversiM          = require "reversiM"
   --
   local AILevel           = params.difficulty
   local autoPlay          = false   
   local numHumans         = 3 - params.players
   local delay             = (numHumans == 0) and 500 or 3000
   local whiteImage        = "images/circle.png"
   local blackImage        = "images/circle.png"
   local cellImg           = "images/cellBack1.png"
   local cellStrokeWidth   = 1
   local whiteFill         = _W_
   local blackFill         = _K_
   local boardSize         = 8
   local cellSize          = 60
   local pieceSize         = 58
   local initOffset        = 4
   --
   local turnIndicator
   local whiteCountIndicator
   local whiteCountLabel
   local blackCountIndicator
   local blackCountLabel
   --
   local updateTurnIndicator
   --
   local function onOver( board, counts, currentTurn )   
      whiteCountLabel.text = counts.white
      blackCountLabel.text = counts.black
      --
      if( counts.white > counts.black ) then
         -- WHITE WINS
         blackCountIndicator.alpha = 0.25
         blackCountLabel.alpha = 0.25
      elseif( counts.black > counts.white ) then
         -- BLACK WINS
         whiteCountIndicator.alpha = 0.25
         whiteCountLabel.alpha = 0.25
      else
         -- TIE!
      end
      board:stop()
   end
   --
   local function onTurnEnded( board, counts, currentTurn )      
      board:toggleTurn()
      updateTurnIndicator( board:getTurn() )
      --
      whiteCountLabel.text = counts.white
      blackCountLabel.text = counts.black
      --
      local allowTouch = numHumans == 2 or 
                         (numHumans == 1 and board:getTurn() == "white" )
      local possibleMoves = board:identifyLegalMoves( allowTouch )
      --
      print( numHumans, board:getTurn() )
      if( #possibleMoves == 0 ) then
         onOver( board, counts, board:getTurn() )
      elseif( numHumans == 0 or (numHumans == 1 and board:getTurn() == "black" ) ) then
         local cell
         if( AILevel == 3 ) then
            cell = possibleMoves[1]      
         elseif( AILevel == 2 ) then
            cell = possibleMoves[math.random(1,#possibleMoves)]         
         else
            cell = possibleMoves[#possibleMoves]         
         end
         lastTimer = timer.performWithDelay( delay, function() board:doMove( cell ) end )
      end
   end
   --   
   if( params.style == 2) then
      whiteImage        = "images/blue.png"
      blackImage        = "images/green.png"
      cellImg           = "images/cellBack2.png"
      cellStrokeWidth   = 0
      blackFill = _W_
   
   elseif( params.style == 3) then
      whiteImage        = "images/girl.png"
      blackImage        = "images/boy.png"
      cellImg           = "images/cellBack3.png"
      cellStrokeWidth   = 0
      cellStrokeWidth = 0
      blackFill = _W_
   end
   --
   if( params.boardSize == 1 ) then
      boardSize = 6
      initOffset = 3
   elseif( params.boardSize == 3 ) then
      boardSize = 10
      initOffset = 5
   end
   --
   board = reversiM.create( layers.content, centerX, centerY,
       { whiteImage = whiteImage, 
         blackImage = blackImage,
         cellImg = cellImg,
         whiteFill = whiteFill,
         blackFill = blackFill,
         cellStrokeWidth = cellStrokeWidth,
         showMoves = (params.difficulty < 3), 
         onOver = onOver, 
         onTurnEnded = onTurnEnded, 
         rows = boardSize, 
         cols = boardSize, 
         initOffset = initOffset } )
   --
   turnIndicator = newRect( layers.content, centerX, board.y - 50, { size = 60 } )
   local y = board.y + board.height + 50   
   whiteCountIndicator = newImageRect( layers.content, board.x, y, whiteImage, { size = 60, anchorX = 0 } )   
   whiteCountIndicator:setFillColor( unpack( whiteFill) )
   whiteCountLabel = easyIFC:quickLabel( layers.content, "2", whiteCountIndicator.x + 70, y, gameFont, 48, _W_, 0 )
   blackCountIndicator = newImageRect( layers.content, board.x + board.width/2, y, blackImage, { size = 60, anchorX = 0 } )   
   blackCountIndicator:setFillColor( unpack( blackFill) )
   blackCountLabel = easyIFC:quickLabel( layers.content, "2", blackCountIndicator.x + 70, y, gameFont, 48, _W_, 0 )
   --
   board:startNewGame()
   local allowTouch = ( numHumans > 0 )
   local possibleMoves = board:identifyLegalMoves( allowTouch )
   updateTurnIndicator = function( currentTurn )
      if( currentTurn == "white" ) then
         turnIndicator.fill = { type = "image", filename = whiteImage }
         turnIndicator:setFillColor( unpack( whiteFill ))
      else
         turnIndicator.fill = { type = "image", filename = blackImage }
         turnIndicator:setFillColor( unpack( blackFill ))
      end      
   end
   updateTurnIndicator( "white" )
   --
   if( numHumans == 0 ) then
      local cell
      if( AILevel == 3 ) then
         cell = possibleMoves[1]      
      elseif( AILevel == 2 ) then
         cell = possibleMoves[math.random(1,#possibleMoves)]         
      else
         cell = possibleMoves[#possibleMoves]         
      end
      lastTimer = timer.performWithDelay( delay, function() board:doMove( cell ) end )
   end

end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene