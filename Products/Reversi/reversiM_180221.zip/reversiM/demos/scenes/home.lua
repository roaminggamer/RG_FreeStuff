-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onStyle
local onBoardSize
local onDifficulty
local onPlayers
local onPlay

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local style = 1
local boardSize = 1
local difficulty = 1
local players = 1

local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()

----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view
   local sceneGroup = self.view
   layers = quickLayers( sceneGroup, 
      "underlay",
      "content", 
         {  "styles", "sizes", "difficulties", "players", "play" },
      "overlay" )
   easyIFC:quickLabel( layers.overlay, "Reversi Module Demos", centerX, top + 10 + topInset, gameFont, 42, _W_, 0.5, 0 )
   easyIFC:quickLabel( layers.overlay, "by Roaming Gamer LLC", centerX, bottom - 10, fontN, 28, _W_, 0.5, 1  )

   local initial
   -- Visual Style
   local label = easyIFC:quickLabel( layers.styles, "Visual Style", centerX, 0, gameFont, 24, _W_, 0.5, 0 )
   local tmp = easyIFC:presetRadio( layers.styles, "default", centerX - 110, label.y + 60, 100, 30, "Style 1", onStyle )
   tmp.style = 1
   initial = tmp
   local tmp = easyIFC:presetRadio( layers.styles, "default", centerX, label.y + 60, 100, 30, "Style 2", onStyle )
   tmp.style = 2
   local tmp = easyIFC:presetRadio( layers.styles, "default", centerX + 110, label.y + 60, 100, 30, "Style 3", onStyle )
   tmp.style = 3
   --
   initial:toggle()

   -- Board Size
   local label = easyIFC:quickLabel( layers.sizes, "Board Size", centerX, tmp.y + 60, gameFont, 24, _W_, 0.5, 0 )
   local tmp = easyIFC:presetRadio( layers.sizes, "default", centerX - 110, label.y + 60, 100, 30, "6 x 6", onBoardSize )
   tmp.boardSize = 1
   local tmp = easyIFC:presetRadio( layers.sizes, "default", centerX, label.y + 60, 100, 30, "8 x 8 ", onBoardSize )
   tmp.boardSize = 2
   initial = tmp
   local tmp = easyIFC:presetRadio( layers.sizes, "default", centerX + 110, label.y + 60, 100, 30, "10 x 10", onBoardSize )
   tmp.boardSize = 3
   --
   initial:toggle()

   -- Difficulty
   local label = easyIFC:quickLabel( layers.difficulties, "Difficulty", centerX, tmp.y + 60, gameFont, 24, _W_, 0.5, 0 )
   local tmp = easyIFC:presetRadio( layers.difficulties, "default", centerX - 110, label.y + 60, 100, 30, "Easy", onDifficulty )
   tmp.difficulty = 1
   local tmp = easyIFC:presetRadio( layers.difficulties, "default", centerX, label.y + 60, 100, 30, "Normal ", onDifficulty )
   tmp.difficulty = 2
   initial = tmp
   local tmp = easyIFC:presetRadio( layers.difficulties, "default", centerX + 110, label.y + 60, 100, 30, "Hard", onDifficulty )
   tmp.difficulty = 3
   --
   local tmp = easyIFC:quickLabel( layers.difficulties, "Easy - Show possible moves + dumb AI moves.", centerX - 170, tmp.y + 35, fontN, 16, _W_, 0 )   
   local tmp = easyIFC:quickLabel( layers.difficulties, "Normal - Show possible moves + random AI", tmp.x, tmp.y + 25, fontN, 16, _W_, 0 )
   local tmp = easyIFC:quickLabel( layers.difficulties, "Hard - Hide possible moves + smarter AI", tmp.x, tmp.y + 25, fontN, 16, _W_, 0 )
   --
   initial:toggle()
   
   -- Players
   local label = easyIFC:quickLabel( layers.players, "Players", centerX, tmp.y + 50, gameFont, 24, _W_, 0.5, 0 )
   local tmp = easyIFC:presetRadio( layers.players, "default", centerX, label.y + 60, 200, 30, "Human vs Human", onPlayers )
   tmp.players = 1
   local tmp = easyIFC:presetRadio( layers.players, "default", centerX, tmp.y + 40, 200, 30, "Human vs AI ", onPlayers )
   tmp.players = 2
   initial = tmp
   local tmp = easyIFC:presetRadio( layers.players, "default", centerX, tmp.y + 40, 200, 30, "AI vs AI", onPlayers )
   tmp.players = 3
   --
   initial:toggle()


   -- Play
   local tmp = easyIFC:presetPush( layers.play, "default", centerX, tmp.y + 120, 300, 150, "Play", onPlay, 
                                  { labelSize = 60, labelFont = _G.fontB, emboss = true } )

   layers.content.y = centerY - layers.content.height/2

end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onStyle = function( event ) 
   style = event.target.style
end
--
onBoardSize = function( event ) 
   boardSize = event.target.boardSize
end
--
onDifficulty = function( event ) 
   difficulty = event.target.difficulty
end
--
onPlayers = function( event ) 
   players = event.target.players
end
--

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
onPlay = function( event )
   local params = { style = style, boardSize = boardSize, difficulty = difficulty, players = players }
   table.dump(params)
   composer.gotoScene( "scenes.play", { time = 0, effect = "crossFade", params = params } )
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene