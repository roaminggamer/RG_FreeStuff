-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
--  main.lua
-- =============================================================
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
_G.fontN 	= "Raleway-Light.ttf" 
_G.fontB 	= "Raleway-Black.ttf" 
_G.gameFont = _G.fontB -- Used by SSK to initialize default (button) presets
-- =============================================================
require "ssk2.loadSSK"
_G.ssk.init( { launchArgs = ...,  gameFont = "Raleway-Light.ttf" } )
--
local composer = require "composer"
composer.gotoScene( "scenes.home" )
--composer.gotoScene( "scenes.play" )
