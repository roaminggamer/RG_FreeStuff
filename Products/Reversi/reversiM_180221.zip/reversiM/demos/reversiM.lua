-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
--  reversiM.lua - Reversi Module
--[[
	Module Functions:
	reversiM.create( group, x, y, params ) - Create a board.
	 > group - Display group to place board in.
	 > x, y - Center position of board.
	 > params - optional parameters
	 	> rows (8)
	 	> cols (8)
	 	> initOffset (4) -- <row,col> offset of initial pieces
	 	> cellSize (60) - Size of individual board cell.
	 	> cellTween (2) - Spacing between cells.
	 	> pieceSize (58) - Size of pieces.
	 	> cellImg ("square.png") - Path to cell image.
	 	> cellFill ({0.25,0.25,0.25}) - Fill color to use for cells.
	 	> cellStroke ({1, 1, 0, 0.5}) - Stroke color to use for cells.
	 	> cellStrokeWidth (1) - Stroke width for cells.
	 	> whiteImage ("circle.png") - Path to white piece image.
	 	> blackImage ("circle.png") - Path to black piece image.
	 	> whiteFill ({1,1,1}) - Fill color to use for white pieces.
	 	> blackFill ({0,0,0}) - Fill color to use for black pieces.
	 	> debugEn (false) - Show debug details on board.
	 	> showMoves (debugEn) - Show next moves and value of moves.
	 	> onOver (function(board, counts, currentTurn) end) - Function to call if no moves remain. (See the demo code.)
	 	> onTurnEnded (function(board, counts, currentTurn) end) - Function to call when turn completed. (See the demo code.)

	 Returns: A display group that is the 'board' and contains all cells and pieces.

   'board' Functions:
   	board:startNewGame() - Resets game and sets board to 'start' state.
   	board:toggleTurn() - Switch currentTurn to next player.
   	board:getTurn() - Get string containing current turn name ('white' or 'black').
   	board:forEachCell( action ) - Iterate over all cells and call action on the current cell.

         Ex:
   	   local function myAction( cell )
   	   	print(cell.x, cell.y)
   	   end
   	   board:forEachCell( myAction )


   	board:getCell( row, col) - Return cell at row,col or 'nil' if none found.
   	board:placePiece( row, col, color ) - Place a 'white' or 'black' piece at <row,col>
   	board:identifyLegalMoves( allowTouch ) - Identifies all legal moves and 
   	   if 'allowTouch' is true those cells can be touched to place a piece.
   	  	This is the primary way the game advances.  (See the demo code.)
   	board:checkForGameOver() - Returns isOver, counts.
   	 > isOver - Boolean value. 'true' means game is over because curent player has no valid moves.
   	 > counts - Table with two fields 'white' and 'black' giving piece count for each color.
   	
   	board:doMove() - Used internally.  DO NOT call this in your game code.
  		board:stop() - Tells game board, game is done.

]]
local reversiM = {}

local function tableCount( t )
	local count = 0
	for k,v in pairs(t) do
		count = count + 1
	end
	return count
end
local function tableInsertUnique( dst, src )
	for k,v in pairs( src ) do
		dst[k] = v
	end
	return dst 
end

function reversiM.create( group, x, y, params )
	--
	-- Defaults
	--
	group = group or display.currentStage
	x = x or display.contentCenterX
	y = y or display.contentCenterY
	params = params or {}

	--
	-- Locals
	--
	local currentTurn 		= "white"
	local rows					= params.rows or 8
	local cols					= params.cols or 8
	local cells 				= {}
	local cellSize 			= params.cellSize or 60
	local cellTween 			= params.cellTween or 2
	local pieceSize 			= params.pieceSize or 58
	local cellImg 				= params.cellImg or "square.png"
	local pieceImage 			= {}
	pieceImage.white 			= params.whiteImage or "circle.png"
	pieceImage.black 			= params.blackImage or "circle.png"
	local pieceFill 			= {}
	pieceFill.white 			= params.whiteFill or { 1, 1, 1 }
	pieceFill.black 			= params.blackFill or { 0, 0, 0 }
	local cellFill 			= params.cellFill or { 0.25, 0.25 ,0.25 }
	local cellStroke 			= params.cellStroke or { 1, 1, 0, 0.5 }
	local cellStrokeWidth 	= params.cellStrokeWidth or 1
	local debugEn 				= params.debugEn or false
	local showMoves 			= params.showMoves or debugEn or false
	local onOver  				= params.onOver or function() end
	local onTurnEnded 		= params.onTurnEnded or function() end
	local initOffset 			= params.initOffset or 4

	local function cleanCell( cell )
		cell.isLegal = false 
		cell.interactive = false
		cell.moveScore = 0 
		cell:setFillColor( unpack( cellFill ) )
		cell.swaps = {}
		cell.moveCount = 0
		display.remove( cell.debugLabel )
		cell.debugLabel = nil
	end

	--
	-- Common Touch Handler
	--
	local function onTouch( self, event )
		local phase 	= event.phase
		local isLegal 	= self.isLegal
		local canTouch = self.canTouch
		local board 	= self.board
		--
		if( phase ~= "ended" or isLegal ~= true or canTouch == false ) then
			return false 
		end
		--
		board:doMove( self )
	end

	--
	-- Draw the 'board'
	--
	local board = display.newGroup()
	group:insert(board)

	--
	local curX = cellSize/2 
	local curY = cellSize/2
	for row = 1, rows do
		for col = 1, cols do
			local cell = display.newImageRect( board, cellImg, cellSize, cellSize )
			cell.x = curX
			cell.y = curY			
			cell:setFillColor( unpack( cellFill ) )
			cell:setStrokeColor( unpack( cellStroke ) )
			cell.strokeWidth = cellStrokeWidth
			cell.row = row
			cell.col = col
			curX = curX + cellSize + cellTween
			cell.touch = onTouch
			cell:addEventListener("touch")
			cell.board = board
			cells[cell] = cell
		end
		curX = cellSize/2
		curY = curY + cellSize + cellTween
	end
	board.x = x - board.width/2
	board.y = y - board.width/2

	--
	-- Attach Functions To the 'board'
	--
	function board.startNewGame( self )
		-- Destroy prior game data if any
		for k,v in pairs(cells) do
			display.remove(v.piece)
			v.piece = nil
		end
		
		-- Place initial pieces
		self:placePiece( initOffset, initOffset, "white" )
		self:placePiece( initOffset+1, initOffset+1, "white" )
		self:placePiece( initOffset, initOffset+1, "black" )
		self:placePiece( initOffset+1, initOffset, "black" )

	end
	--
	function board.toggleTurn( self )
		currentTurn = (currentTurn == "white") and "black" or "white"
	end
	--
	function board.getTurn( self ) 
		return currentTurn
	end
	--
	function board.forEachCell( self, action ) 
		for k,v in pairs(cells) do
			action(v)				
		end
	end
	--

	--
	function board.getCell( self, row, col )
		for k,v in pairs(cells) do
			if( v.row == row and v.col == col ) then 
				return v
			end
		end
		return nil
	end
	--
	function board.placePiece( self, row, col, color )
		local cell = self:getCell(row,col)
		local piece = display.newImageRect( board, pieceImage[color], pieceSize, pieceSize )
		piece.x = cell.x
		piece.y = cell.y
		piece:setFillColor(unpack(pieceFill[color]))
		piece.cell = cell
		cell.piece = piece
		piece.color = color
		return piece, cell		
	end
	--
	local function scanForPossibleMoves( curPiece, dir, possibleMoves )
		--print('--------------------------------', curPiece.cell.row, curPiece.cell.col)
		--print("scanForPossibleMoves() ", curPiece, dir, possibleMoves )
		--
		local count = 0
		local swaps = {}
		local lastCell
		--		
		local inScan 		= true
		local color  		= curPiece.color
		local otherColor 	= (color == "white" ) and "black" or "white"
		local row 			= curPiece.cell.row
		local col 			= curPiece.cell.col	
		--
		local function cellTest( cell )
			if( not cell ) then
				--print('a')
				lastCell = nil
				inScan = false
			elseif( not cell.piece ) then
				--print('b')
				inScan = false
			elseif( cell.piece.color == otherColor ) then
				--print('c')
				lastCell = cell
				count = count + 1
				swaps[cell] = cell
			else
				--print('d')
				lastCell = nil
				inScan = false
			end
		end
		--
		if( debugEn ) then
			curPiece.cell:setFillColor(unpack(_O_))
		end
		-- 1 - scan left
		if( dir == 1 ) then
			--print( "Scanning for LEFT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				col = col - 1				
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end
		-- 2 - scan up
		elseif( dir == 2 ) then
			--print( "Scanning for UP legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row - 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end
		
		-- 3 - scan right
		elseif( dir == 3 ) then
			--print( "Scanning for RIGHT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				col = col + 1
				local cell = board:getCell( row, col )
				cellTest( cell )				
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end

		-- 4 - scan down
		elseif( dir == 4 ) then
			--print( "Scanning for DOWN legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row + 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end

		-- 5 - scan up and left
		elseif( dir == 5 ) then
			--print( "Scanning for UP and LEFT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row - 1
				col = col - 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end

		-- 6 - scan up and right
		elseif( dir == 6 ) then
			--print( "Scanning for UP and RIGHT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row - 1
				col = col + 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end
		
		-- 7 - scan up and right
		elseif( dir == 7 ) then
			--print( "Scanning for DOWN and RIGHT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row + 1
				col = col + 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end

		-- 8 - scan down and left
		elseif( dir == 8 ) then
			--print( "Scanning for DOWN and LEFT legal ", color, " moves", " other color: ", otherColor, row, col )
			while( inScan ) do
				row = row + 1
				col = col - 1
				local cell = board:getCell( row, col )
				cellTest( cell )
				--print( inScan, cell, lastCell, tableCount(swaps), row, col )
				if( not inScan and cell and lastCell and tableCount(swaps) > 0 ) then
					cell.moveCount = cell.moveCount + count
					tableInsertUnique( cell.swaps, swaps )
					possibleMoves[cell] = cell
					lastCell = nil
				end
			end
		end
	end
	--
	function board.identifyLegalMoves( self, allowTouch )
		-- 
		self:forEachCell( cleanCell )
		-- 
		local pieces = {}
		local function getCurColorPieces( cell )
			if( cell and cell.piece and cell.piece.color == currentTurn ) then
				pieces[cell.piece] = cell.piece
			end
		end
		self:forEachCell( getCurColorPieces )
		--
		local possibleMoves = {}
		for k,v in pairs( pieces ) do
			--v:setFillColor(1,0,0)
			for i = 1, 8 do
				scanForPossibleMoves( v, i, possibleMoves )
			end			
		end
		--
		for k,v in pairs( possibleMoves ) do
			if( showMoves ) then
				v:setFillColor(0,1,0)
				v.debugLabel = display.newText( v.parent, v.moveCount, v.x, v.y )
				v.debugLabel:setFillColor(0.5, 0.5, 0.5)
			end
			v.isLegal = true
			v.canTouch = allowTouch
		end
		--
		local tmp = possibleMoves
		possibleMoves = {}
		for k,v in pairs( tmp ) do
			possibleMoves[#possibleMoves+1] = v
		end
		--		
		local function sortByMostMoves( a, b )
			return a.moveCount > b.moveCount
		end
		table.sort( possibleMoves, sortByMostMoves )
		return possibleMoves
	end
	--
	function board.checkForGameOver( self )
		local movesAvailable = false
		local counts = {}
		counts.white = 0
		counts.black = 0
		for k,v in pairs( cells ) do
			if( v.piece == nil ) then
				movesAvailable = true
			else
				counts[v.piece.color] = counts[v.piece.color] + 1
			end
		end
		--
		local isOver = (movesAvailable == false)
		return isOver, counts
	end
	--
	function board.doMove( self, cell )
		self:placePiece( cell.row, cell.col, currentTurn )
		--
		for k,v in pairs( cell.swaps ) do
			v.piece.color = currentTurn
			v.piece.fill = { type = "image", filename = pieceImage[currentTurn] }
			v.piece:setFillColor(unpack(pieceFill[currentTurn]))
		end
		--
		self:forEachCell( cleanCell ) 
		--
		local isOver, counts = self:checkForGameOver()
		if( isOver ) then
			onOver( self, counts, currentTurn )
		else
			onTurnEnded( self, counts, currentTurn )			
		end
	end
	--
	function board.stop( self )
		self:forEachCell(cleanCell)
	end

	--
	-- Return the 'board'
	--
	return board
end

return reversiM