-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar
display.setDefault( "background", 0, 0.3, 0.58 ) -- Make background a nice blue color

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------

-- Locals
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

local pleaseWait = false
local playersTurn = false

local maxSequenceLength = 0
local sequenceLength    = 0
local currentSequence   = {}  -- A table containing the current generated sound sequence.  Grows by one every turn.
local playedSequence    = {}  -- A table to record the sequence as played back by the player.  Accumulates on each button press.

local buttons = {}

local activeColor = {}
activeColor[1] = { 1, 0, 0 }
activeColor[2] = { 0.25, 1, 0.25 }
activeColor[3] = { 0.25, 1, 1 }
activeColor[4] = { 1, 1, 0 }

local inactiveColor = {}
inactiveColor[1] = { 0.78, 0, 0 }
inactiveColor[2] = { 0, 0.78, 0 }
inactiveColor[3] = { 0, 0.5, 0.78 }
inactiveColor[4] = { 0.78, 0.78, 0 }

local buttonOffsets = {}
buttonOffsets[1] = { x = -150, y = -150 }
buttonOffsets[2] = { x = 150, y = -150 }
buttonOffsets[3] = { x = -150, y = 150 }
buttonOffsets[4] = { x = 150, y = 150 }

local buttonSounds = {}
buttonSounds[1] = audio.loadSound( "sounds/1.wav" )
buttonSounds[2] = audio.loadSound( "sounds/2.wav" )
buttonSounds[3] = audio.loadSound( "sounds/3.wav" )
buttonSounds[4] = audio.loadSound( "sounds/4.wav" )

local failSound = audio.loadSound( "sounds/fail.wav" )

-- Labels, Buttons, Etc.
local playButton			
local playButtonText		
local sequenceText			
local maxSequenceText		

-- Function Declarations
local drawBoard				
local doPress				

local playTune				

local isCorrectSequence		

-- Listener Declarations
local onButtonTouch	
local onPlay_RepeatButton

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--    drawBoard() - This function draws the game board.
-- ==
drawBoard = function()

	local tmp

	local xOffset = 140




	--
	-- 1. Game Frame (Orange Circle)
	--
	tmp = display.newImageRect( "images/device.png", 680, 680 )
	tmp.x = centerX + xOffset
	tmp.y = centerY,
	tmp:setFillColor( 0.84,	0.49,	0 )

	--
	-- 2. Draw Colored Buttons 
	--
	local rotations = { 0, 90, 270, 180 }
	for i = 1, 4 do
		-- Button
		tmp = display.newImageRect( "images/button.png", 300, 300 )
		tmp.x = centerX + buttonOffsets[i].x + xOffset
		tmp.y = centerY + buttonOffsets[i].y
		tmp:setFillColor( unpack( inactiveColor[i] ) )


		tmp.rotation = rotations[i]

		tmp.myNum = i

		tmp:addEventListener( "touch", onButtonTouch )

		buttons[i] = tmp

	end

	--
	-- 3. Game Label
	--
	tmp = display.newEmbossedText( "Memory", 0, 0, native.systemFont, 56 )		
	tmp:setFillColor( 0, 0.35, 1 )
	tmp.x = centerX + xOffset
	tmp.y = centerY

	--
	-- 4. Add a "Play Again?" button
	--

	--
	-- A. Create the rectangle base first.
	-- 
	playButton = display.newRect( 0, 0, 240, 60 ) 

	-- Again, change anchor point of rectangle, then position it.
	playButton.x = 140
	playButton.y = bottom - 40

	-- Use same color scheme as the board pieces
	playButton:setStrokeColor( 0.25, 0.25, 0.25, 1 )
	playButton:setFillColor( 0.5, 0.5, 0.5, 1 )
	playButton.strokeWidth = 3

	-- Add a different listener unique to just this button (rectangle)
	playButton:addEventListener( "touch", onPlay_RepeatButton )

	--
	-- B. Create the text label second.
	--
	-- Again, create the text object, then position it to get the results we want.
	playButtonText =  display.newText( "Play Game", 0, 0, native.systemFont, 36 )
	playButtonText.x = playButton.x
	playButtonText.y = playButton.y
	playButtonText:setFillColor(0,0,0)

	playButton.label = playButtonText


	--
	-- 5. Add Sequence Labels
	--
	sequenceText =  display.newText( "Current: 0", 0, 0, native.systemFont, 48 )
	sequenceText.anchorX = 1
	sequenceText.x = left + 260
	sequenceText.y = top + 40

	maxSequenceText =  display.newText( "Max: 0", 0, 0, native.systemFont, 48 )
	maxSequenceText.anchorX = 1
	maxSequenceText.x = left + 260
	maxSequenceText.y = top + 100

end

-- ==
--    doPress( num, inactive) - Light or Un-light the specified button.
--
--    num - Button number 1..4
--    inactive - 'true' button is inactive, otherwise button is active (highlighted).
-- ==
doPress = function( num, inactive )

	local inactive = inactive or false
	
	if( inactive ) then
		buttons[num]:setFillColor( unpack( inactiveColor[num] ) )

	else
		buttons[num]:setFillColor( unpack( activeColor[num] ) )
		audio.play( buttonSounds[num] )
	end

end

-- ==
--    playTune() - Play the current tune (sound sequence).
--
--    generate - If this is set to 'true', add a new random sound to the end of the sequence.
-- ==
playTune = function ( generate )
	local generate = generate or false

	-- Add another sound to the sequence
	if( generate ) then
		currentSequence[#currentSequence+1] = math.random(1,4)

		sequenceLength = sequenceLength + 1
		sequenceText.text = "Current: " .. sequenceLength

	end


	-- Play the sequence back at a fixed speed.
	--
	-- Tip: You could introduce logic here to play longer sequences back faster and faster to make the game harder.
	--
	for i = 1, #currentSequence do
		timer.performWithDelay( 750 * i,
			function()
				doPress( currentSequence[i] )
			end
		)
		timer.performWithDelay( 750 * i + 400,
			function()
				doPress( currentSequence[i], true)
			end
		)

	end

	-- Wait after the last part of the tune is played and the allow the player to touch buttons again.
	-- Also reset the 'playedSequence' list.
	timer.performWithDelay( 750 * #currentSequence + 400,
		function()
			pleaseWait = false
			playersTurn = true
			playedSequence  = {}
		end
	)

end


-- ==
--    isCorrectSequence() - Check the current tune versus the buttons the user has thus far 
--    pressed while playing back the current tune.  This function is called once per key press and will catch 
--    an incorrect playback as soon as it happens.
-- ==
isCorrectSequence = function ( )

	for i = 1, #playedSequence do
		--print(currentSequence[i], playedSequence[i])
		if (currentSequence[i] ~= playedSequence[i]) then
			return false
		end
	end

	return true
end

--==
-- ================================= LISTENER DEFINITIONS
--==

-- ==
--    onButtonTouch() - This is the event handler for all of the colored 'tune' buttons.
-- ==
onButtonTouch = function( event )
	-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	local phase    = event.phase  
	local target   = event.target

	-- Ignore touches if not player's turn
	--
	if( not playersTurn ) then 
		return true 
	end 

	-- Highlight the button and play its sound.  Also grab focus.
	-- All future touch events will go to this button.
	--
	if(event.phase == "began") then
		doPress( target.myNum )
		display.getCurrentStage():setFocus(event.target) 	

	-- De-highlight the button and test the current sequence vs. what the player has pressed so far.
	-- Also release focus (Future touch events will go to the next button that is touched.)
	--
	elseif(event.phase == "ended") then 
		doPress( target.myNum, true) 
		display.getCurrentStage():setFocus(nil) 

		-- add a new key to the 'played sequence'
		--
		playedSequence[#playedSequence+1] = target.myNum

		-- If the 'played sequence' and the current sequence are the same length do one final check then
		-- generate a new sound on the end of the sequence (assuming the player didn't goof the last key/sound).
		--
		if(#playedSequence == #currentSequence) then
		    
			-- Good job, you got it right
			--
			if( isCorrectSequence() ) then
				pleaseWait = true
				playersTurn = false
				timer.performWithDelay( 500, function() playTune( true ) end ) -- generate a new tune
		
				if(maxSequenceLength < sequenceLength) then
					maxSequenceLength = sequenceLength
					maxSequenceText.text = "Max: " .. maxSequenceLength
				end

			-- Oops, that last key/sound must have been wrong!
			--
			else
				currentSequence = {}
				playersTurn = false
				pleaseWait = true
				timer.performWithDelay( 250, 
					function()
						audio.play(failSound)						
					end
				)
				timer.performWithDelay( 2000, 
					function()
						playButtonText.text = "Play Game"
						pleaseWait = false
					end
				)
			end

	    -- The player has only keyed in some of the sounds in the sequence.
		-- Test what s/he has pressed so far.
		--
		elseif( not isCorrectSequence() ) then
			currentSequence = {}
			playersTurn = false
			pleaseWait = true
			timer.performWithDelay( 250, 
				function()
					audio.play(failSound)						
				end
			)
			timer.performWithDelay( 2000, 
				function()
					playButtonText.text = "Play Game"
					pleaseWait = false
				end
			)
		end

	end

	return true
end

-- ==
--    onPlay_RepeatButton() - This is the event handler for the 'Play Game' / 'Repeat' button.
-- ==
onPlay_RepeatButton = function( event )
	-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	local phase    = event.phase  
	local target   = event.target
	local label    = target.label


	-- Don't do anything when the button is pressed if the 'pleaseWait' flag is set.  Generally this means we're in the middle
	-- of a generation playback sequence. i.e. This will be set while the game is playing the current sequence and adding a new sound.
	--
	if( pleaseWait ) then 
		return true 
	end

	-- At the beginning of the touch, highlight the button and grab focus.
	-- All future touch events will go to this button.
	--
	if(event.phase == "began") then
		target:setFillColor( 0.25, 0.25, 0.25, 1 )
		display.getCurrentStage():setFocus(event.target) 

	-- At the end of the touch, de-highlight the button and either start the game or repeat the current sequence
	-- Also release focus (Future touch events will go to the next button that is touched.)
	--
	elseif(event.phase == "ended") then 
		target:setFillColor( 0.5, 0.5, 0.5, 1 )
		display.getCurrentStage():setFocus(nil) 

		-- If the button's label is "Play Game" start a new game
		--
		if(label.text == "Play Game") then
			label.text = "Repeat" 
			pleaseWait = true
			sequenceLength = 0
			timer.performWithDelay( 1000, function() playTune( true ) end ) -- generate a new tune

		-- Otherwise, play back the current tune to help the player memorize it.
		--
		else
			playTune() -- replay tune actually
		end

		pleaseWait = true
		playersTurn = false
	end

	return true
end

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
drawBoard()
