-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
--  main.lua
-- =============================================================
-- Uncomment the next line of code to make your logs QUIET, but be aware that this means
-- no print statements in your code will do anything.
--_G.print = function() end
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
_G.fontN 	= "fonts/Lato-Light.ttf" --native.systemFont
_G.fontB 	= "fonts/Lato-Black.ttf" --native.systemFontBold
-- =============================================================
require "ssk2.loadSSK"
_G.ssk.init( { measure = false } )
-- =============================================================
--ssk.meters.create_fps(true)
--ssk.meters.create_mem(true)
--ssk.misc.enableScreenshotHelper("s") 
-- =============================================================
-- =============================================================
--
-- Run Initialization Code
--
require "scripts.init"

local common = require "scripts.common"
local game  = require "scripts.game"

--
--  This is how you might noramlly start the game, but we are using a harness to control it and test it.
--
--[[
local sceneGroup = display.newGroup()
game.init()
game.create( sceneGroup )
timer.performWithDelay( 1000, game.start )
--]]

-- =============================================================
-- TESTING HARNESS BEGINS
-- =============================================================
----[[
--
-- Warning!  While playing with the harness DO NOT press any buttons during the continue/resume countdown: 3..2..1..
-- The game will malfunction.
--
-- In a normal game, you would not be able to do anything till the countdown elapsed, but in this case,
-- the harness in this file is outside the control of the game module.
--

--
-- Note: The following helper is not meant for learning, but instead 
-- as a nice way to launch and test the various game module features.
--
-- It is complicated and NOT designed for you to take apart.
-- However, if you want to, go for it.  :)
--

-- 'sceneGroup' is a display group put all game content into.
--
local sceneGroup = display.newGroup()

--
local buttons = {}
local interface = display.newGroup()
local bw,bh = 62, 30
local tweenX = bw + 9
local buttonY = bottom - bh - 10
local function newButton( x, y, label, func )
	local overrides = {
	   touchOffset       = {1,2},
	   labelSize         = 14,
	   labelColor        = _W_,
	}
   return ssk.easyIFC:presetPush( interface, "default", x, y, bw, bh, label, func, overrides )
end
local function d()
	for k,v in pairs( buttons ) do
		v:disable()
	end
end

local buttonDefinitions = {
	{ "Init", 		function() d(); buttons["Create"]:enable(); game.init(); end },
	{ "Create", 	function() d(); buttons["Start"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.create( sceneGroup ); end },
	{ "Start", 		function() d(); buttons["Stop"]:enable(); buttons["Pause"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.start(); end },
	{ "Stop", 		function() d(); buttons["Continue"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.stop(); end },
	{ "Continue", 	function() d(); buttons["Stop"]:enable(); buttons["Pause"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.continue(); end },
	{ "Pause", 		function() d(); buttons["Resume"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.pause(true); end },
	{ "Resume", 	function() d(); buttons["Stop"]:enable(); buttons["Pause"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.pause(false); end },
	{ "Destroy", 	function() d(); buttons["Create"]:enable(); game.destroy(); end },
	{ "Recreate", 	function() d(); buttons["Start"]:enable(); buttons["Destroy"]:enable(); buttons["Recreate"]:enable(); game.recreate(); end },
}

for i = 1, #buttonDefinitions do
	local text = buttonDefinitions[i][1]
	buttons[text] = newButton( tweenX * (i - 0.5), buttonY, text, buttonDefinitions[i][2] )
end

d()
buttons["Init"]:enable()

_G.hackStopButton = buttons["Stop"]

-- Comment these out to take full control of sequence/testing:
buttons["Init"]:toggle()
buttons["Create"]:toggle()
--]]


