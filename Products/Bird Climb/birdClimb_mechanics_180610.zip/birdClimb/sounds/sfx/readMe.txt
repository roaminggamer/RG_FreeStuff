Coin + Died sound made with BFXR: http://www.bfxr.net/


flap.wav - Free sound from http://soundbible.com