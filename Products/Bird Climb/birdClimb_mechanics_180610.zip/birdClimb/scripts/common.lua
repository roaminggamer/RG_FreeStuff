-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common = {}

-- =============================================================
-- Select an art theme for the game.
-- =============================================================
common.theme = "clone" -- casual clone flat medieval prototype kenney

-- ==
-- Color Codes
-- ==
--common.yellow					= hexcolor("#ffcc00")
common.green					= hexcolor("#4bcc5a")
common.pink						= hexcolor("#d272b4")
common.red						= hexcolor("#ff452d")
common.blue 					= hexcolor("#009eea")
common.colors 					= { common.green, common.pink, common.red, common.blue }

common.blue2 					= hexcolor("#009eea80")
common.gold 					= hexcolor("#FFDF00")

common.color2Alpha			= 204/255

if( common.theme == "clone" ) then
	common.textFill1 = hexcolor("#009eea")
	common.textFill2 = hexcolor("#009eea")
else
	common.textFill1 = hexcolor("#000000")
	common.textFill2 = hexcolor("#000000")
end

-- On an iPhoneX or another device with a notch at the top? Adjust for that.
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
common.titleOffsetY 	= topInset or 0
common.cornerOffsetX = leftInset --_G.oniPhoneX and 20 or 0
common.cornerOffsetY = topInset -- _G.oniPhoneX and 20 or 0

-- ==
-- Game Settings
-- ==
common.gravityX					= 0
common.gravityY					= 35
common.birdKickMag 				= 25
common.birdSpeed 					= 300
common.allColoredObj 			= {}
common.colorChangeFreq 			= 5

common.worldLeft 					= 0
common.worldRight 				= display.contentWidth
common.pickupSideInset			= 125
common.resumeCoinCost			= 30
common.rewardedAdEarnsCoins	= 20

common.levelHeight			= fullh * 1.5

-- When the game is resumed after a monster collision,
-- we delete nearby monsters.  This controls the delete distance.
common.monsterDestroyDistance = 200


return common
