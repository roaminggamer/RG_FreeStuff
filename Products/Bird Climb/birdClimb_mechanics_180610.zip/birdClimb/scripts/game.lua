-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- game.lua - Game Module
-- =============================================================
local common 		= require "scripts.common"
local physics     = require "physics"
local roomM       = require "scripts.room"
local playerM     = require "scripts.player"
local utils       = require "scripts.utils"

-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua & Corona Functions
local getTimer = system.getTimer; local mRand = math.random
local mAbs = math.abs; local mFloor = math.floor; local mCeil = math.ceil
local strGSub = string.gsub; local strSub = string.sub
-- Common SSK Features
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = math.normRot;local easyAlert = ssk.misc.easyAlert
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
local RGTiled = ssk.tiled; local files = ssk.files
local factoryMgr = ssk.factoryMgr; local soundMgr = ssk.soundMgr
--if( ssk.misc.countLocals ) then ssk.misc.countLocals(1) end

-- =============================================================
-- Forward Declarations
-- =============================================================
local colorSet
local onSound

-- =============================================================
-- Locals
-- =============================================================
local origCreateParams
local origStartParams
local gemBag =  ssk.shuffleBag.new( 0, 0, 1, 1, 1, 1, 2, 2 )
gemBag:shuffle()
--
local diedCount = 0 
--
local pauseBlocker
local aboutButton
local coinIcon
local coinCountLabel

-- =============================================================
-- Module Begins
-- =============================================================
local game = {}

-- ==
--    init() - One-time initialization of game module.
-- ==
function game.init()
   physics.start()
   physics.setGravity( common.gravityX, common.gravityY )
   --physics.setDrawMode("hybrid")
   common.gameInitialized = true
   common.gameCreated     = false
   common.gameIsRunning   = false
   common.gameIsPaused    = false
   --
   common.level = 0
   common.highestLevelToday = 0
end

-- ==
--    create()
-- ==
function game.create( group, params )
   if( common.gameInitialized == false ) then return end
   group = group or display.currentStage
	params = params or {}
   --
   game.destroy() 
   origCreateParams = params
   --
   local layers = ssk.display.quickLayers( group, 
      "underlay", 
      "world", 
         { "background", "particles", "content", "pickups", "monsters", "scores", "instructions" },
      "overlay",
      "blocker" )
   common.layers = layers

   -- ==
   -- Add coins icon
   -- == -- 
   coinIcon = newImageRect( layers.overlay, 
                                w - 80 - common.cornerOffsetX, 
                                top + common.cornerOffsetY + 50, 
                                "images/coin.png",
                                { w = 50, h = 50, isGem = true, fill = common.gold },
                                { bodyType = "static", isSensor = true, radius = 22 } )
   --
   coinCountLabel = easyIFC:quickLabel( layers.overlay, "0", coinIcon.x - 30, coinIcon.y, _G.fontN, 40, _W_, 1 )
   --
   function coinCountLabel.onUpdateCoins(self)
      coinCountLabel.text = ssk.persist.get( "settings.json", "coins" )
   end; listen( "onUpdateCoins", coinCountLabel )
   coinCountLabel:onUpdateCoins()
   --
   function coinCountLabel.finalize( self )
      ignoreList( { "onUpdateCoins" }, self )
   end; coinCountLabel:addEventListener("finalize")

   -- ==
   -- Create easy input helper.
   -- ==
   ssk.easyInputs.oneTouch.create( layers.underlay, { debugEn = false, keyboardEn = false } )

   -- ==
   -- Create player.
   -- ==
   playerM.create()

   -- ==
   -- Create walls and first set of monsters.
   -- ==   
   roomM.setColorSet( colorSet ) -- Passes colorSet function to room module for use from there.
   roomM.drawWallsAndFloor()
   roomM.drawMonsters( 0 )

   -- ==
   -- Use 'enterFrame' listener to generate more monsters when needed.
   -- ==
   function layers.enterFrame( self )
      -- ==
      -- Request monsters generation if we need to.
      -- ==
      if( (common.player.highY - common.levelHeight) < common.player.genY ) then
         -- 1 in 2 chance of drawing a pickup
         roomM.drawMonsters( gemBag:get() )
      end
   end; listen( "enterFrame", layers )

   -- ==
   -- 'onDied' event listener use to handle bird 'death' event.
   -- ==
   function layers.onDied()

      -- THIS IS A HACK TO HOOK THIS CODE TO THE TESTING MENU IN MAIN 
      -- DON'T KEEP THIS IN A REAL GAME
      if( _G.hackStopButton ) then
         _G.hackStopButton:toggle()
      
      -- INSTEAD DO SOMETHING MEANINGFUL ==>
      --
      -- In this case, we stop, then continue in 1 second
      -- (In the full template we give the user a chance to resume for coins or an ad watch.)      
      else      
         game.stop()
         timer.performWithDelay( 1000, game.continue )
      end
   end; listen( "onDied", layers )


   -- ==
   -- Clean up when we destroy the layers super-group.
   -- ==
   function layers.finalize( self )
      ignoreList( { "enterFrame", "onDied" }, self )
   end; layers:addEventListener( "finalize" )

  
   local soundButton = easyIFC:presetToggle( layers.overlay, "sound", 
                                             right - common.cornerOffsetX - 50, 
                                             top + common.cornerOffsetY + 50, 
                                             50, 50, "", onSound )

   if( persist.get( "settings.json", "sound_enabled" ) ) then
      soundButton:toggle(true)
   end

   -- Show scores and plays 
   easyIFC:quickLabel( layers.scores, "Today's High: " .. common.highestLevelToday, centerX, centerY - 250, _G.fontN, 30, common.color1 )
   easyIFC:quickLabel( layers.scores, "Games Played: " .. ssk.persist.get( "settings.json", "gamesPlayed" ), centerX, centerY - 210, _G.fontN, 30, common.color1 )
   easyIFC:quickLabel( layers.scores, "Highscore: " .. ssk.persist.get( "settings.json", "bestScore" ), centerX, centerY - 170, _G.fontN, 30, common.color1 )

   --
   -- Mark game as created 
   --
   common.gameCreated    = true  
end

-- ==
--    destroy() - Remove all game content and reset game state.
-- ==
function game.destroy()
   common.gameCreated      = false
   common.gameIsRunning    = false
   common.gameIsPaused     = false
   --
   display.remove( common.layers )
   common.layers = nil
   --
   origCreateParams = nil
   origStartParams = nil
   --
   common.allColoredObj = {}
   common.level = 0
   --
   pauseBlocker = nil
   aboutButton = nil
   coinIcon = nil
   coinCountLabel = nil
   -- 
   common.monsters = {}
end

-- ==
--    start()
-- ==
function game.start( params )
   if( common.gameCreated == false ) then return end
   params = params or { }
   origStartParams = params
   --
   physics.start()
   --
   common.gameIsRunning = true
   common.gameIsPaused  = false
   --
   common.player:startMoving()

   -- Increment 'games played' count
   ssk.persist.set( "settings.json", "gamesPlayed", ssk.persist.get( "settings.json", "gamesPlayed" ) + 1 )
end

-- ==
--    stop()
-- ==
function game.stop()
   if( common.gameIsRunning == false ) then return end
   game.pause(true)
   common.gameIsRunning = false
end


-- ==
--    restart()
-- ==
function game.restart( )
   if( common.gameCreated == false ) then return end
   local tmp = origStartParams
   game.create( common.layers.parent, origCreateParams )
   game.start( tmp )
end

-- ==
--    recreate()
-- ==
function game.recreate( )
   if( common.gameCreated == false ) then return end
   local tmp = origStartParams
   game.create( common.layers.parent, origCreateParams )

end


-- ==
--    continue() - Continue a stopped game.
-- ==
function game.continue()
   if( common.gameCreated == false ) then return end
   if( common.gameIsRunning == true ) then return end
   -- 
   roomM.destroyMonstersNearPlayer()
   --
   common.gameIsRunning = true
   -- Unpause game
   game.pause(false, true)
end


-- ==
--    pause( pause ) - Pause/resume game. 
-- ==
function game.pause( pause )
   if( common.gameIsRunning == false ) then return end
   if( common.gameIsPaused == pause ) then return end
   
   -- PAUSE
   if( pause ) then      
      physics.pause()
      --
      pauseBlocker = newRect( common.layers.blocker, centerX, centerY, 
         { size = 10000, alpha = 0.1, touch = function() return true end  })
      transition.to( pauseBlocker, { alpha = 0.75, time = 800 } )
      
   
   -- RESUME
   else 
      local function onComplete()
         local counterBack = newImageRect( common.layers.blocker, centerX, centerY,
                                           "images/counterBack.png", 
                                           { w = 230/2, h = 200/2, fill = common.color1 } )
         local countLabel = easyIFC:quickLabel( common.layers.blocker, "3", counterBack.x, counterBack.y, _G.fontB, 80 )
         local count = 3
         timer.performWithDelay( 1000, 
            function()
               count = count - 1
               countLabel.text = count
               if( count <= 0 ) then
                  display.remove(counterBack)
                  display.remove(countLabel)
                  physics.start()
                  display.remove( pauseBlocker )
                  pauseBlocker = nil
                  common.player:startMoving()
               end
            end, 3)
      end
      transition.to( pauseBlocker, { alpha = 0.1, time = 750, onComplete = onComplete } )
      
   end

   common.gameIsPaused = pause
end


----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------

--
-- This function is used to update the color theme and set the 
-- of the coin count label color to match the current color theme.
--
-- While the user plays the game, the room module changes the level color 
-- every N levels.
--
colorSet = function()
   --
   -- Colorize our buttons based on the current color theme
   common.color1 = common.currentColor
   common.color2 = { common.color1[1], common.color1[2], common.color1[3], common.color2Alpha  }

   coinCountLabel:setFillColor( unpack(common.color1) )
end

-- Sound Button Listener
onSound = function( event )
   if( event.phase == "moved" ) then return false end
   local target = event.target 
   persist.set( "settings.json", "sound_enabled", target:pressed() )
   soundMgr.enableSFX( persist.get( "settings.json", "sound_enabled" ) )
   post("onSound", { sound = "click" } )
end


return game