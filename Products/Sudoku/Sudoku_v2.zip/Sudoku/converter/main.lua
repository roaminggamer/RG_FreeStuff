-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================
local function myUnhandledErrorListener( event )
	return true
end

Runtime:addEventListener("unhandledError", myUnhandledErrorListener)

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
require( "helpers" )
sudokuData = require("sudokuData")

----------------------------------------------------------------------
-- 2. Execution
----------------------------------------------------------------------
--local tmp = sudokuData.convert2Tables( "1board.txt" )
--local tmp = sudokuData.convert2Tables( "10boards.txt" )
local tmp = sudokuData.convert2Tables( "100boards.txt" )

-- Uncomment this line to print the entire contents of the table
-- Warning: Don't do this for big tables unless you have lots of time :)
--table.print_r( tmp )

local pd = {}

p1 = {} -- Very Easy
p2 = {} -- Easy
p3 = {} -- Normal
p4 = {} -- Hard
p5 = {} -- Very Hard

pd[1] = p1
pd[2] = p2
pd[3] = p3
pd[4] = p4 
pd[5] = p5

-- Sort the temprary table of puzzles by difficulty
for i = 1, #tmp do
	local curPuzzle = tmp[i]
	if( curPuzzle.rating >= 4.5 ) then 
		p5[#p5+1] = curPuzzle
	elseif( curPuzzle.rating >= 3.5 ) then 
		p4[#p4+1] = curPuzzle
	elseif( curPuzzle.rating >= 2.5 ) then 
		p3[#p3+1] = curPuzzle
	elseif( curPuzzle.rating >= 1.5 ) then 
		p2[#p2+1] = curPuzzle
	else
		p1[#p1+1] = curPuzzle
	end	

end

print(#p1, " very easy puzzles found" )
print(#p2, " easy puzzles found" )
print(#p3, " normal puzzles found" )
print(#p4, " hard puzzles found" )
print(#p5, " very hard puzzles found" )

table.save(pd,"pd.txt" )

