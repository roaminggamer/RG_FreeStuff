-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- converter.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------


----------------------------------------------------------------------
--  3. Local Variables and Forward Declarations
----------------------------------------------------------------------

-- Locals


-- Forward Declarations

----[[
--]]

----------------------------------------------------------------------
--  4. Function Implementations
----------------------------------------------------------------------

-- ==
--	convert2Tables() - Convert a sudoku puzzles source file to a table.
-- ==
local function convert2Tables( fileName )

	if( not io.exists(  fileName, system.ResourceDirectory ) ) then
		print("ERROR: Could not find file: ", fileName )
		return nil
	end

	local theData = {}
	local curPuzzle
	local values
	
	local tmp = io.readFileTable( fileName, system.ResourceDirectory )
	
	for i = 1, #tmp do

		tmp[i] = tmp[i]:rmspaces()


		if( tmp[i]:contains( "PUZZLE" ) ) then
			--print("New Puzzle")
			if(curPuzzle) then
				curPuzzle.solutionData = values
			end

			curPuzzle = {}
			theData[#theData+1] = curPuzzle
			values = ""

		elseif( tmp[i]:contains( "SOLUTION" ) ) then
			--print("Solution")
			values = ""

		elseif( tmp[i]:contains( "RATING" ) ) then
			curPuzzle.rating = tmp[i]:rm("RATING:")
			curPuzzle.rating = tonumber( curPuzzle.rating )
			--print("Rating: " .. curPuzzle.rating )

			curPuzzle.puzzleData = values

		elseif( #tmp[i] > 0 ) then
			values = values .. tmp[i]
			--print(values)
		end
	end

	if(curPuzzle) then
		curPuzzle.solutionData = values
	end

	return theData

end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}

public.convert2Tables  = convert2Tables

return public
