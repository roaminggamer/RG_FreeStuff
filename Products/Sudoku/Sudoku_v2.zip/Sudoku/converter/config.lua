-- Magic Recipe for Scaling: http://www.coronalabs.com/blog/2010/11/20/content-scaling-made-easy/
application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterBox", 
	},
}