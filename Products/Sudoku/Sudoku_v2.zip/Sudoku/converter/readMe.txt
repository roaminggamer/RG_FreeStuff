You must provide your own puzzles and solutions to make the game template work.  

As an example I have provided three sample source files so you can see how the source files should be organized:

* 1board.txt    - Contains a single sudoku puzzle with the solution.
* 10boards.txt  - Contains 10 sudoku puzzles with the solutions.
* 100boards.txt - Contains 100 sudoku puzzles with the solutions.


SAMPLE AND FORMATTING RULES
===========================
1board.txt contains the following (w/o my annoations) and is formatted thus:
PUZZLE                     <= This line tells the converter that puzzle data follows.
4___719__                  <= 1 or more lines after 'PUZZLE' containing numbers and underbars
___3_____                  <= where the total of each is 81 total characters (a 9x9 grid worth).
_9__8__5_                  <= Underbars are blanks in the initial puzzle.
__1____7_                  <= Numbers are shown in the initial puzzle.
2__4__83_
________4
9________
_3_2__6_8
72___64__

RATING: 0                  <= RATING: x.m   Tells the converter the difficulty for this puzzle can be 0 to 6

SOLUTION                   <= This line tells the convert that the puzzle solution follows.
462571983                  <= 1 or more lines after 'SOLUTION' containing a total of 81 numbers
815392746                  <= This is the row, by row solution to the puzzle.
397684152
641823579
279465831
583719264
956148327
134257698
728936415

The converter ignores blank lines.


CONVERTING A SOURCE FILE
===========================
1. Create a new source file using the above rules for foramtting and content and place it in 'converter/' folder.

2. Edit 'converter/main.lua' around line 21 to select your source file.

3. Save your changes and run 'convert/main.lua' in the simulator.

4. Copy the resultant table as follows:

  A. Open the  'Documents' directory in the project Sandbox:
     - From Windows Simulator App: 'File -> Show Project Sandbox'
     - Double click 'Documents' directory in explorer window when it pops up.

  B. Locate pd.txt in the 'Documents' folder.  It it is not there look for errors in the simulator console from your conversion run.

  C. Copy pd.txt to the 'Sudoku_Pure/' folder, replacing the pd.txt file that is there.

Done!  Now you can run the game with your puzzle data.





