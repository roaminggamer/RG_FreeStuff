==============================================================================

Roaming Gamer, LLC "Game Template Package" for the game: Sudoku

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Tips / FAQ - Miscellaneous tips to help you with changing the template, as
   well as answers to question(s) you might have.

D. Reporting Bugs - How to report bugs with this template.

==============================================================================

A. Short and Sweet License 
==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.
   - use anything in this kit to make game templates, starter kits, or any other
     training and/or educational products.


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.




B. What's in the template package?
==================================
Sudoku is a Spirograph like drawing app.  It demonstrates how easily you can use the built-in
features of the Corona SDK to make interesting games and apps.  You just have to think outside the box.


This package only contains:

- Sudoku_Pure/ - A fully functional game with splash screen, main menu, and 100 puzzles written in Pure Lua and Corona SDK.
- Sudoku_Pure_Graphisc2.0/ - Same as above for graphics 2.0 Corona.
- converter/   - A tool to convert sudoku puzzle files into tables that can then be used by the game.  Includes three sample source files to show the proper formatting of puzzle data.
                See 'converter/readMe.txt' for instructions on generating new sudoku tables.

													   
C. Tips / FAQ
=============
* Question: "Where can I go to get more templates?" 
    Answer: The Roaming Gamer, LLC website of course: http://roaminggamer.com/
	

D. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please write me here: 

roaminggamer@gmail.com 

Be sure to include this information in your e-mail:

e-mail Title: "Template Bug: Sudoku"

e-mail Body:

Tell me these details,
	- What you did, 
	- What you expected to see, and 
	- What happened instead.

Please provide any other details about the bug that seem pertinent.


Thanks,

The Roaming Gamer



