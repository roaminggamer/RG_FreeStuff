-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
--
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--  3. Local Variables and Forward Declarations
----------------------------------------------------------------------

-- Locals
local splashGroup 
local menuGroup
local templatesButton
local rgButton


-- Foward Declarations
local destroy
local onGameTemplates
local onRG

----------------------------------------------------------------------
--  4. Function Implementations
----------------------------------------------------------------------

-- ==
--	create() - Create the splash screen.
--
-- -- Tip: This function takes an optional 'parentGroup' argument that allows us to place all of the game's display objects in 
--         a parent group if we want.  This allows you to make this game's content a child of storyboard groups and other frameworks if you want.
--
-- ==
local function create( parentGroup )

	local parentGroup = parentGroup or display.currentStage

	-- Create a separate top-level group to contain all the splash screen objects.
	-- This makes it easy to destroy the splash screen later.
	--
	splashGroup = display.newGroup()	
	parentGroup:insert(splashGroup)

	-- Create a background image.
	local splashImg = display.newImage( splashGroup, "images/splashBack.jpg", 0, 0 )
	splashImg.x = centerX
	splashImg.y = centerY

	-- Add badges with touch listeners
	-- Game Templates Badge
	templatesButton = display.newImageRect( splashGroup, "images/badges/gametemplates.png", 130, 40 )
	templatesButton.x = 135/2 + 5
	templatesButton.y = h - 25
	templatesButton.touch = onGameTemplates
	templatesButton:addEventListener( "touch", templatesButton )

	-- Roaming Gamer Badge
	rgButton = display.newImageRect( splashGroup, "images/badges/rg.png", 40, 40 )
	rgButton.x = w - 25
	rgButton.y = h - 25
	rgButton.touch = onRG
	rgButton:addEventListener( "touch", rgButton )


	-- After a short delay, switch to the main menu
	--
	timer.performWithDelay( 2000, 
		function()
			if( splashGroup ) then
				menuGroup = mainMenu.create()
				menuGroup.alpha = 0
				transition.to( menuGroup, { time = 250, alpha = 1 } )
			end
		end )

	timer.performWithDelay( 2500, 
		function()
			if( splashGroup ) then
				destroy()
				menuGroup = nil
			end
		end )			

end

-- ==
--	destroy() - Destroy the splash screen and all its contents.
-- ==
destroy = function( )

	if( splashGroup ) then
		templatesButton:removeEventListener( "touch", templatesButton )
		rgButton:removeEventListener( "touch", rgButton )

		splashGroup:removeSelf()
		splashGroup = nil

		templatesButton = nil
		rgButton = nil

	end
end

-- ==
--	onGameTemplates() - A touch listener for touches on the 'templates' icon.
-- ==
onGameTemplates = function ( self, event ) 
	if( event.phase == "ended" ) then
		system.openURL( "http://roaminggamer.com/makegames"  )
	end
	return true
end

-- ==
--	onRG() - A touch listener for touches on the 'Roaming Game' icon.
-- ==
onRG = function ( self, event ) 
	if( event.phase == "ended" ) then
		system.openURL( "http://roaminggamer.com"  )
	end
	return true
end


----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}

public.create  = create
public.destroy = destroy

return public
