-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
--
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--  3. Local Variables and Forward Declarations
----------------------------------------------------------------------

-- Locals
local menuBackImg
local menuGroup 
local resumeButton
local difficultyButton
local difficultyText
local playButton
local templatesButton
local rgButton


-- Foward Declarations
local destroy
local onResume
local onDifficulty
local onPlay

local touchBlocker
local selectPuzzle

local onGameTemplates
local onRG


----------------------------------------------------------------------
--  4. Function Implementations
----------------------------------------------------------------------

-- ==
--	create() - Create the main menu.
--
-- -- Tip: This function takes an optional 'parentGroup' argument that allows us to place all of the game's display objects in 
--         a parent group if we want.  This allows you to make this game's content a child of storyboard groups and other frameworks if you want.
--
-- ==
local function create( parentGroup )

	local parentGroup = parentGroup or display.currentStage

	-- Create a separate top-level group to contain all the main menu objects.
	-- This makes it easy to destroy the main menu later.
	--
	menuGroup = display.newGroup()
	parentGroup:insert(menuGroup)

	-- Menu Background Image
	menuBackImg = display.newImage( menuGroup, "images/menuBack.jpg", 0, 0 )
	menuBackImg.x = centerX
	menuBackImg.y = centerY

	-- Tip: Because the main menu can be brought up while playing the game,
	-- and because it will simply be 'over' the current game, we want to block any
	-- stray touches from dropping through to the covered puzzle.
	-- By attaching a 'do nothing' blocking touch listener, we can achieve this goal.
	--
	menuBackImg.touch = touchBlocker
	menuBackImg:addEventListener("touch", menuBackImg)
	
	-- Menu Background Rect
	local menuRect = display.newRoundedRect( menuGroup, 0, 0, 300, 150,12 )
	menuRect.x = centerX
	menuRect.y = centerY
	menuRect.strokeWidth = 2
	menuRect:setStrokeColor( 0,0,0 )	
	menuRect:setFillColor( 255,255,255 )
	
	-- Resume Button
	resumeButton = display.newRoundedRect( menuGroup, 0, 0, 240 , 50 ,12 )
	resumeButton.x = centerX
	resumeButton.y = centerY - 35
	resumeButton.strokeWidth = 2
	resumeButton:setStrokeColor( 0,0,0 )
	resumeButton:setFillColor( 159,255,217 )

	local buttonText = display.newText( menuGroup, "Resume", 20, 10, native.systemFontBold, 20)
	buttonText:setTextColor(0)
	buttonText.x = resumeButton.x
	buttonText.y = resumeButton.y

	if( gameInProgress and not puzzleSolved ) then
		resumeButton.touch = onResume
		resumeButton:addEventListener( "touch", resumeButton )
	
	else
		resumeButton:setFillColor( 128 )
		buttonText:setTextColor( 140 )

	end

	-- Difficulty Button
	difficultyButton = display.newRoundedRect( menuGroup, 0, 0, 110 , 50 ,12 )
	difficultyButton.x = centerX - 65
	difficultyButton.y = centerY + 35
	difficultyButton.strokeWidth = 2
	difficultyButton:setStrokeColor( 0,0,0 )
	difficultyButton:setFillColor( 159,214,217 )

	difficultyText = display.newText( menuGroup, difficultyLevels[currentDifficulty], 20, 10, native.systemFontBold, 20)
	difficultyText:setTextColor(0)
	difficultyText.x = difficultyButton.x
	difficultyText.y = difficultyButton.y


	difficultyButton.touch = onDifficulty
	difficultyButton:addEventListener( "touch", difficultyButton )

	-- Play Button
	playButton = display.newRoundedRect( menuGroup, 0, 0, 110 , 50 ,12 )
	playButton.x = centerX + 65
	playButton.y = centerY + 35
	playButton.strokeWidth = 2
	playButton:setStrokeColor( 0,0,0 )
	playButton:setFillColor( 159,214,217 )

	local buttonText = display.newText( menuGroup, "Play", 20, 10, native.systemFontBold, 20)
	buttonText:setTextColor(0)
	buttonText.x = playButton.x
	buttonText.y = playButton.y

	playButton.touch = onPlay
	playButton:addEventListener( "touch", playButton )

	-- Add badges with touch listeners
	-- Game Templates Badge
	templatesButton = display.newImageRect( menuGroup, "images/badges/gametemplates.png", 130, 40 )
	templatesButton.x = 135/2 + 5
	templatesButton.y = h - 25
	templatesButton.touch = onGameTemplates
	templatesButton:addEventListener( "touch", templatesButton )

	-- Roaming Gamer Badge
	rgButton = display.newImageRect( menuGroup, "images/badges/rg.png", 40, 40 )
	rgButton.x = w - 25
	rgButton.y = h - 25
	rgButton.touch = onRG
	rgButton:addEventListener( "touch", rgButton )

	monitorMem()

	return menuGroup
end

-- ==
--	destroy() - Destroy the meain menu and all its contents.
-- ==
destroy = function( )

	if( menuGroup ) then
		menuBackImg:removeEventListener("touch", menuBackImg)
		resumeButton:removeEventListener("touch", resumeButton)
		difficultyButton:removeEventListener("touch", difficultyButton)		
		playButton:removeEventListener("touch", playButton)

		menuGroup:removeSelf()
		menuGroup = nil
		menuBackImg = nil
		resumeButton = nil
		difficultyButton  = nil
		difficultyText = nil
		playButton  = nil
	end
	monitorMem()
end


-- ==
--	onResume() - Touch handler for the 'resume' button.
-- ==
onResume  = function( self, event )

	local target   = event.target
		
	if(event.phase == "began") then
		-- Grab the focus so this button gets all future touch events.
		display.getCurrentStage():setFocus(event.target)

	elseif(event.phase == "ended") then
		-- Release the focus so that the next button touched will get touch events.
		display.getCurrentStage():setFocus(nil)

		-- After a short delay, destroy the main menu and go back to the game in progress.
		-- Also restart the game timer.
		timer.performWithDelay( 100, 
			function() 
				destroy() 
				if( gameInProgress ) then
					theGame.restartTimer()
				end
			end ) 
	end
	
	return true
end

-- ==
--	onDifficulty() - This touch listener is used to change the requested difficulty level.
-- ==
onDifficulty  = function( self, event )

	local target   = event.target
	
	if(event.phase == "began") then
		-- Grab the focus so this button gets all future touch events.
		display.getCurrentStage():setFocus(event.target)

	elseif(event.phase == "ended") then
		-- Release the focus so that the next button touched will get touch events.
		display.getCurrentStage():setFocus(nil)

		if( difficultyText.text == "Very Easy" ) then
			 difficultyText.text = "Easy"
			 currentDifficulty = 2
		
		elseif( difficultyText.text == "Easy" ) then
			difficultyText.text = "Normal"
			currentDifficulty = 3
		
		elseif( difficultyText.text == "Normal" ) then
			difficultyText.text = "Hard"
			currentDifficulty = 4
		
		elseif( difficultyText.text == "Hard" ) then
			difficultyText.text = "Very Hard"
			currentDifficulty = 5
		
		else
			difficultyText.text = "Very Easy"
			currentDifficulty = 1
		end		
	end
	
	return true
end

-- ==
--	onPlay() - The touch listener for the 'play' button.
-- ==
onPlay  = function( self, event )

	local target   = event.target
	
	if(event.phase == "began") then
		-- Grab the focus so this button gets all future touch events.
		display.getCurrentStage():setFocus(event.target)

	elseif(event.phase == "ended") then
		-- Release the focus so that the next button touched will get touch events.
		display.getCurrentStage():setFocus(nil)

		-- After a short delay destroy the main menu, then create a new game board.
		timer.performWithDelay( 100, 
			function() 
				destroy() 
				theGame.destroy()
				selectPuzzle()
				theGame.create( nil )
			end ) 		
	end
	
	return true
end

-- ==
--	touchBlocker() - A touch listener that grabs all touches on the backgrounds and stops
--                   them from propagating further.
-- ==
touchBlocker  = function( self, event )
	return true
end


-- ==
--	selectPuzzle() - A simple function to randomly select the current puzzle number out of the
--  selected difficuly level puzzle set.
-- ==
selectPuzzle  = function( self, event )

	-- Randomly select a puzzle at the current difficulty level.
	-- 
	currentPuzzle = math.random( 1, #pd[currentDifficulty] )
	return true
end


-- ==
--	onGameTemplates() - A touch listener for touches on the 'templates' icon.
-- ==
onGameTemplates = function ( self, event ) 
	if( event.phase == "ended" ) then
		system.openURL( "http://roaminggamer.com/makegames"  )
	end
	return true
end

-- ==
--	onRG() - A touch listener for touches on the 'Roaming Game' icon.
-- ==
onRG = function ( self, event ) 
	if( event.phase == "ended" ) then
		system.openURL( "http://roaminggamer.com"  )
	end
	return true
end


----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}

public.create  = create
public.destroy = destroy

return public
