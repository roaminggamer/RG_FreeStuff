-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua
-- =============================================================
local function myUnhandledErrorListener( event )
	return true
end

Runtime:addEventListener("unhandledError", myUnhandledErrorListener)

----------------------------------------------------------------------
--	1. Globals - Load first as these are used by most modules.
----------------------------------------------------------------------
-- Useful position variables
_G.w = display.contentWidth
_G.h = display.contentHeight
_G.centerX = w/2
_G.centerY = h/2

_G.gameInProgress = false
_G.puzzleSolved = false
_G.currentDifficulty = 1
_G.difficultyLevels = { "Very Easy", "Easy", "Normal", "Hard", "Very Hard" }
_G.currentPuzzle = 1

----------------------------------------------------------------------
--	2. Requires
----------------------------------------------------------------------
require( "helpers" )

_G.splash         = require("splash")
_G.mainMenu       = require("mainMenu")
_G.theGame        = require( "theGame" )

----------------------------------------------------------------------
--	3. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)
--system.activate("multitouch")


--[[
-- Note: The puzzles data is stored in one large file as a json encoded table.
-- The following line loads all that data into memory as a big table.
-- This is pretty fast, but you may want to change the way data is stored and retrieved
-- if you have tens of thousands or more puzzles.

-- Note 2: This game template comes with 100 puzzles.

--  The puzzle table is organized like this

pd = { 
		{ { Puzzle 1 }, { Puzzle 2 }, ... , { Puzzle N },  }, -- pd[1] Very Easy Puzzles Table
		
		{ { Puzzle 1 }, { Puzzle 2 }, ... , { Puzzle N },  }, -- pd[2] Easy Puzzles Table
		
		{ { Puzzle 1 }, { Puzzle 2 }, ... , { Puzzle N },  }, -- pd[3] Normal Puzzles Table
		
		{ { Puzzle 1 }, { Puzzle 2 }, ... , { Puzzle N },  }, -- pd[4] Hard Puzzles Table
		
		{ { Puzzle 1 }, { Puzzle 2 }, ... , { Puzzle N },  }, -- pd[5] Very Hard Puzzles Table
	}

-- Additionally, every individual puzzle has these fields:

      rating - Integer value between 0 and 6
  puzzleData - String of integers and underbars (blanks) representing the initial puzzle.
solutionData - String of integers representing the solved puzzle.

-- For example, to get the rating if the 25th HARD puzzle, you would access pd like this:

local rating = pd[4][25].rating

--]]

monitorMem()
_G.pd = table.load( "pd.txt", system.ResourceDirectory )

----------------------------------------------------------------------
-- 4. Local Variables and Functions
----------------------------------------------------------------------

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
monitorMem()
splash.create()
--theGame.create(nil)
monitorMem()
--
-- Note: You notice the many calls to 'monitorMem()' and the terminal ouput.  I added this to show that the game does not leak.
-- After several rounds it should settle in at a max of about 1MB of main memory and 10MB of texture memory on the simulator.
--
