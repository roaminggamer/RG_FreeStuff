-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
--
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- None.

----------------------------------------------------------------------
--  3. Local Variables and Forward Declarations
----------------------------------------------------------------------

-- == LOCALS
-- Layer Locals
local layers

-- Board Locals
local offsetX = 0
local offsetY = 0
local gridButtons      -- Each tile is a 'button'
local gridNumbers      -- This variable will hold a table of 81 tables of number images (1 .. 9)
local gridGuesses      -- This variable will hold a table of 81 tables of guess images (1 .. 9)

-- Interface Locals
local curNumber = 1          -- Current number selected on number pad
local curMode   = "number"   -- Current touch mode:
                             -- "number" - Touching a tile will show/hide 'curNumber' and hide all guesses on that tile
                             -- "guess"  - Touching a tile will show/hide the guess image 'curNumber' on that tile
							 -- "clear"  - Touching aa tile will clear it if (and only if) a number is present.  Does not clear guesses.
local allButtons             -- A table to contain references to all of the interface buttons (numbers, note, clear, menu)
local numberButtons          -- A variable to contain a specific reference to the number buttons ONLY.
local noteButton			 -- A variable to contain a specific reference to the note button ONLY.	
local clearButton			 -- A variable to contain a specific reference to the clear button ONLY.
local menuButton			 -- A variable to contain a specific reference to the menu button ONLY.
local lastTimer				 -- A variable used to track the return value for calls to performWithDelay() so we can cancel them. (Used for game timer.)
local timerText              -- A variable to contain a reference to the timerText object
local currentSeconds = 0     -- A variable to contain the current number of seconds played on the current game.  (Used for game timer.)
local completedText          -- A variable to contain a reference to the 'completed'/'errors' message you get when the board is filled.

-- == FORWARD DECLARATIONS
-- Layer Forward Declarations
local createLayers
local destroyLayers

-- Board Forward Declarations
local createBoard
local destroyBoard
local updateHighlights  
local onTouchGrid

-- Interface Forward Declarations
local createInterface
local destroyInterface
local onTouchButton
local clearNumberButtons
local checkSolution
local startTimer
local stopTimer
local onTimer
local stopGame

----------------------------------------------------------------------
--  4. Function Implementations
----------------------------------------------------------------------
-- ==
--	createGame() - A single function that calls various other 'create' functions to create our game and start it.
--
-- -- Tip: This function takes an optional 'parentGroup' argument that allows us to place all of the game's display objects in 
--         a parent group if we want.  This allows you to make this game's content a child of storyboard groups and other frameworks if you want.
--
-- ==
local function createGame( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	createLayers( parentGroup )
	createBoard( layers )
	createInterface( layers )
	updateHighlights()

	-- Mark the game as being 'in progress'
	gameInProgress = true
	monitorMem()
end

-- ==
-- destroyGame() - A single function that calls various other 'destroy' functions to stop and destroy the current game (before starting a new one.)
-- ==
local function destroyGame( )
	
	-- Because we always call this function before creating a board (even the first time the game is started),
	-- let's check the 'gameInProgress' and 'puzzleSolved' status.
	--
	-- We only need to destroy the board in these cases:
	-- 
	-- 1. gameInProgress and not puzzleSolved - Game is in progress but not completed.
	-- 2. not gameInprogress and puzzleSolved - The game is over and the puzzle has been solved.
	--
	-- Case 1 can happen if the user pauses the game via the 'menu' button then clicks 'play' instead of 'resume'.
	-- Case 2 happens if the user pauses the via the 'menu' button after winning a game and then clicks 'play'.
	--
	-- Tip: I could just as well have done this in the place where I call this function, but now I can safely call it from anywhere
	-- without worrying that I'll destroy a non-created board.
	--
	if( gameInProgress or puzzleSolved ) then
		destroyInterface( )
		destroyBoard( )
		destroyLayers( )
	end

	-- Mark the game as not 'in progress' and the puzzle as not solved.
	gameInProgress = false
	puzzleSolved = false
	monitorMem()
end


-- =============================================================
-- Rendering Layers
-- =============================================================
-- ==
--	createLayers() - A function to create 'rendering' layers using the Corona group object.
--
-- Tip: The best way to enforce render laying is by using groups.
--
-- ==
createLayers = function( parentGroup )
	local parentGroup = parentGroup or display.currentStage 

	layers          =	display.newGroup() -- A group contain all the following layers (makes destroying the groups easy)

	layers.back     =	display.newGroup() -- A group for the background
	layers.grid     =	display.newGroup() -- A group for the grid
	layers.pieces   =	display.newGroup() -- A group for the board pieces

	layers.buttons =	display.newGroup() -- a group for the number buttons
	layers.ifcs    =	display.newGroup() -- a group for the remaining buttons and other interface elements

	-- Insert the board layer into the 'parentGroup' display group.
	-- 
	-- Tip: This makes it easy to use this module with the 'storyboard' framework and other 
	-- frameworks that want to 'own' the content in a scene.
	--
	parentGroup:insert( layers )

	-- Insert the rest of the layers (groups) into our board group.
	--
	-- Tip: Again, this makes it easy for us to destroy the board later.
	-- 
	-- Tip2: By inserting these groups into another group, we modiry/control their rendering order.
	--
	layers:insert( layers.back )      
	layers:insert( layers.grid )   
	layers:insert( layers.pieces ) 
	layers:insert( layers.buttons )   
	layers:insert( layers.ifcs )   

	return layers
end

-- ==
-- destroyLayers() - Destroy all of the rendering layers and objects in those layers.
-- ==
destroyLayers = function ( )
	layers:removeSelf()
	layers = nil
end

-- =============================================================
-- The Board
-- =============================================================
-- ==
-- createBoard() - Create the sudoku board. 
--
-- Note: I used a brute force method where all images are pre-created.  I could have created images 'on-demand' but that
-- was more complicated to do (and maintain).  Corona has sufficient performance to handle the simple method instead.
--
-- ==
createBoard = function( layers )

	-- Initialize the button and graphics tables as empty tables to start.
	gridButtons = {}
	gridNumbers = {}
	gridGuesses = {}

	-- Snag the current puzzle's data from our puzzles data table.  
	-- This is a string containing numbers and underbars (blanks).
	local puzzleData = pd[currentDifficulty][currentPuzzle].puzzleData	



	-- Create Background Image (graph paper)
	local tmp = display.newImage( layers.back, "images/backImage.jpg", 0, 0 )
	tmp.x = centerX
	tmp.y = centerY

	-- Draw 9 boxes to give the 3x3 portion of the game a colored background (blue and white)
	local startX = offsetX - 90
	local startY = offsetY - 90
	local gridNum = 1
	for row = 1, 3 do
		for col = 1, 3 do
			local tmp = display.newRect( layers.grid, 0, 0, 90, 90 )

			tmp.x = startX + (col-1) * 90
			tmp.y = startY + (row-1) * 90

			if( gridNum % 2 == 0) then
				tmp:setFillColor(1,1,1)
			else
				tmp:setFillColor(159/256,214/256,217/256)
			end
			
			gridNum = gridNum + 1
		end
	end

	-- Add buttons to the (9x9) grid and attach touch listeners
	--
	-- Note: These are initially transparent, but I also used them to 
	-- highlight the 'current number' later.  See 'updateHighlights()'
	gridButtons = {}
	local startX = offsetX - 120
	local startY = offsetY - 120
	local gridNum = 1
	for row = 1, 9 do
		for col = 1, 9 do
			local tmp = display.newRect( layers.grid, 0, 0, 30, 30 )

			tmp.x = startX + (col-1) * 30
			tmp.y = startY + (row-1) * 30

			tmp:setFillColor(1,1,1,0.05)
			
			tmp.num = gridNum

			tmp.touch = onTouchGrid
			tmp:addEventListener( "touch", tmp )

			gridButtons[gridNum] = tmp
		
			gridNum = gridNum + 1
		end
	end

	-- Add grid guess images
	--
	-- Tip: By pre-placing all of the guess images on every square, we
	-- have simplified the design at the expense of a little memory.
	-- In this case, the tradeoff is a good one. (Cost ~= 175 KB Device Mem and 0.5 MB video memory)
	--
	local startX = offsetX - 120
	local startY = offsetY - 120
	local gridNum = 1
	local currentHints = {}
	gridGuesses[gridNum] = currentHints
	for row = 1, 9 do
		for col = 1, 9 do
			for i = 1, 9 do
				local tmp = display.newImageRect( layers.grid, "images/guess" .. i .. ".png", 28, 28 )
				tmp.x = startX + (col-1) * 30
				tmp.y = startY + (row-1) * 30
				currentHints[i] = tmp
				tmp.isVisible = false

			end		
			gridNum = gridNum + 1
			currentHints = {}
			gridGuesses[gridNum] = currentHints
		end
	end

	-- Add grid number images
	--
	-- Tip: By pre-placing all of the number images on every square, we
	-- have simplified the design at the expense of a little memory.
	-- In this case, the tradeoff is a good one. (Cost ~= 175 KB Device Mem and 0.63 MB video memory)
	--
	local startX = offsetX - 120
	local startY = offsetY - 120
	local gridNum = 1
	local currentNumImages = {}
	gridNumbers[gridNum] = currentNumImages
	for row = 1, 9 do
		for col = 1, 9 do
			local curData = string.sub(puzzleData,gridNum,gridNum)
			curData = tonumber(curData)
			for i = 1, 9 do
				local tmp = display.newImageRect( layers.grid, "images/" .. i .. ".png", 30, 30 )
				tmp.x = startX + (col-1) * 30
				tmp.y = startY + (row-1) * 30
				currentNumImages[i] = tmp
				if(curData == i) then
					tmp.isVisible = true
					tmp:setFillColor(0,0,0,1)
					gridButtons[gridNum].currentNumber = i
					gridButtons[gridNum].locked = true
				else
					tmp.isVisible = false				
				end
			end		
			gridNum = gridNum + 1
			currentNumImages = {}
			gridNumbers[gridNum] = currentNumImages
		end
	end

	-- Finally, draw the grid image over all other parts of the board.
	local tmp = display.newImageRect( layers.grid, "images/grid.png", 280, 280 )
	tmp.x = offsetX
	tmp.y = offsetY

	-- Now, make the board layer (and all children objects ) a little bigger and move it up
	--
	--
	-- Suggestion: Comment this part of the code out to see what is happening.
	-- 
	-- Tip: I could have created all objects with perfect dimensions to start, but using a 280x280 grid and then upscaling
	--      was easier and allowed me more freedom on the final 'size' via scaling.
	--
	layers.grid:scale(1.15,1.15)
	layers.grid.x = centerX
	layers.grid.y = centerY - 50  -- Note: I also pushed the whole grid up by 50 pixels, simply by moving the grid group.

end

-- ==
-- destroyBoard() - Destroy the board.
--
-- Tip: I only have to remove event listeners and clear reference variables the destroyLayers() function 
--      will remove all render objects by  destroying the top-level group containing all sub-layers and objects.
-- ==
destroyBoard = function( )
	
	-- Now clear the table references to be sure there are no dangling references to objects that would then prevent garbage collection.
	gridButtons = nil
	gridNumbers = nil
	gridGuesses = nil
end

-- ==
-- updateHighlights() - Check to see which number is currently selected and highlight any grids with that number (does not
-- highlight guesses, but you could modify it to do that too.)
-- ==
updateHighlights = function( )

	-- Initially unhighlight all grids
	for i = 1, #gridButtons do
		local curGridButton = gridButtons[i]
		curGridButton:setFillColor(1,1,1,0.05)
	end

	-- Only highlight if not in 'clear' mode
	if(curMode == "number" or curMode == "guess") then
		for i = 1, #gridButtons do
			local curGridButton = gridButtons[i]
			if( curGridButton.currentNumber and 
				curGridButton.currentNumber == curNumber ) then
				curGridButton:setFillColor(1,1,0,1)
			end
		end
	end	
end

-- ==
--	checkSolution() - Check the currently filled board versus the final soltion.
--
--  Returns two values:
--		puzzleFilled - 'true' if all numbers are filled in
--		puzzleSolved - 'true' if the numbers on the board match the solution.
-- ==
checkSolution = function( )
	local userSolution = ""
	local puzzleFilled = true
	puzzleSolved = false	

	-- Snag the solutoin for this board from our puzzles data table
	-- This is a string containing 81 numbers.
	local currentSolution = pd[currentDifficulty][currentPuzzle].solutionData

	-- Iterate over the board and create a users solution string.
	for i = 1, #gridButtons do		
		local curGridButton = gridButtons[i]
		if( not curGridButton.currentNumber ) then
			userSolution = userSolution .. " "
			puzzleFilled = false
		else
			userSolution = userSolution .. curGridButton.currentNumber
		end
	end
	
	puzzleSolved = ( currentSolution == userSolution )

	-- While we are checking, let's update the 'completedText' message too.
	--
	if( puzzleFilled ) then
		completedText.isVisible = true
	else
		completedText.isVisible = false
		return 
	end

	if( puzzleSolved ) then		
		-- If the puzzle was solved, stop the game (stop timer and disable all buttons except menu button)
		stopGame()
		completedText:setFillColor(0,128/256,0)
		completedText.text = "Success!"

	else
		completedText:setFillColor(128/256,0,0)
		completedText.text = "Not Right!"
	end


	-- Return the results of our check	
	return puzzleFilled,puzzleSolved
end

-- ==
-- onTouchGrid() - This is the touch listener used for all 81 board grid-buttons.
-- ==
onTouchGrid = function( self, event )

	local target  = event.target
	
	if(event.phase == "began") then
		 -- This grid will get all future touches even if the finger is moved away from the grid
		 -- before being lifted.
		display.getCurrentStage():setFocus(event.target) 

	-- We only do work when the finger is lifted
	-- 
	elseif(event.phase == "ended") then
		 -- Clear the touch tracking/focus for this grid so future touches work properly
		display.getCurrentStage():setFocus(nil)

		-- If the game is in 'guess' mode, show/hide the guess image for this grid.
		--
		if(curMode == "guess") then
			local showGuess = true			
			local numberImages = gridNumbers[target.num]
			-- First check to see if a number is visible, if so, do not show guesses.
			for i = 1, 9 do
				if (numberImages[i].isVisible) then
					showGuess = false
				end
			end

			if( showGuess ) then
				local guessImg = gridGuesses[target.num][curNumber]
				guessImg.isVisible = not guessImg.isVisible
			end


		-- If the game is in 'clear' mode clear this tile if a number (not guesses) is showing.
		--
		elseif(curMode == "clear") then

			-- If the grid button is locked ignore touches
			-- 
			-- Grid entries are locked if they are NOT blank when created.
			-- i.e. The initial numbers shown on a puzzle are all locked.
			--
			if(gridButtons[target.num].locked) then
				return true
			end

			-- Clear the 'currentNumber' tracking variable based on the visibility
			-- of this grid's number.
			--
			-- This is used for assembling the user solution during solution checks.
			--
			gridButtons[target.num].currentNumber = nil

			-- Hide all number images on this grid.
			-- Note: Remember, clearing does not affect guesses, but if you want you can change that here.
			local numberImages = gridNumbers[target.num]
			for i = 1, 9 do
				numberImages[i].isVisible = false
			end
			

		-- If the game is in 'number' mode, show/hide the number image for this grid.
		-- (Also hide any guesses that might be showing on this grid)
		--
		elseif(curMode == "number") then
			local numberImages = gridNumbers[target.num]
			local guessImages = gridGuesses[target.num]

			-- If the grid button is locked ignore touches
			-- 
			-- Grid entries are locked if they are NOT blank when created.
			-- i.e. The initial numbers shown on a puzzle are all locked.
			--
			if(gridButtons[target.num].locked) then
				return true
			end

			-- Hide all numbers (except the current number) and all guesses to start 
			for i = 1, 9 do
				if (i ~= curNumber) then
					numberImages[i].isVisible = false
				end
				guessImages[i].isVisible = false
			end

			-- Toggle the visibility of the current number
			local numberImg = gridNumbers[target.num][curNumber]
			numberImg.isVisible = not numberImg.isVisible
			
			-- Update the 'currentNumber' tracking variable based on the visibility
			-- of this grid's number.
			--
			-- This is used for assembling the user solution during solution checks.
			--
			if(numberImg.isVisible) then
				gridButtons[target.num].currentNumber = curNumber
			else
				gridButtons[target.num].currentNumber = nil
			end

			-- Update the number highlights
			updateHighlights( )

			-- Check to see if the puzzle is solved and update the 'completedText' message.
			checkSolution()
		end
	end
	return true
end	

-- =============================================================
-- The Interface
-- =============================================================
-- ==
-- createInterface() - Create the numbers/note/clear/menu buttons as well as the the game timer, 
-- completed message, and difficulty level message.
-- ==
createInterface =  function( layers )

	-- Initialize all of the interface tables and variables to default settings.
	allButtons = {}
	numberButtons = {}
	curNumber = 1
	curMode = "number"
	currentSeconds = 0

	-- Create Add the Number Buttons
	--
	local buttonWidth = 80
	local buttonHeight = 40
	local startX = buttonWidth/2
	local startY = h - 105
	local buttonNum = 1
	for row = 1, 3 do
		for col = 1, 3 do
			local tmp = display.newImageRect( layers.buttons, "images/buttons/blank.png", buttonWidth, buttonHeight )
			tmp.x = startX + (col-1) * buttonWidth
			tmp.y = startY + (row-1) * buttonHeight
			tmp.buttonID = buttonNum

			local buttonText = display.newText( layers.ifcs, buttonNum, 20, 10, native.systemFontBold, 32)
			buttonText:setFillColor(0)
			buttonText.x = tmp.x
			buttonText.y = tmp.y
			
			if(buttonNum == 1 ) then
				tmp:setFillColor(0,1,0)
			end

			tmp.touch = onTouchButton
			tmp:addEventListener( "touch", tmp )

			allButtons[#allButtons+1] = tmp
			numberButtons[buttonNum] = tmp

			buttonNum = buttonNum + 1
		end
	end

	-- Create the note button.
	--
	local tmp = display.newImageRect( layers.buttons, "images/buttons/blank.png", buttonWidth, buttonHeight )
	tmp.x = w -  buttonWidth / 2
	tmp.y = h-105
	tmp.buttonID = "note"
	tmp.touch = onTouchButton
	tmp:addEventListener( "touch", tmp )
	tmp.isToggled = false
	noteButton = tmp
	allButtons[#allButtons+1] = tmp

	local buttonText = display.newText( layers.ifcs, "Note", 20, 10, native.systemFontBold, 20)
	buttonText:setFillColor(0)
	buttonText.x = tmp.x
	buttonText.y = tmp.y

	
	-- Create the clear button.
	--
	local tmp = display.newImageRect( layers.buttons, "images/buttons/blank.png", buttonWidth, buttonHeight )
	tmp.x = w -  buttonWidth / 2
	tmp.y = h-65
	tmp.buttonID = "clear"
	tmp.touch = onTouchButton
	tmp:addEventListener( "touch", tmp )
	tmp.isToggled = false
	clearButton = tmp
	allButtons[#allButtons+1] = tmp

	local buttonText = display.newText( layers.ifcs, "Clear", 20, 10, native.systemFontBold, 20)
	buttonText:setFillColor(0)
	buttonText.x = tmp.x
	buttonText.y = tmp.y

	-- Create the menu button.
	--
	menuButton = display.newImageRect( layers.buttons, "images/buttons/blank.png", buttonWidth, buttonHeight )
	menuButton.x = w -  buttonWidth / 2
	menuButton.y = h-25
	menuButton.buttonID = "menu"
	menuButton.touch = onTouchButton
	menuButton:addEventListener( "touch", menuButton )
	allButtons[#allButtons+1] = menuButton

	local buttonText = display.newText( layers.ifcs, "Menu", 20, 10, native.systemFontBold, 20)
	buttonText:setFillColor(0)
	buttonText.x = menuButton.x
	buttonText.y = menuButton.y

	-- Create a timer and start it.
	--
	timerText = display.newText( layers.ifcs, "0:00", 15, 10, native.systemFontBold, 16)
	timerText.x = timerText.contentWidth/2 + 12
	timerText:setFillColor(0)
	startTimer()

	-- Create a message for the 'completed' status of this board, but hide it for now.
	--
	completedText = display.newText( layers.ifcs, "Success!", 0, 5, native.systemFontBold, 22)
	completedText.x = centerX - 10
	completedText:setFillColor(0,128,0)
	completedText.isVisible = false

	-- Create difficulty label.
	--
	local tmp = display.newText( layers.ifcs, difficultyLevels[currentDifficulty] .. " #" .. currentPuzzle, 
	                                  0, 10, native.systemFontBold, 16)
	tmp.x = w - tmp.contentWidth/2 - 5
	tmp:setFillColor(0)

end

-- ==
--	destroyInterface() - Destroy the interface elements.
--
-- Tip: I only have to remove event listeners and clear reference variables the destroyLayers() function 
--      will remove all render objects by  destroying the top-level group containing all sub-layers and objects.
-- ==
destroyInterface = function( )

	-- Stop the timer before removing it.
	stopTimer()

	-- Now clear all reference variables/tables to be sure there are no dangling references to objects that would then prevent garbage collection.
	allButtons  = nil
	numberButtons = nil
	noteButton = nil
	clearButton = nil
	menuButton = nil
	lastTimer = nil
	timerText = nil
	currentSeconds = nil
	completedText = nil
end

-- ==
--	clearNumberButtons() - A simple function to de-highlight the number pad.
-- ==
clearNumberButtons = function( )
	for i = 1, #numberButtons do
		numberButtons[i]:setFillColor(1,1,1)
		curNumber = 1
	end

	if( clearButton.isToggled ) then
		clearButton:setFillColor( 1,1,1 )
		clearButton.isToggled = false
		curMode = "number"
	end
end


-- ==
--	onTouchButton() - A single touch listener used for the number buttons and the note/clear/menu buttons.
-- ==
onTouchButton = function( self, event )

	local target   = event.target
	local buttonID = target.buttonID

	print(event.phase,buttonID)

	-- When the player first puts their finger down, do some initial work (highlighting and mode changes).
	--
	if(event.phase == "began") then
		 -- This button will get all future touches even if the finger is moved away from the button
		 -- before being lifted.
		display.getCurrentStage():setFocus(event.target)

		-- If this is a number button, clear (un-highlight) all number buttons, then highlight this one.
		--
		if( tonumber( buttonID ) ) then
			clearNumberButtons()
			target:setFillColor( 0,1,0 )
			curNumber = buttonID
			updateHighlights()  -- Also update the board highlighting.

		
		-- If this is the 'note' button, toggle between 'number' and 'guess' mode.  When the button is 
		-- green, we're in 'guess' mode.
		elseif( buttonID == "note" ) then
			if( target.isToggled ) then
				target:setFillColor( 1,1,1 )				
			else
				target:setFillColor( 0,1,0 )				
			end
			
			-- Always clear and detoggle the 'clear' button, when the 'note' button is touched.
			clearButton:setFillColor(1,1,1)
			clearButton.isToggled = false
		
		-- If this is the 'clear' button, toggle between 'clear' and 'number' modes.
		elseif( buttonID == "clear" ) then
			if( target.isToggled ) then
				target:setFillColor( 1,1,1 )				
			else
				target:setFillColor( 0,1,0 )				
			end

			-- Always clear and detoggle the 'note' button, when the 'clear' button is touched.
			-- It isn't possible to go back to 'guess' mode from 'clear' mode.
			noteButton:setFillColor(1,1,1)
			noteButton.isToggled = false

		-- If this is the 'menu' button, stop the timer immediately.
		--
		elseif( buttonID == "menu" ) then
			target:setFillColor( 0,1,0 )
			stopTimer()
		end

	
	-- When the player's finger is lifted, do more work.
	--
	elseif(event.phase == "ended") then
		-- Clear the touch tracking/focus for this button so future touches work properly.
		display.getCurrentStage():setFocus(nil)

		-- If this is the 'note' button, toggle the state of this button and update the current mode to 'number' or 'guess'.
		--
		if( buttonID == "note" ) then
			if(target.isToggled) then
				target.isToggled =  false
				target:setFillColor( 1,1,1 )				
				curMode = "number"
				updateHighlights() -- Also update the grid highlights				
			else
				target.isToggled = true
				target:setFillColor( 0,1,0 )				
				curMode = "guess"
				updateHighlights() -- Also update the grid highlights				
			end
		
		-- If this is the 'clear' button, toggle this button and update the mode to 'clear' or 'number'.
		--
		elseif( buttonID == "clear" ) then
			if(target.isToggled) then
				target.isToggled =  false
				target:setFillColor( 1,1,1 )				
				curMode = "number"
				updateHighlights() -- Also update the grid highlights
			else
				target.isToggled = true
				target:setFillColor( 0,1,0 )				
				curMode = "clear"
				updateHighlights() -- Also update the grid highlights
			end
		
		-- If this is the 'menu' button, show the main menu
		--
		elseif( buttonID == "menu" ) then
			target:setFillColor( 1,1,1 )
			mainMenu.create()
		end			
	end

	return true
end	


-- ==
--	onTimer() - A simple function that increments the game time and updates the timer message once a second.
-- ==
onTimer = function()
	currentSeconds = currentSeconds + 1
	timerText.text = convertSecondsToTimer( currentSeconds )
end

-- ==
--	startTimer() - Use this function to start and re-start the timer.
-- ==
startTimer = function()
	lastTimer = timer.performWithDelay( 1000, onTimer, 0 )
end

-- ==
--	stopTimer() - Use this function to stop the timer.
-- ==
stopTimer = function()
	timer.cancel( lastTimer )
end

-- ==
--	stopGame() - Stop the timer and disable all buttons except for the menu button.
--
--  Also remove all of the 'grid' touch listeners so the user can't undo their win.
-- ==
stopGame = function()

	-- Stop the timer
	stopTimer()

	-- Disable the buttons
	for i = 1, #allButtons do
		local tmp = allButtons[i]
		if( tmp ~= menuButton ) then
			tmp:removeEventListener( "touch", tmp )
			tmp.alpha = 0.8
			tmp:setFillColor(140)
		end
	end

	-- Disable the grid touch listeners
	for i = 1, #gridButtons do
		local tmp = gridButtons[i]
		tmp:removeEventListener( "touch", tmp )
	end

	-- Mark the game as 'not in progress'
	gameInProgress = false
end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}

public.create		= createGame
public.destroy		= destroyGame
public.restartTimer	= startTimer

return public
