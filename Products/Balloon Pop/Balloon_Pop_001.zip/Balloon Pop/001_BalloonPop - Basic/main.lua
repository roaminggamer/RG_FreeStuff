-- ==========================================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- ==========================================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- ==========================================================================
-- Example Begins Here
-- ==========================================================================

-- **************************************************************************
-- Require any libraries/modules needed here.
-- **************************************************************************
local physics = require "physics"



-- **************************************************************************
-- Initialization
-- **************************************************************************
physics.start()
physics.setGravity( 0, 10 )
--physics.setDrawMode( "hybrid" )


-- **************************************************************************
-- Local Variables
-- **************************************************************************
--
-- 1. Frequently used 'concepts' pre-calculated and stored in easy to 
--    type & remember variable.
--
local centerX = display.contentCenterX       -- Horizontal center of screen
local centerY = display.contentCenterY       -- Vertical center of screen
local w = display.contentWidth               -- Content width (specified in config.lua)
local h = display.contentHeight              -- Content height (specified in config.lua)
local fullw = display.actualContentWidth     -- May be wider or more narrow than content width.
local fullh = display.actualContentHeight    -- May be taller or shorter than content height.
local left = centerX - fullw/2               -- True left-edge of screen
local right = left + fullw                   -- True right-edge of screen
local top = centerY - fullh/2                -- True top-edge of screen
local bottom = top + fullh                   -- True bottom-edge of screen

--
-- 2. (Game) Variables specific to this game and its logic.
--
local layers                           -- Top group containing all child groups
local gameIsRunning        = false     -- Flag to help track if game is running
local waitingForFirstDrop   = true
local gameTimer                        -- Handle to store timer id

local score                            -- Current score

local balloonMinTime       = 500      -- Minimum time (in millseconds) between balloon drops
local balloonMaxTime       = 1250      -- Maximum time (in millseconds) between balloon drops

local balloons             = {}

local balloonTypes         = 5         -- Total balloon types (colors)

local balloonWidth         = 295/3     -- Balloon width
local balloonHeight        = 482/3     -- Balloon height
                                       
local balloonMinX          = left + balloonHeight  -- Min drop position
local balloonMaxX          = right - balloonHeight -- Max drop position

local balloonMinDamping    = 1.0       -- Minimum balloon linear damping
local balloonMaxDamping    = 1.5      -- Maximum balloon linear damping

local labelBarHeight       = 80        -- Height label background bar
local labelFont            = "PartyBalloons.ttf"
local labelSize            = 60

local tapToStartLabel
local scoreLabel

-- (Pre-) Load some sounds for use in our game
--
local sounds = {}
sounds.pop = audio.loadSound( "sounds/pop.wav" )
sounds.gameOver = audio.loadSound( "sounds/game_over.ogg" )


-- **************************************************************************
-- Localize Commonly Used Functions 
--
-- Why Do This?: It gives small execution speedup, but mostly I do it 
-- to simplify typing.  I may not use them all, bit it is handy to have
-- them ready if I need them.
--
--  !!Warning!!: Don't take this too far.  Lua has a limit of 200 
--               local variables in scope at any time.
--
--     Pro Tip:  Be a DRY coder, not a WET coder.
--               WET ==> Write Everything Twice; We Enjoy Typing; ...
--               DRY ==> Don't Repeat Yourself
--
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Forward Declarations
--
-- Tip: This makes the following function names VISIBLE for the rest of the file.
--      They can be called anywhere below as long as they have been defined before
--      the are called. (As soon as this file 'loads', all of the functions will 
--      be defined.)
-- 
-- Note: I split game logic into create, destroy, start, stop... etc. because:
--
-- 1. It makes reading these parts of the code easier.
--
-- 2. It promotes the concepts associated with these function to you.
--    Ex: While 'pausing' may not be super helpful in this game, you might want
--    to have this concept in a future game.  So, practicing the design 
--    pattern now, will be useful to you later.
--
-- 3. Having this functionality broken up discretely helps you prepare for
--    writing game modules, and then for using composer.*.
-- 
-- **************************************************************************
local destroyGame
local createGame
local startGame
local stopGame
local pauseGame
local resumeGame

-- **************************************************************************
-- Function Definitions
-- **************************************************************************

--
-- destroyGame( ) - Create the game content
--
destroyGame = function( group )
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   layers = display.remove( layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   layers = nil

   -- Clear the balloons tracking table by setting it to nil.
   --
   balloons = nil

   -- Stop enterFrame listener and clear paddle varaible
   --
   Runtime:removeEventListener( "enterFrame", paddle )
   paddle = nil

   -- Clear label references so they can be garbage collected
   --
   scoreLabel = nil
   tapToStartLabel = nil

   -- Reset the score
   score = 0
   
end


--
-- createGame( group ) - Create the game content
--
createGame = function( group )
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   destroyGame()


   -- Create fresh balloons table
   --
   balloons = {}


   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   layers            = display.newGroup()
   layers.background = display.newGroup()
   layers.content    = display.newGroup()
   layers.interface  = display.newGroup()
   group:insert( layers )
   layers:insert( layers.background )
   layers:insert( layers.content )
   layers:insert( layers.interface )

   -- Create Background
   -- 
   --local back = newImageRect( layers.background, "images/protoBack.png", 760, 1140)
   local back = newImageRect( layers.background, "images/background.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 0

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      --for k,v in pairs( event ) do
         --print(k,v)      
      --end

      -- If game is not running yet, exit early
      --
      if( not gameIsRunning ) then return false end

      -- Are we waiting to start the ball moving?
      --
      if( waitingForFirstDrop and event.phase == "ended" ) then

         startGame()

      end
      return true
   end
   back:addEventListener( "touch" )
   
   -- Balloon Builder Function
   --
   local function newBalloon( )

      -- Select a random drop point
      local x = mRand( balloonMinX, balloonMaxX )
      local y = top - balloonHeight * 2


      -- Select a random balloon number
      -- 
      local balloonNum = mRand( 1, balloonTypes )

      -- Draw an 'empty hole'
      local balloon = newImageRect( layers.content, "images/balloon" .. balloonNum ..".png", balloonWidth, balloonHeight )
      balloon.x = x
      balloon.y = y

      -- Flag used by bottom bar collision function to determine this is a balloon
      --
      balloon.isBalloon = true

      -- Attach body to balloon
      --
      physics.addBody( balloon, "dynamic", { bounce = 0, friction = 0  } )
      balloon.isSensor = true
      
      -- Tip: math.random() can't give take fractional arguments ranges, so I do the following ...
      balloon.linearDamping = mRand(100 * balloonMinDamping, 100 * balloonMaxDamping)/100


      -- Add a touch listener to the balloon to 'pop' it and get a point
      --
      function balloon.touch( self, event )
         -- Exit early if game is not running
         --
         if( not gameIsRunning ) then return false end

         -- Exit early if this is not the "began" phase of the touch
         if( event.phase ~= "began") then return false end

         -- Play Pop Sound
         --
         audio.play( sounds.pop )

         -- Increment score
         --
         score = score + 1

         -- Update score label
         --         
         scoreLabel.text = score

         -- Remove this balloon from tracking table
         --
         balloons[self] = nil

         -- Destroy the balloon
         --
         display.remove(self)

         return true
      end
      balloon:addEventListener( "touch" )

      -- Call the builder again after a delay
      --
      gameTimer = timer.performWithDelay( mRand( balloonMinTime , balloonMaxTime ), newBalloon )

      -- Add balloon to tracking table
      --
      balloons[balloon] = balloon


      -- Return reference to balloon
      return balloon      
   end

   -- Draw Score Label Background and Label
   --

   local scoreBack = newRect( layers.interface, centerX, top + labelBarHeight/2, fullw, labelBarHeight )
   scoreBack:setFillColor( 0.5, 0.5, 0.5 )

   local scoreLabelPrefix = newText( layers.interface, "Score: ", centerX , scoreBack.y, labelFont, labelSize )
   scoreLabelPrefix.anchorX = 1
   scoreLabelPrefix:setFillColor(0,0,0)
   scoreLabel = newText( layers.interface, 0, centerX , scoreBack.y, labelFont, labelSize )
   scoreLabel.anchorX = 0
   scoreLabel:setFillColor(0,0,0)

   -- Tap To Start Label
   --
   tapToStartLabel = newText( layers.interface, "Tap To Start", centerX, centerY, labelFont, labelSize )
   tapToStartLabel:setFillColor(0,0,1)


   -- Create a block at the bottom of the screen.  If balloons hit this, the game is over.
   --
   local gameOverBlock = newRect( layers.content, centerX, bottom, fullw, 100 )
   gameOverBlock.anchorY = 0
   physics.addBody( gameOverBlock, "static" )
   
   -- Add collision listener to bottom wall to handle 'missed ball' logic
   --
   function gameOverBlock.collision( self, event )
      if( event.phase == "began" and event.other.isBalloon ) then
         -- Play game over sound
         audio.play( sounds.gameOver )

         -- Game over
         stopGame()
      end
      return false
   end
   gameOverBlock:addEventListener( "collision" )


   -- Start the game timer, then pause it immediately
   gameTimer = timer.performWithDelay( 1000, newBalloon )
   timer.pause( gameTimer )  

   -- Mark 'waiting' flag as true
   --
   waitingForFirstDrop = true

   -- Pause Physics
   --
   physics.pause()

   -- Mark game as running
   --
   gameIsRunning = true

end   

--
-- startGame( ) - Start the game running
--
startGame = function( )

   -- Clear the flag
   --
   waitingForFirstDrop = false

   -- Hide 'tap to start' message
   --
   tapToStartLabel.isVisible = false
   
   -- Resume Physics
   --
   physics.start()

   -- Resume the timer
   --
   timer.resume( gameTimer )

end

--
-- stopGame( ) - Stop the game running
--
stopGame = function( )   
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.cancel( gameTimer )
      gameTimer = nil
   end

   -- Pause Physics
   --
   physics.pause()

   -- Shrink all balloons out of view
   --
   for k,v in pairs( balloons ) do
      transition.to( v, { alpha = 0, xScale = 0.01, yScale = 0.01, time = mRand(250,500) } )
   end


   -- Show 'Game Over' message
   --
   tapToStartLabel.text = "Game Over"
   tapToStartLabel.isVisible = true
   tapToStartLabel:setFillColor( 1, 0, 0 )
end

--
-- pauseGame( ) - Like stopping, but non-destructive.
--
pauseGame = function( )
   -- Mark game as 'not running'
   gameIsRunning = false

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end
end

--
-- resumeGame( ) - Start the game running
--
resumeGame = function( )   
   -- Mark game as 'running'
   gameIsRunning = true

   -- If game timer is running, pause
   if( gameTimer ) then
      timer.pause( gameTimer )
   end

end


-- **************************************************************************
-- Create The Game
-- **************************************************************************
createGame()

