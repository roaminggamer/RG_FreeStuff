-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- balloons.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local balloonM = {}

-- **************************************************************************
-- Locals
-- **************************************************************************
-- None.

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************


-- Balloon Builder Function
--
function balloonM.new( )

   -- If game is not running, try again in 100 milliseconds
   if( not common.gameIsRunning ) then 
      common.gameTimer = performWithDelay( 100, balloonM.new )
      return
   end

   -- Select a random drop point
   local x = mRand( common.balloonMinX, common.balloonMaxX )
   local y = top - common.balloonHeight * 2


   -- Select a random balloon number
   -- 
   local balloonNum = mRand( 1, common.balloonTypes )

   -- Draw an 'empty hole'
   local balloon = newImageRect( common.layers.content, "images/balloon" .. balloonNum ..".png", common.balloonWidth, common.balloonHeight )
   balloon.x = x
   balloon.y = y

   -- Flag used by bottom bar collision function to determine this is a balloon
   --
   balloon.isBalloon = true

   -- Attach body to balloon
   --
   physics.addBody( balloon, "dynamic", { bounce = 0, friction = 0  } )
   balloon.isSensor = true
   
   -- Tip: math.random() can't give take fractional arguments ranges, so I do the following ...
   balloon.linearDamping = mRand(100 * common.balloonMinDamping, 100 * common.balloonMaxDamping)/100

   -- Add a touch listener to the balloon to 'pop' it and get a point
   --
   function balloon.touch( self, event )
      -- Exit early if game is not running
      --
      if( not common.gameIsRunning ) then return false end

      -- Exit early if this is not the "began" phase of the touch
      if( event.phase ~= "began") then return false end

      -- Play Pop Sound
      --
      audio.play( common.sounds.pop )


      -- Increment score
      --
      common.score = common.score + 1

      -- Update score label
      --         
      common.scoreLabel.text = common.score

      -- Remove this balloon from tracking table
      --
      common.balloons[self] = nil

      -- Destroy the balloon
      --
      display.remove(self)

      return true
   end
   balloon:addEventListener( "touch" )

   -- Call the builder again after a delay
   --
   common.gameTimer = performWithDelay( mRand( common.balloonMinTime, common.balloonMaxTime ), balloonM.new )

   -- Add balloon to tracking table
   --
   common.balloons[balloon] = balloon

   -- Return reference to balloon
   return balloon      
end

return balloonM