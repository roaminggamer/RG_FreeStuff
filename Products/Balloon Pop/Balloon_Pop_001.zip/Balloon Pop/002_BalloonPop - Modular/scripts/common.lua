-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- common.lua
-- =============================================================
--
-- This module contains common settings and is also used by the
-- other modules as a 'scratch-pad' for sharing references and
-- values between modules instead of using globals.
--
-- =============================================================


local common = {}

common.gameIsRunning       = false     -- Flag to help track if game is running
common.waitingForFirstDrop = true

common.score               = 0         -- Current score

common.balloonMinTime      = 500       -- Minimum time (in millseconds) between balloon drops
common.balloonMaxTime      = 1250      -- Maximum time (in millseconds) between balloon drops

common.balloonTypes        = 5         -- Total balloon types (colors)

common.balloonWidth        = 295/3     -- Balloon width
common.balloonHeight       = 482/3     -- Balloon height
                                       
common.balloonMinX         = left + common.balloonHeight  -- Min drop position
common.balloonMaxX         = right - common.balloonHeight -- Max drop position

common.balloonMinDamping   = 1.0       -- Minimum balloon linear damping
common.balloonMaxDamping   = 1.5       -- Maximum balloon linear damping

common.labelBarHeight      = 80        -- Height label background bar
common.labelFont           = "PartyBalloons.ttf"
common.labelSize           = 60
common.labelSize2          = 80

-- (Pre-) Load some sounds for use in our game
--
common.sounds = {}
common.sounds.pop = audio.loadSound( "sounds/pop.wav" )
common.sounds.gameOver = audio.loadSound( "sounds/game_over.ogg" )

return common