-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- game.lua
-- ==========================================================================
local physics     = require "physics"
local common      = require "scripts.common"
local balloonM    = require "scripts.balloons"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay


-- **************************************************************************
-- Module Begins
-- **************************************************************************
local game = {}

-- **************************************************************************
-- Locals
-- **************************************************************************

-- **************************************************************************
-- Forward Declarations
-- **************************************************************************
-- None.

-- **************************************************************************
-- Module Method Definitions
-- **************************************************************************

--
-- destroy( ) - Create the game content
--
game.destroy = function( group )
   
   -- Destroy any previously created game layers (groups) and their 'children'
   --
   common.layers = display.remove( common.layers )   
   
   -- Set layers to nil so Lua memory manager can clean up
   --
   common.layers = nil

   -- Clear the balloons tracking table by setting it to nil.
   --
   common.balloons = nil

   -- Stop enterFrame listener and clear paddle varaible
   --
   Runtime:removeEventListener( "enterFrame", common.paddle )
   common.paddle = nil

   -- Clear label references so they can be garbage collected
   --
   common.scoreLabel = nil
   common.tapToStartLabel = nil

   -- Reset the common.score
   common.score = 0
   
end

--
-- create( group ) - Create the game content
--
game.create = function( group, onGameOver)
   -- If no display group reference is passed is, set 'group' to current stage: 
   -- the parent display group for all objects which is created by Corona.
   --
   group = group or display.currentStage

   -- Call destroy in case this is a new game start
   --
   game.destroy()

   -- Create fresh balloons table
   --
   common.balloons = {}


   -- Create a basic groups (layer) hierachy to help
   -- orgnize our rendering (bottom-to-top):
   -- 
   -- group\
   --      |---\layers\
   --                 |--\background
   --                 |--\content
   --                 \--\interfaces
   --
   common.layers            = display.newGroup()
   common.layers.background = display.newGroup()
   common.layers.content    = display.newGroup()
   common.layers.interface  = display.newGroup()
   group:insert( common.layers )
   common.layers:insert( common.layers.background )
   common.layers:insert( common.layers.content )
   common.layers:insert( common.layers.interface )

   -- Create Background
   -- 
   local back = newImageRect( common.layers.background, "images/background.png", 760, 1140)
   back.x = centerX
   back.y = centerY
   back.rotation = 0

   -- Add touch listener to background to enable easy and clean game interaction
   --
   -- Tip: Although the message say 'tap' to start, I am using a 'touch' listener.
   -- To me, 'touch' events are superior in almost all cases becaue they allow more
   -- finese and control over when responds to the touch, where as a tap is the equivalent 
   -- of a the 'ended' phase of a touch.
   --
   function back.touch( self, event )
      --for k,v in pairs( event ) do
         --print(k,v)      
      --end

      -- If game is not running yet, exit early
      --
      if( not common.gameIsRunning ) then return false end

      -- Are we waiting to start the ball moving?
      --
      if( common.waitingForFirstDrop and event.phase == "ended" ) then

         game.start()

      end
      return true
   end
   back:addEventListener( "touch" )
   
   
   -- Draw Score Label Background and Label
   --
   local scoreBack = newRect( common.layers.interface, centerX, top + common.labelBarHeight/2, fullw-4, common.labelBarHeight-4 )
   scoreBack:setFillColor( 0, 0.5, 0.7 )
   scoreBack.strokeWidth = 4
   scoreBack:setStrokeColor( 1, 1, 0 )

   local scoreLabelPrefix = newText( common.layers.interface, "Score ", left + 100, scoreBack.y, common.labelFont, common.labelSize )
   scoreLabelPrefix.anchorX = 0
   scoreLabelPrefix:setFillColor(1,1,0)
   common.scoreLabel = newText( common.layers.interface, 0, scoreLabelPrefix.x + scoreLabelPrefix.contentWidth , scoreBack.y, common.labelFont, common.labelSize )
   common.scoreLabel.anchorX = 0
   common.scoreLabel:setFillColor(0.2,1,0.2)

   -- Tap To Start Label
   --
   common.tapToStartLabel = newText( common.layers.interface, "Tap To Start", centerX, centerY, common.labelFont, common.labelSize2 )
   common.tapToStartLabel:setFillColor(0,0,1)


   -- Create a block at the bottom of the screen.  If alloons hit this, the game is over.
   --
   local gameOverBlock = newRect( common.layers.content, centerX, bottom, fullw, 100 )
   gameOverBlock.anchorY = 0
   physics.addBody( gameOverBlock, "static" )
   
   -- Add collision listener to bottom wall to handle 'missed ball' logic
   --
   function gameOverBlock.collision( self, event )
      if( event.phase == "began" and event.other.isBalloon ) then

         -- Play game over sound
         audio.play( common.sounds.gameOver )

         -- Game over
         game.stop()

         -- If "Game Over" function was supplied, call it
         --
         if( onGameOver ) then
            onGameOver()
         end
         
      end
      return false
   end
   gameOverBlock:addEventListener( "collision" )


   -- Start the game timer, then pause it immediately
   common.gameTimer = timer.performWithDelay( 1000, balloonM.new )
   timer.pause( common.gameTimer )  

   -- Mark 'waiting' flag as true
   --
   common.waitingForFirstDrop = true

   -- Pause Physics
   --
   physics.pause()

   -- Mark game as running
   --
   common.gameIsRunning = true

end   

--
-- start( ) - Start the game running
--
game.start = function( )

   -- Clear the flag
   --
   common.waitingForFirstDrop = false

   -- Hide 'tap to start' message
   --
   common.tapToStartLabel.isVisible = false
   
   -- Resume Physics
   --
   physics.start()

   -- Resume the timer
   --
   timer.resume( common.gameTimer )

end

--
-- stop( ) - Stop the game running
--
game.stop = function( )   
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.cancel( common.gameTimer )
      common.gameTimer = nil
   end

   -- Pause Physics
   --
   physics.pause()

   -- Shrink all balloons out of view
   --
   for k,v in pairs( common.balloons ) do
      transition.to( v, { alpha = 0, xScale = 0.01, yScale = 0.01, time = mRand(250,500) } )
   end

   -- Show 'Game Over' message
   --
   common.tapToStartLabel.text = "Game Over"
   common.tapToStartLabel.isVisible = true
   common.tapToStartLabel:setFillColor( 1, 0, 0 )
end

--
-- pause( ) - Like stopping, but non-destructive.
--
game.pause = function( )
   -- Mark game as 'not running'
   common.gameIsRunning = false

   -- Pause Physics
   physics.pause()

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.pause( common.gameTimer )
   end
end

--
-- resume( ) - Start the game running
--
game.resume = function( )   
   -- Mark game as 'running'
   common.gameIsRunning = true

   -- Resume Physics
   physics.start()

   -- If game timer is running, pause
   if( common.gameTimer ) then
      timer.resume( common.gameTimer )
   end

end


return game