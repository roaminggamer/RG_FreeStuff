-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
--  scenes/play.lua
-- =============================================================
local composer       = require( "composer" )
local scene          = composer.newScene()
local common         = require "scripts.common"
local buttonM        = require "scripts.buttons"
local game           = require "scripts.game"

-- **************************************************************************
-- Localize Commonly Used Functions 
-- **************************************************************************
local mDeg = math.deg; local mRad = math.rad; local mCos = math.cos
local mSin  = math.sin; local mAcos = math.acos; local mAsin = math.asin
local mSqrt = math.sqrt; local mCeil = math.ceil; local mFloor = math.floor
local mAtan2 = math.atan2; local mPi = math.pi
local mRand = math.random; local mAbs = math.abs; local mCeil = math.mCeil
local mFloor = math.floor; local getTimer = system.getTimer
local newCircle = display.newCircle; local newImageRect = display.newImageRect
local newLine = display.newLine; local newRect = display.newRect
local newText = display.newText
local performWithDelay = timer.performWithDelay

-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local onPause
local pauseButton
local onGameOver

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local layers
local isPaused = false

----------------------------------------------------------------------
-- scene:create( event ) - Called on first scene open ONLY (unless
-- the scene has been manually or automatically destroyed.)
----------------------------------------------------------------------
function scene:create( event )
   local sceneGroup = self.view   

   local back = newRect( sceneGroup, centerX, centerY, fullw, fullh )
   back:setFillColor( 0.0, 0.5, 0.78 )

   local title =  newText( sceneGroup, "Home", centerX, centerY - 240, "Raleway-Black.ttf", 50 )   
   title.anchorY = 0

   -- Create button
   pauseButton = buttonM.newImageButton( sceneGroup, left + 40, top + 40, 80, 80, "images/pause.png", "", onPause )

end

----------------------------------------------------------------------
-- scene:willShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "will" phase of scene:show().
----------------------------------------------------------------------
function scene:willShow( event )
   local sceneGroup = self.view


   -- Note: I create the game on each NEW entry to this scene.

   -- Create Game   
   game.create( sceneGroup, onGameOver )

   -- Raise Pause Button To Front
   pauseButton:toFront()


end

----------------------------------------------------------------------
-- scene:didShow( event ) - Replaces the scene:show() method.  This
-- method is called during the "did" phase of scene:show().
----------------------------------------------------------------------
function scene:didShow( event )
   local sceneGroup = self.view   

   -- Reset pause status because this is a new run of the game
   isPaused = false

end

----------------------------------------------------------------------
-- scene:willHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "will" phase of scene:hide().
----------------------------------------------------------------------
function scene:willHide( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
-- scene:didHide( event ) - Replaces the scene:hide() method.  This
-- method is called during the "did" phase of scene:hide().
----------------------------------------------------------------------
function scene:didHide( event )
   local sceneGroup = self.view

   -- Note: I destroy the game on each exit from this scene.

   -- Destroy the game
   game.stop()
   game.destroy()

end

----------------------------------------------------------------------
-- scene:destroy( event ) - Called automatically by Composer scene library
-- to destroy the contents of the scene (based on settings and memory constraints):
-- https://docs.coronalabs.com/daily/api/library/composer/recycleOnSceneChange.html
--
-- Also called if you manually call composer.removeScene()
-- https://docs.coronalabs.com/daily/api/library/composer/removeScene.html
----------------------------------------------------------------------
function scene:destroy( event )
   local sceneGroup = self.view
end

----------------------------------------------------------------------
--          Custom Scene Functions/Methods
----------------------------------------------------------------------
onPause = function( event )
   if( isPaused ) then
      print("Resume")
      game.resume()

   else
      print("Pause")
      game.pause()
   end

   isPaused = not isPaused
end


onGameOver = function()
   timer.performWithDelay( 1000, 
      function()
         local params = {}
         composer.gotoScene( "scenes.home", { time = 500, effect = "slideRight", params = params } )

      end )
end

---------------------------------------------------------------------------------
-- Scene Dispatch Events, Etc. - Generally Do Not Touch Below This Line
---------------------------------------------------------------------------------

-- This code splits the "show" event into two separate events: willShow and didShow
-- for ease of coding above.
function scene:show( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willShow( event )
   elseif( willDid == "did" ) then
      self:didShow( event )
   end
end

-- This code splits the "hide" event into two separate events: willHide and didHide
-- for ease of coding above.
function scene:hide( event )
   local sceneGroup  = self.view
   local willDid  = event.phase
   if( willDid == "will" ) then
      self:willHide( event )
   elseif( willDid == "did" ) then
      self:didHide( event )
   end
end
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
---------------------------------------------------------------------------------
return scene