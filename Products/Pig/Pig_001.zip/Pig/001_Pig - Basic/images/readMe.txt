
The following images are from clker.com (EULA: http://www.clker.com/disclaimer.html):

Robot: http://www.clker.com/clipart-robot-cartoon-.html
Pig: http://www.clker.com/clipart-3418.html

Dice:
1 - http://www.clker.com/clipart-dice-1.html
2 - http://www.clker.com/clipart-dice-2.html
3 - http://www.clker.com/clipart-dice-3.html
4 - http://www.clker.com/clipart-dice-4.html
5 - http://www.clker.com/clipart-dice-5.html
6 - http://www.clker.com/clipart-dice-6.html

Blank - Created by modifying 1.png


---------
---------


The boy and girl images are from a free art pack provided by Daniel Cook at the Lost Garden.

http://www.lostgarden.com/search/label/free%20game%20graphics

Please read his license here if you want to know more:

http://www.lostgarden.com/2007/03/lost-garden-license.html

