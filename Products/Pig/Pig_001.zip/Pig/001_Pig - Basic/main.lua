-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
-- main.lua
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------

-- Locals
											-- Some helper variables specifying:
local w       = display.contentWidth		-- Design width, height, and center <x,y> positions.
local h       = display.contentHeight
local centerX = display.contentWidth/2 
local centerY = display.contentHeight/2

local gameIsRunning	= true	-- Boolean variable used to track whether game is running or over.
local isPlayerTurn	= true	-- Boolean variable tracking whether it is the player's turn or not.
local isRolling		= false	-- Boolean variable used to tell the touch handler that the dice are rolling
										-- and thus to ignore any touches till the roll is done.

local dieSize		= 128			-- The size to make the die.
local scoreTarget	= 100			-- Whoever gets to this score first wins the round (Tip: make smaller for testing.)

-- Labels & Buttons
local playerScoreText			-- Empty variable that will be used to store a handle to 'Player score' text object.
local aiScoreText					-- Empty variable that will be used to store a handle to 'AI score' text object.

local playerWinsText				-- Empty variable that will be used to store a handle to 'Player wins' text object.
local aiWinsText					-- Empty variable that will be used to store a handle to 'AI wins' text object.

local theDie						-- Empty variable that will be used to store a handle to the current die image.
										-- Note: In this version of the game every roll of the die destroys the last image
										-- and creates a new one.  This is simple, but very inefficient.  Later versions of the
										-- game will use more efficient methods.

local playerRollMessage			-- Empty variable that will be used to store a handle to the player's 'roll button label' text object.
local playerTray					-- Empty variable that will be used to store a handle to the player's 'tray'.
										-- Note: This tray is also used as the player's 'roll button'
local aiTray						-- Empty variable that will be used to store a handle to the AI's 'tray'

local playAgainButton			-- Empty variable that will be used to store a handle to the player's 'play again button' object.
local playAgainButtonText		-- Empty variable that will be used to store a handle to the player's 'play again button label' text object.

local soundEnabled = true		-- A flag to enable/disble sound
local rollSounds   = {}			-- A table to store our sounds if we load them

if( soundEnabled ) then
							-- Load a three homemade audio files for the die roll sound (so we can avoid too much repetition)
	
	rollSounds[1] = audio.loadSound( "sounds/homemadeDieRoll1.mp3" )
	rollSounds[2] = audio.loadSound( "sounds/homemadeDieRoll2.mp3" )
	rollSounds[3] = audio.loadSound( "sounds/homemadeDieRoll3.mp3" )
end
							-- Find a free (available) sound channel to play our sound on
local freeChannel	= audio.findFreeChannel() 

							-- Set the volume for our free channel to 100% of the device's current volume
audio.setVolume( 1.0 , {channel = freeChannel} )


-- Function Declarations
local createDie				-- Function to draw a new die.
local drawBoard				-- Function to draw the game board.
local checkTheRoll			-- Function to check the value on the die and apply the game rules based on what is found.

local rollTheDie			-- Function to 'roll' the die.  

-- Listener Declarations
local onPlayerTray			-- Touch handler for the player's 'roll  button'. Rolls the die if it is the player's turn, and
							-- if the die is not already rolling.

local onPlayAgain			-- Touch handler for the 'play again button'.  This button is shown after the player or AI wins.

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------

--==
-- ================================= FUNCTION DEFINITIONS
--==

-- ==
--    createDie() - This function creates a new die image and places it at 
--                  the specified x,y position.  The image is selected base on the 
--                  argument 'num'.
--
--					Note: If the die already exists, the the new die is placed where 
--					old die was instead of the specified <x,y> position.  This is a trick
--					that lets us place the die once and then forget about its position.
--
--					Note2: This die creation is (very) inefficient because it destroys
--					any existing die and the replace it with a new image.  On the other hand
--					it is simple and fast.  
--
--					Tip: At the end of the day, nobody cares how you implemented your game.  
--					It is all about getting the game done and getting it into the players' hands.
-- ==
createDie = function( num, x, y )
	
	local x = x or 0  -- Default to 0
	local y = y or 0  -- Default to 0

	-- Does the die already exist?  If so, override x- and y-positions and use the 
	-- current position of the existing die as the position for the replacement die.
	--
	if(	theDie ) then
		x = theDie.x
		y = theDie.y

		-- Now that we have extracted the position data from the existing
		-- die, lets destroy it before making a new one.
		--
		theDie:removeSelf()
	end

	-- Note: See how we assemble the path to our die object based on the die 'num'
	-- that was passed in to the function.
	--
	theDie = display.newImageRect( "images/" .. num .. ".png", dieSize, dieSize)

	-- Initially, the die image is created at < 0, 0 >
	-- So, we need to re-position it to the < x, y > position we want (from above)
	-- Please note that by default, image rectangles (created by 'newImagerRect'
	-- are positioned by their centers.  If you need to position by one of the corners, etc.
	-- use the method 'theDie:setReferencePoint()' You can read more about it here: 
	-- http://docs.coronalabs.com/api/type/DisplayObject/setReferencePoint.html
	--
	theDie.x = x
	theDie.y = y 

	-- Keep track of the die number as a dynamically created field on the new die object
	--
	theDie.myNum = num
end

-- ==
--    drawBoard() - Draw the game board.  In this case, the board has these pieces:
--
--		* Game Logo and Title - On the left third of the screen, the board will show a 'Pig' image
--		and three blank dice with the letters 'P', 'I', and 'G'.  This will all be placed over
--		a white rounded rectangle with a 'off pink' border.
--
--		* Player Tray - The player and AI 'trays' will take up the right two-thirds of the screen.
--		The player tray will take up the lower half of this space and has these parts:
--			** Rounded rectangle background with green border.
--			** Boy (or girl) image on the right showing this is the player (human) space.
--			** Score counter to show the player's accumulated roll score.
--			** 'Tap To Roll' message which is only shown when it is the player's turn.
--			** A die.  The player always starts first.
--			** Note: The winner of a game starts first next time.
--
--		* AI Tray - The AI tray takes up the remainder of the screen and is positioned on the top-half
--		above the player's tray and has these parts:
--			** Rounded rectangle background with a red border.
--			** Robot image on the right to show this is the AI (computer) space.
--			** Score counter to show the AI's accumulated roll score.
--
--		Note: All positioning values were hand selected based on a 480 x 320 design space.
--
-- ==
drawBoard = function()

	local tmp	-- A (local) temporary varible for storing object handles as they are created
				-- so that we can configure them a little.
	local tmp2	-- A second temporary variable (used to show you a positioning trick for the
				-- logo letters.

	-- 0. Add a background image that will display nicely on ALL devices.
	--
	-- This works nicely with the currently selected resolution in config.lua for all devices.
	--
	local back = display.newImageRect( "images/backImage.png", 1140, 760 )
	back.x = centerX
	back.y = centerY


	--
	-- 1. Create Game Logo & Title
	--
	-- Rounded Rect (Tray)
	--
	tmp = display.newRoundedRect( 0, 0, w/3 - 10, h - 10, 18 )
	tmp.x = w/6 + 5
	tmp.y = centerY
	tmp:setFillColor( 1 ) -- White (Tip: Interpreted by 'setFillColor()' as 1, 1, 1 )
	tmp.strokeWidth = 6 -- A little thick
	tmp:setStrokeColor( 0, 1, 1 )

	-- Pig Image
	--
	tmp = display.newImageRect( "images/pig.png", 180, 128 )
	tmp.x = w/6 + 5
	tmp.y = 90

	-- Dice Title (Blank Die Images under Embossed Text)
	--
	tmp = display.newImageRect( "images/blank.png", dieSize, dieSize )
	tmp.x = w/6 + 5
	tmp.y = 240
	
	tmp2 = display.newEmbossedText( "P", 0, 0, native.systemFont, 96 )		
	tmp2:setFillColor( 0.8, 0, 0 )
	local color =  {
		highlight = { r = 1,   g = 1,   b = 1 },
		shadow    = { r = 0.3, g = 0.3, b = 0.3 }
	}
	tmp2:setEmbossColor( color )		
	tmp2.x = tmp.x  -- Trick: Use the position of the die
	tmp2.y = tmp.y  -- Trick: Use the position of the die

	tmp = display.newImageRect( "images/blank.png", dieSize, dieSize )
	tmp.x = w/6 + 5
	tmp.y = 380

	tmp2 = display.newEmbossedText( "I", 0, 0, native.systemFont, 96 )		
	tmp2:setFillColor( 0.8, 0, 0 )
	local color =  {
		highlight = { r = 1,   g = 1,   b = 1 },
		shadow    = { r = 0.3, g = 0.3, b = 0.3 }
	}
	tmp2:setEmbossColor( color )		
	tmp2.x = tmp.x  -- Trick: Use the position of the die
	tmp2.y = tmp.y  -- Trick: Use the position of the die

	tmp = display.newImageRect( "images/blank.png", dieSize, dieSize )
	tmp.x = w/6 + 5
	tmp.y = 520

	tmp2 = display.newEmbossedText( "G", 0, 0, native.systemFont, 96 )		
	tmp2:setFillColor( 0.8, 0, 0 )
	local color =  {
		highlight = { r = 1,   g = 1,   b = 1 },
		shadow    = { r = 0.3, g = 0.3, b = 0.3 }
	}
	tmp2:setEmbossColor( color )		
	tmp2.x = tmp.x  -- Trick: Use the position of the die
	tmp2.y = tmp.y  -- Trick: Use the position of the die

	--
	-- 2. Player Play Area
	--
	-- Rounded Rect (Tray)
	--
	playerTray = display.newRoundedRect( 0, 0, 2 * w/3 - 40, h/2 - 10, 18 )
	playerTray.x = 2 * w/3
	playerTray.y = centerY + h/4
	playerTray:setFillColor( 0.87 ) -- White (Tip: Interpreted by 'setFillColor()' as 0.87, 0.87, 0.87 )
	playerTray.strokeWidth = 6
	playerTray:setStrokeColor( 0, 1, 0 )

	-- Attach an touch event listener to the tray. Touching anywhere 
	-- on the tray rolls the die (if it is the player's turn and if
	-- the die is not already rolling.)
	--
	playerTray:addEventListener( "touch", onPlayerTray )

	-- Player Image 
	--
	tmp = display.newImageRect( "images/boy.png", 136, 156 )  -- Use this line for a boy
	--tmp = display.newImageRect( "images/girl.png", 136, 156 )  -- Use this line for a girl
	tmp.x = w - 100
	tmp.y = centerY + h/4

	-- Player message
	--
	-- Note: I used emobossed text for this mesage because it looks nicer.  Notice
	-- how I modified the text color?  this changes the text label color while the 
	-- highlight and shadow remain the same.  The Corona SDK doesn't supply directly
	-- accessible methods for changing the highlight/shadow values.  If
	-- you want this functionality I suggest using the SSK label class instead.
	-- See (Label) on this page: https://github.com/roaminggamer/SSKCorona/wiki/SSKCorona-Classes
	--
	playerRollMessage = display.newEmbossedText( "Tap To Roll", 0, 0, native.systemFont, 48 )		
	playerRollMessage:setFillColor( 0, 1, 0 )
	playerRollMessage.x = 2 * w/3 
	playerRollMessage.y = centerY + 260

	-- Player Score
	--
	-- Note: I used the 'newText()' function to create this object because
	-- the resulting object's text can be changed simply by assigning it a new
	-- value.
	--
	-- Tip: I set the text value (first argument) to 0.  Notice that I used
	-- a number and not a string "0".  Either is OK.
	--
	-- Ex: playerScoreText.text = 5 -- Sets the label value to 5
	--
	playerScoreText = display.newText( 0, 0, 0, native.systemFont, 48 )		
	playerScoreText:setFillColor( 0 )
	playerScoreText.x = centerX - 40
	playerScoreText.y = centerY + 50

	-- Player Wins Counter (Counts number of times player has won)
	--
	tmp = display.newEmbossedText( "Wins:", 0, 0, native.systemFont, 48 )		
	tmp:setFillColor( 0, 1, 0 )
	tmp.x = w - 180
	tmp.y = centerY + 50

	playerWinsText = display.newText( 0, 0, 0, native.systemFont, 48 )		
	playerWinsText:setFillColor( 0 )
	playerWinsText.x = w - 84
	playerWinsText.y = centerY + 50
	
	--
	-- 3. AI Play Area
	--
	-- Rounded Rect
	--
	aiTray = display.newRoundedRect( 0, 0, 2 * w/3 - 40, h/2 - 10, 18 )
	aiTray.x = 2 * w/3
	aiTray.y = centerY - h/4
	aiTray:setFillColor( 0.75, 0.75, 0.75 )
	aiTray.strokeWidth = 6 -- A little thick
	aiTray:setStrokeColor( 1, 0, 0 )

	-- AI (Robot) Image
	--
	tmp = display.newImageRect( "images/computer.png", 136, 160 )
	tmp.x = w - 100
	tmp.y = centerY - h/4

	-- AI Score
	--
	aiScoreText = display.newText( 0, 0, 0, native.systemFont, 48 )		
	aiScoreText:setFillColor( 0 )
	aiScoreText.x = centerX - 40
	aiScoreText.y = centerY - 270

	-- AI Wins Counter (Counts number of times AI has won)
	--
	tmp = display.newEmbossedText( "Wins:", 0, 0, native.systemFont, 48 )		
	tmp:setFillColor( 1, 0, 0 )
	tmp.x = w - 180
	tmp.y = centerY - 270

	aiWinsText = display.newText( 0, 0, 0, native.systemFont, 48 )		
	aiWinsText:setFillColor( 0 )
	aiWinsText.x = w - 84
	aiWinsText.y = centerY - 270

	--
	-- 4. Add The Die
	--
	-- Note: Don't forget.  The player goes first, so we will place the 
	-- die over the player's tray.
	--
	createDie( 1, playerTray.x, playerTray.y )  -- Place over center of player's 'tray'

	--
	-- 5. Add a "Play Again?" button
	--

	--
	-- A. Create the rectangle base first.
	-- 
	playAgainButton = display.newRoundedRect( 0, 0, 320, 80, 9) 
	playAgainButton.x = centerX + w/6 + 10
	playAgainButton.y = centerY

	-- Use same color scheme as the board pieces
	--
	playAgainButton:setFillColor( 0.86 ) -- Off-White
	playAgainButton:setStrokeColor( 0,0,1 ) -- Blue
	playAgainButton.strokeWidth = 6

	-- Add a touch event listener to the rounded rectangle.
	--
	playAgainButton:addEventListener( "touch", onPlayAgain )

	-- Hide this for now
	--
	playAgainButton.isVisible = false

	--
	-- B. Create the text label second.
	--
	-- Note: Embossed text objects default to a 'Black' label, so we don't need
	-- to change the color
	--
	playAgainButtonText =  display.newEmbossedText( "Play Again?", 0, 0, native.systemFont, 48 )
	playAgainButtonText.x = playAgainButton.x -- Here is that positioing trick again!
	playAgainButtonText.y = playAgainButton.y -- Here is that positioing trick again!

	-- Hide this for now
	--
	playAgainButtonText.isVisible = false  

end


-- ==
--    checkTheRoll() - This function has the following jobs:
--
--		1. Check to see if the die is a 1, and if so do the following:
--			* If it is currently the player's turn move the die to the AI tray and 
--			change the isPlayerTurn to 'false'
--			* If it is currently the AI's turn move the die to the player tray and 
--			change the isPlayerTurn to 'true'
--
--		2. If the die was NOT a 1, do the following:
--			* Get the number of pips (myNum) from the die and add that to the current
--			roller's score (player or AI).
--			* Check to see if the current roller has reached the target score (100) and
--			if so, end the game and display the 'Play again button'
--
--
--		3.  Clear the 'isRolling' flag on the way out so that more rolls can me made (assuming
--		the game is not over.)
--
-- ==
checkTheRoll = function ()

	-- Is there only one pip showing?
	--
	if( theDie.myNum == 1 ) then

		-- Yes!
		--

		-- Is it the player's turn?  If so, move the die to the AI tray's y-position.
		--
		if( isPlayerTurn ) then
			print("Player: ", theDie.myNum) -- Look in the console for the output of the debug code

			-- This code uses the Corona transition library to slide the die
			-- to its new position in 300 milliseconds
			--
			transition.to( theDie, { y = aiTray.y, time = 300 } )

			-- Update tray colors to show whose turn it is
			--
			aiTray:setFillColor( 0.87 )
			playerTray:setFillColor( 0.75, 0.75, 0.75 )
			
			-- Use this cod instead of the transition for an immediate move
			--
			--theDie.y = aiTray.y

			-- Change to AI's turn
			--
			isPlayerTurn = false

			-- Start the 'rollTheDie()' function if 1000 milliseconds (1 second)
			--
			timer.performWithDelay( 1000, rollTheDie )		
			
		--
		-- It is the AI's turn.  Move the die to the player's tray's y-position.
		--
		else
			print("AI: ", theDie.myNum) -- Look in the console for the output of the debug code

			-- This code uses the Corona transition library to slide the die
			-- to its new position in 300 milliseconds
			--
			transition.to( theDie, { y = playerTray.y, time = 300 } )

			-- Update tray colors to show whose turn it is
			--
			aiTray:setFillColor( 0.75, 0.75, 0.75 )
			playerTray:setFillColor( 0.87 )


			-- Use this cod instead of the transition for an immediate move
			--
			--theDie.y = playerTray.y

			-- Wait 500 milliseconds (1/2 second) and then switch the turn
			-- flag to the player's turn.  Also, show the 'Tap To Roll' message.
			--
			timer.performWithDelay( 500, 
				function()
					isPlayerTurn = true
					playerRollMessage.isVisible = true
				end
			)
		end

	else
		-- Is it the player's turn?  If so, add points to the player's score.
		--
		if( isPlayerTurn ) then
			
			print("Player: ", theDie.myNum) -- Look in the console for the output of the debug code

			-- Extract the text value from the player's score label and convert that to a number
			--
			local score = tonumber(playerScoreText.text)

			-- Increment the score by the number of pips on the die
			--
			score = score + theDie.myNum

			-- Set the player's score label to the new score value
			--
			playerScoreText.text = score

			-- Did the player win?  If so, 
			--	* Mark the game as 'not running'
			--	* Set the player's roll message to show "Player Won!"
			--	* Show the 'Play Again' button.
			--
			if(score >= scoreTarget ) then
				gameIsRunning = false
				playerRollMessage:setText( "Player Won!" )
				playAgainButton.isVisible = true
				playAgainButtonText.isVisible = true
			
				-- Extract the text value from the player's wins label and convert that to a number
				--
				local wins = tonumber(playerWinsText.text)

				-- Increment the Wins by the number of pips on the die
				--
				wins = wins + 1

				-- Set the player's wins label to the new win value
				--
				playerWinsText.text = wins

			end

			playerRollMessage.isVisible = true
			
		-- 
		-- Nope, it's the AI's turn.  Add points to the AI's score.
		--
		else
			print("AI: ", theDie.myNum) -- Look in the console for the output of the debug code

			-- Extract the text value from the AI's score label and convert that to a number
			--
			local score = tonumber(aiScoreText.text)

			-- Increment the score by the number of pips on the die
			--
			score = score + theDie.myNum
			
			-- Set the player's score label to the new score value
			--
			aiScoreText.text = score

			-- Did the AI win?  If so, 
			--	* Mark the game as 'not running'
			--	* Set the player's roll message to show "AI Won!"
			--	* Show the 'Play Again' button.
			--
			if(score >= scoreTarget ) then
				gameIsRunning = false
				playerRollMessage.isVisible = true
				playerRollMessage:setText( "AI Won!" )
				playAgainButton.isVisible = true
				playAgainButtonText.isVisible = true

				-- Extract the text value from the ai's wins label and convert that to a number
				--
				local wins = tonumber(aiWinsText.text)

				-- Increment the Wins by the number of pips on the die
				--
				wins = wins + 1

				-- Set the ai's wins label to the new win value
				--
				aiWinsText.text = wins


			--
			-- Nope, the AI did not win, but it is still the computers turn
			-- so roll again in 1 second.
			--
			else
				timer.performWithDelay( 1000, rollTheDie )

			end
			
		end
	end

	-- Clear the 'isRolling' flag
	--
	isRolling = false

end


-- ==
--    rollTheDie() - This function is responsible for rolling the die and then scheduling a roll check.
-- ==
rollTheDie = function ()
		
		-- Mark the die as 'rolling' so other parts of the game know to wait till the die roll is over.
		-- before rolling again or doing anything else with the die.
		--
		isRolling = true

		if( soundEnabled ) then
			-- Randomly play one of the three die rolling sounds
			--
			audio.play( rollSounds[math.random(1,3)], {channel = freeChannel} )
		end

		-- Create 10 delayed rolls, where each new roll happens 60 ms (one or two frames) apart.
		--
		-- Basically, what this does is schedule a new die creation in 60, 120, ..., 600 milliseconds.
		-- This gives the visual impression of the die being rolled.
		--
		for i = 1, 10 do
			timer.performWithDelay( i * 60, 
				function()
					createDie( math.random(1,6) )
				end
			)
		end

		-- Schedule a die check at 800 milliseconds
		-- In total, the whole roll takes 0.8 seconds
		--
		-- Note: Remember, that 'checkTheRoll()' will set 'isRolling' back to false when it is 
		-- done checking the pips on the die.
		--
		timer.performWithDelay( 800 , checkTheRoll )
end

--==
-- ================================= LISTENER DEFINITIONS
--==

-- ==
--    onPlayerTray() - This is the touch handler for the player's tray.  If,
--
--		* The game is running, AND
--		* It is the player's turn, AND
--		* The die is not already rolling,
--
--		this function will roll the die when the player's tray is touched and released.
-- ==
onPlayerTray = function( event )

	--	
	-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	local phase    = event.phase  
	local target   = event.target

	-- Ignore all touches if the game is not running
	--
	if( not gameIsRunning ) then 
		return true 
	end

	--  Ignore all touches if it isn't the player's turn.
	--
	if( not isPlayerTurn ) then 
		return true 
	end

	-- Ignore all touches if the die is already rolling
	--
	if( isRolling ) then 
		return true 
	end


	-- Only do something if the touch has ended (the player lifted their finger).
	--
	-- Tip: You could also make this "began", if you prefer the action to happen as soon as the 
	-- touch begins, but most games start actions at the end of a touch.
	--
	if(phase == "ended") then

		-- Hide the "Tap to Roll" message
		--
		playerRollMessage.isVisible = false

		-- Use our die rolling function to 'roll' the die.
		--
		rollTheDie()

	end

	return true
end


-- ==
--    onPlayAgain() - This is the touch handler for the 'Play Again' button.  When 
--	  the button is touched, the scores will be reset and the game will be marked as 
--    running.
-- ==
onPlayAgain = function( event )
	
	-- Tip: For all but the simplest cases, it is best to extract the values you need from 'event' into local variables.
	--
	local phase    = event.phase  
	local target   = event.target

	-- Again, don't do anything until the user lifts their finger from the screen.
	--
	if( phase == "ended" ) then
	
		-- Clear the scores
		--
		playerScoreText.text = 0
		aiScoreText.text = 0

		-- Hide the 'Play Again' button
		--
		playAgainButton.isVisible = false
		playAgainButtonText.isVisible = false
		
		-- Mark the game as running
		--
		gameIsRunning = true

		-- Make sure the player's roll message is set to "Tap To Roll"
		--
		playerRollMessage:setText( "Tap To Roll" )

		-- If the player won, then s/he can continue to play
		-- 
		if( isPlayerTurn ) then

			-- Be sure the 'Tap To Roll' message is shown.
			--
			playerRollMessage.isVisible = true

		--
		-- If the AI won, start rolling again in 1/2 second
		--
		else
			-- Be sure the 'Tap To Roll' message is NOT shown.
			--
			playerRollMessage.isVisible = false

			-- 
			-- Schedule a new roll in 1 second
			--
			timer.performWithDelay( 1000, rollTheDie )
		end

	end


	return true
end
----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
drawBoard()
