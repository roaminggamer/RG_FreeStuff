I made these sounds myself, so you can use them any way you like (except to sell on their own or in a package).

The process was simple:

1. Record die roll with hand-held voice recorder.
2. Transfer to PC
3. Convert .wma file to .wav using Winamp's built-in NULL writer filter.
4. Edit .wav file using free Audacity tool (http://audacity.sourceforge.net/).
5. Export selected sounds to .mp3 files

Done!

