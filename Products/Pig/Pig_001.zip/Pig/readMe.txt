==============================================================================

Roaming Gamer: Pig (Game Template)

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Reporting Bugs - How to report bugs with this template.

==============================================================================


A. Short and Sweet License 

==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.  
     (I don't want to see this show up on Chupamobile or any other website that sells templates!)


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.



B. What's in the template package?
==================================

In this package you will find two version of of the game:

* 001_Pig - Basic - Basic Implementation of the Pig dice-game: https://en.wikipedia.org/wiki/Pig_(dice_game)
                  Note: This is a 'player versus AI' version of the game.



C. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please file a bug in the forums.  
Direct emails will be ignored.  It is better to share bugs where everyone can see them and see they are fixed.


>> Please report to this forum: https://forums.coronalabs.com/forum/659-marketplace-assets/

>> Please use this post title format: RG Pig: VERY-SHORT BUG DESCRIPTION

>> In the body of your post, please: Give a clear, concise, and precise description of the bug.  
>> Also be sure to give the following information:
 >>> Version of Corona SDK you are using (ex: 2017.3032)
 >>> Version of this content you have.  (I release updates on occasion, so be sure you have the latest.)
 >>> Exact content you are having trouble with.  (Many of my templates come with multiple variations of the game/template.)
 >>> OS you are developing on and version.
 >>> Device(s) you are experiencing trouble on and version of their OS.
 >>> Description of problem including:
 >>>> What you saw.
 >>>> What you expected to see.
 >>>> What you tried to debug the problem.


If you do not follow these directions it may take longer for me to notice and then resolve the bug.


Thanks,

The Roaming Gamer



