-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- machineLoader.lua- This module is used to load slot machine specifications from 
-- CSV files and convert them into a Lua 'class' that contains all of the details for that machine.
-- This class can also calculate payouts based on how many symbols are round in a row. 
--
-- This module does not have the logic to test for wild and special symbols, but adding this logic
-- should be fairly straightforward.  To do this, modify these method: 
--  - calculatePayout()
--  - calculatePayoutFromData()
--
-- =============================================================

----------------------------------------------------------------------
-- 1. The Module
----------------------------------------------------------------------
local public = {}

-- ==
--	new() - This function creates a new slot machine class instance.
-- ==
public.new = function( srcFile )
	local calc =  {}
	
	-- 1. Load the raw reel data, line by line
	--
	local rawReelTxt = io.readFile( srcFile , system.ResourceDirectory) 
	--print(rawReelTxt)

	-- 2. Convert to table of tables
	--
	local reelData = {}
	calc.reelData = reelData
	
	local numRecords = rawReelTxt:getRecordCount() 
	--print("Num Reel Records == ", rawReelTxt:getRecordCount() )
	local curRecord

	for i = 1, numRecords do
		curRecord = rawReelTxt:getRecord( i )
		reelData[#reelData+1]	= fromCSV(curRecord)	
	end

	-- 3. Massage the data to make is more usable
	--
	calc.name         = reelData[1][2]
	calc.sheetName    = reelData[2][2]
	calc.frameWidth   = reelData[2][3]
	calc.frameHeight  = reelData[2][4]
	calc.frameCount   = reelData[2][5]
	calc.numSymbols   = tonumber(reelData[3][2])
	calc.numReels      = tonumber(reelData[4][2])

	calc.firstReel = 5
	calc.lastReel = calc.firstReel + calc.numReels - 1

	calc.firstPayout = calc.lastReel + 1
	calc.lastPayout = numRecords
	calc.numPayouts = calc.lastPayout - calc.firstPayout + 1
	
	-- Convert the reel data from strings to numbers
	for i = calc.firstReel, calc.lastReel do
		local entry = reelData[i]
		for j = 2, #entry do
			entry[j] = tonumber(entry[j])
		end
	end

	-- Convert the payout data from strings to numbers
	for i = calc.firstPayout, calc.lastPayout do
		local entry = reelData[i]
		for j = 2, 4 do
			entry[j] = tonumber(entry[j])
		end
	end

	-- Create a fast lookup paytable
	local quickPayouts = {}
	calc.quickPayouts = quickPayouts
	for i = calc.firstPayout, calc.lastPayout do
		local entry = reelData[i]
		local symbolNum   = entry[2]
		local inARowCount = entry[3]
		local payout      = entry[4]

		if( not quickPayouts[symbolNum] ) then
			quickPayouts[symbolNum] = {}
		end
		quickPayouts[symbolNum][inARowCount] = payout
	end

	-- 4. Add some useful methods
	--

	-- ===
	--  calc:getReel( ) - Retruns reel layout data for the specified 'reelNum' as a table of integers.
	-- ===
	function calc:getReel( reelNum )
		local reelData = self.reelData[self.firstReel + reelNum - 1]
		local reel = {}
		for i = 2, #reelData do
			reel[i-1] = reelData[i]
		end
		return reel 
	end

	-- ===
	--  calc:calculatePayout( ) - Returns the payout multiplier for the specified 'symbolNum' depending on how many
	--  are in a row ('inARowCount').  
	-- ===
	function calc:calculatePayout( symboNum, inARowCount )
		local symbolPayouts = quickPayouts[symboNum]
		if( not symbolPayouts ) then return 0 end
		return (symbolPayouts[inARowCount] or 0)
	end

	-- ===
	--  calc:calculatePayoutFromData( ) - This method looks at first symbol in the passed 'row' table and counts how
	--  many of those symbols are found in a row.   It then uses the 'calculatePayout()' method to get a payout for that
	--  count.
	-- ===
	function calc:calculatePayoutFromData( row )
		local symbolNum = row[1]
		local inARowCount = 1
		local i = 2
		while i <= #row and row[i] == symbolNum do
			inARowCount = inARowCount + 1
			i = i + 1
		end
		return self:calculatePayout( symbolNum, inARowCount )
	end

	return calc
end

return public