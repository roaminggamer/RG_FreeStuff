-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- simpleSlotMachine.lua - This is a very simple slot machine example.
-- This example is capable of making a slot machine with 2 to 5 reels.
-- 
-- Note: I made this machine very simple so you could see the basic moving parts
-- and design your own machine to be fancier if you want.  Having said that, be warned:
--
-- - This machine does not support multitouch (the touch listeners are simpler without it).
-- - This machine has no sound or animations.  
-- - In the end, this example is ALL about mechanics.
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
local machineLoader		= require( "machineLoader" )
local slotsTesterModule	= require( "slotTester" )
local reelModule        = require( "reel" )
local reelsModule       = require( "reels" )

----------------------------------------------------------------------
-- 2. Local Variables
----------------------------------------------------------------------
local balance   = 1000 -- Start with $1000
local balanceText

local lastWinText 

local linesButton
local linesCount = 1
local linesText

local lineBetButton
local lineBet = 10
local lineBetText

local totalBet
local totalBetLabel

local spinButton

local machine
local theReels

local activePayLines = 1
local payLineImages  = {}
local payLineDefinitions = {}

----------------------------------------------------------------------
-- 3. Function and listener pre-declarations
----------------------------------------------------------------------
local onLines
local onLineBet
local onSpin
local onSpinsComplete

----------------------------------------------------------------------
-- 4. Function and Listner definitions
----------------------------------------------------------------------
-- ==
--  create() - This function does it all.
--
--  1. Creates single layer for all objects to live in.
--  2. Loads the machine data.
--  3. Initializes the reel art.
--  4. Creates the reels.
--  5. Adds an overlay to cover the 'hidden' parts of the machine.
--  6. Adds a super basic interface (balance label, last win label, active bet lines button,
--     bet per line button, total bet label, and spin button).
--  7. Creates some simple lines to act as pay line indicators.
--
-- ==
local function create( machineCSV, parentGroup )

	-- 1. Create a group to contain our machine and insert it into the (optional) parent group.
	--
	local parentGroup = parentGroup or display.currentStage
	local smGroup = display.newGroup()
	parentGroup:insert(smGroup)

	-- 2. Load the machine data from a CSV file
	--
	machine  = machineLoader.new( machineCSV )

	local params = { machine = machine, 
					 x = centerX, y = centerY,
					 tileWidth = 70, tileHeight = 50, 
					 spinTime = 80,
					 spinsComplete = onSpinsComplete,
					 --debug = true,
					 }
					  

	-- 3. Initialize the single reel module (sets up sprite sheet)
	--
	reelModule.init(params)

	-- 4. Create the reels
	--
	theReels = reelsModule.createReels( smGroup, params )

	-- 5. Add a simple overlay to hide the parts we don't want visible
	--
	theOverlay = display.newImageRect( smGroup, "images/simpleOverlay" .. machine.numReels .. ".png", 570, 380)
	theOverlay.x = centerX
	theOverlay.y = centerY
	--theOverlay.isVisible = false  -- Uncomment to see the man behind the curtain.

	-- 6. Add some simple interfaces elements
	--
	
	-- Balance Label
	balanceText = display.newText( smGroup, "Balance: $" .. balance, 10, 10, native.systemFontBold, 24)
	 
	-- Last Win Label
	lastWinText = display.newText( smGroup, "Last Win: $" .. 0, centerX + 60, 10, native.systemFontBold, 24)

	-- Lines Button (Increase Number of Lines when pressed; rolls around)
	linesButton = display.newRect( smGroup, 0, 0, 100, 40 )
	linesButton.x = 10 + linesButton.contentWidth/2
	linesButton.y = h - linesButton.contentHeight/2 - 10
	linesButton:setFillColor( 32,32,32)
	linesButton:setStrokeColor( 255,255,0)
	linesButton.strokeWidth = 2
	linesText = display.newText( smGroup, "Lines: " .. linesCount, 0,0, native.systemFontBold, 24)
	linesText.x = linesButton.x
	linesText.y = linesButton.y
	linesButton.touch = onLines
	linesButton:addEventListener( "touch", linesButton )

	-- Line Bet Button (Increase bet per line when pressed; rolls around)
	lineBetButton = display.newRect( smGroup, 0, 0, 100, 40 )
	lineBetButton.x = linesButton.x + linesButton.contentWidth/2 + lineBetButton.contentWidth/2 + 10
	lineBetButton.y = linesButton.y
	lineBetButton:setFillColor( 32,32,32)
	lineBetButton:setStrokeColor( 255,255,0)
	lineBetButton.strokeWidth = 2	
	lineBetText = display.newText( smGroup, "Bet $" .. lineBet, 0,0, native.systemFontBold, 24)
	lineBetText.x = lineBetButton.x
	lineBetText.y = lineBetButton.y
	lineBetButton.touch = onLineBet
	lineBetButton:addEventListener( "touch", lineBetButton )

	-- Total Bet Label
	totalBet = linesCount * lineBet
	totalBetLabel = display.newText( smGroup, "Total Bet: $" .. totalBet, 0, 0, native.systemFontBold, 24)
	totalBetLabel.x = lineBetButton.x + lineBetButton.contentWidth/2 + totalBetLabel.contentWidth/2 + 10
	totalBetLabel.y = linesButton.y

	-- Spin Button
	spinButton = display.newRect( smGroup, 0, 0, 70, 40 )
	spinButton.x = w - spinButton.contentWidth/2 - 10
	spinButton.y = linesButton.y
	spinButton:setFillColor( 32,32,32)
	spinButton:setStrokeColor( 255,255,0)
	spinButton.strokeWidth = 2	
	local tmp = display.newText( smGroup, "Spin", 0,0, native.systemFontBold, 24)
	tmp.x = spinButton.x
	tmp.y = spinButton.y
	spinButton.touch = onSpin
	spinButton:addEventListener( "touch", spinButton )

	-- Three Pay Line Indicators
	local lineWidth = params.tileWidth * (machine.numReels + 0.5)
	local tmp
	-- 1 (middle)
	tmp = display.newLine( 0, 0, lineWidth, 0 )
	tmp:setColor( 255, 255, 0 )
	tmp.width = 5
	tmp.x = params.x - lineWidth/2
	tmp.y = params.y
	payLineImages[1] = tmp
	timer.performWithDelay( 1000, function() payLineImages[1].isVisible = false end )	

	-- 2 (top)
	tmp = display.newLine( 0, 0, lineWidth, 0 )
	tmp:setColor( 255, 255, 0 )
	tmp.width = 5
	tmp.x = params.x - lineWidth/2
	tmp.y = params.y - params.tileHeight	
	payLineImages[2] = tmp
	payLineImages[2].isVisible = false

	-- 3 (bottom)
	tmp = display.newLine( 0, 0, lineWidth, 0 )
	tmp:setColor( 255, 255, 0 )
	tmp.width = 5
	tmp.x = params.x - lineWidth/2
	tmp.y = params.y + params.tileHeight	
	payLineImages[3] = tmp
	payLineImages[3].isVisible = false

	-- 7. Define the paylines (this machine can handle between 2 and 5 reels )
	--
	payLineDefinitions[1] = {}
	payLineDefinitions[2] = {}
	payLineDefinitions[3] = {}
					
	for reelNum = 1, machine.numReels do
		payLineDefinitions[1][reelNum] = 2 -- Payline 1 is the middle line
		payLineDefinitions[2][reelNum] = 1 -- Payline 2 is the top line
		payLineDefinitions[3][reelNum] = 3 -- Payline 3 is the bottom line
	end
		
end

-- ==
--  onLines() - This listener is attached to the 'linesCount' button. For every press of that button,
--  this listener will increment the number of active pay lines till it gets to 3 and the roll back
--  around to 1 payline.  It also adjusts to total bet based on the new active lines count.
-- ==
onLines = function( self, event ) 
	if(event.phase == "ended") then
		-- Increment active lines counter (roll around if necessary)
		linesCount = linesCount + 1
		if(linesCount > 3) then
			linesCount = 1
		end

		linesText.text = "Lines: " .. linesCount

		-- Flash the active lines
		payLineImages[1].isVisible = false
		payLineImages[2].isVisible = false
		payLineImages[3].isVisible = false

		for i=1, linesCount do
			payLineImages[i].isVisible = true

			-- Tip: Tracking and cancelling last timer, lets us nicely handle multiple quick presses
			if( payLineImages[i].lastTimer ) then
				timer.cancel( payLineImages[i].lastTimer )
				payLineImages[i].lastTimer = nil
			end
			payLineImages[i].lastTimer = 
				timer.performWithDelay( 1000, function() payLineImages[i].isVisible = false end )		
		end

		-- Update total bet
		totalBet = linesCount * lineBet
		if(totalBet > balance) then
			totalBet = balance
		end
		totalBetLabel.text = "Total Bet: $" .. totalBet
	end
	return true
end

-- ==
--  onLineBet() - This listener is attached to the 'linesCount' button. For every press of that button,
--  this listener will increment the bet $ per line.  Once this value goes above $10, it rolls back to $1.
--  It also adjusts to total bet based on the new active lines count.
-- ==
onLineBet = function( self, event ) 
	if(event.phase == "ended") then
		-- Increment active lines counter (roll around if necessary)
		lineBet = lineBet + 1
		if(lineBet > 10) then
			lineBet = 1
		end

		lineBetText.text = "Bet $" .. lineBet

		-- Update total bet
		totalBet = linesCount * lineBet
		if(totalBet > balance) then
			totalBet = balance
		end
		totalBetLabel.text = "Total Bet: $" .. totalBet

	end
	return true
end

-- ==
--  onSpin() - This button tells the reels to spin.  It also subtracts money from the balance
--  if the spin was allowed.  Note: Attempting to spin while the reels are spinning will do nothing.
--  The reels handle this logic and simply return 'false' when theReels:spin() is called and the reels
--  are already in motion.
-- ==
onSpin = function( self, event ) 
	if(event.phase == "ended") then

		-- If total bet is $0, do nothing
		if( totalBet == 0 ) then
			return true
		end

		-- Try to spin (will return false if already spinning)
		if( theReels:spin() ) then
			-- Subtract our bet amount from our balance
			balance = balance - totalBet

			-- Update the balance label
			balanceText.text = "Balance: $" .. balance
		end

	end
	return true
end

-- ==
-- onSpinsComplete - This callback is passed into the reels builder and is later called
-- after a spin starts and when the last reel has stopped spinning.  The purpose of this
-- callback function is to calculate the result of the last spin.  It does this by 
-- asking the reels for the symbol numbers on the specified pay lines.  For this simple machine
-- the paylines are simply horizontal, but you can ask for any combination of row/column positions
-- when asking for a payline.  See the simple horizontal payline definitions at the end of create() above.
-- ==
onSpinsComplete = function( reels ) 

	-- Get payout for payline 1
	local payline = reels:getPayline( payLineDefinitions[1] )
	local payout  = lineBet * machine:calculatePayoutFromData(payline)

	-- If enabled, get payout for payline 2
	if( linesCount > 1 ) then
		payline = reels:getPayline(payLineDefinitions[2] )
		payout = payout + lineBet * machine:calculatePayoutFromData(payline)
	end

	-- If enabled, get payout for payline 3
	if( linesCount > 2 ) then
		payline = reels:getPayline(payLineDefinitions[3] )
		payout = payout + lineBet * machine:calculatePayoutFromData(payline)
	end

	-- Update the last win and balance labels
	lastWinText.text = "Last Win: $" .. payout

	balance = balance + payout
	balanceText.text = "Balance: $" .. balance

end

----------------------------------------------------------------------
-- 5. The module
----------------------------------------------------------------------
local public = {}
public.create = create
return public

