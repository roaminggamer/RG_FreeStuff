These are placeholder app icons for the game.  Use them in your prototypes if you wish.

However, please do not use them in commercial products.

Copy the appropriate images into the root directory of your game for either: Android or iPhone builds.

Cheers,

The Roaming Gamer