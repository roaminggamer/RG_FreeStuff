-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- globals.lua - A bunch of global variables.
-- =============================================================

-- Useful design sizing and position variables
_G.w = display.contentWidth
_G.h = display.contentHeight
_G.centerX = w/2
_G.centerY = h/2

--[[ NOT USED BUT KEPT IN CASE YOU WANT THEM LATER 

-- Variables to control sounds
_G.sfxEnabled = false
_G.musicEnabled = false
_G.musicVolume = 0.8
_G.sfxVolume   = 0.8

-- A debug variable used during development to skip the splash screen.
_G.showSplash = true

--]]