-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- reel.lua- A module for creating a single slot machine reel.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------
local sheetData
local imageSheet
local sequenceData

-- ==
--	init() - This function is used to configure the sprite sheets for the current slot machine.
-- ==
local function init( params )
	-- Initialize all data for reel 1 sprites
	sheetData = { 
		width     = params.machine.frameWidth,  
		height    = params.machine.frameHeight,  
		numFrames = params.machine.frameCount,
	}	
	imageSheet = graphics.newImageSheet( "images/reels/" .. params.machine.sheetName, sheetData )
	sequenceData = { { name = "all", start = 1, count = params.machine.frameCount, loopCount = 0 } }
end

-- ==
--	cleanup() - This function is used to cleanup the sprite sheets and should be called before creating
--  a new machine.
-- ==
local function cleanup( params )
	sheetData = nil
	imageSheet = nil
	sequenceData = nil
end


-- ==
--	createReel() - Creates a single reel. (This should only be called by the code in reels.lua.)
-- ==
local function createReel( layer, x, y, reelNum, params )

	-- 1. Localize some of the parameterized settings
	--
	local x          = x or centerX
	local y          = y or centerY
	local width      = params.tileWidth
	local height     = params.tileHeight
	local reelData   = params.machine:getReel( reelNum )

	-- 2. Create a group to contain the reel tiles (5 per reel)
	--
	local reel = display.newGroup()
	layer:insert(reel)

	-- 3. Attach some important data to our reel for easy (external) access
	reel.num = reelNum
	reel.spinsComplete = 0
	local tiles = {}
	reel.tiles = tiles

	-- 4. Create the individual reel tiles
	--
	for i = 1, 5 do
		local tile = display.newGroup()
		tile.back   = display.newRect( tile, 0, 0, width, height )
		tile.sprite = display.newSprite( imageSheet, sequenceData )
		tile.sprite.x = width/2
		tile.sprite.y = height/2
		tile.sprite.xScale = width/tile.sprite.contentWidth
		tile.sprite.yScale = height/tile.sprite.contentHeight
		tile:insert(tile.sprite)
		tile.sprite:pause()
		
		tile:setReferencePoint( display.CenterReferencePoint )
		tile.y = (i-1) * height
		reel.tiles[i] = tile
		reel:insert(tile)		
		
		tile.imageNumText = display.newText( tile, "EFM", 0,0, native.systemFont, 36)
		tile.imageNumText:setTextColor(0)
		tile.imageNumText.x = tile.sprite.x
		tile.imageNumText.y = tile.sprite.y


		-- ==
		--	spin() - This method spins just this reel.
		-- ==
		--
		-- Note: This may seem weird at first, but having each tile 'spin' itself is actually easier
		-- than spinning them as a group.
		--
		-- Note 2: Spinning is accomplished by moving tiles down (via transition calls) and then, when the
		-- tiles get to a certain position, translating them back to the top of the tile pile.  When a tile
		-- is translated we also change the image of that tile to the next tile image in the reel
		-- image list.
		--
		tile.spin = function( self )
			-- A. Check to see if the tile has moved too far down and if so 
			--   translate it to the top, simultaneously getting the next image 
			--   in our reel data list.
			--
			if( self.y > 4 * height) then
				-- Move
				self.y = 0
				
				-- Update image data
				self.sprite:setFrame(reelData[reel.tileIndex])
				self.imageNum = reelData[reel.tileIndex]
				self.imageNumText.text = self.imageNum

				-- Get next reel data entry (wrap around to first entry if past end)
				reel.tileIndex = reel.tileIndex + 1
				if(reel.tileIndex > #reelData) then
					reel.tileIndex = 1
				end
			end

			-- B. Decrement number of remaining spins
			-- 
			self.remainingSpins = self.remainingSpins - 1

			-- C. If no spins remain, execute the post-spin effect
			--			
			if(self.remainingSpins <= 1 ) then
				transition.to( self, { y = self.y + height/5, time = self.spinTime} )
				transition.to( self, { y = self.y, delay = self.spinTime + 10, time = self.spinTime/5, easing = easing.inOutExpo  } )
				local position =  (self.y + height) / height
				tiles[position] = self
				
				reel.spinsComplete = reel.spinsComplete + 1

				if(reel.spinsComplete == 5) then
					if(reel.spinCompleteCB) then
						reel:spinCompleteCB( )
					end
				end
				return
			
			-- D. Otherwise, spin using the proper spin animation
			--
			elseif( self.spinState == "preSpin" ) then
				transition.to( self, { y = self.y - height/5, time = self.spinTime, easing = easing.inOutExpo } )
				self.lastTransition =
					transition.to( self, { y = self.y, delay = self.spinTime + 10, time = self.spinTime/5, onComplete=self.spin } )
				tile.spinState = "normalSpin"
			
			else
				if(self.lastTransition) then
					transition.cancel( self.lastTransition )
					self.lastTransition = nil
				end

				self.lastTransition = 
					transition.to( self, { y = self.y+height, time = self.spinTime, onComplete=self.spin } )
			end
		end		
	end

	-- 5. Change the tile's reference point and the position it.
	--
	reel:setReferencePoint( display.CenterReferencePoint )
	reel.x = x
	reel.y = y
	
	-- 6. Initialize the reel images
	--
	-- Tip: You can start all reels at 1 for debugging purpose, but 
	--      normally we want to start with a random reel position.
	--	
	if(params.debug) then
		reel.tileIndex = 1 
	else
		reel.tileIndex = math.random( 1, #reelData-5)		
	end
	

	for i = 5, 1, -1 do
		local tile = reel.tiles[i]
		tile.sprite:setFrame(reelData[reel.tileIndex])
		tile.imageNum = reelData[reel.tileIndex]
		reel.tileIndex = reel.tileIndex + 1
		tile.imageNumText.text = tile.imageNum
		if(not params.debug) then
			tile.imageNumText.isVisible = false			
		end
	end

	-- 7. Add some methods to the reel
	--

	-- ===
	--  reel:getRow( row ) - This method will return the image number for the specified row.
	--
	--  Note: Although the reel has five tiles, the top and bottom tiles are not counted as rows.
	--  In other words, row 1 is the second tile from the top, row 2 is the tile below that, and row 3
	--  is the second tile from the bottom of the reel.
	-- ===
	function reel:getRow( row )		
		return self.tiles[row+1].imageNum
	end

	-- ===
	--  reel:spin( time, spins, spinCompleteCB ) - This method spins the reel.
	-- ===
	function reel:spin( time, spins, spinCompleteCB )
		self.spinsComplete = 0
		self.spinCompleteCB = spinCompleteCB
		for i = 1, 5 do
			local tile = reel.tiles[i]
			tile.spinTime = time
			tile.spinState = "preSpin"
			tile.remainingSpins = spins
			tile:spin()			
		end
	end

	return reel
end

----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

-- Attach our local functions as module 'functions'
--
public.init        = init
public.createReel  = createReel
public.cleanup     = cleanup

return public