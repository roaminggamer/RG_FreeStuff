-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- main.lua 
-- =============================================================

----------------------------------------------------------------------
--	1. Globals - Load first as these are used by most modules.
----------------------------------------------------------------------
require("globals")
require("globalFunctions")

----------------------------------------------------------------------
--	2. Requires
----------------------------------------------------------------------
require("ioExtensions")
require("stringExtensions")
require("tableExtensions")

local machineLoader		= require( "machineLoader" )
local slotsTesterModule	= require( "slotTester" )

----------------------------------------------------------------------
--	3. Initialization
----------------------------------------------------------------------
display.setStatusBar(display.HiddenStatusBar)

----------------------------------------------------------------------
-- 4. Local Variables and Functions
----------------------------------------------------------------------
local machineCSV = "test3ReelMachine.csv" 
local testing    = false

----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------

-- Step 1 - Run in testing mode and edit your machine source file till you are happy
if( testing ) then
	local machine  = machineLoader.new( machineCSV )
	
	slotsTesterModule.testMachine( machine )

-- Step 2 - Switch to running mode and try it out
else
	local machine  = machineLoader.new( machineCSV )
	
	local slotMachine  = require( "simpleSlotMachine" )

	slotMachine.create( machineCSV )
end
