==============================================================================

Roaming Gamer, LLC "Game Template Package" for the game: Slot Machine(s)

==============================================================================
Table of Contents:

A. Short and Sweet License - Tells you how you can and cannot use the contents
   of this package.

B. What's in the template package? - A quick listing of the package contents.

C. Tips / FAQ - Miscellaneous tips to help you with changing the template, as
   well as answers to question(s) you might have.

D. Reporting Bugs - How to report bugs with this template.

==============================================================================

A. Short and Sweet License 
==========================

1. You MAY use anything you find in this package to:

  - make applications
  - make games 

   for free or for profit ($).


2. You MAY NOT:

   - sell or distribute the source code from this package.
   - use anything in this kit to make game templates, starter kits, or any other
     training and/or educational products.


3. If you intend to use the art or external code assets/resources, 
   you must read and follow the licenses found in the various associated
   readMe.txt files near those assets.




B. What's in the template package?
==================================
Slot Machine(s) is a customer requested implementation of a 2 to 5 reel slot machine.

This package only contains one version of the slot machine implementation, but because this is a data driven 
design, it can be used to implement an infinite number of slot machines.

Please see the usage.txt file for simple instructions on making your own slot machines.

													   
C. Tips / FAQ
=============
* Before you modify the SSK version - The SSK version of the game includes a copy of the 
SSK library.  However, it is sure to be out of date.  So, be sure to get the latest version 
here: https://github.com/roaminggamer/SSKCorona


* SSKCorona Wiki - There is a free quick reference to SSKCorona here: https://github.com/roaminggamer/SSKCorona/wiki

* Question: "Where can I go to get more templates?" 
    Answer: The Roaming Gamer, LLC website of course: http://roaminggamer.com/
	


D. Reporting Bugs
=================
Is something wrong with this package? Did you find a bug?  If so, please write me here: 

roaminggamer@gmail.com 

Be sure to include this information in your e-mail:

e-mail Title: "Template Bug: Slot Machine(s)"

e-mail Body:

Tell me these details,
	- What you did, 
	- What you expected to see, and 
	- What happened instead.

Please provide any other details about the bug that seem pertinent.


Thanks,

The Roaming Gamer



