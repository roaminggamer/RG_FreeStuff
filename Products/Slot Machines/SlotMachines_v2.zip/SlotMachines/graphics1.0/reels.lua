-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- reels.lua- A module for creating 2 to 5 reels.
-- =============================================================

----------------------------------------------------------------------
-- 1. Local Variables and Functions
----------------------------------------------------------------------
local reelModule  = require( "reel" )

-- ==
--	createReels() - This function creates between 2 and 5 reels based on the settings in params.
-- ==
function createReels( layer, params )

	-- 1. Localize the function parameters and set up default values if neccesary
	--
	local params     = params or {}
	params.spinTime  = params.spinTime or 80
	params.x         = params.x or centerX
	params.y         = params.y or centerY
	
	local tileWidth  = params.tileWidth
	local tileHeight = params.tileHeight
	local numReels   = params.machine.numReels
	local spinTime   = params.spinTime or  80

	-- 2. Create a display group to contain all of our reels (an a background)
	local theReels = display.newGroup()
	layer:insert(theReels)
	theReels.reels = {} -- Table for easy tracking of reels.

	-- 3. Add a white background (For rare cases when the reels don't spin perfectly, we won't see gaps).
	--
	display.newRect(theReels, 0, 0, numReels * tileWidth, 5 * tileHeight)

	-- 4. Create 'numReels' single reels and position them.
	---
	for i = 1, numReels do
		theReels.reels[i] = reelModule.createReel( theReels, i*tileWidth-tileWidth/2, (tileHeight*5/2), i, params )		                                           
	end
	theReels:setReferencePoint( display.CenterReferencePoint )
	theReels.x = params.x
	theReels.y = params.y

	-- 5. Add functions and methods to theReels
	--

	-- ==
	--  reelModuleSpinComplete(reel) - A local callback responsible for determining when all reels have stopped spinning.
	-- ==
	local spinningReels = 0
	local function reelModuleSpinComplete( reel )
		--print( "Reel number " .. reel.num .." done spinning. " ) 

		-- Decrement spin count by one for each call to this function
		-- and when the count gets to 0, all spins are done.
		--
		spinningReels = spinningReels - 1 
		
		-- Then, try to call the spinsComplete() callback.
		--		
		if(spinningReels == 0) then
			if( params.spinsComplete ) then
				params.spinsComplete( theReels )
			end
		end
	end

	-- ==
	--  theReels:spin( ) - This method is used to spin all of the reels.
	-- ==
	function theReels:spin( )
		local tenthSpinTime = params.spinTime/10
		local lastSpins = 12
		local doneTime = 0

		if(spinningReels > 0 ) then	
			--print("Still spinning, ignoring spin request")
			return false
		end

		spinningReels = numReels -- i.e. How many reels did we start spinning

		for i = 1, numReels do
			lastSpins = lastSpins + math.random(5,7)
			local spins = lastSpins	
			local f = function() 
				self.reels[i]:spin( params.spinTime, spins, reelModuleSpinComplete )
			end
			timer.performWithDelay( tenthSpinTime * (i-1), f ) 
			doneTime = params.spinTime * spins + 1000
		end

		return true
	end

	-- ==
	--  theReels:getPayline( ) - This method is used extract the reel values from each reel at a specified row position.
	-- ==
	function theReels:getPayline( payLineRows )
		local thePayline = {}
		for i = 1, #payLineRows do
			thePayline[i] = self.reels[i]:getRow(payLineRows[i])
		end

		return thePayline
	end

	return theReels
end


----------------------------------------------------------------------
-- 2. The Module
----------------------------------------------------------------------
local public = {}

public.createReels = createReels

return public