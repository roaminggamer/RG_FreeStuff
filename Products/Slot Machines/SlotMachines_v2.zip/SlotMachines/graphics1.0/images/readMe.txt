These images are made by me (The Roaming Gamer).  You can use them as you wish.

