The source clip-art used in this template can be found on this site:
http://clipart.nicubunu.ro/

These images are covered by this Creative Commons license: http://creativecommons.org/licenses/publicdomain/

