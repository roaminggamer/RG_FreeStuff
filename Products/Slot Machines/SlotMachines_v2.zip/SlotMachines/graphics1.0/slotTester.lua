-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2013 
-- =============================================================
-- slotTester.lua- This module implements a brute force test for basic slot machines.
--
-- It can handle slot machines (produced by machineLoader.lua) with between 2 and 5 reels.
--
-- This module does not have the logic to test for wild and special symbols.  
-- Most of the work for this can be done in the machineLoader.lua module.
--
-- Warning: Be careful about making excessively large reels. Because this module tests all possible
-- spin combinations, it can be slow for large machines.
--
-- For example, if you specified a 5-reel machine where each reel had 20 symbols, this tester would
-- iterate over 20^5 == 3.2 million tests.  My suggestion is that you increase the reel size slowly.
--
-- When the test is complete, this module reports this data
--
--        maxCombinations - Number of possible symbol combinations.
--            totalPayout - Total amount paid out by all combinations on this machine (assumes $1 per bet).
--          payoutMatches - Total combinations that paid out.
--       Rolls per payout - The average number of rolls per payout.  This is only true for 'maxCombinations' rolls.  During
--                          normal usage, the actual payout will be (more) random.
-- Machine Payout Percent - Basically, this number tells you how much money a machine should make.  Most real world slot machines
--                          look for about an 85% payout. i.e. They earn a minimum of 15%.
-- 
-- =============================================================
----------------------------------------------------------------------
-- 1. The Module
----------------------------------------------------------------------

local public = {}

-- ==
--	testMachine() - This function tests the passed slot machine logic class instance.
-- ==
public.testMachine = function( machine )

	local numReels = machine.numReels
	local reels = {}

	local maxCombinations = 1
	local totalPayout   = 0
	local payoutMatches = 0

	for i = 1, numReels do
		reels[i] = machine:getReel(i)
		maxCombinations = maxCombinations * #reels[1]
	end

	-- Iterate over every combination and calculate the matches and payouts for those matches
	for i = 1, #reels[1] do
		for j = 1, #reels[2] do
			if(  numReels > 2 ) then
				for k = 1, #reels[3] do
					if( numReels > 3) then
						for l = 1, #reels[4] do
							if( numReels > 4) then
								for m = 1, #reels[5] do
									local payout = machine:calculatePayoutFromData( { reels[1][i], reels[2][j], reels[3][k], reels[4][l], reels[5][m] } )
								
									if( payout > 0 ) then
										payoutMatches = payoutMatches + 1
										totalPayout = totalPayout + payout
									end								   
								end
							else
								local payout = machine:calculatePayoutFromData( { reels[1][i], reels[2][j], reels[3][k], reels[4][l] } )
								
								if( payout > 0 ) then
									payoutMatches = payoutMatches + 1
									totalPayout = totalPayout + payout
								end								   
							end
						end
					else
						local payout = machine:calculatePayoutFromData( { reels[1][i], reels[2][j], reels[3][k] } )
						if( payout > 0 ) then
							payoutMatches = payoutMatches + 1
							totalPayout = totalPayout + payout
						end								   
					end
				end
			else
				local payout = machine:calculatePayoutFromData( { reels[1][i], reels[2][j]} )
				if( payout > 0 ) then
					payoutMatches = payoutMatches + 1
					totalPayout = totalPayout + payout
				end								   
			end
		end
	end

	print( "       maxCombinations: " .. maxCombinations )
	print( "           totalPayout: " .. totalPayout )
	print( "         payoutMatches: " .. payoutMatches )
	print( "      Rolls per payout: " .. round( maxCombinations/payoutMatches,2) )
	print( "Machine Payout Percent: " .. round(totalPayout/maxCombinations,2) * 100 .. "%" )
end

return public
