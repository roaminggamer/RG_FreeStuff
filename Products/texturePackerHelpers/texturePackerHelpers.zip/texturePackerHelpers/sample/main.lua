-- 
-- Abstract: texturePackerHelpers Library Plugin Test Project
-- 
-- Sample code is MIT licensed, see http://www.coronalabs.com/links/code/license
-- Copyright (C) 2015 Corona Labs Inc. All Rights Reserved.
--
------------------------------------------------------------

--
-- TEST RUNS BEST ON ANY DEVICE WITH RESOLUTION 640 x 960
--

-- Texture Packer (https://www.codeandweb.com/texturepacker)
local group = display.newGroup()
local ex = require "texturePacker.example"
ex.run( group )
group:scale(0.55,0.55)
group.x = -50

-- ShoeBox (http://renderhjs.net/shoebox/)
local group = display.newGroup()
local ex = require "shoeBox.example"
ex.run( group )
group:scale(0.55,0.55)
group.x = display.contentCenterX - 100

-- Free Texture Packer 0.2.4 (http://free-tex-packer.com/)
-- When using too, export as JSON (array) + Method ==> bestAreaFit
--
local group = display.newGroup()
local ex = require "freeTexturePacker_web.example"
ex.run( group )
group:scale(0.55,0.55)
group.x = -50
group.y = display.contentCenterY - 20
--group.x = display.contentCenterX - 100

-- Leshy Sprite Tool (https://www.leshylabs.com/apps/sstool/)
local group = display.newGroup()
local ex = require "leshySpriteSheetTool_web.example"
ex.run( group )
group:scale(0.55,0.55)
group.x = display.contentCenterX - 100
group.y = display.contentCenterY - 20

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------