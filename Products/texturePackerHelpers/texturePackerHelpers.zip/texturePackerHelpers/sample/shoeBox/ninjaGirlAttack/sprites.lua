local M = {}
M.sheetData = {
	frames = {
		{ name=Attack__000, x = 1373, y = 0, width = 289, height = 485, sourceX=45, sourceY=37, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__001, x = 1318, y = 966, width = 289, height = 488, sourceX=37, sourceY=34, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__002, x = 1004, y = 966, width = 312, height = 491, sourceX=5, sourceY=31, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__003, x = 511, y = 952, width = 491, height = 490, sourceX=33, sourceY=32, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__004, x = 516, y = 0, width = 487, height = 482, sourceX=37, sourceY=40, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__005, x = 0, y = 0, width = 514, height = 472, sourceX=10, sourceY=52, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__006, x = 0, y = 474, width = 512, height = 476, sourceX=12, sourceY=52, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__007, x = 0, y = 952, width = 509, height = 476, sourceX=15, sourceY=52, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__008, x = 0, y = 1430, width = 394, height = 474, sourceX=26, sourceY=48, sourceWidth=524 , sourceHeight=565 },
		{ name=Attack__009, x = 1004, y = 484, width = 367, height = 480, sourceX=46, sourceY=42, sourceWidth=524 , sourceHeight=565 }
	},
	sheetContentWidth = 1664,
	sheetContentHeight = 1906
}
return M