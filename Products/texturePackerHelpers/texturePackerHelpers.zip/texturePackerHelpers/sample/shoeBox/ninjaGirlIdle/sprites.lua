local M = {}
M.sheetData = {
	frames = {
		{ name=Idle__000, x = 0, y = 0, width = 289, height = 500, sourceX=0, sourceY=0, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__001, x = 0, y = 502, width = 288, height = 499, sourceX=1, sourceY=1, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__002, x = 579, y = 0, width = 286, height = 499, sourceX=3, sourceY=1, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__003, x = 867, y = 0, width = 285, height = 498, sourceX=4, sourceY=2, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__004, x = 1153, y = 500, width = 284, height = 497, sourceX=5, sourceY=3, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__005, x = 1154, y = 0, width = 283, height = 496, sourceX=6, sourceY=4, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__006, x = 867, y = 500, width = 284, height = 497, sourceX=5, sourceY=3, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__007, x = 580, y = 501, width = 285, height = 498, sourceX=4, sourceY=2, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__008, x = 291, y = 0, width = 286, height = 499, sourceX=3, sourceY=1, sourceWidth=290 , sourceHeight=500 },
		{ name=Idle__009, x = 290, y = 502, width = 288, height = 499, sourceX=1, sourceY=1, sourceWidth=290 , sourceHeight=500 }
	},
	sheetContentWidth = 1439,
	sheetContentHeight = 1003
}
return M