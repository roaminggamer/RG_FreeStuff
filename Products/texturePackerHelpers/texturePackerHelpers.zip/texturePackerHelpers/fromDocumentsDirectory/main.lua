
require "ssk2.loadSSK"
_G.ssk.init()

--
-- 1 - Copy assets to documents folder so we can emulate the case where scripts and images are sourced there.
-- 
local src = ssk.files.resource.getPath( 'copySrc' )
local dst = ssk.files.documents.getPath( 'texturePacker' )
ssk.files.util.mkFolder( dst )
ssk.files.util.cpFolder( src, dst )

-- 
-- 2 - Load and enable patcher
--
local patcher = require "patcher"
patcher.debug(true)
patcher.export()
patcher.enabled(true)

--
-- 3 - Load and select Texture Packer Helper
--
local helpers = require "texturePackerHelpers"
local helper = helpers.texturePacker

--
-- 4 - Examples
--

local group = display.newGroup()

--
-- A - Load and use sheet definition from documents folder to make newImageRect()
--
local baseDir 		= system.DocumentsDirectory
local data 			= require( 'texturePacker.slots' )
local imageSheet 	= graphics.newImageSheet( 'texturePacker/slots.png', baseDir, data.sheet  )	
local img  			= display.newImageRect( group, imageSheet, 0, 100, 100 )
img.x = 100
img.y = 100

--
-- B - Do same as A with texturePackerHelpers 
--
local slotsSheet 	= helper.newImageSheet( { definition = "texturePacker.slots",  image = "texturePacker/slots.png", baseDir = baseDir } )
print(slotsSheet,'yo')
local cherry 	= display.newImage( group, slotsSheet, 1, 200 , 100 )

--
-- C - Alternative using just texturePackerHelpers
--
local grapes = helper.newImage( { definition = "texturePacker.slots", 
	                              image = "texturePacker/slots.png", frameIndex = 3, 
	                              baseDir = baseDir,
		                          parent = group, x = 300, y = 100 } )


--
-- D - Ninja Girl - Creating Animated Sprite From SINGLE Image Sheet
--
local ninjaGirlIdleSequenceData =
{
	name		= "idle",
   start		= 1,
   count 		= 10,
   time 		= 1000,
   loopCount 	= 0
}

local ninjaGirlIdleSprite = helper.newSprite( { definition = "texturePacker.ninjaGirlIdle", 
												image = "texturePacker/ninjaGirlIdle.png",
												parent = group, x = centerX, y = centerY, baseDir = baseDir },
												ninjaGirlIdleSequenceData )
ninjaGirlIdleSprite:scale(0.5,0.5)
ninjaGirlIdleSprite:setSequence("idle")
ninjaGirlIdleSprite:play()

--
