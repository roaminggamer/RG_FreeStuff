Hi.

When you first run this example it will FAIL.

1. You need to locate and open the 'documents directory' yourself and then copy the 'assets' folder into it.

2. Then re-run.