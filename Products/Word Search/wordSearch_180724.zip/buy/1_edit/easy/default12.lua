
-- Tool used to generate this  puzzles:
-- http://puzzlemaker.discoveryeducation.com/WordSearchSetupForm.asp
local data = {}

data.puzzle =
[[
G E T A L O C O H C A T 
Y E K O P Y E K O H L U 
S T R A W B E R R Y L N 
S E S E E R D C E I I L 
A N A N A B A D Q M N A 
Y K C O R E O Y P K A W 
A R W W H Z R S B M V E 
S K C A R T E S O O M L 
F N A C E P F U D G E P 
W J O G E L O V Y S J A 
C K W U I G W B X X D M 
C O T T O N C A N D Y B 
]]

data.list = 
[[
BANANA
CHOCOLATE
COTTON CANDY
FUDGE
HOKEY OKEY
MAPLE WALNUT
MOOSE TRACKS
PECAN
REESES
ROAD
ROCKY
STRAWBERRY
VANILLA
]]

return data