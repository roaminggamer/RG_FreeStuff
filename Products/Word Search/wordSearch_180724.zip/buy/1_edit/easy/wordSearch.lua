-- =============================================================
-- Copyright Roaming publicr, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local utils 		= require "easy.utils"
local buttonMaker = require "easy.buttonMaker"

-- =============================================================
-- Localizations
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right = round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
local getTimer = system.getTimer;local strGSub = string.gsub
local strSub = string.sub; local strFormat = string.format
local mFloor = math.floor; local mRand = math.random
local files = utils.files

-- =============================================================
-- Forward Declarations
-- =============================================================
local cleanData
local drawPuzzle
local solvePuzzle
local drawAndSolvePuzzle
local savePuzzle
local editorLoadPuzzle
local markWord
local drawLine
local getLetter
local searchRows
local searchColumns
local searchDiagonalsRight
local searchDiagonalsLeft
local getTile
local getWord
local checkList

-- =============================================================
-- Locals
-- =============================================================
local editorFont 	= native.systemFont

local lineWidth = 20
local eFontSize = 18
local eFont = native.newFont( editorFont, eFontSize )

local evGroup
local puzzleGroup
--
local puzzleLettersBox
local puzzleListBox
local puzzleNameBox
--
local curRawPuzzle 	= ""
local curRawList 		= ""
--
local curPuzzle 		= {}
local curList 			= {}
--
local rows 			= 0
local cols 			= 0
local inRows 		= 0
local inCols 		= 0
local inDiagonals = 0
local difficulty = 0
--
local levelsFolder 	= "puzzles"
local levelsRoot 		= system.pathForFile(levelsFolder)
local tileWidth 		= 60
local tileHeight 		= 60
local letterFontSize = 30
--
local isEditing = true
local gameIsRunning = false

-- Line Colors
local lchex = { "#7ec696", "#e9c9bc", "#aaf2e7", "#df93ed", "#dbc1a6", 
                "#7f89ad", "#9194ff", "#7fafc5", "#93d3b8", "#aa84cd", 
                "#e1e5c2", "#e1e5c2", "#f9f7c4", "#92ba9f", "#ec99e1", 
                "#af89d6", "#a3a1c9", "#afdece", }
local lc = {}
for i = 1, #lchex do
	lc[#lc+1] = utils.hexcolor(lchex[i])
end

-- =============================================================
-- Module Begins
-- =============================================================
local public = {}

-- ******************************************************************
-- Editor  *  Editor  *  Editor  *  Editor  *  Editor  *  Editor
-- ******************************************************************
function public.destroyEditor( )
	if( puzzleLettersBox ) then
		puzzleLettersBox:removeEventListener( "userInput" )
	end
	display.remove(puzzleNameBox)
	display.remove(puzzleLettersBox)
	display.remove(evGroup)
	evGroup = nil
	puzzleLettersBox = nil
	puzzleNameBox = nil
	curRawPuzzle = ""
	curRawList = ""
	inRows 		= 0
	inCols 		= 0
	inDiagonals = 0
	difficulty  = 0
	gameIsRunning = false
end

function public.createEditor( group )
	group = group or display.currentStage
	public.destroyEditor()
	evGroup = display.newGroup()
	group:insert( evGroup )
	isEditing = true
	gameIsRunning = true
	lineWidth = 20
	--

	local tmp = require "easy.default10"
	--local tmp = require "easy.default12"
	curRawPuzzle = tmp.puzzle
	curRawList   = tmp.list
	--print(curRawPuzzle, curRawList)
	curRawPuzzle = cleanData( curRawPuzzle )
	curRawList = cleanData( curRawList, true )	

	-- Raw Puzzle Letters Edit Box   
	local tmp = display.newText( evGroup, "1. Paste Puzzle", left + 25, top + 25, editorFont, 20 )
	tmp.anchorX = 0
	local ebw = 250
	local ebh = 250
	local function textListener( self, event )
		self.text = string.upper(self.text)
		curRawPuzzle = self.text
		curRawPuzzle = cleanData( curRawPuzzle )
	end
	puzzleLettersBox = native.newTextBox( left + ebw/2 + 10, top + ebh/2 + 40, ebw, ebh )
	puzzleLettersBox.text = curRawPuzzle
	puzzleLettersBox.isEditable = true	
	puzzleLettersBox.font = eFont
	puzzleLettersBox.userInput = textListener
	puzzleLettersBox:addEventListener( "userInput" )
	evGroup:insert(puzzleLettersBox)

	-- Raw Puzzle List Edit Box
	local tmp = display.newText( evGroup, "2. Paste List", left + 25, puzzleLettersBox.y + ebh/2 + 15, editorFont, 20 )
	tmp.anchorX = 0
	local ebh2 = 125
	local function textListener( self, event )
		self.text = string.upper(self.text)
		curRawList = self.text
		curRawList = cleanData( curRawList, true )
	end
	puzzleListBox = native.newTextBox( puzzleLettersBox.x , puzzleLettersBox.y + ebh/2 + ebh2/2 + 30, ebw, ebh2 )
	puzzleListBox.text = curRawList
	puzzleListBox.isEditable = true	
	puzzleListBox.font = eFont
	puzzleListBox.userInput = textListener
	puzzleListBox:addEventListener( "userInput" )
	evGroup:insert(puzzleListBox)

	local b = buttonMaker.easyPush( { parent = evGroup, x = puzzleLettersBox.x - 5, y = puzzleListBox.y + ebh2/2 + 25, fontSize = 15, font = editorFont,
		                     width = 240, height = 30, labelText = "3. Draw & Verify Puzzle", listener = drawAndSolvePuzzle } )	


	local tmp = display.newText( evGroup, "4. Name Puzzle", left + 25, b.y + 35, editorFont, 20 )
	tmp.anchorX = 0
	puzzleNameBox = native.newTextField( left + 135, tmp.y + 30, 250, 30 )
	puzzleNameBox.text = "puzzle_001"

	buttonMaker.easyPush( { parent = evGroup, x = puzzleLettersBox.x - 5, y = bottom - 65, fontSize = 15, font = editorFont,
		                     width = 240, height = 30, labelText = "5. Save Puzzle", listener = savePuzzle } )
	buttonMaker.easyPush( { parent = evGroup, x = puzzleLettersBox.x - 5, y = bottom - 25, fontSize = 15, font = editorFont,
		                     width = 240, height = 30, labelText = "Load Puzzle", listener = editorLoadPuzzle } )	
	drawAndSolvePuzzle()
end

savePuzzle = function( )
	local saveData = 
	{ 
		inRows 		= inRows, 
		inCols 		= inCols, 
		inDiagonals = inDiagonals, 
		rawPuzzle 	= curRawPuzzle, 
		rawList 		= curRawList,
		rows 			= rows,
		cols 			= cols,
		difficulty  = difficulty,
	}
	files.util.saveTable( saveData, levelsRoot .. "/" .. puzzleNameBox.text .. ".json" )
end

editorLoadPuzzle = function( )
	local loadData = files.util.loadTable( levelsRoot .. "/" .. puzzleNameBox.text .. ".json" )
	--utils.dump(loadData)
	inRows = loadData.inRows
	inCols = loadData.inCols
	inDiagonals = loadData.inDiagonals
	curRawPuzzle = loadData.rawPuzzle
	curRawList = loadData.rawList
	puzzleLettersBox.text = curRawPuzzle
	puzzleListBox.text = curRawList
	drawAndSolvePuzzle()
end

drawAndSolvePuzzle = function( )
	inRows 		= 0
	inCols 		= 0
	inDiagonals = 0
	--
	puzzleLettersBox.text = curRawPuzzle
	--
	drawPuzzle( puzzleLettersBox.x + puzzleLettersBox.contentWidth/2 + 10, top + 40 )
	solvePuzzle()
end


-- ******************************************************************
-- Editor  *  Editor  *  Editor  *  Editor  *  Editor  *  Editor
-- ******************************************************************
function public.destroyPuzzleViewer( )
	display.remove(evGroup)
	evGroup = nil
	curRawPuzzle = ""
	curRawList = ""
	inRows 		= 0
	inCols 		= 0
	inDiagonals = 0
	difficulty  = 0
	gameIsRunning = false
end

function public.createPuzzleViewer( group, x, y, puzzleToLoad, params )
	group = group or display.currentStage
	public.destroyPuzzleViewer()
	evGroup = display.newGroup()
	group:insert( evGroup )
	isEditing = false
	gameIsRunning = true
	--
	local loadData = utils.load( levelsFolder .. "/" .. puzzleToLoad, system.ResourceDirectory )
	--utils.dump(loadData)
	inRows = loadData.inRows
	inCols = loadData.inCols
	inDiagonals = loadData.inDiagonals
	curRawPuzzle = loadData.rawPuzzle
	curRawList = loadData.rawList
	drawPuzzle( x, y, params )
end

-- ******************************************************************
-- Viewer & Editor  *  Viewer & Editor  *  Viewer & Editor
-- ******************************************************************
function public.setTileSize( size )
	tileWidth = size
	tileHeight = size
	letterFontSize = math.ceil(size/3) + 2
end

function public.setLineWidth( width )
	lineWidth = width
end

function public.setColors( colorCodes )
	lc = {}
	for i = 1, #colorCodes do
		lc[#lc+1] = utils.hexcolor(colorCodes[i])
	end
end

function public.setFont( ef )
	editorFont = ef or native.systemFont
	eFont = native.newFont( editorFont, eFontSize )
end

function public.getPuzzle( puzzleToLoad )
	local loadData = utils.load( levelsFolder .. "/" .. puzzleToLoad, system.ResourceDirectory )
	return loadData
end

cleanData = function( oldData, allowSpaces )
	local newData
	oldData = string.gsub(oldData,"\r","")
	local tmp = utils.split(oldData,"\n")
	for i = 1, #tmp do
		if( not allowSpaces ) then
			tmp[i] = strGSub(tmp[i]," ", "")			
			tmp[i] = strGSub(tmp[i],"\t", "")
		else
			tmp[i] = strGSub(tmp[i],"\t", " ")
		end
		tmp[i] = utils.trim(tmp[i])
		if( string.len(tmp[i]) > 0 ) then
			if( not newData ) then
				newData = tmp[i]
			else
				newData = newData .. "\n" .. tmp[i]
			end
		else
			print("EMPTY")
		end
	end
	return newData
end

drawPuzzle = function( x, y, params )
	params = params or {}
	curRawPuzzle = cleanData(curRawPuzzle)
	curPuzzle = {}
	curList = {}
	rows = 0
	cols = 0
	inRows = 0
	inCols = 0
	inDiagonals = 0

	if( not isEditing ) then
		curList = utils.split(curRawList, "\n" )
		for i = #curList, 1, -1 do
			if( string.len(utils.trim(curList[i])) == 0 ) then
				table.remove( curList, i)
			end
		end
		--utils.dump(curList)
	end	

	local letters = string.gsub(curRawPuzzle,"\r","")
	letters = utils.split(letters,"\n")
	rows = #letters
	for i = 1, #letters do
		local oldRow = letters[i]
		local len = string.len(oldRow)
		cols = (len>cols) and len or cols
		local row = {}
		for j = 1, len do
			row[j] = string.sub(oldRow,j,j)
		end
		letters[i] = row
	end
	--
	display.remove(puzzleGroup)
	puzzleGroup = display.newGroup()
	puzzleGroup.x = x
	puzzleGroup.y = y
	evGroup:insert(puzzleGroup)
	--
	local sx = tileWidth/2
	local sy = tileHeight/2
	local cx = sx
	local cy = sy
	for i = 1, cols do
		for j = 1, rows do
			local img = params.tileImg or "images/fillW.png"
			local tile = display.newImageRect( puzzleGroup, img, tileWidth, tileHeight )
			tile.x = cx
			tile.y = cy
			tile.letter = letters[j][i] or "#"
			tile.row = j
			tile.col = i
			curPuzzle[tile] = tile
			local letter = display.newText( puzzleGroup, tile.letter, cx, cy, 
				                             params.letterFont or editorFont, 
				                             params.letterSize or (letterFontSize + 4) )
			letter:setFillColor(unpack(params.letterColor or {0,0,0}))
			cy  = cy + tileHeight
			tile.letterLabel = letter
			--
			if( not isEditing ) then
				function tile.touch( self, event )
					if( not gameIsRunning ) then return false end
					local phase 	= event.phase
					local id 		= event.id
					local setNum 	= self.set
					if( phase == "began" ) then

						self.isFocus = true
						display.currentStage:setFocus( self, id )

						drawLine( self, event )

					elseif( self.isFocus ) then
						local dx = event.x - event.xStart
						local dy = event.y - event.yStart

						if( phase == "moved" ) then

							drawLine( self, event )

						elseif( phase == "ended" or phase == "cancelled" ) then
							self.isFocus = false
							display.currentStage:setFocus( self, nil )
							--
							display.remove( self.line )
							self.line = nil
							--
							local over
							for k,v in pairs( curPuzzle ) do
								if( v ~= self and utils.isInBounds( event, v ) ) then
									over = v
								end
							end
							if( over ) then
								local dRow = over.row - self.row
								local dCol = over.col - self.col
								local endTile
								--								
								if( dRow == 0 and dCol == 0 ) then
									-- Should not happen
								elseif( dRow == 0 ) then
									endTile = over
								elseif( dCol == 0 ) then
									endTile = over
								elseif( math.abs(dCol) == math.abs(dRow) ) then
									endTile = over
								end
								--
								if( endTile ) then
									local word = getWord( self.col, self.row, over.col, over.row )
									local word, complete = checkList( word )
									if( word ) then
										markWord( self.col, self.row, endTile.col, endTile.row, lc[self.lineColorNum] )
										if( params.listener ) then
											params.listener( { phase = "foundWord", word = word } )
										end
										if( complete ) then
											gameIsRunning = false
											if( params.listener ) then
												params.listener( { phase = "puzzleComplete" } )
											end
										end
									end

								end

							end
						end
					end
					return true
				end; tile:addEventListener("touch")
			end
		end
		cx  = cx + tileWidth
		cy = sy
	end
end

local count = 0
markWord = function( col1, row1, col2, row2, color )
	local tile1, tile2 
	for k,v in pairs( curPuzzle ) do
		if( v.row == row1 and v.col == col1 ) then
			tile1 = v
		end
		if( v.row == row2 and v.col == col2 ) then
			tile2 = v
		end
	end
	--
	count = count + 1 
	if( count > #lc ) then
		count = 1
	end
	color = color or lc[count]
	--
	local cap1 = display.newImageRect( tile1.parent, "images/circle.png", lineWidth + 0, lineWidth + 0 )
	cap1.x = tile1.x
	cap1.y = tile1.y
	cap1:setFillColor( unpack(color) )
	local cap2 = display.newImageRect( tile1.parent, "images/circle.png", lineWidth + 0, lineWidth + 0 )
	cap2.x = tile2.x
	cap2.y = tile2.y
	cap2:setFillColor( unpack(color) )
	local line = display.newLine( tile1.parent, tile1.x, tile1.y, tile2.x, tile2.y )
	line.strokeWidth = lineWidth
	line:setStrokeColor( unpack(color) )
	for k,v in pairs( curPuzzle ) do
		v.letterLabel:toFront()
	end
end

drawLine = function( obj, event  )
	local size1 = lineWidth
	local size2 = lineWidth + 0
	local x1 = obj.x
	local y1 = obj.y
	local x2 = event.x - obj.parent.x
	local y2 = event.y - obj.parent.y
	if( not obj.line ) then
		count = count + 1 
		if( count > #lc ) then
			count = 1
		end
		obj.lineColorNum = count

		obj.line = display.newGroup()
		obj.parent:insert(obj.line)
		local cap1 = display.newImageRect( obj.line, "images/circle.png", lineWidth + 0, lineWidth + 0 )
		cap1.x = x1
		cap1.y = y1
		cap1:setFillColor( unpack(lc[obj.lineColorNum]) )
	else
		display.remove( obj.line )
		obj.line = display.newGroup()
		obj.parent:insert(obj.line)
		local cap1 = display.newImageRect( obj.line, "images/circle.png", lineWidth + 0, lineWidth + 0 )
		cap1.x = x1
		cap1.y = y1
		cap1:setFillColor( unpack(lc[obj.lineColorNum]) )
		local cap2 = display.newImageRect( obj.line, "images/circle.png", lineWidth + 0, lineWidth + 0 )
		cap2.x = x2
		cap2.y = y2
		cap2:setFillColor( unpack(lc[obj.lineColorNum]) )
		local line = display.newLine( obj.line, x1, y1, x2, y2 )
		line.strokeWidth = lineWidth
		line:setStrokeColor( unpack(lc[obj.lineColorNum]) )
	end
	for k,v in pairs( curPuzzle ) do
		v.letterLabel:toFront()
	end
end


-- ******************************************************************
-- Solving  *  Solving  *  Solving  *  Solving  *  Solving  *  Solving  
-- ******************************************************************
getLetter = function( col, row, letters )
	local index = cols * (row-1) + col
	return strSub( letters, index, index )
end
local function getTile( col, row )
	for k,v in pairs( curPuzzle ) do
		if( v.col == col and v.row == row ) then 
			return v
		end
	end
end

searchRows = function( word, rec )
	local col1
	local row1
	local col2
	local row2
	--
	local letters = cleanData(curRawPuzzle)
	letters = utils.split( letters, "\n" )
	local row = 1
	while( not rec.found and row <= #letters ) do
		local at = string.find( letters[row], word, 1, true )
		if( at ) then
			rec.found = true
			col1 = at
			col2 = at + string.len( word ) -1
			row1 = row
			row2 = row
		end
		row = row + 1
	end
	if( rec.found ) then 
		markWord( col1, row1, col2, row2 )
		inRows = inRows + 1
	end
end

searchColumns = function( word, rec )
	local col1
	local row1
	local col2
	local row2
	--
	local letters = cleanData(curRawPuzzle)
	letters = utils.split( letters, "\n" )
	--
	local tmp = {}
	for col = 1, #letters[1] do
		tmp[col] = ""
		for row = 1, #letters do
			tmp[col] = tmp[col] .. strSub( letters[row], col, col )
		end
	end
	letters = tmp
	tmp = nil
	--
	local col = 1
	while( not rec.found and col <= #letters ) do
		local at = string.find( letters[col], word, 1, true )
		if( at ) then
			rec.found = true
			row1 = at
			row2 = at + string.len( word ) -1
			col1 = col
			col2 = col
		end
		col = col + 1
	end
	if( rec.found ) then 
		markWord( col1, row1, col2, row2 )		
		inCols = inCols + 1
	end
end

searchDiagonalsRight = function( word, rec )
	local col1
	local row1
	local col2
	local row2
	--
	local letters = cleanData(curRawPuzzle)
	letters = strGSub( letters, "\n", "" )
	--
	local letters2 = ""
	local tmpTiles = {}
	for row = 1, rows do
		local curRow = row
		local curCol = 1
		while( curRow > 0 and curCol <= cols ) do
			tmpTiles[#tmpTiles+1] = getTile( curCol, curRow )
			letters2 = letters2 ..  getLetter( curCol, curRow, letters )
			curRow = curRow - 1
			curCol = curCol + 1
		end
	end
	for col = 2, cols do
		local curRow = rows
		local curCol = col
		while( curCol <= cols and curCol <= cols ) do
			tmpTiles[#tmpTiles+1] = getTile( curCol, curRow )
			letters2 = letters2 ..  getLetter( curCol, curRow, letters )
			curRow = curRow - 1
			curCol = curCol + 1
		end
	end
	local at = string.find( letters2, word, 1, true )
	if( at ) then
		rec.found = true
		row1 = tmpTiles[at].row
		col1 = tmpTiles[at].col 
		row2 = tmpTiles[at + string.len( word ) -1].row
		col2 = tmpTiles[at + string.len( word ) -1].col 
	end
	if( rec.found ) then 
		inDiagonals = inDiagonals + 1
		markWord( col1, row1, col2, row2 )
	end
end

searchDiagonalsLeft = function( word, rec )
	local col1
	local row1
	local col2
	local row2
	--
	local letters = cleanData(curRawPuzzle)
	letters = strGSub( letters, "\n", "" )
	--
	local letters2 = ""
	local tmpTiles = {}
	for row = rows, 1, -1 do
		local curRow = row
		local curCol = 1
		while( curRow <= rows and curCol <= cols ) do
			tmpTiles[#tmpTiles+1] = getTile( curCol, curRow )
			letters2 = letters2 ..  getLetter( curCol, curRow, letters )
			curRow = curRow + 1
			curCol = curCol + 1
		end
	end
	for col = 2, cols do
		local curRow = 1
		local curCol = col
		while( curRow <= rows and curCol <= cols ) do
			tmpTiles[#tmpTiles+1] = getTile( curCol, curRow )
			letters2 = letters2 ..  getLetter( curCol, curRow, letters )
			curRow = curRow + 1
			curCol = curCol + 1
		end
	end	
	local at = string.find( letters2, word, 1, true )
	if( at ) then
		rec.found = true
		row1 = tmpTiles[at].row
		col1 = tmpTiles[at].col 
		row2 = tmpTiles[at + string.len( word ) -1].row
		col2 = tmpTiles[at + string.len( word ) -1].col 
	end
	if( rec.found ) then 
		markWord( col1, row1, col2, row2 )
	end
end

solvePuzzle = function( )
	local wordList = cleanData(curRawList)
	wordList = utils.split(wordList,"\n")
	--
	local tmp = {}
	for i = 1, #wordList do
		local word = utils.trim(wordList[i])
		if( string.len(word) > 0) then
			tmp[#tmp+1] = { found = false, word = word }
		end
	end
	wordList = tmp
	tmp = nil
	--
	local inDiff = {}
	local count = 0
	local function accumulateDifficulty( index )
		local lastCount = count
		count = 0
		for i = 1, #wordList do
			if(wordList[i].found) then
				count = count + 1
			end
		end
		local delta = count - lastCount
		inDiff[index] = delta / 32 
	end
	-- Horiz	
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchRows( wordList[i].word, wordList[i] ) end
	end
	accumulateDifficulty(1)
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchRows( string.reverse(wordList[i].word), wordList[i] ) end
	end
	accumulateDifficulty(2)
	-- Vert
	for i = 1, #wordList do		
		if( not wordList[i].found ) then searchColumns( wordList[i].word, wordList[i] ) end
	end
	accumulateDifficulty(3)
	for i = 1, #wordList do		
		if( not wordList[i].found ) then searchColumns( string.reverse(wordList[i].word), wordList[i] ) end
	end
	accumulateDifficulty(4)
	-- Diagonal Right
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchDiagonalsRight( wordList[i].word, wordList[i] ) end
	end	
	accumulateDifficulty(5)
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchDiagonalsRight( string.reverse(wordList[i].word), wordList[i] ) end
	end	
	accumulateDifficulty(6)
	-- Diagonal Left
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchDiagonalsLeft( wordList[i].word, wordList[i] ) end
	end
	accumulateDifficulty(7)
	for i = 1, #wordList do
		if( not wordList[i].found ) then searchDiagonalsLeft( string.reverse(wordList[i].word), wordList[i] ) end
	end
	accumulateDifficulty(8)

	--
	local curX = -puzzleGroup.x + puzzleListBox.x + puzzleListBox.contentWidth/2 + 20
	local curY = top + rows * tileHeight + 20
	local verifyCount = 0
	for i = 1, #wordList do
		if( wordList[i].found ) then
			verifyCount = verifyCount + 1
		else
			local tmp = display.newText( puzzleGroup, "Missing: " .. wordList[i].word,  curX, curY, editorFont, 16 )
			tmp.anchorX = 0
			curY = curY + 15
			tmp:setFillColor(1,0,0)
		end
	end
	if( verifyCount == #wordList ) then
		difficulty = 0
		local mult = 0
		for i = 1, #inDiff do
			mult = mult + 0.5
			difficulty = difficulty + (mult * inDiff[i]) 			
		end
		difficulty = difficulty * 10
		local tmp = display.newText( puzzleGroup, "SUCCESS!", curX, curY, editorFont, 16 )
		tmp.anchorX = 0
		curY = curY + 30
		tmp:setFillColor(0,1,0)
		local tmp = display.newText( puzzleGroup, string.format( "Difficulty: %1.2f of 10.00", difficulty), curX, curY, editorFont, 16 )
		tmp.anchorX = 0
		curY = curY + 30
		tmp:setFillColor(0,1,0)
		local tmp = display.newText( puzzleGroup, "All words found in puzzle!", curX, curY, editorFont, 16 )
		tmp.anchorX = 0
		tmp:setFillColor(0,1,0)
	end
end

getTile = function( col, row )
	for k,v in pairs( curPuzzle ) do
		if( v.col == col and v.row == row ) then
			return v
		end
	end
end

getWord = function( col1, row1, col2, row2 )
	local dCol = col2 - col1
	local dRow = row2 - row1
	local word = ""
	--
	if( dRow == 0 ) then
		word = getTile( col1, row1 ).letter
		if( dCol > 0 ) then
			col1 = col1 + 1
			while( col1 <= col2 ) do
				word = word .. getTile( col1, row1 ).letter
				col1 = col1 + 1
			end
		else
			col1 = col1 - 1
			while( col2 <= col1 ) do
				word = word .. getTile( col1, row1 ).letter
				col1 = col1 - 1
			end
		end
		return word
	elseif( dCol == 0 ) then
		word = getTile( col1, row1 ).letter
		if( dRow > 0 ) then
			row1 = row1 + 1
			while( row1 <= row2 ) do
				word = word .. getTile( col1, row1 ).letter
				row1 = row1 + 1
			end
		else
			row1 = row1 - 1
			while( row2 <= row1 ) do
				word = word .. getTile( col1, row1 ).letter
				row1 = row1 - 1
			end
		end
		return word
	elseif( math.abs(dCol) == math.abs(dRow) ) then
		word = getTile( col1, row1 ).letter
		if( dCol > 0 ) then			
			if( dRow > 0 ) then
				col1 = col1 + 1
				row1 = row1 + 1
				while( col2 >= col1 and row2 >= row1 ) do
					word = word .. getTile( col1, row1 ).letter
					col1 = col1 + 1
					row1 = row1 + 1
				end
			else
				col1 = col1 + 1
				row1 = row1 - 1
				while( col2 >= col1 and row2 <= row1 ) do
					word = word .. getTile( col1, row1 ).letter
					col1 = col1 + 1
					row1 = row1 - 1
				end
			end
		else
			if( dRow > 0 ) then
				col1 = col1 - 1
				row1 = row1 + 1
				while( col2 <= col1 and row2 >= row1 ) do
					word = word .. getTile( col1, row1 ).letter
					col1 = col1 - 1
					row1 = row1 + 1
				end
			else
				col1 = col1 - 1
				row1 = row1 - 1
				while( col2 <= col1 and row2 <= row1 ) do
					word = word .. getTile( col1, row1 ).letter
					col1 = col1 - 1
					row1 = row1 - 1
				end
			end
		end
		return word
	end	
end

checkList = function( word )
	local index 
	for i = 1, #curList do
		if( curList[i] == word ) then
			index = i
		elseif( curList[i] == string.reverse(word) ) then
			index = i 
			word = string.reverse(word)
		end
	end
	--
	if( index ) then
		table.remove(curList,index)
		return word, (#curList == 0)
	end
	return nil, false
end

return public



