
-- Tool used to generate this  puzzles:
-- http://puzzlemaker.discoveryeducation.com/WordSearchSetupForm.asp
local data = {}

data.puzzle =
[[
Y S V H A B W Z S Y 
J R E A A I Z Q E P 
J V R N N S J K B E 
T F A E E I O Y Y C 
L N M S B P L K L A 
A E E F Y W C L L N 
N E H E U O A W A V 
R M K N R D E R Y Y 
X O R O A D G G T T 
H Z Q N R A F E Y S
]]

data.list = 
[[
BANANA
FUDGE
HOKEY POKEY
PECAN
REESES
ROAD
ROCKY
STRAWBERRY
VANILLA
]]	

return data