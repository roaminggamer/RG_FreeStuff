-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- 
-- =============================================================
local utils = require "easy.utils"
-- =============================================================
local effects  = {}
local music  = {}
local playingEffects = {}
local playingMusic = {}

--
-- Module Begins
--
local public = {}

-- ==
-- 
-- ==
function public.addEffect( name, src )
	if(effects[name]) then return nil end
	effects[name] = audio.loadSound( src )
	return effects[name]
end

-- ==
-- 
-- ==
function public.addMusic( name, src )
	if(music[name]) then return nil end
	music[name] = audio.loadStream( src )
	return music[name]
end

-- ==
-- 
-- ==
function public.removeEffect( name )
	if( not effects[name] ) then return end

	-- stop all playing instances of sound first
	public.stopEffect( name )
	-- dispose of the sound and remove its record
	if( effects[name] ) then
		audio.dispose(effects[name])
		effects[name] = nil
	end
end

-- ==
-- 
-- ==
function public.removeMusic( name, src )
	if( not music[name] ) then return end

	-- stop all playing instances of sound first
	public.stopMusic( name )
	-- dispose of the sound and remove its record
	if( music[name] ) then
		audio.dispose(music[name])
		music[name] = nil
	end
end

-- ==
-- 
-- ==
function public.playEffect( name, options )
	if( not effects[name] ) then return end
	--
	options = options or {}
	local rec = {}
	playingEffects[rec] = rec 
	local function onComplete()
		playingEffects[rec] = nil
		if( options and options.onComplete )
			then options.onComplete()
		end
	end
	local loptions = {}
	for k,v in pairs(options) do
		loptions[k] = v
	end
	loptions.onComplete = onComplete
	rec.name = name
	rec.handle = audio.play( effects[name], loptions )
end


-- ==
-- 
-- ==
function public.playMusic( name, options )
	if( not music[name] ) then return end
	--
	options = options or {}
	--
	for k,v in pairs(playingMusic) do
		if( v.name == name ) then return end
	end
	--
	local rec = {}
	playingMusic[rec] = rec 
	local function onComplete()
		playingMusic[rec] = nil
		if( options and options.onComplete )
			then options.onComplete()
		end
	end
	local loptions = {}
	for k,v in pairs(options) do
		loptions[k] = v
	end
	loptions.onComplete = onComplete
	rec.name = name
	rec.handle = audio.play( music[name], loptions )
end

-- ==
-- 
-- ==
function public.stopEffect( name )
	if( not effects[name] ) then return end
	--
	for k,v in pairs(playingEffects) do
		if( v.name == name ) then
			audio.stop(v.handle)
		   playingEffects[k] = nil
		end
	end
end

-- ==
-- 
-- ==
function public.stopMusic( name )
	if( not music[name] ) then return end
	--
	for k,v in pairs(playingMusic) do
		if( v.name == name ) then
			audio.stop(v.handle)
		   playingMusic[k] = nil
		end
	end
end

return public