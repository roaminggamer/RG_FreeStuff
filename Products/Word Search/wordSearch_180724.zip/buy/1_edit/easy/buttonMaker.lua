-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local utils = require "easy.utils"

-- =============================================================
-- Locals
-- =============================================================
local presets = {}

local _WHITE_ = { 1, 1, 1, 1 }
local _BLACK_ = { 0, 0, 0, 1 }
local default = 
{ 
   selImg   			= "easy/fillW.png",
   selColor    		= { 0.5, 0.5, 0.5 },
   selLabelColor	= { 0.125, 0.125, 0.125 },
  
   unselImg  		= "easy/fillW.png",
   unselColor   	= { 0.25, 0.25, 0.25 },
   unselLabelColor	= { 1, 1, 1 },

   font       		= native.systemFontBold,
   fontSize   		= 32,
   labelOffset     = { 0, 0 },
}

--
-- Module Begins
--
local public = {}

local version = "180714"
function public.version() print("buttonMaker.lua", version);return version; end

-- ==
--    
-- ==
function public.getPreset( name )
	if( not presets[name] )	 then
		print( "Warning! buttonMaker.getPreset() - Preset not defined: ", name )		
		return default
	end
	local preset = utils.deepCopy(presets[name])
	return preset
end
function public.addPreset( name, definition )
	presets[name] = utils.deepCopy(definition)
end

-- ==
-- Base Button (builder) - Makes base button object.
-- ==
local function baseButton( params )
	local parent = params.parent or display.currentStage
	local preset = public.getPreset( params.preset or "default" )
	--	
	preset.unselColor = preset.unselColor or params.unselColor or _WHITE_
	preset.selColor = preset.selColor or params.selColor or _WHITE_
	preset.unselLabelColor = preset.unselLabelColor or params.unselLabelColor or _BLACK_
	preset.selLabelColor = preset.selLabelColor or params.selLabelColor or _BLACK_
	preset.labelOffset = params.labelOffset or preset.labelOffset or {0,0}
	preset.font = params.font or preset.font or native.systemFontBold
	preset.fontSize = params.fontSize or preset.fontSize or 32
	-- 
	local width  = params.width or preset.width or 200
	local height = params.height or preset.height or  60
	--
	local button = display.newGroup()
	button.x = params.x or 0
	button.y = params.y or 0
	parent:insert(button)	
	--
	button.sel = display.newRect( button, 0, 0, width, height )
	button.unsel = display.newRect( button, 0, 0, width, height )	
	--
	button.sel.isVisible = false
	button.isToggled = false
	--
	button.sel.fill = { type = "image", filename = preset.selImg }
	button.unsel.fill = { type = "image", filename = preset.unselImg }
	-- 
	button.sel:setFillColor(unpack(preset.selColor))
	button.unsel:setFillColor(unpack(preset.unselColor))
	--
	button.label = display.newText( button, params.labelText or "", 
		                           	preset.labelOffset[1], preset.labelOffset[2], 
		                              preset.font, preset.fontSize )
	button.label:setFillColor(unpack(preset.unselLabelColor))
	--
	function button._toggleVis( self, toggled )
		self.sel.isVisible = toggled
		self.unsel.isVisible = not toggled
		if( toggled ) then
			self.label:setFillColor(unpack(self._preset.selLabelColor))
		else
			self.label:setFillColor(unpack(self._preset.unselLabelColor))
		end
	end
	--
	button._preset = preset	

	return button
end

-- ==
-- easyPush() - Basic Push Button
-- ==
function public.easyPush( params )	
	params = params or {}
	local button = baseButton( params )

	button.touch = function( self, event )
		local phase = event.phase
		local id 	= event.id

		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self.isToggled = true
			self:_toggleVis( self.isToggled )

		elseif( self.isFocus ) then
			self.isToggled = utils.isInBounds( event, self )

			if( event.phase == "ended" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				--
				if( self.isToggled and params.listener ) then
					params.listener( self, event )
				end
				--
				self.isToggled = false
			end

			self:_toggleVis( self.isToggled )
		end
		return true
	end
	button:addEventListener( "touch" )

	return button
end

-- ==
-- easyToggle() - Basic Toggle Button
-- ==
function public.easyToggle( params )	
	params = params or {}
	local button = baseButton( params )

	button.toggle = function( self )
		self.isToggled = true
		self:_toggleVis( true )	
	end

	button.touch = function( self, event )
		local phase = event.phase
		local id 	= event.id

		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self.isHighlighted = true
			self:_toggleVis( self.isHighlighted )

		elseif( self.isFocus ) then
			self.isHighlighted = utils.isInBounds( event, self )

			if( event.phase == "ended" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				if( utils.isInBounds( event, self ) ) then
					self.isToggled = not self.isToggled
				end
				--
				if( utils.isInBounds( event, self ) and params.listener ) then
					params.listener( self, event )
				end
				--
				self:_toggleVis( self.isToggled )
			else
				self:_toggleVis( self.isHighlighted or self.isToggled )
				self:_toggleVis( self.isHighlighted or self.isToggled )
			end
		end
		return true
	end
	button:addEventListener( "touch" )

	return button
end

-- ==
-- easyRadio() - Basic Radio Button
-- ==
function public.easyRadio( params )	
	params = params or {}
	local button = baseButton( params )
	button._isRadioButton = true

	button.toggle = function( self )
		self.isToggled = true
		self:_toggleVis( true )
		for i = 1, self.parent.numChildren do
			local obj = self.parent[i]
			if(obj._isRadioButton and obj ~= self ) then
				obj.isToggled = false
				obj:_toggleVis( false )
			end
		end
	end

	button.touch = function( self, event )
		local phase = event.phase
		local id 	= event.id

		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self.isHighlighted = true
			self:_toggleVis( self.isHighlighted )

		elseif( self.isFocus ) then
			self.isHighlighted = utils.isInBounds( event, self )

			if( event.phase == "ended" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				self.isToggled = self.isToggled or self.isHighlighted
				--
				if( utils.isInBounds( event, self ) and self.isToggled ) then
					for i = 1, self.parent.numChildren do
						local obj = self.parent[i]
						if(obj._isRadioButton and obj ~= self ) then							
							obj.isToggled = false
							obj:_toggleVis( false)
						end
					end

					if( params.listener ) then
						params.listener( self, event )
					end
				end
				self:_toggleVis( self.isToggled )
			else
				self:_toggleVis( self.isHighlighted or self.isToggled )
			end
		end
		return true
	end
	button:addEventListener( "touch" )

	return button
end

return public