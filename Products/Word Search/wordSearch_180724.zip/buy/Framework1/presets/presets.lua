-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local buttonMaker = require "easy.buttonMaker"
-- =============================================================
local  utils = require "easy.utils"
--utils.generateButtonPresets( ) 
require "presets.presets_gen"


local params = 
{ 
   selImg   			= "easy/fillW.png",
   selColor    		= { 0.5, 0.5, 0.5 },
   selLabelColor	= { 0.125, 0.125, 0.125 },
  
   unselImg  		= "easy/fillW.png",
   unselColor   	= { 0.25, 0.25, 0.25 },
   unselLabelColor	= { 1, 1, 1 },

   font       		= native.systemFontBold,
   fontSize   		= 32,
   labelOffset     = { 0, 0 },
}
buttonMaker.addPreset( "default", params )

