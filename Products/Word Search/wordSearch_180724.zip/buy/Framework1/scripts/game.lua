-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- game.lua - Placeholder 'dummy' game to show basic usage of features.
-- =============================================================
local composer       = require( "composer" )
local common         = require "scripts.common"
local utils          = require "easy.utils"
local buttonMaker    = require "easy.buttonMaker"
local persist   		= require "easy.persist"
local soundMgr       = require "easy.soundMgr"
local persist        = require "easy.persist"
-- =============================================================
-- Locals
-- =============================================================
local curHealth = 100
local incrButton
local decrButton

-- =============================================================
-- Game Module Begins
-- =============================================================
local game = {}

function game.giveReward()
end


function game.create( group )

	curHealth = 100

	local healthLabel = display.newText( group, "", centerX, centerY - 160, _G.fontB, 44)

	local function updateHealth( value )
		curHealth = curHealth + value
		curHealth = (curHealth < 0 ) and 0 or curHealth
		curHealth = (curHealth > 100 ) and 100 or curHealth
		--
		if( curHealth == 0 ) then			
			incrButton.isVisible = false
			decrButton.isVisible = false
			healthLabel.text = "You Died!"
		else
			healthLabel.text = "Health: " .. curHealth			
		end
	end

	local function incrementHealth( self, event )
	   if( persist.get( "settings.json", "sound_enabled" ) ) then
	      soundMgr.playEffect( "click" )
	   end
		updateHealth( math.random(10,20) )
	end

	local function decrementHealth( self, event )
	   if( persist.get( "settings.json", "sound_enabled" ) ) then
	      soundMgr.playEffect( "click" )
	   end
		updateHealth( math.random(-20,-10) )
	end

	incrButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY, 
		labelText = "Increase Health", width = 400, height = 40, font = _G.fontN, listener = incrementHealth } )	

	decrButton = buttonMaker.easyPush( { parent = group, x = centerX, y = centerY + 60, 
		labelText = "Decrease Health", width = 400, height = 40, font = _G.fontN, listener = decrementHealth } )	

	updateHealth(0)

end

function game.destroy()
	incrButton = nil
	decrButton = nil
end


return game
