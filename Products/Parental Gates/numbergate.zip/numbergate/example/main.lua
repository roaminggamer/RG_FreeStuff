-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================

-- This kit come with four samples of the gate: ex1, ex2, ex3, ex4 
--
-- Try them all by changing the following varaible.
--
local exampleToRun = "ex4" 

-- 1. Require gate module.
local gate = require "gate"

-- 2. Define onSuccess() listener.
--
local function onSuccess()
	gate.easyAlert("Success", 
		"You succesfully filled in the sequence.\n" ..
		"This is where you wold do the 'gated' work." )
end

-- 3. (Optional) Define onCancel() listener to handle user 
--    quitting without answering question.
--
local function onCancel()
	gate.easyAlert("Cancelled", 
		"You quit the Child Gate Dialog without filling in the correct number sequence." )
end


-- 4. Create a gate to block progress.
--

if( exampleToRun == "ex1" ) then
	local myGate = gate.new( {
			imagesPath 	= "images/numbers_ex1",
			onSuccess 	=  onSuccess,
			onCancel 	= onCancel,
		} )

elseif( exampleToRun == "ex2" ) then
	local myGate = gate.new( {
			imagesPath 					= "images/numbers_ex2",
			onSuccess 					=  onSuccess,
			onCancel 					= onCancel,
			frameColor  				= { 123/255, 1, 191/255 },
			trayColor  					= { 0.2, 0.3, 0.5 },
			instructionsFontColor 	= { 1,1,1 },
			questionFontColor 		= { 1, 1, 0 },
			title							= "", -- No title!	
			instructions 				= "enter these numbers:",
			-- Adjust vertical layout
			verticalRatios 			=  
			{ 
				title 			= 0.0,
				numbers 			= 0.22,
				instructions 	= 0.40,
				question 		= 0.52,
				buttons 			= 0.68,
			},
		} )

elseif( exampleToRun == "ex3" ) then
	local myGate = gate.new( {
			imagesPath 	= "images/numbers_ex3",
			onSuccess 	=  onSuccess,
			onCancel 	= onCancel,
			title			= "Child Gate",
		} )

elseif( exampleToRun == "ex4" ) then
	local myGate = gate.new( {
			imagesPath 			= "images/numbers_ex4",
			onSuccess 			=  onSuccess,
			onCancel 			= onCancel,
			edgeOffset 			= 40,
			title					= "Kenney Gate",
			titleFont   		= "images/numbers_ex4/Kenney Bold.ttf",
			titleFontSize 		= 48,			
			verticalRatios 	= 
			{ 
				title 			= 0.12, -- Title
				numbers 			= 0.28, -- Numbers
				instructions 	= 0.45, -- Instructions
				question 		= 0.55, -- Question
				buttons 			= 0.71, -- Inputs
			},
			exitButtonOffsetX = 32,
			exitButtonOffsetY = 32,
			numberCount 		= 6,
			numberTween			= 24,
			questionFontSize 	= 40,
			buttonTween 		= 24,
			numberFontSize		= 36,
			numberOX 			= 6,
			numberOY 			= 2,
		} )


end