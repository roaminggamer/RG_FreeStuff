-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================
local function round(val) return math.floor(val+0.5); end
local w = display.contentWidth; local h = display.contentHeight
local centerX = display.contentCenterX;local centerY = display.contentCenterY
local fullw = display.actualContentWidth;local fullh = display.actualContentHeight
local unusedWidth = fullw - w;local unusedHeight = fullh - h
local left = round(0 - unusedWidth/2);local top = round(0 - unusedHeight/2)
local right  round(w + unusedWidth/2);local bottom = round(h + unusedHeight/2)
local topInset, leftInset, bottomInset, rightInset = display.getSafeAreaInsets()
-- =============================================================

-- =============================================================
-- Localizations
-- =============================================================
-- Commonly used Lua Functions
local getTimer          = system.getTimer
local mRand					= math.random
local mAbs					= math.abs
--
-- Common SSK Display Object Builders
local newCircle = display.newCircle;local newRect = display.newRect
local newImage = display.newImage; local newImageRect = display.newImageRect
local newText = display.newText; local newGroup = display.newGroup
--
-- Forward Declarations
local isInBounds, addSmartTouch, addSmartDrag, easyShake, easyAlert
local fnn, listen, ignore, ignoreList, autoIgnore, post, split
local secondsToTimer, hexcolor, quickButton, quickGateGroup

-- Number names
local numberNames = {}
numberNames[0] = "ZERO"
numberNames[1] = "ONE"
numberNames[2] = "TWO"
numberNames[3] = "THREE"
numberNames[4] = "FOUR"
numberNames[5] = "FIVE"
numberNames[6] = "SIX"
numberNames[7] = "SEVEN"
numberNames[8] = "EIGHT"
numberNames[9] = "NINE"


-- =============================================================
-- Module Definition
-- =============================================================
local gate = {}


-- Numbers Gate
gate.new = function( params )
	local imagesPath 			= params.imagesPath
	local trayColor 			= params.trayColor or { 1, 1, 1 }
	local frameColor 			= params.frameColor or { 1, 1, 1 }
	local edgeOffset 			= params.edgeOffset or 20	
	--
	local exitButtonOffsetX = params.exitButtonOffsetX or 60
	local exitButtonOffsetY = params.exitButtonOffsetY or 60
	--
	local numberCount 		= params.numberCount or 4
	local numberTween 		= params.numberTween or 40
	local numberOX				= params.numberOX or 0
	local numberOY				= params.numberOY or 0
	--
	local buttonTween 		= params.buttonTween or 30
	--
	local titleFont 			= params.titleFont or native.systemFontBold
	local titleFontColor 	= params.titleFontColor or { 0, 0, 0 }
	local titleFontSize 		= params.titleFontSize or 52
	--
	local numberFont 			= params.numberFont or titleFont
	local numberFontColor 	= params.numberFontColor or { 0, 0, 0 }
	local numberFontSize 	= params.numberFontSize or 100
	--
	local instructionsFont 			= params.instructionsFont or native.systemFont
	local instructionsFontColor 	= params.instructionsFontColor or { 0, 0, 0 }
	local instructionsFontSize 	= params.instructionsFontSize or 60
	--
	local questionFont 		= params.questionFont or native.systemFont
	local questionFontColor	= params.questionFontColor or { 0, 0, 0 }
	local questionFontSize 	= params.questionFontSize or 65
	--
	local shakeAmplitude		= params.shakeAmplitude or 10
	local shakeTime 			= params.shakeTime or 500
	-- 
	local completeDelay 		= params.completeDelay or 333
	--
	local onSuccess 			= params.onSuccess or function() end
	local onCancel 			= params.onCancel or function() end
	--
	local title 				= params.title or "PARENTAL GATE"
	local instructions		= params.instructions or "to continue tap:"
	--
	local verticalRatios 	= params.verticalRatios or { 
		title 			= 0.08, -- Title
		numbers 			= 0.28, -- Numbers
		instructions 	= 0.45, -- Instructions
		question 		= 0.55, -- Question
		buttons 			= 0.71, -- Inputs
	}
	--
	numberNames 				= params.numberNames or numberNames

	--
	--
	--
	local gateGroup = quickGateGroup()
	gateGroup.x = centerX
	gateGroup.y = centerY
	gateGroup.isValid = true
	gateGroup.isActive = true
	--
	-- Question Tray
	local trayGroup = newGroup()
	gateGroup:insert(trayGroup)
	local tray = newImage( trayGroup, imagesPath .. "/tray.png" )
	tray.top = tray.y - tray.height/2
	if( trayColor ) then
		tray:setFillColor(unpack( trayColor ))
	end
	--
	-- Exit Button
	local function onExit(doCancel)		
		display.remove(gateGroup)
		if(doCancel == nil) then
			onCancel()
		end
	end
	local button = quickButton( trayGroup, imagesPath .. "/exit", function() onExit() end )
	button.x = -tray.width/2 + button.width/2 + exitButtonOffsetX
	button.y = -tray.height/2 + button.height/2 + exitButtonOffsetY
	--
	-- Title
	local titleLabel = newText( trayGroup, title, 0, tray.top + verticalRatios.title * tray.height, titleFont, titleFontSize )
	titleLabel:setFillColor( unpack(titleFontColor) )
	--
	-- Number Frames
	local frames = {}
	local firstFrame = newImage( trayGroup, imagesPath .. "/frame.png" )
	firstFrame:setFillColor( unpack(frameColor) )
	local fw = firstFrame.width
	local fh = firstFrame.height
	local fy = tray.top + tray.height * verticalRatios.numbers
	--
	local curX = -((numberCount * fw) + ((numberCount-1) * numberTween))/2 + fw/2
	firstFrame.x = curX
	firstFrame.y = fy
	frames[1] = firstFrame	
	for i = 2, numberCount do
		curX = curX + fw + numberTween
		local frame = newImage( trayGroup, imagesPath .. "/frame.png" )
		frame:setFillColor( unpack(frameColor) )
		frame.x = curX
		frame.y = fy
		frames[i] = frame
	end
	--
	-- Numbers 
	local numbers = {}
	for i = 1, #frames do
		local number = newText( trayGroup, 0, frames[i].x + numberOX, frames[i].y + numberOY, numberFont, numberFontSize )
		number:setFillColor(unpack( numberFontColor ) )
		numbers[i] = number
		number.isVisible = false
	end
	--
	-- Random numbers
	local curNumbers = {}
	for i = 1, #frames do
		curNumbers[i] = mRand(0,9)
	end
	--
	-- Instructions Message 
	local tmp = newText( trayGroup, instructions, 0, tray.top + tray.height * verticalRatios.instructions, instructionsFont, instructionsFontSize )
	tmp:setFillColor( unpack(instructionsFontColor) )
	--
	-- Question Message 
	local msg
	for i = 1, #frames do
		if( msg ) then 
			msg = msg .. ", " 
		else 
			msg = ""
		end
		msg = msg .. numberNames[curNumbers[i] ]		
	end
	local tmp = newText( trayGroup, msg, 0, tray.top + tray.height * verticalRatios.question, questionFont, questionFontSize )
	tmp:setFillColor( unpack(questionFontColor) )

	--
	-- Buttons
	local curNum = 1
	local function onButton( self )
		if( not gateGroup.isActive ) then return end
		local num = self.num
		if( num == 99 ) then
			curNum = curNum - 1
			if( curNum < 1 ) then curNum = 1 end
			numbers[curNum].text = "0"
			numbers[curNum].isVisible = false			

		elseif( curNum <= #numbers ) then
			numbers[curNum].text = num
			numbers[curNum].isVisible = true
			curNum = curNum + 1
			if( curNum > #numbers ) then
				local matches = true
				for i = 1, #numbers do
					local numA = tonumber(numbers[i].text)
					local numB = tonumber(curNumbers[i])
					--print( i, numA, numB, matches )
					matches = matches and (numA == numB)
				end
				if( matches ) then 
					gateGroup.isActive = false
					timer.performWithDelay( completeDelay, 						
						function() 
							onSuccess()
							onExit(false)
						end )
				else 
					easyShake( trayGroup, shakeAmplitude, shakeTime )
					timer.performWithDelay( 25,
						function()
							curNum = curNum - 1
							numbers[curNum].text = "0"
							numbers[curNum].isVisible = false
						end )
				end				
			end
		end
	end
	--	
	local firstButton = quickButton( trayGroup, imagesPath .. "/1", onButton )
	firstButton.num = 1
	local bw = firstButton.width
	local bh = firstButton.height
	local by = tray.top + tray.height * verticalRatios.buttons
	--
	local startX = -((6 * bw) + (5 * buttonTween))/2 + bw/2
	local curX = startX
	firstButton.x = curX
	firstButton.y = by
	--
	for i = 2, 6 do
		curX = curX + bw + buttonTween
		local button = quickButton( trayGroup, imagesPath .. "/" .. i, onButton )
		button.num = i
		button.x = curX
		button.y = by
	end
	--
	by = by + bw + buttonTween
	curX = startX - bw - buttonTween
	--
	for i = 7, 9 do
		curX = curX + bw + buttonTween
		local button = quickButton( trayGroup, imagesPath .. "/" .. i, onButton )
		button.num = i
		button.x = curX
		button.y = by
	end
	--
	curX = curX + bw + buttonTween
	local button = quickButton( trayGroup, imagesPath .. "/0", onButton )
	button.num = 0
	button.x = curX
	button.y = by
	--
	curX = curX + (bw + buttonTween) * 1.5
	local button = quickButton( trayGroup, imagesPath .. "/back", onButton )
	button.num = 99
	button.x = curX
	button.y = by

	--[[
	local EFM 	= params.EFM
	local EFM 	= params.EFM
	local EFM 	= params.EFM
	local EFM 	= params.EFM
	local EFM 	= params.EFM
	local EFM 	= params.EFM
	--]]

	--
	-- Scale tray
	local scaleW = (fullw-edgeOffset)/tray.width
	local scaleH = (fullh-edgeOffset)/tray.height
	if( scaleW < scaleH ) then
		trayGroup:scale( scaleW, scaleW )
	else
		trayGroup:scale( scaleH, scaleH )
	end

	return gateGroup
end


-- =============================================================
-- Local Function Definitions
-- =============================================================
isInBounds = function( obj, obj2 )
	if(not obj2) then return false end
	local bounds = obj2.contentBounds
	if( obj.x > bounds.xMax ) then return false end
	if( obj.x < bounds.xMin ) then return false end
	if( obj.y > bounds.yMax ) then return false end
	if( obj.y < bounds.yMin ) then return false end
	return true
end

addSmartTouch = function( obj, params )
	params = params or {}
	obj.touch = function( self, event )
		local phase = event.phase
		local id 	= event.id
		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			if( params.toFront ) then self:toFront() end
			if( params.listener ) then
				return params.listener( self, event ) or fnn(params.retval,false)
			end			
		elseif( self.isFocus ) then
			event.inBounds = isInBounds( event, self )
			if( phase == "ended" or phase == "cancelled" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
			end
			if( params.listener ) then
				return params.listener( self, event ) or fnn(params.retval,false)
			end
		end
		if( params.listener ) then
			return params.listener( self, event ) or fnn(params.retval,false)
		else
			return fnn(params.retval,false)
		end		
	end; obj:addEventListener("touch")
end

addSmartDrag = function( obj, params )
	params = params or {}
	obj.touch = function( self, event )
		local phase = event.phase
		local id 	= event.id
		if( phase == "began" ) then
			self.isFocus = true
			display.currentStage:setFocus( self, id )
			self.x0 = self.x
			self.y0 = self.y
			if( params.toFront ) then self:toFront() end
			if( self.onDragged ) then
				self:onDragged( { obj = self, phase = event.phase, x = event.x, y = event.y,  dx = 0, dy = 0, time = getTimer(), target = self } )
			end
			post("onDragged", { obj = self, phase = event.phase, x = event.x, y = event.y, dx = 0, dy = 0, time = getTimer(), target = self } )
			if( params.listener ) then
				return params.listener( self, event ) or fnn(params.retval,false)
			end						
		elseif( self.isFocus ) then
			local dx = event.x - event.xStart
			local dy = event.y - event.yStart
			self.x = self.x0 + dx
			self.y = self.y0 + dy

			event.dx = dx
			event.dy = dy

			if( phase == "ended" or phase == "cancelled" ) then
				self.isFocus = false
				display.currentStage:setFocus( self, nil )
				if( self.onDragged ) then
					self:onDragged( { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
				end
				if( self.onDropped ) then
					self:onDropped( { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
				end
				post("onDragged", { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
				post("onDropped", { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
			else
				if( self.onDragged ) then
					self:onDragged( { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
				end
				post("onDragged", { obj = self, phase = event.phase, x = event.x, y = event.y, dx = dx, dy = dy, time = getTimer(), target = self } )
			end
			if( params.listener ) then
				return params.listener( self, event ) or fnn(params.retval,false)
			end
		end
		if( params.listener ) then
			return params.listener( self, event ) or fnn(params.retval,false)
		else
			return fnn(params.retval,false)
		end		
	end; obj:addEventListener("touch")
end
easyShake = function( obj, amplitude, time, delay )
	obj = obj or display.currentStage
	amplitude = amplitude or 100
	time = time or 1000
	local shakeEasing = function(currentTime, duration, startValue, targetDelta)
		local shakeAmplitude = amplitude -- maximum shake in pixels, at start of shake
		local timeFactor = (duration-currentTime)/duration -- goes from 1 to 0 during the transition
		local scaledShake =( timeFactor*shakeAmplitude)+1 -- adding 1 prevents scaledShake from being less then 1 which would throw an error in the random code in the next line
		local randomShake = math.random(scaledShake)
		return startValue + randomShake - scaledShake*0.5 -- the last part detracts half the possible max shake value so the shake is "symmetrical" instead of always being added at the same side
	end -- shakeEasing
	if( not obj._shakeX0 ) then
		obj._shakeX0 = obj.x
		obj._shakeY0 = obj.y
	end
	local function onComplete(self)
		if( obj.removeSelf == nil ) then return end
		obj.x = obj._shakeX0
		obj.y = obj._shakeY0
	end
	transition.to(obj , {time = time, x = obj.x, y = obj.y, delay = delay, transition = shakeEasing, onComplete = onComplete } ) -- use the displayObjects current x and y as parameter
end
easyAlert = function( title, msg, buttons )
	buttons = buttons or { {"OK"} }
	local function onComplete( event )
		local action = event.action
		local index = event.index
		if( action == "clicked" ) then
			local func = buttons[index][2]
			if( func ) then func() end 
	    end
	    --native.cancelAlert()
	end

	local names = {}
	for i = 1, #buttons do
		names[i] = buttons[i][1]
	end
	--print( title, msg, names, onComplete )
	local alert = native.showAlert( title, msg, names, onComplete )
	return alert
end
fnn = function( ... ) 
   for i = 1, #arg do
      local theArg = arg[i]
      if(theArg ~= nil) then return theArg end
   end
   return nil
end
-- =============================================================
-- Shorthand for Runtime:addEventListener( name, listener )
-- =============================================================
listen = function( name, listener ) 
   Runtime:addEventListener( name, listener ) 
end

-- =============================================================
-- Shorthand for Runtime:removeEventListener( name, listener )
-- =============================================================
ignore = function( name, listener ) 
   Runtime:removeEventListener( name, listener ) 
end

-- =============================================================
-- Safe Runtime listener remover similar to 'ignore' (above), but
-- takes list (table of strings) for each listener name to remove.
-- =============================================================
ignoreList = function( list, obj )
   if( not obj ) then return end
   for i = 1, #list do
      local name = list[i]
      if(obj[name]) then 
         ignore( name, obj ) 
         obj[name] = nil
      end
  end
end

-- =============================================================
-- Checks if obj is still valid and if not, removes named listener
-- Returns 'true' if object was invalid and listener was removed.
-- =============================================================
autoIgnore = function( name, obj ) 
   if( not util.isValid( obj ) ) then
      ignore( name, obj )
      obj[name] = nil
      return true
   end
   return false 
end

-- =============================================================
-- Shorthand helper that does job of Runtime:dispatchEvent( event )
-- =============================================================
post = function( name, params )
   params = params or {}
   local event = {}
   for k,v in pairs( params ) do event[k] = v end
   event.name = name
   if( not event.time ) then event.time = system.getTimer() end
   Runtime:dispatchEvent( event )
end

-- =============================================================
-- Splits a string on specified token and returns table of values.
-- =============================================================
split = function(str,tok)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local ftok = "(.-)" .. tok
   local last_end = 1
   local s, e, cap = str:find(ftok, 1)
   while s do
      if s ~= 1 or cap ~= "" then
         table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(ftok, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

secondsToTimer = function( seconds, version )	
	local seconds = seconds or 0
	version = version or 1

	if(version == 1) then
		seconds = tonumber(seconds)
		local minutes = math.floor(seconds/60)
		local remainingSeconds = seconds - (minutes * 60)

		local timerVal = "" 

		if(remainingSeconds < 10) then
			timerVal =	minutes .. ":" .. "0" .. remainingSeconds
		else
			timerVal = minutes .. ":"	.. remainingSeconds
		end

		return timerVal
	elseif( version == 2 ) then
		seconds = tonumber(seconds)
		local nHours = string.format("%02.f", mFloor(seconds/3600));
		local nMins = string.format("%02.f", mFloor(seconds/60 - (nHours*60)));
		local nSecs = string.format("%02.f", mFloor(seconds - nHours*3600 - nMins *60));
		return nHours..":"..nMins.."."..nSecs

	elseif( version == 3 ) then
		local nDays = 0
		seconds = tonumber(seconds)
		local nHours = string.format("%02.f", mFloor(seconds/3600));
		local nMins = string.format("%02.f", mFloor(seconds/60 - (nHours*60)));
		local nSecs = string.format("%02.f", mFloor(seconds - nHours*3600 - nMins *60));

		nHours = tonumber(nHours)
		nMins = tonumber(nMins)
		
		while (nHours >= 24) do
			nDays = nDays + 1
			nHours = nHours - 24
		end

		return nDays,nHours,nMins,nSecs 
	end
end
--
hexcolor = function( code )
   code = code or "FFFFFFFF"
   code = string.gsub( code , " ", "")
   code = string.gsub( code , "0x", "")
   code = string.gsub( code , "#", "")
   local colors = {1,1,1,1}
   while code:len() < 8 do
      code = code .. "F"
   end
   local r = tonumber( "0X" .. strSub( code, 1, 2 ) )
   local g = tonumber( "0X" .. strSub( code, 3, 4 ) )
   local b = tonumber( "0X" .. strSub( code, 5, 6 ) )
   local a = tonumber( "0X" .. strSub( code, 7, 8 ) )
   local colors = { r/255, g/255, b/255, a/255  }
   return colors
end; gate.hexcolor = hexcolor 
--
quickButton = function( group, imgBasePath, cb )
	local button = newImage( group, imgBasePath .. "_unsel.png" )
	function button.touch( self, event )
		local id = event.id
		local phase = event.phase
		if( phase == "began" ) then
			self.isFocus = true
			display.getCurrentStage():setFocus( self, id )
			self.fill= { type = "image", filename = imgBasePath .. "_sel.png" }
		elseif( self.isFocus ) then
			if( isInBounds( event, self ) ) then
				self.fill = { type = "image", filename = imgBasePath .. "_sel.png" }
			else
				self.fill = { type = "image", filename = imgBasePath .. "_unsel.png" }
			end
			if( phase == "ended" ) then
				self.isFocus = false
				display.getCurrentStage():setFocus( self, nil )
				self.fill = { type = "image", filename = imgBasePath .. "_unsel.png" }
				if( isInBounds( event, self ) ) then
					if(cb) then cb(self) end 
				end
			end
		end
		return true
	end; button:addEventListener( "touch" )
  	return button
end
--
quickGateGroup = function()
	local gateGroup = newGroup()	
	gateGroup.x = centerX
	gateGroup.y = centerY
	gateGroup.isValid = true
	--
	gateGroup.enterFrame =
		function() 
			if(gateGroup.isValid) then
				gateGroup:toFront()
			end
		end
	Runtime:addEventListener( "enterFrame", gateGroup )
	-- 
	function gateGroup.finalize( self )
		self.isValid = false
		Runtime:removeEventListener( "enterFrame", gateGroup )
	end;gateGroup:addEventListener( "finalize" )
	--
	local blocker = newRect( gateGroup, 0, 0, fullw, fullh )
	blocker.isHitTestable = true
	blocker.alpha = 0
	blocker.touch = function() return true end
	blocker:addEventListener("touch")
	gateGroup.blocker = blocker
	return gateGroup
end
--
-- 
gate.easyAlert = easyAlert


return gate