-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
-- =============================================================
-- If you have purchased this template, you may use it to make:
-- 1 PAID or FREE APPLICATION.
-- =============================================================
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
_G.fontN 	= "fonts/AmaticSC-Regular.ttf" 
_G.fontB 	= "fonts/AmaticSC-Bold.ttf" 
_G.gameFont = _G.fontB
-- =============================================================
require "ssk2.loadSSK"
_G.ssk.init( { launchArgs = ...,  gameFont = fontN } )
--
require "scripts.common"
--
-- Run game app
----[[
local composer = require "composer"
composer.gotoScene( "scenes.splash" )
--composer.gotoScene( "scenes.home" )
--composer.gotoScene( "scenes.play", { params = { quiz = 'add' } } )
--]]

-- OR -- 

-- Test game directly
--[[
local group = display.newGroup()
local game = require "scripts.game"
game.create( group, 2 )
--game.next()
--]]