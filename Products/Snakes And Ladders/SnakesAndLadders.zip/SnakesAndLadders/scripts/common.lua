-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local common = {}

--
-- Used on Splash Screen
--
common.waitTime 				= 5000
common.splashTitle 			= "Snakes & Ladders"
common.splashTitleFont 		= _G.fontB -- from main.lua
common.splashTitleSize 		= 68
common.splashTitleFill  	= _O_

common.splashBy 				= "by the 'Roaming Gamer'"
common.splashByFont 			= _G.fontN -- from main.lua
common.splashBySize 			= 32
common.splashByFill  		= _K_

--
-- Used on Menu Screen
--
common.menuTitle 				= "Snakes & Ladders"
common.menuTitleFont 		= _G.fontB -- from main.lua
common.menuTitleSize 		= 68
common.menuTitleFill  		= _O_

common.menuMessage 			= "Choose Number Of Players"
common.menuMessageFont 		= _G.fontN -- from main.lua
common.menuMessageSize 		= 52
common.menuMessageFill  	= _K_

--
-- Used on Play Screen
--
common.gameScoreFont 		= _G.fontB -- from main.lua
common.gameScoreSize 		= 44
common.gameScoreFill  		= { 1, 1, 1 }

common.cellStep 				= 64
common.cellSize 				= 62
common.cellFill 				= { 1, 1, 1 }
common.cellStroke 			= { 0.25, 0.25, 0.25 }
common.cellStrokeWidth 		= 1

common.cellTextFont			= _G.fontB
common.cellTextFontSize		= 44
common.cellTextFill 			= { 0.25, 0.25, 0.25 }

common.cellStartFill 			= _GREY_
common.cellStartTextFont		= _G.fontB
common.cellStartTextFontSize	= 34
common.cellStartTextFill 		= { 1,1,1 }

common.cellEndFill 				= _DARKERGREY_
common.cellEndTextFont			= _G.fontB
common.cellEndTextFontSize		= 32
common.cellEndTextFill 			= { 1,1,1 }

common.ladderWidth 				= common.cellStep/2
common.snakeWidth 				= common.cellStep/2

common.playerSize 				= 48
common.playerSpeed 				= 300
common.playerMoveTime 			= 1000 * common.cellStep/common.playerSpeed

common.dieSize						= 80
common.playerIconSize			= 60

common.instructionsTextFont		= _G.fontB
common.instructionsTextFontSize	= 54
common.instructionsTextFill 		= _K_

common.rollFacesPer					= 10
common.rollTimePerFace				= 100

return common