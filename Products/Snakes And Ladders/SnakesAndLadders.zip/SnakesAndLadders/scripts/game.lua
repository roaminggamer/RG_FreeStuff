-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
local composer       = require( "composer" )
local common         = require "scripts.common"

-- =============================================================
-- Localizations
-- =============================================================
local getInfo = system.getInfo; local getTimer = system.getTimer
local mRand = math.random
local newCircle = ssk.display.newCircle;local newRect = ssk.display.newRect
local newImageRect = ssk.display.newImageRect;local newSprite = ssk.display.newSprite
local quickLayers = ssk.display.quickLayers;local newText = display.newText
local easyIFC = ssk.easyIFC;local persist = ssk.persist
local isValid = display.isValid;local isInBounds = ssk.easyIFC.isInBounds
local normRot = ssk.misc.normRot;local easyAlert = ssk.misc.easyAlert
--
-- SSK 2D Math Library
local addVec = ssk.math2d.add;local subVec = ssk.math2d.sub;local diffVec = ssk.math2d.diff
local lenVec = ssk.math2d.length;local len2Vec = ssk.math2d.length2;
local normVec = ssk.math2d.normalize;local vector2Angle = ssk.math2d.vector2Angle
local angle2Vector = ssk.math2d.angle2Vector;local scaleVec = ssk.math2d.scale
-- =============================================================
-- =============================================================
-- =============================================================

----------------------------------------------------------------------
-- Forward Declarations
----------------------------------------------------------------------
local addLadder
local addSnake
local selectNextPlayer
local showCurrentPlayerPiece
local movePlayer
local onTouchBack

----------------------------------------------------------------------
-- Locals
----------------------------------------------------------------------
local gameIsRunning 		= false
local playerIsMoving	 	= false
local gameIsOver 			= false
local numPlayers 			= 1
local currentPlayer 		= 1
--
local content 
local cells = {}
local players = {}
local theDie
local theInstructions
local playerIcon
local goHome

----------------------------------------------------------------------
-- Module Begins
----------------------------------------------------------------------
local game = {}

--
-- create( group, playerCount ) - Create and start a game with playerCount == 1 .. 4
--
function game.create( group, playerCount, onHome ) 	
	-- Store group we were passed as 'content' so it can be used in all module functions.
	-- Default to 'currentStage' if group == nil
	--
	content = group or display.currentStage

	-- Track current number of players
	numPlayers = playerCount

	--  Track (optional) function passed by play scene 
	goHome = onHome

	-- Draw Background
	local back = newImageRect( content, centerX, centerY, "images/kenney/back.png", { w = 720, h = 1386 } )
	
	-- Draw Board Grid (10 x 10)
	local cellStep = common.cellStep
	local startX 	= centerX - 5 * cellStep + cellStep/2
	local startY   = centerY + 5 * cellStep - cellStep/2
	local curX 		= startX
	local curY 		= startY - 50
	local dir = 1
	--
	local function drawCell()
		local cell = {}
		--
		cells[#cells+1] = cell
		--
		cell.num = #cells
		cell.x = curX
		cell.y = curY
		--
		cell.back = newRect( content, curX, curY, 
			                 	{ size = common.cellSize, fill = common.cellFill,
			                 	  strokeWidth = common.cellStrokeWidth, 
			                 	  stroke = common.cellStroke, alpha = 1 } )
		--
		cell.back.myCell = cell
		--
		if( cell.num ~= 1 and cell.num ~= 100 ) then
			cell.label = display.newText( content, cell.num, curX, curY, common.cellTextFont, common.cellTextFontSize )
			cell.label:setFillColor( unpack(common.cellTextFill) )
		end
	end
	--
	for i = 1, 10 do
		if (dir == 1) then
			for j = 1, 10 do
				drawCell()
				--
				curX = curX + cellStep
			end
			curX = curX - cellStep
			dir = -1
		else
			for j = 10, 1, -1 do
				drawCell()
				--
				curX = curX - cellStep
			end
			curX = startX
			dir = 1
		end
		curY = curY - cellStep
	end

	-- Modify Start and End cells
	local cell = cells[1]
	cell.back:setFillColor(unpack(common.cellStartFill))
	cell.label = display.newText( content, "START", cell.back.x, cell.back.y, 
		                           common.cellStartTextFont, common.cellStartTextFontSize )
	cell.label:setFillColor( unpack(common.cellStartTextFill) )

	local cell = cells[100]
	cell.back:setFillColor(unpack(common.cellEndFill))
	cell.label = display.newText( content, "FINISH", cell.back.x, cell.back.y, 
		                           common.cellEndTextFont, common.cellEndTextFontSize )
	cell.label:setFillColor( unpack(common.cellEndTextFill) )

	-- Add Ladders and Snakes	
	addLadder( 6, 27 )
	addLadder( 9, 50 )
	addLadder( 25, 59 )
	addLadder( 20, 39 )
	addLadder( 61, 82 )
	addLadder( 54, 85 )
	addLadder( 53, 72 )
	addSnake( 43, 16 )
	addSnake( 55, 34 )
	addSnake( 70, 48 )
	addSnake( 78, 42 )
	addSnake( 95, 73 )
	addSnake( 96, 82 )
	addSnake( 99, 65 )

	-- Draw Player(s)
	for i = numPlayers, 1, -1 do
		local player = newImageRect( content, cells[1].x, cells[1].y, "images/kenney/p" .. i .. ".png", { size = common.playerSize } )
		players[i] = player
		player.curCell = 1
	end

	-- Draw Instructions
	theInstructions = display.newText( content, "Tap To Roll", centerX, startY + 28, 
		                           common.instructionsTextFont, common.instructionsTextFontSize )
	theInstructions:setFillColor( unpack(common.instructionsTextFill) )

	-- Draw the Die and Player Icon
	theDie = newImageRect( content, centerX - 10, startY + 120, "images/kenney/dice/white0.png", { size = common.dieSize, anchorX = 1 })
	playerIcon = newImageRect( content, centerX + 10, startY + 120, "images/kenney/p1.png", { size = common.playerIconSize, anchorX = 0 })

	-- Attach touch listener to back and activate it
	back.touch = onTouchBack
	back:addEventListener("touch")

	-- Game is now running
	gameIsRunning = true
end


--
-- game.over() - Game is over.  Show who won.
--
function game.over( winner )
	winner = winner or 1
	-- Do not allow answer touches
	gameIsRunning 	= false
	playerIsMoving	= false
	gameIsOver 		= true
	--
	theDie.isVisible = false
	playerIcon.isVisible = false
	--
	theInstructions.isVisible = true
	theInstructions.text = "Player #" .. tostring(winner) .. " Wins The Game!\n" ..
	                       "Tap To Return To Menu "
	theInstructions.y = theInstructions.y + 50	                       
end

--
-- game.destroy() - Destroy all game content and clean up.
--
function game.destroy() 
	display.remove( content )
	content = nil	
	--
	gameIsRunning 		= false
	playerIsMoving	 	= false
	gameIsOver 			= false
	numPlayers 			= 1
	currentPlayer 		= 1
	--	 
	cells = {}
	players = {}
	theDie = nil
	theInstructions = nil
	playerIcon = nil
	goHome = nil
end

-- =============================================================
-- Local Function Definitions
-- =============================================================

-- ==
--    addLadder() - Add a ladder from a low cell to a high cell.
--    Tip: Cascading snakes and/or ladders are not supported.
-- ==
addLadder = function( from, to )
	local fromCell = cells[from]
	local toCell = cells[to]
	local vec = diffVec( fromCell, toCell )
	local angle = vector2Angle( vec )
	local ladderLen = lenVec( vec )
	--
	local ladder = newImageRect( content, fromCell.x, fromCell.y, "images/ladder_medium.png",
											{ w = common.ladderWidth, h = ladderLen, rotation = angle,
											  anchorY = 1 } )
	--
	ladder.toCell = toCell
	--
	fromCell.ladder = ladder
	--
	return ladder
end

-- ==
--    addSnake() -- Add a snake connected from a high cell to a low cell.
--    Tip: Cascading snakes and/or ladders are not supported.
-- ==
addSnake = function( from, to ) 
	local fromCell = cells[from]
	local toCell = cells[to]
	local vec = diffVec( fromCell, toCell )
	local angle = vector2Angle( vec )
	local snakeLen = lenVec( vec )
	--
	local snake = newImageRect( content, fromCell.x, fromCell.y, "images/snake_medium.png",
											{ w = common.snakeWidth, h = snakeLen, rotation = angle,
											  anchorY = 0, yScale = -1 } )
	--
	snake.toCell = toCell
	--
	fromCell.snake = snake
	--
	return snake
end

-- ==
--		selectNextPlayer() - Prepare turn for next player.
-- ==
selectNextPlayer = function()
	currentPlayer = currentPlayer + 1
	if( currentPlayer > numPlayers ) then
		currentPlayer = 1
	end
	--
	theInstructions.isVisible = true
	--
	playerIsMoving = false
end

-- ==
--		showCurrentPlayerPiece() - Change player icon to reflect current player turn.
-- ==
showCurrentPlayerPiece = function()
	local player = players[currentPlayer]
	player:toFront()
	playerIcon.fill = { type = "image", filename = "images/kenney/p" .. currentPlayer .. ".png" }			
	return player
end

-- ==
--    movePlayer() - Self-contained player mover using sequential transitions to handle all movement.
-- ==
movePlayer = function( moveBy )
	moveBy = moveBy
	local player = showCurrentPlayerPiece()
	local toCell = player.curCell + moveBy
	--
	if( toCell > 100 ) then 
		toCell = 100 
	end

	-- 
	player.onComplete = function( self )
		if( not gameIsRunning ) then return end
		--
		if( self.curCell ~= toCell ) then
			--print( "onComplete - move ", self.curCell, toCell )
			self.curCell = self.curCell + 1
			--
			local cell = cells[self.curCell]
			--
			transition.to( self, { x = cell.x, y = cell.y, onComplete = self, time = common.playerMoveTime } )

		else
			--print( "onComplete - done ", self.curCell, toCell )
			self.onComplete = nil
			--
			local cell = cells[self.curCell]
			local ladder = cell.ladder
			local snake = cell.snake
			--
			if( toCell == 100 ) then
				game.over(currentPlayer)
			elseif( ladder ) then
				self.onComplete = function( self )
					if( not gameIsRunning ) then return end
					--
					self.onComplete = nil
					self.curCell = ladder.toCell.num
					selectNextPlayer()
					showCurrentPlayerPiece()
				end
				--
				local time = 1000 * ladder.height/common.playerSpeed
				--
				transition.to(self, { x = ladder.toCell.x, y = ladder.toCell.y, time = time, onComplete = self  })
			
			elseif( snake ) then
				self.onComplete = function( self )
					self.onComplete = nil
					self.curCell = snake.toCell.num
					selectNextPlayer()
					showCurrentPlayerPiece()
				end
				--
				local time = 1000 * snake.height/common.playerSpeed
				--
				transition.to(self, { x = snake.toCell.x, y = snake.toCell.y, time = time, onComplete = self  })
			
			else
				selectNextPlayer()
				showCurrentPlayerPiece()
			end
		end
	end
	player:onComplete()
end

-- ==
--
-- ==
onTouchBack = function( self, event )
	if( gameIsRunning == false ) then return true end
	if( playerIsMoving == true ) then return true end
	if( event.phase ~= "ended" ) then return true end
	if( gameIsOver ) then
		gameIsOver = false
		if( goHome ) then
			goHome()
		end
		return
	end
	--
	theInstructions.isVisible = false
	--
	playerIsMoving = true
	--
	local count = 0
	local function rollDie()
		if( not gameIsRunning ) then return end
		--
		face = mRand( 1, 6 )
		theDie.fill = { type = "image", filename = "images/kenney/dice/white" .. face .. ".png" }
		-- 
		count = count + 1
		if( count < common.rollFacesPer ) then
			timer.performWithDelay( common.rollTimePerFace, rollDie  )
		else
			movePlayer(face)
		end
	end
	rollDie()
end

return game