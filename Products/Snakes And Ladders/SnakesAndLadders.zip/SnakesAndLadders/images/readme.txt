https://openclipart.org/detail/179405/snake
https://openclipart.org/detail/18440/ladder-flat