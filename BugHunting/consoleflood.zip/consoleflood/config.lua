-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2015 
-- =============================================================
-- This content produced for Corona Geek Hangouts audience.
-- You may use any and all contents in this example to make a game or app.
-- =============================================================

application = {
	content = {
		width = 640,
		height = 960,
		scale = "letterbox",
		fps = 60
		--fps = 30
	},
}

