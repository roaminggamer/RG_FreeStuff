system.openURL( "https://www.youtube.com/watch?v=SEQPPeP0vsQ" ) 
--[[
Results:
2015.2634 - Windows 7   ==> FAIL (All lower case: https://www.youtube.com/watch?v=seqppep0vsq  )
2015.2625 - OS X 10.107 ==> SUCCESS
2015.2625 - iOS 8.2     ==> SUCCESS
2015.2634 - Android 4.4 ==> SUCCESS

--]]