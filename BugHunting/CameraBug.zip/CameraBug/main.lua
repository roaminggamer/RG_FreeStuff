local doSave = true

local sessionComplete = function(event)	
	local image = event.target

	print( "Camera ", ( image and "returned an image" ) or "session was cancelled" )
	print( "event name: " .. event.name )
	print( "target: " .. tostring( image ) )

	if ( image ) then	 
		local group = display.newGroup()
		group:insert( image )
		image.xScale = 0.1
		image.yScale = 0.1
		group.x = 160
		group.y = 120


		if( doSave ) then
			display.save( group, { filename="thePicture.png", 
				                   baseDir = system.DocumentsDirectory, 
				                   isFullResolution = true, 
				                   backgroundColor = { 0, 0, 0, 1 } } )

			timer.performWithDelay( 100, 
				function()
					local tmp = display.newImageRect( "thePicture.png", system.DocumentsDirectory, 50, 50  )
					tmp.x = 160				
					tmp.y = 360
					tmp:setStrokeColor(1,1,0)
					tmp.strokeWidth = 2
				end )

		end
		
	end
end

if media.hasSource( media.Camera ) then
	media.show( media.Camera, sessionComplete )
end

