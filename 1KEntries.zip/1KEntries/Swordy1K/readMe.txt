
Swordy 1K (Roaming Gamer; Entry #1; 1021 bytes)
-----------------------------------------------

This is my first entry for the "Code Less. Play More. 1K Contest".

In this game, it is just you, your sword, and zombies, lots and lots of zombies.

(Everything is better with zombies, right?)

The goal of the game is simply stay alive as long as possible. 
To stay alive, you must kill zombies by hitting them with your sword.
Zombies can kill you by touching your body.

Sure, at first there are just a few zombies, but don't worry, the game will soon ramp up.

So, how long can you stay alive.


Implemenation Details
---------------------
* This entry is 1021 bytes long as measured by Windows 7 Explorer
* The game draws cubes and rectangles.  
* Zombies are randomly colored (green to grey).
* The player has a physics joint attaching the body to the sword.
* The sword and zombies use collision detection.
* Physics debug mode is set to "hybrid" to give me a free arm and elbow.
* The 'allowed' files can be found in the "code/" subfolder.

Beware, the game will exit 10 second after you die, so if you want to take a screenshot
to impress folks with your kigh zombie kill count, do it before then.
Why did I use quit?  so you can easily re-load and play it again of course.



This entry by,

Ed Maurina of 
Roaming Gamer, LLC. 
http://roaminggamer.com/


