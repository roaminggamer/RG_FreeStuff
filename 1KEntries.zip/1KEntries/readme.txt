My 1K entries to a contest from 2013.

i.e. Small apps in 1K or less of code (by size on disk).