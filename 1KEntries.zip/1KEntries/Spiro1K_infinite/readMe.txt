
Spiro1K Infinite (Roaming Gamer; Entry #2; 821 bytes)
-----------------------------------------------------

This is my second entry for the "Code Less. Play More. 1K Contest".

This is an app that automatically draws a new 'spriograph' every 30 seconds.

Thats it.  I coded this simply to see if it could be done.




Implemenation Details
---------------------
* This entry is 867 bytes long as measured by Windows 7 Explorer
* The game uses physics joints and three proxy objects (circles) to achieve the 
  behind the scenes magic.
* It uses math.random() to select the sizes of the circles, the locations of
  the joints, and the colors of the spirograph lines.
* The spirograph finshes drawing after about 22.5 seconds, so you should never
  get a old pattern still drawing on a new one.  But hey, you can't
  do much checking in 1K of code.
* I suggest running this on the simulator, and reloading if it starts to lag.
* The 'allowed' files can be found in the "code/" subfolder.

Don't forget, the spirograph resets every 30 seconds, so if you get a nice one take a snapshot fast!

Ed Maurina of 
Roaming Gamer, LLC. 
http://roaminggamer.com/


