Answer to this question:

http://forums.coronalabs.com/topic/47151-scale-a-group/#entry243587