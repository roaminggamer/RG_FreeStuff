Answer to this question:

http://forums.coronalabs.com/topic/47175-layouts-in-corona/#entry243719