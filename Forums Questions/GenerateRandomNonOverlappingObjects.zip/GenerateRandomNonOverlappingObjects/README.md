Answer to this question:

http://forums.coronalabs.com/topic/47560-create-random-position-that-are-not-colliding-each-other/#entry245588



