You can drop these into a project and they will override the default grey buttons and sliders.

Use this an an example for creating your own drop in 'override' presets.