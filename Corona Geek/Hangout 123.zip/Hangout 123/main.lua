-- =============================================================
-- main.lua
-- =============================================================

require "scaling" -- Run scaling example

--require "scrolling" -- Run scrolling example