
To run the FORCES example, 

uncomment line 19 in main.lua
comment out line 20 in main.lua


To run the IMPULSES example, 

uncomment line 20 in main.lua
comment out line 19 in main.lua



Tip: Uncomment line 15 in main.lua to see the physics bodies.