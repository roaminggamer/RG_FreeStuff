application = {
	content = {
        graphicsCompatibility = 1,  -- Turn on V1 Compatibility Mode
		width = 320,
		height = 480, 
		scale = "letterBox", -- Good in some cases
	},
}