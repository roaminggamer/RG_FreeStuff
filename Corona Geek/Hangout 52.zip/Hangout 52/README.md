Character Jump
============
This folder contains these versions of the 'Character Jump' code from Hangout 52.

(Note: Artwork does not match that seen in the show, but the code is similar.)

1. Character-Jump - Version 1 (Original) => Original version of example

2. Character-Jump - Version 2 => Modified to jump away from tap and to handle mass changes relative to size.

3. Character-Jump - Version 3 (Two Characters) => Same as prior version but with two characters, has been cleaned up and organized, and uses 'table' listener methodology for touch input.