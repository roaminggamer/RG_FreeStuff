Goodies From Hangout 54
============
This folder contains code++ discussed during Corona Geek Hangout 54.


Code (Folders)
============
1. Water Buoyancy 1 => Basic water buoyancy example.

2. Water Buoyancy 2 => More realistice (ingeneous!) water buoyancy example.

3. Water Buoyancy 2.1 => Above example with FPS set to 60.  See how it breaks?

4. Water Buoyancy 3 => Water Buoyancy 2 with code added to: a. Make it FPS insensitive; b. Make block fall faster in air than water.; c. Make the simulation a little smoother (almost neglibily).

