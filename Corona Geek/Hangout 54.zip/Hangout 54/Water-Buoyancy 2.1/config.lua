application = {
	content = {
		fps = 60
	}
}
