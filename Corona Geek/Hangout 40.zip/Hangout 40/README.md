Free sample code that came out of this talk:

http://www.coronalabs.com/blog/coronageek/corona-geek-hangout-40/

