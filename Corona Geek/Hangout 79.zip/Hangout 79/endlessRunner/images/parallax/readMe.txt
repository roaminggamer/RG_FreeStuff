Images from here:

http://blog.spiralgraphics.biz/2011/02/nine-cartoon-backdrops.html