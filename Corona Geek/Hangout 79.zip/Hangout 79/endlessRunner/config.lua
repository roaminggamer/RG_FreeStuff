application = {
	content = {
		width = 384,
		height = 512, 
		scale = "zoomEven", -- Choices: zoomEven, letterbox, zoomStretch, none		
		fps = 30,
        imageSuffix = 
        {
            --["@2x"] = 1.5,
            --["@4x"] = 3.0,
        },
	},
}

