Goodies From Hangout 53
============
This folder contains code++ discussed during Corona Geek Hangout 53.


Code (Folders)
============
1. Lighting	=> Dr. Burtons original lightning code.

2. Lightning - Version 2 => Modified variant of above code to add randomness and ability to combine types, create multiple strikes, etc.

3. Rain => Original rain sample from Charles.

4. Rain Cats N Dogs => Modfied variant of rain using cats, dogs, and a goofy soundtrack.  Just for kicks by Ed.

5. Water Ripples - An interesting demo of how to simulate water ripples in Corona.