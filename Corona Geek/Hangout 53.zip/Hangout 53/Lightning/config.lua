-- config.lua for project: RobotWars
-- Managed with http://CoronaProjectManager.com
-- Copyright 2012 Brian Burton. All Rights Reserved.

application =
{
	content =
	{
		--width = 320,
		--height = 480,
		--scale = "zoomEven"
	},
}

