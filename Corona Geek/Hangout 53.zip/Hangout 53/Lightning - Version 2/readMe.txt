This code was provided by Dr. Brian Burton as a demo for Corona Geek hangout #53.  It was derived from code originally seen in the Corona Labs forums.

This version (#2) was further modified by Ed Maurina (aka The Roaming Gamer) and adds these changes:
- Fixes bug where sound is played over and over till channels are all used.
- Adds ability to randomly select number and kind of bolt produced per touch.

See code with initials (EFM)

