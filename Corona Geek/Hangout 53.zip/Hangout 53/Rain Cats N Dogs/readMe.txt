This is a modified version or 'Rain' originally written by:

Volodymyr Sergeyev - http://www.youtube.com/user/vsergeyev

Note: Original link to source code unknown.
