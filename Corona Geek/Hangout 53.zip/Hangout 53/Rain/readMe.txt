This example of a simple rain effect was written by:

Volodymyr Sergeyev - http://www.youtube.com/user/vsergeyev

Note: Original link to source code unknown.
