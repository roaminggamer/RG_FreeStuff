These Sprite Sheets were made With Shoe Box

http://renderhjs.net/shoebox/

Requires 'Adobe Air': https://get.adobe.com/air/