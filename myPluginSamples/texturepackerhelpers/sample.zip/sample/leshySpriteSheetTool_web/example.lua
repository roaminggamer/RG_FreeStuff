-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2017 (All Rights Reserved)
-- =============================================================

local helpers = require "plugin.texturePackerHelpers"
local helper = helpers.leshy

local cx = display.contentCenterX
local cy = display.contentCenterY

-- Slots - Creating Images From Image Sheet
--
local function ex1( group )

	-- Method 1 - Get sheet from helper and use display.newImage() to create and place image from sheet.
	local slotsSheet 	= helper.newImageSheet( { definition = "leshySpriteSheetTool_web/slots.txt",  image = "leshySpriteSheetTool_web/slots.png" } )
	local cherry 	= display.newImage( group, slotsSheet, 1, cx - 200 , cy - 200 )


	-- Method 2 - Use helper to make image directly, but re-use previously loaded sheet
	local apple = helper.newImage( { sheet  = slotsSheet, frameIndex = 2, parent = group, x = cx - 200, y = cy} )

	-- Method 3 - Use helper to do all the work.
	local grapes = helper.newImage( { definition = "leshySpriteSheetTool_web/slots.txt", image = "leshySpriteSheetTool_web/slots.png", frameIndex = 3, 
		                            parent = group, x = cx - 200, y = cy + 200 } )
end

-- Ninja Girl - Creating Animated Sprite From SINGLE Image Sheet
--
local function ex2( group )
	local ninjaGirlIdleSequenceData =
	{
		name			= "idle",
	   start			= 1,
	   count 		= 10,
	   time 			= 1000,
	   loopCount 	= 0
	}

	local ninjaGirlIdleSprite = helper.newSprite( { definition = "leshySpriteSheetTool_web/ninjaGirlIdle.txt", 
																image = "leshySpriteSheetTool_web/ninjaGirlIdle.png",
																parent = group, x = cx, y = cy },
															 ninjaGirlIdleSequenceData )
	ninjaGirlIdleSprite:scale(0.5,0.5)
	ninjaGirlIdleSprite:setSequence("idle")
	ninjaGirlIdleSprite:play()
end

-- Ninja Girl MULTI - Creating Animated Sprite From MULTIPLE Image Sheets
--
local function ex3( group )
	-- 1. Get sheets from helper
	local ninjaGirlIdleSheet 	= 	 helper.newImageSheet( { definition = "leshySpriteSheetTool_web/ninjaGirlIdle.txt", 
																 image = "leshySpriteSheetTool_web/ninjaGirlIdle.png" } )

	local ninjaGirlAttackSheet	= 	 helper.newImageSheet( { definition = "leshySpriteSheetTool_web/ninjaGirlAttack.txt", 
																 image = "leshySpriteSheetTool_web/ninjaGirlAttack.png" } )

	-- 2. Write sequence data table (defines how animation plays)
	local ninjaGirlSequenceData =
	{
		{ name = "idle",  sheet = ninjaGirlIdleSheet, start = 1, count = 10, time	= 1000, loopCount = 0 },
	   { name = "attack",  sheet = ninjaGirlAttackSheet, start = 1, count = 10, time	= 500, loopCount = 1 },
	}

	-- 3. Create sprite and star it
	--
	local ninjaGirlSprite = helper.newSprite( { sheet = ninjaGirlIdleSheet, parent = group, x = cx + 200, y = cy },
														ninjaGirlSequenceData )

	ninjaGirlSprite:setSequence("idle")
	ninjaGirlSprite:play()
	ninjaGirlSprite:scale(0.5,0.5)

	-- 4. Attach Some Code To Make Demoing Easier (touch girl to play attack sprite, then go back to idle)
	--
	function ninjaGirlSprite.sprite( self, event ) 
		if( event.phase == "ended" ) then
			self:setSequence("idle")
			self:play()
		end
	end
	ninjaGirlSprite:addEventListener("sprite")

	function ninjaGirlSprite.touch( self, event )
		if( event.phase ~= "began" ) then return false end
		self:setSequence("attack")
		self:play()
		return true
	end

	ninjaGirlSprite:addEventListener("touch")

	local label = display.newText( group, "Tap To Play Animation", ninjaGirlSprite.x, ninjaGirlSprite.y + 140, 
		                            native.systemFont, 20 )

end

local public = {}
function public.run( group )
	ex1( group )
	ex2( group )
	ex3( group )
	local label = display.newText( group, "Leshy Sprite Tool Helper Demo", 400, cy + 200, native.systemFont, 32 )
	label.anchorX = 0 
end
return public