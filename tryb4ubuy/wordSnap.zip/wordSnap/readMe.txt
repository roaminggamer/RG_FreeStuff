-- =============================================================
-- Word Snap - 'Documentation'
-- =============================================================
This is a 'try before you buy' template.  Feel free to use it and 
make games with it, but if you want to distribute them please buy it.

Thanks,
Roaming Gamer

-- =============================================================
-- Need Help?
-- =============================================================
Aside from fixing bugs and releasing update to the module(s),
support is not provided. 

That said, if you need help making your game, I am available and 
you can pay me to help.

Send me an email titled 'Paid Help - Word Snap' at roaminggamer@gmail.com

I'll get back to you promptly.


-- =============================================================
-- What Comes In This Template
-- =============================================================
+ 1_edit        - Example of editor and viewer with four puzzles.
+ 2_basic       - Basic game board creation.
+ 3_textured    - Game board using single texture each for land and tiles.
+ 4_lettertiles - Game board made using individual textures for each letter.
+ 5_scaled      - Scaled version of board
+ easy          - Compiled modules.
+ readMe.txt    - This file.
+ template      - Blank starter project for making your games.

-- =============================================================
-- Basic Usage
-- =============================================================
There are 5 examples and a template.  You can work it out. :)


-- =============================================================
-- Editor (easy.wordSnap)
-- =============================================================

-- Require It:
local wordSnap = require "easy.wordSnap"	

-- Set the size of tiles:
wordSnap.setTileDimensions(60,60) -- width, height

-- Create the editor
wordSnap.createEditor()


-- =============================================================
-- Viewer  (easy.wordSnap)
-- =============================================================

-- Require It:
local wordSnap = require "easy.wordSnap"	

-- Set the size of tiles:
wordSnap.setTileDimensions(60,60) -- width, height

-- Optionally adjust the piece fly time and easing
wordSnap.setFlySettings(1500, easing.outElastic)

-- Optionally define some parameters (more on this later)
local params = 
{
	tileImages 			= "images/letters_kenney",
	tileExtension   	= ".png",
	--landImage 			= "images/letters_kenney/letter.png",
	landWidth 			= 40,
	landHeight 			= 40,
	landStroke 			= {0,0,0},
	landStrokeWidth	= 2,
	listener  			= completeListener,
}


-- Create a viewer
-- group - Display group to put viewer in
-- x, y - Next two args are x,y position of board center.
-- levelName - Name of level to load, including the .json extension.
-- optiona parametrs
local viewer = wordSnap.createViewer( group, tray.x, tray.y, "level_1_" .. puzzleNum .. ".json", params)


-- =============================================================
-- Viewer Parameters (in no particular order)
-- =============================================================
+ listener - Function to call when board is solved.
+ landWidth, landHeight - Width and height of 'lands'.
+ landStroke - Stroke width of land.
+ landImage - Image to use for drawing lands. If none supplied, a rectangle is drawn.
+ landColor - Fill color to use for land.  Default is white.
+ tileWidth, tileHeight - Width and height of 'tiles'.
+ tileStroke - Stroke width of tile.
+ tileImage - Image to use for drawing tiles. If none supplied, a rectangle is drawn.
+ tileImages - If supplied, you are telling the module to look in this folder for the letter tiles.
               You must supply an image for each letter and/or number you use in your puzzles.
               Name format for these files: letters_?.png or letters_?.jpg, where ? is the letter or number in uppercase.
               Ex: letter_A.png
+ tileExtension - Optionally used with 'tileImages' parameter and must be either ".png" or ".jpg".
                  Default is ".png"
+ tileColor - Fill color to use for tile.  Default is white.
+ letterFont - Font to use for letters if you're not supplying letter tiles.
+ letterSize - Size of letters (only for non-letter tile case).
+ letterColor - Color of letters (only for non-letter tile case).


-- =============================================================
-- wordSnap.getPuzzleInfo( puzzleName )
-- =============================================================
This function returns a table with these named fields:
+   rows - Number of rows in puzzle.
+   cols - Number of colums in puzzle.
+  width - Width of puzzle.
+ height - Height of puzzle.
+   sets - Numer of 'sets' in puzzle. i.e. Number of puzzle pieces.


-- =============================================================
-- Utility Functions (easy.utils)
-- =============================================================
There are a number of utility functions in this module and they are all 
(for the most part) documented internally, so take a look a the file.

That said, you will probably want to use this function in your games:

utils.createSlicedImage( group, slicePath, x, y, width, height )		

This function uses 9 image slices to draw a puzzle tray for your game, where 
'slicePath' is the path to those slices.  

See examples 4 and 5 for this being used to see how it works and how the images
are named and made.


