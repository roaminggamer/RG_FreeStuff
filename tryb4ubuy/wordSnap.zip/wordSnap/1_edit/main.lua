-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
local mode = "edit" -- edit view

if( mode == "edit" ) then
	local utils = require "easy.utils"
	require "presets.presets" -- For button maker
	local wordSnap = require "easy.wordSnap"

	wordSnap.setFonts( "viewer.ttf", "editor.ttf" )
	wordSnap.setTileDimensions(60,60)
	
	wordSnap.createEditor()

else
	local wordSnap = require "easy.wordSnap"	
	wordSnap.setTileDimensions(60,60)
	wordSnap.createViewer( nil, centerX, centerY, "level_1_3.json" )
end

