-- =============================================================
-- Copyright Roaming Gamer, LLC. 2008-2018 (All Rights Reserved)
-- =============================================================
io.output():setvbuf("no")
display.setStatusBar(display.HiddenStatusBar)
-- =============================================================
local group
local puzzleNum = 2
local function run()
	local utils 		= require "easy.utils"
	local wordSnap 	= require "easy.wordSnap"
	require "presets.presets" -- For button maker
	local buttonMaker = require "easy.buttonMaker"

	puzzleNum = puzzleNum + 1
	puzzleNum = (puzzleNum > 4) and 1 or puzzleNum

	display.remove(group)
	group = display.newGroup()

	--
	-- Draw a background
	--		
	local back = display.newRect( group, centerX, centerY, fullw, fullh )
	back:setFillColor(unpack(utils.hexcolor("#128223")))

	--
	-- Draw a win label
	--
	local winLabel = display.newText( group, "Puzzle Complete", centerX, bottom - 50, "Lato-Black.ttf", 60 )
	winLabel.isVisible = false

	--
	-- Add a button to 're-run' this example
	--
	local button = buttonMaker.easyPush( { parent = group, x = right - 55, y = top + 20,  fontSize = 20,
	                     width = 100, height = 30, labelText = "Next", listener = run } )	
	button.isVisible = false


	--
	-- Draw the puzzle tray using 9-slices feature
	--
	local info = wordSnap.getPuzzleInfo("level_1_" .. puzzleNum .. ".json")
	utils.dump(info,'info')
	local tray = utils.createSlicedImage( group, "images/slices", centerX, centerY, 
		                      (info.width + 20) * 0.9, (info.height + 20) * 0.9 )		

	--
	-- Draw the puzzle
	--
	-- This function is called when the puzzle is completed
	local function completeListener( )
		button.isVisible = true
		winLabel.isVisible = true
		wordSnap.stop()
	end

	-- This table is used to configure the puzzle		
	local params = 
	{
		tileImages 			= "images/letters_kenney",
		tileExtension   	= ".png",
		--landImage 			= "images/letters_kenney/letter.png",
		landWidth 			= 40,
		landHeight 			= 40,
		landStroke 			= {0,0,0},
		landStrokeWidth	= 2,
		listener  			= completeListener,
	}

	-- Set the width and height of the tiles 
	-- IMPORTANT! ==> This must match the width and height used when building the puzzles.
	wordSnap.setTileDimensions(60,60)

	-- Modifies the missed snap/ fly back behavior
	wordSnap.setFlySettings(1500, easing.outElastic)

	-- Draws the puzzle viewer
	local viewer = wordSnap.createViewer( group, tray.x, tray.y, "level_1_" .. puzzleNum .. ".json", params)
	viewer:scale(0.9,0.9)
end
run()