The boy and girl images used in this version of the game are from a free art pack provided by Daniel Cook at the Lost Garden.

http://www.lostgarden.com/search/label/free%20game%20graphics

Please read his license here if you want to know more:

http://www.lostgarden.com/2007/03/lost-garden-license.html




