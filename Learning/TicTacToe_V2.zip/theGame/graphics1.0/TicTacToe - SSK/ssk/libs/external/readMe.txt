All content in this and sub-directories is created/written by others.  

I am including attribution files for each case.  See readMe.txt in each 
subdirectory.