application = {
	content = {
		graphicsCompatibility = 1,
		width = 320,
		height = 480, 
		scale = "letterBox", -- Good in some cases
	},
}