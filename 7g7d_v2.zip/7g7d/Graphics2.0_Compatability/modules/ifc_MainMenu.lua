-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 

local screens = {}

local gameButton

-- Forward Declarations
local create 
local destroy

local onPlay
local onEdit
local onOptions
local onCredits

local onGameSelect
local onScreenTouch

local onRG
local onCorona



----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	screens = {}

	options.game = options.game or gameNames[1]
	table.save( options, "options.txt" )		

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "screens", "buttons", "overlay" )

	local backImage
	if(build_settings.orientation.default == "landscapeRight") then
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Landscape.jpg" )
		backImage = display.newImage( layers.background, "images/backr.png" )
	else
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Portrait.jpg" )
		backImage = display.newImage( layers.background, "images/back.png" )
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	-- Create Title
	ssk.labels:quickLabel( layers.buttons, "7-Games-in-7-Days (7G7D)", centerX, 40, nil, 32, _BLACK_ )

	-- Create Menu Buttons
	local xPos = 120 
	local yPos = centerY - 120
	local bw = 160
	local bh = 40
	gameButton = ssk.buttons:presetPush( layers.buttons, "default", 340, 85,   240, 30, options.game, ssk.sbc.table2TableRoller_CB, {fontSize = 12})
	ssk.sbc.prep_table2TableRoller( gameButton, options, "game", gameNames, onGameSelect ) 

	ssk.buttons:presetPush( layers.buttons, "default", xPos, yPos + 50,  bw, bh, "Play", onPlay )
	
	if( editorEnabled ) then
		ssk.buttons:presetPush( layers.buttons, "default", xPos, yPos + 100, bw, bh, "Edit", onEdit )
	else 
		ssk.buttons:presetPush( layers.buttons, "default", xPos, yPos + 100, bw, bh, "Enable Editor", onEdit )
	end
	
	ssk.buttons:presetPush( layers.buttons, "default", xPos, yPos + 150, bw, bh, "Options", onOptions )
	ssk.buttons:presetPush( layers.buttons, "default", xPos, yPos + 200, bw, bh, "About", onCredits )


	-- Add Screenshots
	local screenNames = {
		"attractrepel.png",
		"somethinggreen.png",
		"gravityflipper.png",		
		"schmup.png",		
		"pinball.png",
		"linefollower.png",
		"21hangman.png"
	}
	local tmp 

	tmp = display.newRect( layers.screens, 0,0,244,164 )
	tmp.x = 340
	tmp.y = h - 135
	tmp:setFillColor( unpack(_BLACK_) )

	for i = 1, #screenNames do	
		tmp = display.newImage( layers.screens, "images/screens/" .. screenNames[i] )
		screens[gameNames[i]] = tmp
		tmp.x = 340
		tmp.y = h - 135
		if(gameNames[i] ~= gameButton:getText()) then
			tmp.isVisible = false
		end

		tmp.touch = onScreenTouch
		tmp:addEventListener( "touch", tmp )
	end

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	-- Roaming Gamer Badge
	local tmp = display.newImageRect( layers.overlay, "images/badges/rg.png", 40, 40 )
	tmp.x = w - 25
	tmp.y = h - 25
	tmp.touch = onRG
	tmp:addEventListener( "touch", tmp )


	-- Roaming Gamer Badge
	tmp = display.newImageRect( layers.overlay, "images/badges/coronaBadge_tinyt.png", 40, 40 )
	tmp.x = 25
	tmp.y = h - 25
	tmp.touch = onCorona
	tmp:addEventListener( "touch", tmp )


	ssk.debug.monitorMem()
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	layers:removeSelf()
	layers = nil
	screens = {}
	gameButton = nil
end

-- ==
-- onPlay() - Play Game
-- ==
onPlay = function ( )
	currentMode = "play"

	if( gameButton:getText() == gameNames[7] ) then return end

	ifc_SelectLevel.create()
	ssk.debug.monitorMem()
end


-- ==
-- onEdit() - Play Game
-- ==
onEdit = function ( )
	currentMode = "edit"

	if( gameButton:getText() == gameNames[7] ) then return end

	print(options.currentGameDir)
	if( options.currentGameDir and presets[options.currentGameDir] ) then
		presets[options.currentGameDir].init()
		ifc_SelectLevel.create()
	end
	
	ssk.debug.monitorMem()	
end


-- ==
-- onOptions() - Destroy EFM
-- ==
onOptions = function ( )
	ifc_Options.create()
	ssk.debug.monitorMem()
end

-- ==
-- onCredits() - Destroy EFM
-- ==
onCredits = function ( )
	ifc_Credits.create()
	ssk.debug.monitorMem()
end


-- ==
-- onGameSelect() - Destroy EFM
-- ==
onGameSelect = function ( event )
	local target = event.target
	print(target:getText())

	for i = 1, #gameNames do	
		screens[gameNames[i]].isVisible = false
		if(gameNames[i] == target:getText()) then
			screens[gameNames[i]].isVisible = true
		end
	end

	options.currentGameDir = gameDirs[target:getText()]

	table.save( options, "options.txt" )		
	return true
end


-- ==
-- onScreenTouch() - Destroy EFM
-- ==
onScreenTouch = function ( setlf, event  )
	if( event.phase == "ended" ) then
		gameButton:toggle()
	end
		
	return true
end

onRG = function ( self, event ) 
	print("onRG", event.phase )
	if( event.phase == "ended" ) then
		system.openURL( "http://roaminggamer.com"  )
	end
	return true
end

onCorona = function ( self, event ) 
	print("onCorona", event.phase )
	if( event.phase == "ended" ) then
		system.openURL( "http://www.coronalabs.com/"  )
	end
	return true
end




----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
