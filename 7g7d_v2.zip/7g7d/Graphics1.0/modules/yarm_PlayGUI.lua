-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local playPuzzle = {}

local curLenMult = 1

local currentVelocity = 25

local thePlayer
local nearestMagnet
local magnets = {}

-- Forward Declarations
local create 
local destroy

local ignoreCollisions = false

local createPiece
local createLevel


local onCollision 
local onBack
local onHelp


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	local vel  = {}

	vel.Wimpy  = 30
	vel.Easy   = 50
	vel.Normal = 75
	vel.Hard   = 100
	vel.Insane = 150

	currentVelocity = vel[options.difficulty] 

	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
	if(not currentPuzzle) then currentPuzzle = {} end

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back2.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2



	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	createLevel()

	ignoreCollisions = false
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroyoing level" )

	for k,v in pairs( magnets ) do
		v.enterFrame = drawLine
		Runtime:removeEventListener( "enterFrame", v )
	end

	layers:removeSelf()
	layers = nil
	backImage = nil
	magnets = nil
	nearestMagnet = nil
end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end


-- ==
-- createLevel() - EFM
-- ==
onCollision = function( self, event )
	local other = event.other
	local type  = other.type
	
	if( event.phase == "began" ) then
		print(event.phase, type)		
		if( type == "goal" and not ignoreCollisions) then
			ignoreCollisions = true			

			local pass = true
			for k,v in pairs( playPuzzle ) do
				if( v.type == "unlocker" ) then
					pass = false
				end
			end

			if( pass ) then
				currentLevelNum = currentLevelNum + 1
				ssk.gem:post( "PLAY_EFFECT" , { effectName = "win1" } )	
			else
				ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			end

			print("*****  In goal code", currentLevelNum, existingLevels)
			if( currentLevelNum > existingLevels ) then
				currentLevelNum = 1
			end
				
			timer.performWithDelay(10, 
				function() 
					destroy()
					create ()
				end )	
											

		elseif( type == "unlocker" and not ignoreCollisions) then
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "good" } )
			timer.performWithDelay(1, 
				function() 
					playPuzzle[other] = nil
					other:removeSelf()					
				end )			

		elseif( type == "danger" and not ignoreCollisions) then
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			print("*****  In danger code", currentLevelNum, existingLevels)
			ignoreCollisions = true
			timer.performWithDelay(10, 
				function() 
					destroy()
					create ()
				end )			
		end
	end
	return true
end

createPiece = function ( group, x, y, rotation, type, myCC )
	--print("creating: ", type)
	local tmp 

	if( type == "anchor" or  type == "push" or  type == "pull" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = 20 }, { calculator = myCC, colliderName = "magnet", bodyType = "static" }  )
	elseif( type == "player" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = 8 }, { calculator = myCC, colliderName = type }  )
		thePlayer = tmp
		tmp.collision = onCollision
		tmp:addEventListener( "collision", tmp )
	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = 20 }, { calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	
	end
	tmp.type = type	
	tmp.rotation = rotation	

	playPuzzle[tmp] = tmp

	return tmp
end

createLevel = function()
	local myCC = ssk.ccmgr:newCalculator()
	myCC:addName("player")
	myCC:addName("magnet")
	myCC:addName("goal")
	myCC:addName("danger")
	myCC:addName("unlocker")
	myCC:collidesWith( "player", "danger", "unlocker", "goal" )

	local piece
	magnets = {}
	playPuzzle = {}

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]

		piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type, myCC)	
		count = count + 1		

		if( tmp.type == "anchor" or tmp.type == "push" or tmp.type == "pull") then
			magnets[#magnets+1] = piece
		end

	end
	--print("Total blocks == " .. count )

	for k,v in pairs( magnets ) do
		v:toFront()
	end

	-- Locate Start Block
	local startBlock
	for k,v in pairs( playPuzzle ) do
		if (v.type == "player" ) then
			startBlock = v
		end
	end
			
	local startX = - 20
	local startY = centerY
	local startR = 0
	
	if( startBlock ) then
		startX = startBlock.x
		startY = startBlock.y
		startR = startBlock.rotation
	end

	local v = ssk.math2d.angle2Vector( startR, true )
	--table.dump(v)

	v = ssk.math2d.scale( v, currentVelocity )

	if( startBlock ) then
		startBlock:setLinearVelocity(v.x, v.y)
		--startBlock:setLinearVelocity(0, currentVelocity)
	end

	-- Locate Magnet(s)
	for k,v in pairs( playPuzzle ) do
		if (v.type == "anchor" ) then
			startBlock = v

			magnet = ssk.display.rect( layers.content , v.x, v.y, 
											{ size = 8, fill = _PINK_ , stroke = _YELLOW_, strokeWidth = 1 }, 
											{ calculator = myCC, colliderName = "magnet", bodyType = "static",
											  bounce = 0.5, density = 1.0, friction = 1.0 } )  	
			v.isVisible = false
			magnet.type = v.type
		elseif (v.type == "push" ) then
			startBlock = v

			magnet = ssk.display.rect( layers.content , v.x, v.y, 
											{ size = 8, fill = _RED_ , stroke = _YELLOW_, strokeWidth = 1 }, 
											{ calculator = myCC, colliderName = "magnet", bodyType = "static",
											  bounce = 0.5, density = 1.0, friction = 1.0 } )  	
			v.isVisible = false
			magnet.type = v.type
		elseif (v.type == "pull" ) then
			startBlock = v

			magnet = ssk.display.rect( layers.content , v.x, v.y, 
											{ size = 8, fill = _GREEN_ , stroke = _YELLOW_, strokeWidth = 1 }, 
											{ calculator = myCC, colliderName = "magnet", bodyType = "static",
											  bounce = 0.5, density = 1.0, friction = 1.0 } )  	
			v.isVisible = false
			magnet.type = v.type
		end
	end
	


	local function drawLine(self) 	

		if(self.theLine) then
			self.theLine:removeSelf()
			self.theLine = nil
		end

		local tweenVec = ssk.math2d.sub( thePlayer, self )
		local len = ssk.math2d.length(tweenVec)

		local vx,vy = thePlayer:getLinearVelocity()
		local speed = ssk.math2d.length(vx,vy)
		local nx,ny = ssk.math2d.normalize(vx,vy)

		local vx2,vy2 = ssk.math2d.scale(nx,ny,currentVelocity)
		thePlayer:setLinearVelocity(vx2,vy2)
		

		--print(len, speed,nx,ny)
		if(nearestMagnet) then
			--print( "EDO: ", nearestMagnet.jointLength )
		end
		if( self.theJoint ) then
			if( self.type == "anchor") then
				--self.theJoint.length = len
				nearestMagnet.theJoint.length = nearestMagnet.jointLength * curLenMult
			elseif( self.type == "pull") then
				self.theJoint.length = len * 0.98
			elseif( self.type == "push") then
				self.theJoint.length = len * 1.008
			end
			
			self.theLine = display.newLine(layers.content, self.x, self.y, thePlayer.x, thePlayer.y )
		end

		return true		
	end

	for k,v in pairs( magnets ) do
		v.enterFrame = drawLine
		Runtime:addEventListener( "enterFrame", v )
	end


	local function onTouch( self, event )
		local phase = event.phase

		--print(phase)

		if(phase == "began") then

			local distance = 10000000
			
			for k,v in pairs( magnets ) do
				local vec = ssk.math2d.sub( v, thePlayer )
				local len2 = ssk.math2d.squarelength( vec )
				if (len2 < distance) then
					distance = len2
					nearestMagnet = v
				end
			end

			if( nearestMagnet ) then
				print(nearestMagnet.type)
				nearestMagnet.theJoint = physics.newJoint( "distance", nearestMagnet, thePlayer, nearestMagnet.x, nearestMagnet.y, thePlayer.x, thePlayer.y )
				nearestMagnet.jointLength = nearestMagnet.theJoint.length

				--print( "EDOCHI: ", nearestMagnet.jointLength )
			end
		
		elseif(phase == "moved") then


			local deltaX = event.x - event.xStart
			local deltaY = event.y - event.yStart
			curLenMult = 1 + 0.01 * -deltaY
			 

		elseif(phase == "ended") then
		
			if( nearestMagnet ) then
				if(nearestMagnet.type == "anchor") then
					nearestMagnet:setFillColor(unpack(_YELLOW_))
				elseif(nearestMagnet.type == "push") then
					nearestMagnet:setFillColor(unpack(_RED_))
				elseif(nearestMagnet.type == "pull") then
					nearestMagnet:setFillColor(unpack(_GREEN_))
				end

				nearestMagnet.theJoint:removeSelf()
				nearestMagnet.theJoint = nil
			end
			nearestMagnet = nil 
		end

		return true	
	end


	-- 
	backImage.touch = onTouch
	backImage:addEventListener( "touch", backImage )

end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
