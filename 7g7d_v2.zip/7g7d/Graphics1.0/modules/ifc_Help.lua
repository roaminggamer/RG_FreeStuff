-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 

local effectsSlider
local musicSlider

-- Forward Declarations
local create 
local destroy

local onBack

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "buttons", "overlay" )

	local backImage
	if(build_settings.orientation.default == "landscapeRight") then
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Landscape.jpg" )
		backImage = display.newImage( layers.background, "images/back2r.png" )
	else
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Portrait.jpg" )
		backImage = display.newImage( layers.background, "images/back2.png" )
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	-- Add dummy touch catcher to backImage to keep touches from 'falling through'
	backImage.touch = function() return true end
	backImage:addEventListener( "touch", backImage )


	-- Labels and Buttons
	ssk.labels:quickLabel( layers.buttons, "Help?" , centerX, 40, nil, 40 )

	local text

	--[[
	gameDirs[gameNames[1]] =  "yarm"
gameDirs[gameNames[2]] =  "sgreen"
gameDirs[gameNames[3]] =  "gflip"
gameDirs[gameNames[4]] =  "schmup"
gameDirs[gameNames[5]] =  "pinball"
gameDirs[gameNames[6]] =  "follower"
gameDirs[gameNames[7]] =  "hangman21"
--]]

	if(options.currentGameDir == "yarm") then
		text = "'" .. gameNames[1] .. "' was was inspired by Magentized:\n" ..
		"http://www.kongregate.com/games/rocky10529/magnetized\n\n" ..
		"Press and hold the screen and the nearest magnet will attract,\n" ..
		"repel, or anchor the moving block.\n\n" ..
		"There are three 'magnet' types: attract, repel and variable.\n\n" ..
		"Variable anchors respond to finger movement and change the\n" ..
		"anchor distance to the moving piece."
	elseif(options.currentGameDir == "sgreen") then
		text = "'" .. gameNames[2] .. "' is a remake of my old game:\n" ..
		"'Something Blue' ==> http://bit.ly/XjqQCb\n\n"..
		"The goal is to remove all 'green' numbered squares from the board.\n\n" ..
		"Tap pieces that are horizontally or vertically aligned with the player\n" ..
		"to move.\n\n" ..
		"Moving over a green square decrements it by 1.  At 0, they are removed.\n\n" ..
		"Colored stars teleport you to similarly-colored stars."

	elseif(options.currentGameDir == "gflip") then
		text = "'" .. gameNames[3] .. "' is a gravity flipping game with a twist.\n\n" ..
		"In this game, the world spins uncontrollably, whily you control gravity.\n\n" ..
		"Touch the screen and drag your finger to change the direction and \n" ..
		"strength of gravity.\n\n" ..
		"Move to the green square to win.  Watch our for red blocks and spinners!\n\n" ..
		"The arrow in the upper-left indicates the strength and direction of gravity."

	elseif(options.currentGameDir == "schmup") then
		text = "'" .. gameNames[4] .. "' is a shoot-em up where you don't shoot.\n" ..
		"Instead you get shot at.\n\n" ..
		"Touch and drag to move your ship.\n\n" ..
		"Get to the green 'goal' squares while avoiding dangers.\n\n\n" ..
		"Note: This game is buggy. :( Sorry!"	

	elseif(options.currentGameDir == "pinball") then
		text = "'" .. gameNames[5] .. "' is a pinball-esque game with\n" ..
		"paddles, bumpers, and a ball.\n\n" ..
		"Your goal is to get the ball to drop on the green squares\n" ..
		"while keeping it away from the red squares."
	
	elseif(options.currentGameDir == "follower") then
		text = "'" .. gameNames[6] .. "' is the beginning of a plane landing\n" ..
		"line-follower.\n\n" ..
		"Touch colored planes and drag to make a flight path.\n\n" ..
		"Draw the path to the correctly colored 'runway' to land.\n\n" ..
		"Note: This not a great game and it's buggy. :( Sorry!"	
	end

	ssk.labels:quickLabel( layers.buttons, text , centerX, centerY, nil, 12 )
	
	ssk.buttons:presetPush( layers.buttons, "default", 55, h-25, 100, 40, "Back", onBack )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	layers:removeSelf()
	layers = nil
	effectsSlider = nil
	musicSlider = nil

end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
