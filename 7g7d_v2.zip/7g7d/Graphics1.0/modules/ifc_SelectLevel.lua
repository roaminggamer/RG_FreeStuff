-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 

-- Forward Declarations
local create 
local destroy

local onLevel
local onEdit
local onOptions
local onBack


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "buttons", "overlay" )

	local backImage
	if(build_settings.orientation.default == "landscapeRight") then
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Landscape.jpg" )
		backImage = display.newImage( layers.background, "images/backr.png" )
	else
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Portrait.jpg" )
		backImage = display.newImage( layers.background, "images/back.png" )
	end


	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	local firstMissing = true

	-- Create Menu Buttons
	local count = 1
	for i = 1, 5 do
		for j = 1, 8 do
			local x = centerX - 220 + j * 50
			local y = centerY - 170 + i * 50
			local tmp = ssk.buttons:presetPush( layers.buttons, "default", x, y, 40, 40, count, onLevel )
			tmp.myLevelNum = count

			local exists = io.exists(options.currentGameDir .. "/level" .. count .. ".txt",system.DocumentsDirectory)
			--print("Level file number " .. count .. "exists ?= " .. tostring(exists) )

			if( exists ) then 

				if( currentMode == "edit" and count <= premadeLevels[options.currentGameDir] ) then
					tmp:disable()
				else
					tmp:enable()
				end
			else
				if( currentMode == "edit" and firstMissing ) then
					tmp:enable()
					firstMissing = false
				else
					tmp:disable()
				end
			end

			count = count + 1
		end
	end

	existingLevels = 0
	for i = 1, 40 do
		if( io.exists(options.currentGameDir .. "/level" .. i .. ".txt",system.DocumentsDirectory ) ) then
			existingLevels = existingLevels + 1
		else
			break
		end	
	end

	print("Found " ..  existingLevels .. " levels")



	ssk.buttons:presetPush( layers.buttons, "default", 55, h-25, 100, 40, "Back", onBack )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	ssk.debug.monitorMem()
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	layers:removeSelf()
	layers = nil
end

-- ==
-- onLevel() - Play Game
-- ==
onLevel = function ( event )
	currentLevelNum = event.target.myLevelNum
	print(currentLevelNum)

	onBack()

	print(options.currentGameDir)

	if( currentMode == "play" ) then	
		playGUI[options.currentGameDir].create()
	else
		editGUI[options.currentGameDir].create()
	end
	
	ssk.debug.monitorMem()
end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end


----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
