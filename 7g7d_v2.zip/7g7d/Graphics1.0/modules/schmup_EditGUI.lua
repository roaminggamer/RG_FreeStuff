-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.
function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local edochi

local dragButton

local dragMode = false

local centerGroup

local currentEditMode = "player"
local editGroup
local editPuzzle = {}

local dragMode = false
local paletteLabel

-- Forward Declarations
local create 
local destroy

local createPiece
local drawLevel
local createPalette

local doClear
local doSave

local levelDragger

local removeIt

local onDone
local onEditTouch


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	imageWidth = 32
	halfPieceWidth = imageWidth/2
	halfBoardRowCol = 32

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/interface/protoBack.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	doClear()


	local path =  options.currentGameDir .."/level" .. currentLevelNum .. ".txt" 

	currentPuzzle = table.load( path )
	if( not currentPuzzle ) then 
		currentPuzzle = {} 
	end

	edochi = ssk.labels:quickLabel( layers.buttons, "edo", centerX, 40, nil, 12 )
	local exists = tostring( io.exists( path )  )
	edochi:setText(  exists .. " : " .. path  .. tostring(currentPuzzle) .. " : " .. tablelength(currentPuzzle))

	drawLevel()
	createPalette()

end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	doClear()
	layers:removeSelf()
	layers = nil
	backImage = nil
	paletteLabel = nil
	editGroup = nil
	centerGroup = nil
	dragButton = nil
end

-- ==
-- onDone() - EFM
-- ==
onDone = function( event ) 
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- createPalette() - EFM
-- ==
levelDragger = function( self, event )
	local phase = event.phase 
	if(phase == "began") then
		self.dragStartX = event.x
		self.dragStartY = event.y
	elseif(phase == "moved") then
		self.x = self.x + (event.x - self.dragStartX)
		self.y = self.y + (event.y - self.dragStartY)
		self.dragStartX = event.x
		self.dragStartY = event.y

	elseif(phase == "ended" or phase == "cancelled") then
	end
	return true
end

-- ==
-- EFM() - EFM
-- ==
doClear = function()
	if( editPuzzle ) then
		--table.dump( editPuzzle )
		for k,v in pairs(editPuzzle) do
			removeIt(v)
			--if(v.type == "green") then v.label:removeSelf() end
			--v:removeSelf()			
		end
	end
	currentPuzzle = {}
	editPuzzle = {}
end

-- ==
-- EFM() - EFM
-- ==
removeIt =  function( obj )

	
	if(obj.type == "green" and isDisplayObject(obj) and isDisplayObject(obj.label)) then 
		obj.label:removeSelf() 
	end
	timer.performWithDelay(1, function() if( isDisplayObject(obj) ) then obj:removeSelf() end end )			
end

-- ==
-- EFM() - EFM
-- ==
doSave =  function()
	currentPuzzle = {}
	for k,v in pairs( editPuzzle ) do
		--if(v.type ~= "blank" ) then
			local tmp = {}
			tmp.x = v.x
			tmp.y = v.y
			tmp.rotation = v.rotation
			tmp.curCount = v.curCount
			tmp.type = v.type
			currentPuzzle[#currentPuzzle+1] = tmp
		--end
	end
	table.save( currentPuzzle, options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )

	local path =  options.currentGameDir .."/level" .. currentLevelNum .. ".txt" 
	local exists = tostring( io.exists( path )  )
	edochi:setText(  exists .. " : " .. path  .. tostring(currentPuzzle) .. " : " .. tablelength(currentPuzzle))

end

-- ==
-- EFM() - EFM
-- ==
local function modeTouch( event )

	local newMode = event.target.mode

	if(newMode == "done") then
		if( dragMode ) then
			dragButton:toggle()
		end
		doSave()
		onDone()
		return true

	elseif(newMode == "+") then
		editGroup.xScale = editGroup.xScale + 0.1
		editGroup.yScale = editGroup.yScale + 0.1
		return true

	elseif(newMode == "-") then
		editGroup.xScale = editGroup.xScale - 0.1
		editGroup.yScale = editGroup.yScale - 0.1
		return true

	elseif(newMode == "1") then
		editGroup.xScale = 1
		editGroup.yScale = 1
		return true

	elseif(newMode == "clear") then
		if( dragMode ) then
			dragButton:toggle()
		end
		centerGroup:removeSelf()
		doClear()		
		drawLevel()
		return true

	elseif(newMode == "drag") then
		dragMode = event.target:pressed()
		print("dragMode == " .. tostring( dragMode ) )
		return true


	elseif(newMode == "test") then
		if( dragMode ) then
			dragButton:toggle()
		end

		doSave()		
		playGUI[options.currentGameDir].create()
		ssk.debug.monitorMem()
		onDone()
		return true

	elseif( newMode == "snap") then
		dragMode = event.target:pressed()
		print("dragMode == " .. tostring( dragMode ) )
		return true

	end

	if( dragMode ) then
		dragButton:toggle()
	end


	currentEditMode = newMode
	paletteLabel:setText( newMode )
	return true
end


-- ==
-- EFM() - EFM
-- ==
createPalette = function()

	dragMode = false
	local palette = display.newGroup()

	layers.palette:insert(palette)

	local paletteBack = ssk.display.rect( palette, 90, centerY, { width = 180, height = h , fill = _WHITE_, stroke = _CYAN_, strokeWidth = 2, alpha = 0.25 } )

	paletteLabel = ssk.labels:quickLabel( palette, "Edit", 90, 20, nil, 26 )

                
	-- Row 1 Piece Buttons
	local offset = 0
	local tmp
	local names = { "player", "wall", "goal", "blank"  }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], offset + i * 35, 60, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end
	
	-- Row 2 Piece Buttons
	local names = { "aimingTurret", "fixedTurret1", "fixedTurret2", "fixedTurret3" }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], offset + i * 35, 100, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end

	-- Row 3 Piece Buttons
	--local names = { "gem", "drop", "mover", "lightning" }
	local names = {  "drop", "mover", "lightning" }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], offset + i * 35, 140, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end

--[[
	-- Row 4 Piece Buttons
	local names = { "enemy" }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], offset + i * 35, 180, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end
--]]

	local bw = 60
	local offset = 25
	tmp = ssk.buttons:presetPush( palette, "default",   50, h - 100, 30, 30, "+", modeTouch, { mode = "+", fontSize = 14 } )
	tmp = ssk.buttons:presetPush( palette, "default", 90, h - 100, 30, 30, "-", modeTouch, { mode = "-", fontSize = 14 } )
	tmp = ssk.buttons:presetPush( palette, "default", 130, h - 100, 30, 30, "1:1", modeTouch, { mode = "1", fontSize = 14 } )
	
	tmp = ssk.buttons:presetPush( palette, "default", offset + bw/2 + 0 * bw, h - 60, bw, 30, "Reset", modeTouch, { mode = "clear", fontSize = 14 } )
	dragButton = ssk.buttons:presetToggle( palette, "default", offset + bw/2 + 1 * bw + 10, h - 60, bw, 30, "Drag", modeTouch, { mode = "drag", fontSize = 14 } )
	tmp = ssk.buttons:presetPush( palette, "default", offset + bw/2 + 0 * bw, h - 20, bw, 30, "Test", modeTouch, { mode = "test", fontSize = 14 } )
	tmp = ssk.buttons:presetPush( palette, "default", offset + bw/2 + 1 * bw + 10, h - 20, bw, 30, "Done", modeTouch, { mode = "done", fontSize = 14 } )
end

-- ==
-- EFM() - EFM
-- ==
onEditTouch = function ( self, event )

	if(dragMode) then return false end

	local phase = event.phase
	local type = self.type

	--print("\n=====\n",phase,type,currentEditMode)
	if(phase == "began") then
		display.getCurrentStage():setFocus(event.target)

	elseif(phase == "moved") then
	
	elseif(phase == "ended" or phase == "cancelled") then
		display.getCurrentStage():setFocus(nil)


		if( currentEditMode == "greenplus" and type == "green" ) then
			self.curCount = self.curCount + 1
			self.label:setText(self.curCount)
		
		elseif( currentEditMode == "greenminus" and type == "green" ) then
			self.curCount = self.curCount - 1
			if(self.curCount <= 0 ) then self.curCount = 1 end
			self.label:setText(self.curCount)
		
		elseif( ( currentEditMode == "greenplus" or currentEditMode == "greenminus" ) and type ~= "green" ) then

			editPuzzle[self] = nil
			removeIt(self)
			--timer.performWithDelay(1, function() self:removeSelf() end )

			local x = self.x
			local y = self.y
			local tmp = createPiece( editGroup, x, y, 1, "green" )

		
		elseif( currentEditMode ~= type ) then
			print(currentEditMode,type)
			editPuzzle[self] = nil
			removeIt(self)
			--if(self.type == "green") then self.label:removeSelf() end
			--timer.performWithDelay(1, function() self:removeSelf() end )			

			local x = self.x
			local y = self.y
			local tmp = createPiece( editGroup, x, y, 0, currentEditMode )

		elseif( type ~= "blank" and type ~= "player" and type ~= "goal" and type ~= "gem" ) then
			self.rotation = self.rotation + 90
			if(self.rotation >= 360) then self.rotation = 0 end
			doSave()
		end

		doSave()

	end

	return true
end

-- ==
-- EFM() - EFM
-- ==
createPiece = function ( group, x, y, curCount, type )
	--print("\n-------------------------------------------", system.getTimer())
	local tmp 

	--print("editPuzzle",editPuzzle)
	--table.dump(editPuzzle)
	
	-- Only allow one player 
	if(type == "player") then
		for k,v in pairs( editPuzzle ) do
			if (v.type == type) then
				createPiece( group, v.x, v.y, 0, "blank" )
				editPuzzle[k] = nil				
				removeIt(v)
				--timer.performWithDelay( 1, function() v:removeSelf() end )
				break
			end
		end
	end

	if( type == "blank" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/editorblank.png", { size = imageWidth } )  		
	elseif( type == "mover" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/moverEdit.png", { size = imageWidth } )  		
	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth } )  		
	end
	tmp.type = type	
	tmp.curCount = curCount

	if( type == "green" ) then
		tmp.label = ssk.labels:quickLabel( group, tmp.curCount, tmp.x, tmp.y, nil, 26 )
	end


	tmp.touch = onEditTouch
	tmp:addEventListener( "touch", tmp )

	editPuzzle[tmp] = tmp

	return tmp
end

-- ==
-- EFM() - EFM
-- ==
drawLevel = function( fill )

	dragMode = false

	editPuzzle = {}

	editGroup = display.newGroup()

	editGroup.touch = levelDragger
	editGroup:addEventListener( "touch", editGroup )

	centerGroup = display.newGroup()
	editGroup:insert(centerGroup)

	layers.content:insert(editGroup)

	local count = 0

	--table.dump(currentPuzzle)

	if(#currentPuzzle > 0 ) then
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type ~= "magnet" ) then
				local piece = createPiece( editGroup, tmp.x, tmp.y, tmp.curCount, tmp.type)	
				piece.rotation = tmp.rotation
				count = count + 1		
			end
		end
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type == "magnet" ) then
				createPiece( editGroup, tmp.x, tmp.y, tmp.curCount, tmp.type)	
				count = count + 1		
			end
		end
	else
		for i = -halfBoardRowCol, halfBoardRowCol do
			for j = -halfBoardRowCol, halfBoardRowCol do
				local x = j * imageWidth
				local y = i * imageWidth
				count = count + 1
				local piece = createPiece( editGroup, x, y, 0, "blank")			
			end
		end
	end
	print("Total blocks == " .. count )

	-- Add Center Cross (for reference)
	local tmp = display.newLine(centerGroup, -2 *  imageWidth,0, 2 * imageWidth, 0)
	tmp.width = 3
	tmp:setColor(255,0,0)
	local tmp = display.newLine(centerGroup, 0, -2 *  imageWidth, 0, 2 * imageWidth)
	tmp.width = 3
	tmp:setColor(255,0,0)
	centerGroup:toBack()


	--editGroup:scale( 0.55, 0.55 )
	editGroup:setReferencePoint( display.CenterReferencePoint )
	editGroup.x = centerX + 90
	editGroup.y = centerY

	local function onTouch( self, event )
		local phase = event.phase
		if(phase == "began") then
		elseif(phase == "ended") then
		end

		return true	
	end


end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
