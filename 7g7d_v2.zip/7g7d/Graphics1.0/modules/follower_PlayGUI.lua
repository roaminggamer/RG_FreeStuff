-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local planeSpeed = 50

local planeCount = 0

local planeTimer

local runway = {}


local imageWidth = 32
local slideTime = 250
local playPuzzle = {}

local allowTransitions = true

local thePlayer

local scoreLabel

-- Forward Declarations
local create 
local destroy

local createPlane
local createPiece
local createLevel

local landedCheck
local landedCheck2

local onCollision 
local onBack
local onHelp


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	runway["red"] = false
	runway["green"] = false
	runway["blue"] = false	

	planeCount = 0

	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "points", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	local function dummy( self, event ) return true end
	backImage.touch = dummy
	backImage:addEventListener( "touch", backImage )

	allowTransitions = true
	createLevel()	

	--planeTimer = timer.performWithDelay( 1000, createPlane )
	planeTimer = timer.performWithDelay( 0, createPlane )

	scoreLabel = ssk.labels:quickLabel( layers.content, 0, centerX, h-30, nil, 40 )
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroying level" )

	if( planeTimer ) then
		timer.cancel( planeTimer )
		planeTimer = nil
	end

	layers:removeSelf()
	layers = nil
	backImage = nil
	thePlayer = nil

	scoreLabel = nil
end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end




-- ==
-- createLevel() - EFM
-- ==
onCollision = function( self, event )
	local other = event.other
	local type  = other.type
	
	if( event.phase == "began" ) then
		if(other.isPlane) then
			print("Mid air collision" )
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay( 2000, onBack )
		end
	end
	return true
end

landedCheck =  function ( plane )

	if( not isDisplayObject( plane ) ) then return end

	local safe = false

	for k,v in pairs( playPuzzle ) do
		if( math.pointInRect( plane.x, plane.y,  v.x - v.width/2, v.y - v.height/2, v.width, v.height ) and
			v.type == plane.myColor ) then
			safe = true
		end
	end
	
	if( isDisplayObject(plane) and plane.myGroup ) then 
		plane.myGroup:removeSelf()
		plane.myGroup = nil
	end

	playPuzzle[plane] = nil
	plane:removeSelf()
	planeCount = planeCount - 1

	print("Decremented plane count", planeCount )

	if( safe ) then
		print("Plane is down safely")
		createPlane()
		local score = scoreLabel:getText()
		score = tonumber(score)
		score = score + 1

		scoreLabel:setText(score)
		ssk.gem:post( "PLAY_EFFECT" , { effectName = "good" } )
	else
		print("Plane crashed")
		ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
		timer.performWithDelay( 2000, onBack )
	end
end

landedCheck2 =  function ( plane )

	if( not isDisplayObject( plane ) ) then return end

	local safe = false

	for k,v in pairs( playPuzzle ) do
		if( math.pointInRect( plane.x, plane.y,  v.x - v.width/2, v.y - v.height/2, v.width, v.height ) and
			v.type == plane.myColor ) then
			safe = true
		end
	end
	
	if( safe ) then
		print("Plane is down safely")
		createPlane()
	else
		print("Plane crashed")
		timer.performWithDelay( 2000, onBack )
	end
end


local function land( plane )
	if( not isDisplayObject( plane ) ) then return end
	if( not plane.landing ) then
		plane.landing = true
		transition.to( plane, { xScale = 0.5, yScale = 0.5, onComplete = landedCheck, time = 2000 } )
	end	
end

local function landingCheck( plane )
	if( not isDisplayObject( plane ) ) then return end
	for k,v in pairs( playPuzzle ) do
		if( math.pointInRect( plane.x, plane.y,  v.x - v.width/2, v.y - v.height/2, v.width, v.height ) and
			v.type == plane.myColor ) then
			land( plane )
			return
		end
	end
end

local function followPath( plane )
	plane.following = true

	landingCheck( plane )

	if( not plane.myGroup ) then 
		plane.following = false
		return 
	end

	plane.curPoint = plane.curPoint + 1

	local point = plane.myGroup[plane.curPoint]

	if( not point ) then
		plane.following = false

		if( isDisplayObject(plane) and plane.myGroup ) then
			plane.myGroup:removeSelf()
			plane.myGroup = nil
		end

		local vec = ssk.math2d.angle2Vector( plane.rotation, true )
		vec = ssk.math2d.scale( vec, w )
		vec = ssk.math2d.add( vec.x, vec.y, plane.x, plane.y, true )

		local len = ssk.math2d.length(vec) 	
		local time = 1000 * len/planeSpeed 
		
		plane.lastTransition = transition.to( plane, { x = vec.x, y = vec.y, time = time, onComplete = landedCheck2 } )
		
		--landedCheck2( plane )
		return 
	end

	if( plane.curPoint > 1 ) then
		local point2 = plane.myGroup[plane.curPoint-1]
		point2.isVisible = false
	end

	local toVec = ssk.math2d.sub( plane.x, plane.y, point.x, point.y, true )
	local angle = ssk.math2d.vector2Angle( toVec )

	local len = ssk.math2d.length(toVec) 

	local time = 1000 * len/planeSpeed
	

	transition.to( plane, { rotation = angle, time = time/2 } )
	transition.to( plane, { x = point.x, y = point.y, time = time, onComplete = followPath } )

end


local function onTouch( self, event )
	local phase = event.phase

	local minDist2 = (imageWidth/2)^2

	if(phase == "began") then
		display.getCurrentStage():setFocus(event.target)
		if( self.myLine ) then 
			self.myLine = {}
		end

		if( isDisplayObject(self) and self.myGroup ) then
			self.myGroup:removeSelf()
			self.myGroup = nil			
		end

		if( self.lastTransition ) then
			transition.cancel( self.lastTransition )
			self.lastTransition = nil
		end


		self.curPoint = 0

		self.lastPos = { x = event.x, y = event.y }

		self.myGroup = display.newGroup()
		layers.points:insert( self.myGroup )

		self.following = false

	elseif(phase == "moved") then

		if( self.myGroup ) then
			local tweenVec = ssk.math2d.sub( event, self.lastPos )

			local len2 = ssk.math2d.squarelength( tweenVec )

			if( len2 >= minDist2 ) then
				local point = { x = event.x,  y = event.y }
				local pointImg = ssk.display.circle( self.myGroup, event.x, event.y, { radius = 2, fill = _BLACK_ } )
				self.lastPos = { x = event.x, y = event.y }

				if(not self.following) then
					followPath( self )
				end
			end
		end

	elseif(phase == "ended") then
		display.getCurrentStage():setFocus(nil)
	end

	return true	
end

createPiece = function ( group, x, y, rotation, type )
	--print("creating: ", type)
	local tmp 
	tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { isSensor = true }  )  	
	tmp.type = type		
	
	runway[type] = true

	playPuzzle[tmp] = tmp
	return tmp
end

local function planeDone( self )
	print("Transition done")
	createPlane()
end

createPlane = function( )

	if( not isDisplayObject(layers) ) then return end

	print("Current plane count: ", planeCount)


	if( planeCount > 0 ) then
		planeTimer = timer.performWithDelay( 2000, createPlane )
	else

		local colors = { "red", "green", "blue" }

		local curColor = colors[math.random(1,#colors)]

		print(tostring(runway["red"]))
		print(tostring(runway["green"]))
		print(tostring(runway["blue"]))

		while( not runway[curColor]) do
			curColor = colors[math.random(1,#colors)]
		end

		local x = centerX
		local y = centerY

		local startX
		local startY

		if( math.random(1,2) == 1 ) then
			startX = centerX + w/2 + math.random(30, 60)
			if( math.random(1,2) == 1 ) then
				startY = centerY + h/2 + math.random(30, 60)
			else
				startY = centerY - h/2 - math.random(30, 60)
			end
		else
			startX = centerX - w/2 - math.random(30, 60)
			if( math.random(1,2) == 1 ) then
				startY = centerY + h/2 + math.random(30, 60)
			else
				startY = centerY - h/2 - math.random(30, 60)
			end
		end

		local toVec = ssk.math2d.sub( startX, startY, centerX, centerY, true )
		toVec = ssk.math2d.scale( toVec, 2.25 )
		local angle = ssk.math2d.vector2Angle( toVec )

		local len = ssk.math2d.length(toVec) 
	
		local time = 1000 * len/planeSpeed 

		local plane = ssk.display.imageRect( layers.content, startX, startY, "images/" .. options.currentGameDir .. "/" .. curColor .. "Plane.png", { size = 30 }, { isSensor = true }  )  	
		--local plane = ssk.display.imageRect( layers.content, centerX, centerY, "images/" .. options.currentGameDir .. "/" .. curColor .. "Plane.png", { size = 30 }, { isSensor = true }  )  	

		plane.rotation = angle
		plane.isPlane  = true
		plane.speed    = speed

		plane.myColor = curColor

		plane.touch = onTouch
		plane:addEventListener( "touch", plane )

		plane.collision = onCollision
		plane:addEventListener( "collision", plane )

		--plane.lastTransition = transition.to( plane, { x = toVec.x, y = toVec.y, time = time, onComplete = planeDone } )
		plane.lastTransition = transition.to( plane, { x = toVec.x, y = toVec.y, time = time, onComplete = landedCheck2 } )


		print("Create ", curColor, " plane") 

		planeCount = planeCount + 1

		planeTimer = timer.performWithDelay( 2000, createPlane )

	end
end


createLevel = function()

	local piece
	playPuzzle = {}

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]
		if(tmp.type ~= "blank") then
			piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type)	
			count = count + 1		
		end
	end

	print("Total blocks == " .. count )

	-- Locate Start Block
	local startBlock
	for k,v in pairs( playPuzzle ) do
		if (v.type == "player" ) then
			startBlock = v
		end
	end
			
	local startX = - 20
	local startY = centerY
	local startR = 0
	
	if( startBlock ) then
		startX = startBlock.x
		startY = startBlock.y
		startR = startBlock.rotation
	end

	local v = ssk.math2d.angle2Vector( startR, true )
	--table.dump(v)

	v = ssk.math2d.scale( v, 75 )

end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
