-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local imageWidth = 32
local slideTime = 250
local playPuzzle = {}

local allowTransitions = true

local thePlayer

-- Forward Declarations
local create 
local destroy

local createPiece
local createLevel

local onCollision 
local onBack
local onHelp


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back2.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	allowTransitions = true
	createLevel()	
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroyoing level" )

	layers:removeSelf()
	layers = nil
	backImage = nil
	thePlayer = nil
end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end



-- ==
-- createLevel() - EFM
-- ==
onCollision = function( self, event )
	local other = event.other
	local type  = other.type
	
	if( event.phase == "began" ) then
		print(event.phase, type)		
		if( type == "goal" ) then
			allowTransitions = false

			local pass = true
			for k,v in pairs( playPuzzle ) do
				if( v.curCount and v.curCount > 0 ) then
					print(v.curCount)
					pass = false
				end
			end

			if( pass ) then
				currentLevelNum = currentLevelNum + 1
				ssk.gem:post( "PLAY_EFFECT" , { effectName = "win1" } )	
			else
				ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			end

			print("*****  In goal code", currentLevelNum, existingLevels)
			if( currentLevelNum > existingLevels ) then
				currentLevelNum = 1
			end

			if( pass) then
				timer.performWithDelay(2000, 
					function() 
						destroy()
						create ()
					end )
			else
				timer.performWithDelay(500, 
					function() 
						destroy()
						create ()
					end )
			end

		elseif( type == "green") then
			print("*****  In green code=: ", other.curCount)
			other.curCount = other.curCount - 1
			if( other.curCount <= 0 ) then
				timer.performWithDelay(200, 
					function() 
						other.label:removeSelf()
						other:removeSelf()
						other.curCount = 0						
					end )
			else
				timer.performWithDelay(200, 
					function() 
						other.label:setText( other.curCount )
					end )
			end

		elseif( not self.blockTele and 
			(type == "blueTele" or
		    type == "greenTele"  or
			type == "redTele") ) then

			print("====> BOOP", self.blockTele, system.getTimer(), "\n\n")
			local targetTele

			for k,v in pairs( playPuzzle ) do 
				if( v.type == type and v ~= other) then
					targetTele = v
				end
			end

			if( targetTele ) then
				print("Teleporting at: ", system.getTimer() ) 

				self.blockTele = true

				if( self.lastTrans ) then
					transition.cancel(self.lastTrans)
					self.lastTrans = nil
				end

				timer.performWithDelay( 250, 
					function()				
						self:toFront()
						self.x = targetTele.x
						self.y = targetTele.y					
					end )

				timer.performWithDelay( 500, 
					function()				
						self.blockTele = false
					end )
			end
		end

	elseif( event.phase == "ended" ) then							
	end
	return true
end

local function onTouch( self, event )
	local phase = event.phase
	if(phase == "ended") then
		if( self.type ~= "player" ) then
			local px = thePlayer.x
			local py = thePlayer.y
			local tx = self.x
			local ty = self.y

			if( tx > px and ty == py ) then -- Right		
				print("right")	

				thePlayer.goalX = tx
				thePlayer.goalY = ty
				
				local attemptMoveRight
				attemptMoveRight = function ( player )					
					if( not allowTransitions ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end
					if( player.x == player.goalX and player.y == player.goalY ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end

					print( player.x, player.y, player.x + imageWidth, player.y ) 

					local hits = physics.rayCast( player.x, player.y, player.x + imageWidth, player.y, 3 )					
					if(hits and #hits > 0) then
						print( "Hit count to right: " .. tostring( #hits ) )
						player:toFront()
						player.lastTrans = transition.to( player, {x = hits[1].object.x, time = slideTime, onComplete = attemptMoveRight } )
					else
						player.goalX = nil
						player.goalY = nil
					end
				end
				attemptMoveRight(thePlayer)


			elseif( tx < px and ty == py ) then -- Left
				print("left")

				thePlayer.goalX = tx
				thePlayer.goalY = ty
				
				local attemptMoveLeft
				attemptMoveLeft = function ( player )					
					if( not allowTransitions ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end
					if( player.x == player.goalX and player.y == player.goalY ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end

					print( player.x, player.y, player.x - imageWidth, player.y ) 

					local hits = physics.rayCast( player.x, player.y, player.x - imageWidth, player.y, 3 )					
					if(hits and #hits > 0) then
						print( "Hit count to left: " .. tostring( #hits ) )
						player:toFront()
						transition.to( player, {x = hits[1].object.x, time = slideTime, onComplete = attemptMoveLeft } )
					else
						player.goalX = nil
						player.goalY = nil
					end
				end
				attemptMoveLeft(thePlayer)


			elseif( ty < py and tx == px ) then -- Up
				print("up")

				thePlayer.goalX = tx
				thePlayer.goalY = ty
				
				local attemptMoveUp
				attemptMoveUp = function ( player )					
					if( not allowTransitions ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end
					if( player.x == player.goalX and player.y == player.goalY ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end

					print( player.x, player.y, player.x, player.y - imageWidth ) 

					local hits = physics.rayCast( player.x, player.y, player.x , player.y - imageWidth, 3 )					
					if(hits and #hits > 0) then
						print( "Hit count to up: " .. tostring( #hits ) )
						player:toFront()
						transition.to( player, {y = hits[1].object.y, time = slideTime, onComplete = attemptMoveUp } )
					else
						player.goalX = nil
						player.goalY = nil
					end
				end
				attemptMoveUp(thePlayer)


			elseif( ty > py and tx == px  ) then -- Down
				print("down")

				thePlayer.goalX = tx
				thePlayer.goalY = ty
				
				local attemptMoveDown
				attemptMoveDown = function ( player )					
					if( not allowTransitions ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end
					if( player.x == player.goalX and player.y == player.goalY ) then 
						player.goalX = nil
						player.goalY = nil
						return
					end

					print( player.x, player.y, player.x, player.y + imageWidth ) 

					local hits = physics.rayCast( player.x, player.y, player.x , player.y + imageWidth, 3 )					
					if(hits and #hits > 0) then
						print( "Hit count to down: " .. tostring( #hits ) )
						player:toFront()
						transition.to( player, {y = hits[1].object.y, time = slideTime, onComplete = attemptMoveDown } )
					else
						player.goalX = nil
						player.goalY = nil
					end
				end
				attemptMoveDown(thePlayer)

			else
				print("diagonal - ignore")
			end

			print(self.type,self.curCount)
		end
	end
	return true	
end


createPiece = function ( group, x, y, rotation, type, curCount, myCC )
	--print("creating: ", type)
	local tmp 

	if( type == "player" ) then
		createPiece( group, x, y, rotation, "blue", 0, myCC )
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth - 2 }, { calculator = myCC, colliderName = type }  )
		thePlayer = tmp
		tmp.collision = onCollision
		tmp:addEventListener( "collision", tmp )
	elseif( type == "green" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	
		tmp.curCount = curCount
		tmp.label = ssk.labels:quickLabel( group, tmp.curCount, tmp.x, tmp.y, nil, 26 )
	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	
	end
	tmp.type = type		
	
	-- 
	tmp.touch = onTouch
	tmp:addEventListener( "touch", tmp )

	playPuzzle[tmp] = tmp

	return tmp
end

createLevel = function()
	local myCC = ssk.ccmgr:newCalculator()
	myCC:addName("player")
	myCC:addName("green")
	myCC:addName("goal")
	myCC:addName("blue")
	myCC:addName("blueTele")
	myCC:addName("greenTele")
	myCC:addName("redTele")
	myCC:collidesWith( "player", "green", "goal", "blueTele", "greenTele", "redTele" )

	local piece
	playPuzzle = {}

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]
		if(tmp.type ~= "blank") then
			piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type, tmp.curCount, myCC)	
			count = count + 1		
		end
	end

	print("Total blocks == " .. count )

	-- Locate Start Block
	local startBlock
	for k,v in pairs( playPuzzle ) do
		if (v.type == "player" ) then
			startBlock = v
		end
	end
			
	local startX = - 20
	local startY = centerY
	local startR = 0
	
	if( startBlock ) then
		startX = startBlock.x
		startY = startBlock.y
		startR = startBlock.rotation
	end

	local v = ssk.math2d.angle2Vector( startR, true )
	--table.dump(v)

	v = ssk.math2d.scale( v, 75 )

end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
