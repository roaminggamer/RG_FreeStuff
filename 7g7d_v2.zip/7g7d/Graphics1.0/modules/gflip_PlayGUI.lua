-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local ignoreCollisions = false


local slideTime = 250
local playPuzzle = {}
local allowTransitions = true
local thePlayer
local gravityArrow

local gravityMagnitude = 0

local gravityAngle = 180

-- Forward Declarations
local create 
local destroy

local createPiece
local createLevel

local onCollision 
local onBack
local onHelp

local joystickListener


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	imageWidth = 32
	halfPieceWidth = imageWidth/2
	halfBoardRowCol = 8


	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content",  "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	allowTransitions = true
	ignoreCollisions = false
	createLevel()	

	gravityArrow = ssk.display.imageRect( layers.buttons, 50, 50, "images/" .. options.currentGameDir .. "/arrow.png", { size = 40, rotation = gravityAngle, alpha = 0.25} )  		

	backImage.touch = joystickListener
	backImage:addEventListener( "touch", backImage )

--[[
	ssk.inputs:createJoystick( layers.buttons, w - 100, h - 100, 
								   { eventName = "myJoystickEvent",  inputObj = backImage,
									 inUseAlpha = 0.7, notInUseAlpha = 0.05, useAlphaFadeTime = 250,
									 outerStrokeColor = _WHITE_, outerAlpha = 0,
									 stickImg = "images/" .. options.currentGameDir .. "/dpad.png", stickRadius = 45,
									 deadZoneRadius = 9 } )
	ssk.gem:add("myJoystickEvent", joystickListener)
--]]
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroyoing level" )
	
	ssk.gem:remove("myJoystickEvent", joystickListener)

	layers:removeSelf()
	layers = nil
	backImage = nil
	thePlayer = nil

	physics.setGravity(0,0)
end


-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end



-- ==
-- createLevel() - EFM
-- ==
onCollision = function( self, event )
	local other = event.other
	local type  = other.type

	if( ignoreCollisions ) then return true end
	
	if( event.phase == "began" ) then
		print(event.phase, type)		
		if( type == "goal" ) then
			ignoreCollisions = true
			currentLevelNum = currentLevelNum + 1
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "win1" } )	
			print("*****  In goal code", currentLevelNum, existingLevels)
			if( currentLevelNum > existingLevels ) then
				currentLevelNum = 1
			end
			allowTransitions = false
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
				end )
		elseif( type == "danger" or type == "danger2" or type == "danger3") then
			ignoreCollisions = true
			print("*****  In danger code", currentLevelNum, existingLevels)
			allowTransitions = false
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
				end )
		end

	elseif( event.phase == "ended" ) then							
		if( type == "green") then
			print("*****  In green code=: ", other.curCount)
			other.curCount = other.curCount - 1
			if( other.curCount <= 0 ) then
				timer.performWithDelay(10, 
					function() 
						other.label:removeSelf()
						other:removeSelf()
					end )
			else
				other.label:setText( other.curCount )
			end
		end
	end
	return true
end



createPiece = function ( group, x, y, rotation, type, curCount, myCC )
	--print("creating: ", type)
	local tmp 

	if( type == "player" ) then
		tmp = ssk.display.circle( group, x, y, { size = imageWidth - 2, fill = _GREEN_ }, { density = 1, calculator = myCC, colliderName = type, bounce = 0.3, friction = 1 }  )
		thePlayer = tmp
		tmp.collision = onCollision
		tmp:addEventListener( "collision", tmp )
	elseif( type == "goal" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	
	
	elseif( type == "danger" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	
	
	elseif( type == "danger2" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, {  density = 1, calculator = myCC, colliderName = type, bodyType = "dynamic", radius = imageWidth/2 - 2, friction = 0 }  )  	
		tmp.gravityScale = 0.5
		tmp:applyAngularImpulse(15)

	elseif( type == "danger3" ) then
		local mount = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/blank.png", { size = imageWidth }, {  density = 1, calculator = myCC, colliderName = "blank", bodyType = "static", radius = 2, friction = 0 }  )  	
		playPuzzle[mount] = mount

	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, {  density = 1, calculator = myCC, colliderName = type, bodyType = "dynamic", radius = imageWidth/2 - 2, friction = 0 }  )  	

		tmp:applyAngularImpulse(15)

		local joint = physics.newJoint( "pivot", tmp, mount, x,y )
		
	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth }, { calculator = myCC, colliderName = type, isSensor = false, bodyType = "static", bounce = 0.3 }  )  	
	end
	tmp.type = type		
	
	-- 
	--tmp.touch = onTouch
	--tmp:addEventListener( "touch", tmp )

	playPuzzle[tmp] = tmp

	return tmp
end

createLevel = function()

	local myCC = ssk.ccmgr:newCalculator()
	myCC:addName("player")
	myCC:addName("safe")
	myCC:addName("danger")
	myCC:addName("danger2")
	myCC:addName("danger3")
	myCC:addName("goal")
	myCC:addName("blank")
	
	myCC:collidesWith( "player", "safe", "danger", "goal"  )
	myCC:collidesWith( "danger2", "player", "safe", "danger"  )
	myCC:collidesWith( "danger3", "player", "safe", "danger"  )


	local piece
	playPuzzle = {}

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]
		piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type, tmp.curCount, myCC)	
		count = count + 1		
	end

	print("Total blocks == " .. count )

	-- Locate Start Block
	local startBlock
	for k,v in pairs( playPuzzle ) do
		if (v.type == "player" ) then
			startBlock = v
		end
	end
			
	local startX = - 20
	local startY = centerY
	local startR = 0
	
	if( startBlock ) then
		startX = startBlock.x
		startY = startBlock.y
		startR = startBlock.rotation
	end

	local v = ssk.math2d.angle2Vector( startR, true )
	--table.dump(v)

	v = ssk.math2d.scale( v, 75 )
		
	layers.content:setReferencePoint( display.CenterReferencePoint )
	layers.content.x = centerX
	layers.content.y = centerY
	layers.content:scale(0.5, 0.5)

	layers.content.timer = 
		function (self) 
			self.rotation = self.rotation + 0.25 
			
			if( self.rotation >= 360 ) then 
				self.rotation = self.rotation - 360 
			end

			local rotateBackAngle = -self.rotation

			local playerAngle = rotateBackAngle

			thePlayer.rotation = playerAngle

			local gVec = { x = 0, y = -1 }

			local gAngle = ssk.math2d.vector2Angle( gVec )

			gAngle = gravityAngle

			local gVec2 = ssk.math2d.angle2Vector( gAngle + rotateBackAngle , true )

			gVec2 = ssk.math2d.scale( gVec2, 10 * gravityMagnitude )

			--print( gAngle, gAngle + rotateBackAngle, round( gVec2.x, 4),  round( gVec2.y, 4) )

			physics.setGravity(gVec2.x, gVec2.y)

		end
	timer.performWithDelay( 30, layers.content, 0 )

end

-- ==
--	joystickListener() - This function interprets all joystick inputs into rotation, thrusting, and firing
-- ==
joystickListener = function( self, event )
	--table.dump(event)

	local deadZone = 10
	local maxLen = 110

	local tmpMag 
	local tmpAlpha = 0.2 


	if( event.phase == "began" ) then
	elseif( event.phase == "moved" ) then
		local v = ssk.math2d.sub( event.xStart, event.yStart, event.x, event.y, true ) 
		local len = ssk.math2d.length( v )
		local angle = ssk.math2d.vector2Angle( v )
		print( v.x,v.y, len, angle )


		gravityAngle = angle
		gravityArrow.rotation = angle

		if( len <= deadZone ) then
			tmpMag = 0
		elseif( len > maxLen ) then
			tmpMag = 1
		else
			tmpMag = len/( maxLen - deadZone )
		end

		gravityMagnitude = tmpMag

		tmpAlpha = tmpAlpha + tmpMag

		if( tmpAlpha > 1 ) then
			tmpAlpha = 1
		end

		gravityArrow.alpha = gravityMagnitude
		gravityArrow.alpha = tmpAlpha 

		print( event.xStart, event.yStart, event.x, event.y, " :", tmpMag, len, deadZone, maxLen ) 

	elseif( event.phase == "ended" or event.phase == "cancelled" ) then

		gravityMagnitude = 0 --.1
		gravityArrow.alpha = tmpAlpha 

	end

	return true
end


joystickListener_old = function( event )
	--table.dump(event)
	--local labelNames = {"vx", "vy", "nx", "ny", "percent", "phase", "state", "angle", "direction" }
	
	local phase = event.phase
	local state = event.state
	local angle = event.angle
	local percent = event.percent/100

	gravityAngle = angle
	gravityArrow.rotation = angle
	gravityMagnitude = percent
	local tmpAlpha = 0.25 + percent
	if(tmpAlpha > 1) then tmpAlpha = 1 end
	gravityArrow.alpha = tmpAlpha
	if(gravityArrow.alpha > 1) then gravityArrow.alpha = 1 end


	--print(state, percent)
	if( phase == "began" ) then
	elseif( phase == "moved" ) then
	elseif( phase == "ended" or phase == "cancelled" ) then
	end

	return true
end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
