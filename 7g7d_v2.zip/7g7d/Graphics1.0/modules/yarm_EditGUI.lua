-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local currentEditMode = "player"
local editGroup
local editPuzzle = {}

local snapMode = false
local paletteLabel

-- Forward Declarations
local create 
local destroy

local createPiece
local drawLevel
local createPalette

local doClear
local doSave


local onDone
local onEditTouch


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/interface/protoBack.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	doClear()

	if( io.exists( options.currentGameDir .."/level" .. currentLevelNum .. ".txt",system.DocumentsDirectory ) ) then
		currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
	else
		currentPuzzle = {}
	end

	drawLevel()
	createPalette()
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	doClear()
	layers:removeSelf()
	layers = nil
	backImage = nil
	paletteLabel = nil
	editGroup = {}	
end

-- ==
-- onDone() - EFM
-- ==
onDone = function( event ) 
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- createPalette() - EFM
-- ==
local function paletteDragger( self, event )
	local phase = event.phase 
	if(phase == "began") then
		self.dragStartX = event.x
		self.dragStartY = event.y
	elseif(phase == "moved") then
		self.x = self.x + (event.x - self.dragStartX)
		self.y = self.y + (event.y - self.dragStartY)
		self.dragStartX = event.x
		self.dragStartY = event.y

	elseif(phase == "ended" or phase == "cancelled") then
	end
	return true
end

-- ==
-- EFM() - EFM
-- ==
doClear = function()
	if( editPuzzle ) then
		--table.dump( editPuzzle )
		for k,v in pairs(editPuzzle) do
			v:removeSelf()
		end
	end
	currentPuzzle = {}
	editPuzzle = {}
end

-- ==
-- EFM() - EFM
-- ==
doSave =  function()
	currentPuzzle = {}
	for k,v in pairs( editPuzzle ) do
		local tmp = {}
		tmp.x = v.x
		tmp.y = v.y
		tmp.rotation = v.rotation
		tmp.type = v.type
		currentPuzzle[#currentPuzzle+1] = tmp
	end
	table.save( currentPuzzle, options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
end

-- ==
-- EFM() - EFM
-- ==
local function modeTouch( event )

	if(event.target.mode == "done") then
		doSave()
		onDone()
		return true

	elseif(event.target.mode == "clear") then
		doClear()		
		drawLevel()
		return true

	elseif(event.target.mode == "fill") then
		for k,v in pairs(editPuzzle) do
			v:removeSelf()
		end
		currentPuzzle = {}
		editPuzzle = {}
		drawLevel( true )
		return true


	elseif(event.target.mode == "test") then
		doSave()		
		playGUI[options.currentGameDir].create()
		ssk.debug.monitorMem()
		onDone()
		return true

	elseif( event.target.mode == "snap") then
		snapMode = event.target:pressed()
		print("snapMode == " .. tostring( snapMode ) )
		return true
	end

	currentEditMode = event.target.mode
	paletteLabel:setText( event.target.mode )
	print("currentEditMode == " .. currentEditMode ) 
	return true
end


-- ==
-- EFM() - EFM
-- ==
createPalette = function()

	snapMode = false
	local palette = display.newGroup()
	palette.touch = paletteDragger
	palette:addEventListener( "touch", palette )

	layers.palette:insert(palette)

	local paletteBack = ssk.display.rect( palette, centerX, centerY + 20, { width = 300, height = 160 , fill = _GREEN_, stroke = _CYAN_, strokeWidth = 2, alpha = 0.35 } )

	paletteLabel = ssk.labels:quickLabel( palette, "Edit", centerX, centerY - 38, nil, 26 )

	local tmp
	local names = {"player", "goal", "danger", "unlocker", "anchor", "pull", "push", "blank" }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], centerX - 155 + i * 35, centerY, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end

	tmp = ssk.buttons:presetPush( palette, "default", centerX - 110, centerY + 45, 50, 30, "Clear", modeTouch, { mode = "clear" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX - 55, centerY + 45, 50, 30, "Fill", modeTouch, { mode = "fill" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX, centerY + 45, 50, 30, "Test", modeTouch, { mode = "test" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX + 55, centerY + 45, 50, 30, "Done", modeTouch, { mode = "done" } )
	tmp = ssk.buttons:presetToggle( palette, "default", centerX + 110, centerY + 45, 50, 30, "Snap", modeTouch, { mode = "snap" } )
end

-- ==
-- EFM() - EFM
-- ==
onEditTouch = function ( self, event )

	-- local names = {"player", "goal", "danger", "unlocker", "anchor", "pull", "push", "blank" }
	local phase = event.phase
	local type = self.type

	print("\n=====\n",phase,type,currentEditMode, self.dragged)
	if(phase == "began") then
		display.getCurrentStage():setFocus(event.target)
		if( type ~= "backImage" ) then
			self.dragStartX = event.x
			self.dragStartY = event.y
			self.dragged = false
		end


	elseif(phase == "moved") then
		if( type ~= "backImage" ) then

			local vec = ssk.math2d.sub( self, event )
			len = ssk.math2d.length(  vec )
			if( self.dragged == false and len < 10 and type == "player") then
			else
				local deltaX = self.x + (event.x - self.dragStartX)
				local deltaY = self.y + (event.y - self.dragStartY)

				self.dragged = true

				if(snapMode) then	
					local halfWidth = self.width/2				
					if( deltaX % halfWidth == 0 ) then
						self.x = deltaX
						self.dragStartX = event.x
					end
					if( deltaY % halfWidth == 0 ) then
						self.y= deltaY
						self.dragStartY = event.y
					end
				else
					self.x = deltaX
					self.dragStartX = event.x
					self.y= deltaY
					self.dragStartY = event.y
				end
			end
		end	
		
	
	elseif(phase == "ended" or phase == "cancelled") then
		display.getCurrentStage():setFocus(nil)

		if( currentEditMode == "blank" and type ~= "backImage") then
			editPuzzle[self] = nil
			timer.performWithDelay(1, function() self:removeSelf() end )

		elseif( type == "backImage" ) then
			local x = event.x
			local y = event.y
			local tmp = createPiece( editGroup, x, y, 0, currentEditMode )
			--tmp:toBack()
		end

		if( self.dragged == false and type == "player") then
			if(self.rotation == 270 ) then
				self.rotation = 0 
			else
				self.rotation = self.rotation + 90
			end
		end

		doSave()

	end

	return true
end

-- ==
-- EFM() - EFM
-- ==
createPiece = function ( group, x, y, rotation, type )
	--print("\n-------------------------------------------", system.getTimer())
	local tmp 

	--print("editPuzzle",editPuzzle)
	--table.dump(editPuzzle)
	
	-- Only allow one player 
	if(type == "player") then
		for k,v in pairs( editPuzzle ) do
			if (v.type == type) then
				editPuzzle[k] = nil				
				timer.performWithDelay( 1, function() v:removeSelf() end )
			end
		end
	end


	tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = 20 } )  	
	
	tmp.type = type	

	tmp.rotation = rotation	

	tmp.touch = onEditTouch
	tmp:addEventListener( "touch", tmp )

	editPuzzle[tmp] = tmp

	return tmp
end

-- ==
-- EFM() - EFM
-- ==
drawLevel = function( fill )

	editPuzzle = {}

	local myCC = ssk.ccmgr:newCalculator()
	myCC:addName("player")
	myCC:addName("wall")
	myCC:addName("magnet")
	myCC:collidesWith( "player", "wall" )

	editGroup = display.newGroup()

	layers.content:insert(editGroup)

	local count = 0

	--table.dump(currentPuzzle)

	if(#currentPuzzle > 0 ) then
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type ~= "magnet" ) then
				createPiece( editGroup, tmp.x, tmp.y, tmp.rotation, tmp.type)	
				count = count + 1		
			end
		end
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type == "magnet" ) then
				createPiece( editGroup, tmp.x, tmp.y, tmp.rotation, tmp.type)	
				count = count + 1		
			end
		end
	elseif( fill ) then
		for x = 10, w-10, 20 do
			for y = 10, h-10, 20 do
				count = count + 1
				createPiece( editGroup, x, y, 0, "danger")			
			end
		end
	end
	print("Total blocks == " .. count )

	--editGroup:scale( 0.8, 0.8 )
	--editGroup:setReferencePoint( display.CenterReferencePoint )
	--editGroup.x = w * 0.1
	--editGroup.y= h * 0.1


	local function onTouch( self, event )
		local phase = event.phase
		if(phase == "began") then
		elseif(phase == "ended") then
		end

		return true	
	end
	-- Add dummy touch catcher to backImage to keep touches from 'falling through'
	--backImage.touch = onTouch
	--backImage:addEventListener( "touch", backImage )
	backImage.type = "backImage"
	backImage.touch = onEditTouch
	backImage:addEventListener( "touch", backImage )


	for k,v in pairs( editPuzzle ) do
		if( v.type == "pull" ) then
			v:toFront()
		elseif( v.type == "anchor" ) then
			v:toFront()
		elseif( v.type == "push" ) then
			v:toFront()
		end
	end


end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
