-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 

local effectsSlider
local musicSlider

-- Forward Declarations
local create 
local destroy

local onBack

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "buttons", "overlay" )

	local backImage
	if(build_settings.orientation.default == "landscapeRight") then
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Landscape.jpg" )
		backImage = display.newImage( layers.background, "images/back2r.png" )
	else
		--backImage = display.newImage( layers.background, "images/interface/RGSplash2_Portrait.jpg" )
		backImage = display.newImage( layers.background, "images/back2.png" )
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	-- Add dummy touch catcher to backImage to keep touches from 'falling through'
	backImage.touch = function() return true end
	backImage:addEventListener( "touch", backImage )


	-- Labels and Buttons
	ssk.labels:quickLabel( layers.buttons, "About", centerX, 30, nil, 30 )

	local text = 
	"Hi!  These games were created as part of a personal challenge\n" ..
	"and to warm up the old brain cells for the 2013 GIGJam48.\n\n" .. 
	"My original challenge was to complete 7-Games-in-7-Days.  \n" ..
	"I finished 6 out 7, which ain't too shabby.\n" ..
	"\n" ..
	"'You Attract\Repel Me' was inspired by Magnetized:\n" ..
	"http://www.kongregate.com/games/rocky10529/magnetized\n" ..
	"\n" ..
	"The sound track is 'Call to Adventure!' by Kevin MacLeod\n" ..
	"\n" ..
	"The ship in 'Simple Schump' is by Dave Toulouse @ www.over00.com\n" ..
	"\n" ..
	"Everything else in the games was made by me."


--http://www.kongregate.com/games/rocky10529/magnetized

	ssk.labels:quickLabel( layers.buttons, text , centerX, centerY+5, nil, 11 )
	
	ssk.buttons:presetPush( layers.buttons, "default", 55, h-25, 100, 40, "Back", onBack )
	--ssk.buttons:presetPush( layers.buttons, "default", w-55, h-25, 100, 40, "Credits", onCredits )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	layers:removeSelf()
	layers = nil
	effectsSlider = nil
	musicSlider = nil

end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end



----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
