-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local imageWidth = 32
local halfWidth = imageWidth/2

local currentEditMode = "player"
local editGroup
local editPuzzle = {}

local snapMode = false
local paletteLabel

-- Forward Declarations
local create 
local destroy

local createPiece
local drawLevel
local createPalette

local doClear
local doSave

local removeIt

local onDone
local onEditTouch


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	local parentGroup = parentGroup or display.currentStage

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/interface/protoBack.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	doClear()

	if( io.exists( options.currentGameDir .."/level" .. currentLevelNum .. ".txt",system.DocumentsDirectory ) ) then
		currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt")
	else
		currentPuzzle = {}
	end

	drawLevel()
	createPalette()
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	doClear()
	layers:removeSelf()
	layers = nil
	backImage = nil
	paletteLabel = nil
	editGroup = {}	
end

-- ==
-- onDone() - EFM
-- ==
onDone = function( event ) 
	local closure = 
		function()
			destroy()
			ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- createPalette() - EFM
-- ==
local function paletteDragger( self, event )
	local phase = event.phase 
	if(phase == "began") then
		self.dragStartX = event.x
		self.dragStartY = event.y
	elseif(phase == "moved") then
		self.x = self.x + (event.x - self.dragStartX)
		self.y = self.y + (event.y - self.dragStartY)
		self.dragStartX = event.x
		self.dragStartY = event.y

	elseif(phase == "ended" or phase == "cancelled") then
	end
	return true
end

-- ==
-- EFM() - EFM
-- ==
doClear = function()
	if( editPuzzle ) then
		--table.dump( editPuzzle )
		for k,v in pairs(editPuzzle) do
			removeIt(v)
			--if(v.type == "green") then v.label:removeSelf() end
			--v:removeSelf()			
		end
	end
	currentPuzzle = {}
	editPuzzle = {}
end

-- ==
-- EFM() - EFM
-- ==
removeIt =  function( obj )

	
	if(obj.type == "green" and isDisplayObject(obj) and isDisplayObject(obj.label)) then 
		obj.label:removeSelf() 
	end
	timer.performWithDelay(1, function() if( isDisplayObject(obj) ) then obj:removeSelf() end end )			
end

-- ==
-- EFM() - EFM
-- ==
doSave =  function()
	currentPuzzle = {}
	for k,v in pairs( editPuzzle ) do
		local tmp = {}
		tmp.x = v.x
		tmp.y = v.y
		tmp.curCount = v.curCount
		tmp.type = v.type
		currentPuzzle[#currentPuzzle+1] = tmp
	end
	table.save( currentPuzzle, options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
end

-- ==
-- EFM() - EFM
-- ==
local function modeTouch( event )

	local newMode = event.target.mode

	if(newMode == "done") then
		doSave()
		onDone()
		return true

	elseif(newMode == "clear") then
		doClear()		
		drawLevel()
		return true

	elseif(newMode == "fill") then
		for k,v in pairs(editPuzzle) do
			removeIt(v)
			--if(v.type == "green") then v.label:removeSelf() end
			--v:removeSelf()			
		end
		currentPuzzle = {}
		editPuzzle = {}
		drawLevel( true )
		return true


	elseif(newMode == "test") then
		doSave()	
		playGUI[options.currentGameDir].create()
		ssk.debug.monitorMem()
		onDone()
		return true

	elseif( newMode == "snap") then
		snapMode = event.target:pressed()
		print("snapMode == " .. tostring( snapMode ) )
		return true

	elseif( newMode == "up") then
		for k,v in pairs( editPuzzle ) do
			if (v.y == halfWidth) then
				removeIt( v )
				editPuzzle[k] = nil
			end
		end
		for k,v in pairs( editPuzzle ) do
			v.y = v.y - imageWidth
			if(v.label) then
				v.label.y = v.y
			end
		end

		for x = halfWidth, w-halfWidth, imageWidth do
			for y = h-halfWidth, h-halfWidth, imageWidth do
				createPiece( editGroup, x, y, 0, "blank")			
			end
		end
		return true

	elseif( newMode == "down") then
		for k,v in pairs( editPuzzle ) do
			if (v.y == h-halfWidth) then
				removeIt( v )
				editPuzzle[k] = nil
			end
		end
		for k,v in pairs( editPuzzle ) do
			v.y = v.y + imageWidth
			if(v.label) then
				v.label.y = v.y
			end
		end

		for x = halfWidth, w-halfWidth, imageWidth do
			for y = halfWidth, halfWidth, imageWidth do
				createPiece( editGroup, x, y, 0, "blank")			
			end
		end
		return true

	elseif( newMode == "left") then
		for k,v in pairs( editPuzzle ) do
			if (v.x == halfWidth) then
				removeIt( v )
				editPuzzle[k] = nil
			end
		end
		for k,v in pairs( editPuzzle ) do
			v.x = v.x - imageWidth
			if(v.label) then
				v.label.x = v.x
			end
		end

		for x = w-halfWidth, w-halfWidth, imageWidth do
			for y = halfWidth, h-halfWidth, imageWidth do
				createPiece( editGroup, x, y, 0, "blank")			
			end
		end
		return true

	elseif( newMode == "right") then
		for k,v in pairs( editPuzzle ) do
			if (v.x == w-halfWidth) then
				removeIt( v )
				editPuzzle[k] = nil
			end
		end
		for k,v in pairs( editPuzzle ) do
			v.x = v.x + imageWidth
			if(v.label) then
				v.label.x = v.x
			end
		end

		for x = halfWidth, halfWidth, imageWidth do
			for y = halfWidth, h-halfWidth, imageWidth do
				createPiece( editGroup, x, y, 0, "blank")			
			end
		end
		return true

	end

	currentEditMode = newMode
	paletteLabel:setText( newMode )
	return true
end


-- ==
-- EFM() - EFM
-- ==
createPalette = function()

	snapMode = false
	local palette = display.newGroup()
	palette.touch = paletteDragger
	palette:addEventListener( "touch", palette )

	layers.palette:insert(palette)

	local paletteBack = ssk.display.rect( palette, centerX, centerY + 20, { width = 320, height = 160 , fill = _BLUE_, stroke = _CYAN_, strokeWidth = 2, alpha = 0.55 } )

	paletteLabel = ssk.labels:quickLabel( palette, "Edit", centerX, centerY - 38, nil, 26 )

	local tmp
	local names = { "player", "greenplus", "greenminus", "goal" , "blue", "blueTele", "greenTele", "redTele", "blank" }
	for i = 1, #names do	
		tmp = ssk.buttons:presetRadio( palette, names[i], centerX - 175 + i * 35, centerY, 30, 30, "", modeTouch, { mode = names[i] } )
		if( i == 1 ) then tmp:toggle() end
	end

	tmp = ssk.buttons:presetPush( palette, "default", centerX - 90, centerY + 45, 50, 30, "Clear", modeTouch, { mode = "clear" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX - 30, centerY + 45, 50, 30, "Fill", modeTouch, { mode = "fill" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX + 30, centerY + 45, 50, 30, "Test", modeTouch, { mode = "test" } )
	tmp = ssk.buttons:presetPush( palette, "default", centerX + 90, centerY + 45, 50, 30, "Done", modeTouch, { mode = "done" } )
	
	tmp = ssk.buttons:presetPush( palette, "upButton", centerX - 60, centerY + 80, 30, 30, "", modeTouch, { mode = "up" } )
	tmp = ssk.buttons:presetPush( palette, "downButton", centerX - 20, centerY + 80, 30, 30, "", modeTouch, { mode = "down" } )

	tmp = ssk.buttons:presetPush( palette, "leftButton", centerX + 20, centerY + 80, 30, 30, "", modeTouch, { mode = "left" } )
	tmp = ssk.buttons:presetPush( palette, "rightButton", centerX + 60, centerY + 80, 30, 30, "", modeTouch, { mode = "right" } )
end

-- ==
-- EFM() - EFM
-- ==
onEditTouch = function ( self, event )

	-- local names = {"player", "goal", "danger", "unlocker", "anchor", "pull", "push", "blank" }
	local phase = event.phase
	local type = self.type

	--print("\n=====\n",phase,type,currentEditMode)
	if(phase == "began") then
		display.getCurrentStage():setFocus(event.target)

	elseif(phase == "moved") then
	
	elseif(phase == "ended" or phase == "cancelled") then
		display.getCurrentStage():setFocus(nil)


		if( currentEditMode == "greenplus" and type == "green" ) then
			self.curCount = self.curCount + 1
			self.label:setText(self.curCount)
		
		elseif( currentEditMode == "greenminus" and type == "green" ) then
			self.curCount = self.curCount - 1
			if(self.curCount <= 0 ) then self.curCount = 1 end
			self.label:setText(self.curCount)
		
		elseif( ( currentEditMode == "greenplus" or currentEditMode == "greenminus" ) and type ~= "green" ) then

			editPuzzle[self] = nil
			removeIt(self)
			--timer.performWithDelay(1, function() self:removeSelf() end )

			local x = self.x
			local y = self.y
			local tmp = createPiece( editGroup, x, y, 1, "green" )

		
		elseif( currentEditMode ~= type ) then
			print(currentEditMode,type)
			editPuzzle[self] = nil
			removeIt(self)
			--if(self.type == "green") then self.label:removeSelf() end
			--timer.performWithDelay(1, function() self:removeSelf() end )			

			local x = self.x
			local y = self.y
			local tmp = createPiece( editGroup, x, y, 0, currentEditMode )


		end

		doSave()

	end

	return true
end

-- ==
-- EFM() - EFM
-- ==
createPiece = function ( group, x, y, curCount, type )
	--print("\n-------------------------------------------", system.getTimer())
	local tmp 

	--print("editPuzzle",editPuzzle)
	--table.dump(editPuzzle)
	
	-- Only allow one player 
	if(type == "player" or type == "goal") then
		for k,v in pairs( editPuzzle ) do
			if (v.type == type) then
				createPiece( group, v.x, v.y, 0, "blank" )
				editPuzzle[k] = nil				
				removeIt(v)
				--timer.performWithDelay( 1, function() v:removeSelf() end )
				break
			end
		end
	end

	if( type == "blank" ) then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/editorblank.png", { size = imageWidth } )  		
	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", { size = imageWidth } )  		
	end
	tmp.type = type	
	tmp.curCount = curCount

	if( type == "green" ) then
		tmp.label = ssk.labels:quickLabel( group, tmp.curCount, tmp.x, tmp.y, nil, 26 )
	end


	tmp.touch = onEditTouch
	tmp:addEventListener( "touch", tmp )

	editPuzzle[tmp] = tmp

	return tmp
end

-- ==
-- EFM() - EFM
-- ==
drawLevel = function( fill )

	editPuzzle = {}

	editGroup = display.newGroup()

	layers.content:insert(editGroup)

	local count = 0

	--table.dump(currentPuzzle)

	if(#currentPuzzle > 0 ) then
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type ~= "magnet" ) then
				createPiece( editGroup, tmp.x, tmp.y, tmp.curCount, tmp.type)	
				count = count + 1		
			end
		end
		for i = 1, #currentPuzzle do
			local tmp = currentPuzzle[i]
			if( tmp.type == "magnet" ) then
				createPiece( editGroup, tmp.x, tmp.y, tmp.curCount, tmp.type)	
				count = count + 1		
			end
		end
	else
		for x = halfWidth, w-halfWidth, imageWidth do
			for y = halfWidth, h-halfWidth, imageWidth do
				count = count + 1
				createPiece( editGroup, x, y, 0, "blank")			
			end
		end
	end
	print("Total blocks == " .. count )

	--editGroup:scale( 0.8, 0.8 )
	--editGroup:setReferencePoint( display.CenterReferencePoint )
	--editGroup.x = w * 0.1
	--editGroup.y= h * 0.1


	local function onTouch( self, event )
		local phase = event.phase
		if(phase == "began") then
		elseif(phase == "ended") then
		end

		return true	
	end
	-- Add dummy touch catcher to backImage to keep touches from 'falling through'
	--backImage.touch = onTouch
	--backImage:addEventListener( "touch", backImage )
	backImage.type = "backImage"
	--backImage.touch = onEditTouch
	--backImage:addEventListener( "touch", backImage )


end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
