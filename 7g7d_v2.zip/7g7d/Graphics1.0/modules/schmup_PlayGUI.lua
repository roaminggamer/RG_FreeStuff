-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.

local myCC

local mAbs = math.abs

local animOptions = 
{
	-- Required params
	width = 64,
	height = 64,
	numFrames = 4,

	-- content scaling
	sheetContentWidth = 256,
	sheetContentHeight = 64,
}
local sheet
local sequenceData
local sequence


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local gameRunning = true

local ignoreCollisions = false

local rotForce      = rotForce or 5   
local thrustForce   = thrustForce or 0.1

local playPuzzle = {}
local thePlayer

-- Forward Declarations
local create 
local destroy

local createPiece
local createLevel

local createdLevel = false

local onPlayerCollision 
local onBack
local onHelp

local joystickListener

local initCam
local updateCam

local playerMover

local maxAimFireDist2 = 200 ^ 2
local maxDropDist2 = 200 ^ 2
local aimTurret
local fireTurret

local slideTime = 5000
local transitionMover
local doDrop
local toggleLightning


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	myCC = ssk.ccmgr:newCalculator()
	myCC:addName( "blank" )
	myCC:addName( "player" )
	myCC:addName( "wall" )
	myCC:addName( "goal" )
	myCC:addName( "turret" )
	myCC:addName( "drop" )
	myCC:addName( "mover" )
	myCC:addName( "lightning" )
	myCC:addName( "playerBullet" )
	myCC:addName( "enemyBullet" )

	myCC:collidesWith( "player", "wall", "goal", "turret", "drop", "mover", "lightning" )

	myCC:collidesWith( "playerBullet", "wall", "goal", "turret", "drop", "mover"  )

	myCC:collidesWith( "enemyBullet", "player", "wall", "drop", "mover" )

	myCC:collidesWith( "drop", "wall", "turret" )

	myCC:dump()


	if( not sheet ) then
		sheet = graphics.newImageSheet( "images/" .. options.currentGameDir .. "/lightningSheet.png", animOptions )
		sequenceData = {}
		sequence = { name="lightning1", start=1, count=4, loopDirection="bounce", time = 250 }
	end


	imageWidth = 32
	halfPieceWidth = imageWidth/2
	halfBoardRowCol = 32

	gameRunning = true

	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
	if( not currentPuzzle ) then currentPuzzle = {} end

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "world", { "content" },  "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	ignoreCollisions = false
	playPuzzle = {}
	createLevel()

	--[[
	timer.performWithDelay( 5000, 

		function()
			print("890234890238490123")
			createLevel( )
		end )
	--]]

	layers.content:setReferencePoint( display.CenterReferencePoint )
	layers.content.x = centerX
	layers.content.y = centerY
	--layers.content:scale(0.8, 0.8)


	initCam( )

	Runtime:addEventListener( "enterFrame", playerMover )

	backImage.touch = joystickListener
	backImage:addEventListener( "touch", backImage )


--[[
	ssk.inputs:createJoystick( layers.buttons, w - 100, h - 100, 
								   { eventName = "myJoystickEvent",  inputObj = backImage,
									 inUseAlpha = 0.7, notInUseAlpha = 0.05, useAlphaFadeTime = 250,
									 outerStrokeColor = _WHITE_, outerAlpha = 0,
									 stickImg = "images/" .. options.currentGameDir .. "/dpad.png", stickRadius = 45,
									 deadZoneRadius = 9 } )
	ssk.gem:add("myJoystickEvent", joystickListener)
--]]

end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroying level" )

	gameRunning = false

	ssk.gem:removeAll() --("myJoystickEvent", joystickListener)
	Runtime:removeEventListener( "enterFrame", playerMover )


	layers:removeSelf()
	layers = nil
	backImage = nil
	thePlayer = nil
end


-- ==
-- onBack() - EFM
-- ==
onBack = function( event, restart ) 

	gameRunning = false
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end



-- ==
-- onPlayerCollision() - EFM
-- ==
onPlayerCollision = function( self, event )
--	if(true) then return true end
	local other = event.other
	local type  = other.type

	print("HIT")

	if( ignoreCollisions ) then 
		print("Ignoring collisions")
		return true 
	end
	
	if( event.phase == "began" ) then
		print(event.phase, type)		
		if( type == "goal" ) then
			ignoreCollisions = true
			currentLevelNum = currentLevelNum + 1
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "win1" } )	
			print("*****  In goal code", currentLevelNum, existingLevels)
			if( currentLevelNum > existingLevels ) then
				currentLevelNum = 1
			end
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
				end )
		elseif( type == "lightning" and other.isVisible ) then
			
			ignoreCollisions = true
			print("*****  In lightning code", currentLevelNum, existingLevels)
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
					--onBack( nil, true)
				end )

		elseif( type == "mover"  ) then

			ignoreCollisions = true
			print("*****  In mover code", currentLevelNum, existingLevels)
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
					--onBack( nil, true)
				end )


		elseif( type == "drop"  ) then

			ignoreCollisions = true
			print("*****  In drop code", currentLevelNum, existingLevels)
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
					--onBack( nil, true)
				end )


		elseif( type == "enemyBullet"  ) then

			ignoreCollisions = true
			print("*****  In lightning code", currentLevelNum, existingLevels)
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )
			timer.performWithDelay(50, 
				function() 
					destroy()
					create ()
					--onBack( nil, true)
				end )

			--[[
			other.isVisible = false			
			ignoreCollisions = true
			print("*****  In enemyBullet code", currentLevelNum, existingLevels)

			timer.performWithDelay(100, 
				function() 
					print("Fake!")
					--createLevel()
					onBack( nil, true)
					--create()
					--timer.performWithDelay( 50, create )
					ignoreCollisions = false
				end )
			--]]

		end
	end
	return true
end

toggleLightning = function( obj, firstCall )
	if( not isDisplayObject( obj ) ) 
		then return 
	end

	if( obj.isVisible and not firstCall ) then
		obj.isVisible = false
		timer.performWithDelay( 2000, function() toggleLightning( obj ) end )
	
	else
		obj.isVisible = true
		timer.performWithDelay( 3000, function() toggleLightning( obj ) end )

	end
end

aimTurret = function( turret, firstCall )
	if( not isDisplayObject( turret ) ) 
		then return 
	end

	if(firstCall) then
		turret.initialRotation = turret.rotation
		turret.minRot = turret.rotation - 60
		turret.maxRot = turret.rotation + 60

		--print( turret.minRot, turret.maxRot )

	elseif( isDisplayObject( thePlayer ) ) then
		local tweenVec = ssk.math2d.sub( turret, thePlayer )
		local len2 = ssk.math2d.squarelength( tweenVec )

		if( len2 < maxAimFireDist2 ) then
			local vecAngle = ssk.math2d.vector2Angle( tweenVec )

			if( vecAngle < turret.minRot ) then
				vecAngle = turret.minRot
			elseif( vecAngle > turret.maxRot ) then
				vecAngle = turret.maxRot
			end

			turret.rotation = vecAngle

		end
	end

	timer.performWithDelay( 30, function() aimTurret( turret ) end )
	
end


fireTurret = function( turret )
	--if(true) then return end 
	if( not isDisplayObject( turret ) ) then return end

	local group = layers.content
	local x = turret.x
	local y = turret.y
	local r = turret.rotation
	local v = ssk.math2d.angle2Vector( r, true )
	v = ssk.math2d.scale( v, 100 )

	if( isDisplayObject( thePlayer ) ) then
		local tweenVec = ssk.math2d.sub( turret, thePlayer )
		local len2 = ssk.math2d.squarelength( tweenVec )

		if( len2 < maxAimFireDist2 ) then
			local bullet = ssk.display.rect( group, x, y, 
											 { size = 4, rotation = r, fill = _RED_ }, 
											 { calculator = myCC, colliderName = "enemyBullet", 
											 bounce = 0, friction = 0, isSensor = false }  )
			bullet.type = "enemyBullet"
			bullet:toBack()
			bullet:setLinearVelocity(v.x, v.y)

			playPuzzle[bullet] = bullet

			bullet.collision = function( self, event ) 
				
				print("Same?", tostring(bullet == self) )
				if(self.ignoreCollision) then 
					print("Bullet ignoring collision")
					return true 
				end
				self.ignoreCollision = true
				--self:removeEventListener( "collision", self )
				--physics.removeBody( self )
				self.isVisible = false

				print("===========> Is visible? ", self.isVisible )

				
				timer.performWithDelay( 10,
					function() 
						if( not isDisplayObject( self ) )  then 
							return 
						end
						self:removeSelf() 
					end )
				return true
			end
			bullet:addEventListener( "collision", bullet )
		end
	end

	timer.performWithDelay( 1500, function() fireTurret( turret ) end )
end


transitionMover = function( obj, firstCall )
	if( not isDisplayObject( obj ) )  then
		return 
	end

	if( firstCall ) then
		if( obj.rotation == 0 ) then
			obj.left  = { x = obj.x - 2 * imageWidth, y = obj.y  }
			obj.right = { x = obj.x + 2 * imageWidth, y = obj.y  }
		elseif( obj.rotation == 180 ) then
			obj.left  = { x = obj.x + 2 * imageWidth, y = obj.y  }
			obj.right = { x = obj.x - 2 * imageWidth, y = obj.y  }
		elseif( obj.rotation == 90 ) then
			obj.left  = { x = obj.x, y = obj.y - 2 * imageWidth }
			obj.right = { x = obj.x, y = obj.y + 2 * imageWidth }
		else
			obj.left  = { x = obj.x, y = obj.y + 2 * imageWidth }
			obj.right = { x = obj.x, y = obj.y - 2 * imageWidth }
		end
		obj.dir = "left"
		obj.x = obj.right.x
		obj.y = obj.right.y
	end

	if( obj.dir == "left" ) then
		obj.dir = "right"
		transition.to( obj, { x = obj.left.x, y = obj.left.y, time = slideTime, onComplete = transitionMover} )
	else
		obj.dir = "left"
		transition.to( obj, { x = obj.right.x, y = obj.right.y, time = slideTime, onComplete = transitionMover} )
	end
end

doDrop = function( obj, firstCall )
	if( not isDisplayObject( obj ) ) then 
		return 
	end

	if( obj.hasDropped ) then
		return
	end

	if( firstCall ) then
		obj.hasDropped = false
	
	elseif( isDisplayObject( thePlayer ) ) then
		local tweenVec = ssk.math2d.sub( obj, thePlayer )
		local len2 = ssk.math2d.squarelength( tweenVec )

		if( len2 < maxDropDist2 ) then
			local vecAngle = ssk.math2d.vector2Angle( tweenVec )
			if( vecAngle < 0 ) then
				vecAngle = vecAngle + 360
			elseif( vecAngle >= 360 ) then
				vecAngle = vecAngle - 360
			end

			if(vecAngle > 140 and vecAngle < 200 ) then
				obj.hasDropped = true
				print("Drop!")
				obj:applyLinearImpulse( 0, 4, obj.x, obj.y )
				return
			end
		end
	end
	timer.performWithDelay( 30, function() doDrop( obj ) end )
end

createPiece = function ( group, x, y, rotation, type, curCount, myCC )
	--print("creating: ", type)
	local tmp 

	if( type == "player" ) then
		if( not isDisplayObject( thePlayer)  ) then
			tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/player.png",
			                          { size = imageWidth - 12, rotation = rotation }, 
				                      { calculator = myCC, colliderName = type, 
									    bounce = 0, friction = 0, linearDamping = 3, }  )
			thePlayer = tmp
			tmp.collision = onPlayerCollision
			tmp:addEventListener( "collision", tmp )

		else
			--print("Alt player code" )
			--tmp = thePlayer
		end
		thePlayer.thrustForce	= 0	-- Initially not thrusting
		thePlayer.rotForce		= 0	-- Initially not rotating
		thePlayer.isFiring      = false
		thePlayer.x = x
		thePlayer.y = y
		thePlayer.rotation = rotation
		thePlayer.isVisible = true


	elseif(  type == "drop") then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		                            { size = imageWidth-8, rotation = rotation }, 
									{ calculator = myCC, colliderName = type, isSensor = false, bodyType = "dynamic", density = 1, friction = 0, bounce = 0 }  )  	

	elseif(  type == "wall") then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = type, isSensor = false, bodyType = "static", density = 1, friction = 0, bounce = 0 }  )  	

	elseif(  type == "goal") then
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = type, isSensor = true, bodyType = "static" }  )  	


	elseif(  type == "fixedTurret1" ) then
		local turret =
		    ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/fixedTurret.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "turret", isSensor = false, bodyType = "static", radius = imageWidth/2 - 5 }  )  	
		playPuzzle[turret] = turret
		turret.type = type

		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/halfWall.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "blank", isSensor = false, bodyType = "static" }  )
		turret.myWall = tmp 
		
		fireTurret( turret)  	
	elseif(  type == "fixedTurret2" ) then
		local turret =
		    ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/fixedTurret.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "turret", isSensor = false, bodyType = "static", radius = imageWidth/2 - 5 }  )  	
		playPuzzle[turret] = turret
		turret.type = type

		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/halfWall.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "blank", isSensor = false, bodyType = "static" }  )
		turret.myWall = tmp  	
		turret.rotation = turret.rotation - 45
		if(turret.rotation < 0 ) then 
			turret.rotation = turret.rotation + 360
		elseif(turret.rotation >= 360 ) then 
			turret.rotation = turret.rotation - 360
		end

		fireTurret( turret) 
	elseif(  type == "fixedTurret3" ) then
		local turret =
		    ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/fixedTurret.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "turret", isSensor = false, bodyType = "static", radius = imageWidth/2 - 5 }  )  	
		playPuzzle[turret] = turret
		turret.type = type

		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/halfWall.png", 
		                            { size = imageWidth }, 
									{ calculator = myCC, colliderName = "blank", isSensor = false, bodyType = "static" }  )
		turret.myWall = tmp  	
		turret.rotation = turret.rotation + 45
		if(turret.rotation < 0 ) then 
			turret.rotation = turret.rotation + 360
		elseif(turret.rotation >= 360 ) then 
			turret.rotation = turret.rotation - 360
		end

		fireTurret( turret) 
	elseif(  type == "aimingTurret" ) then

		local turret =
		    ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/aimingTurretPlay.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "turret", isSensor = false, bodyType = "static", radius = imageWidth/2 - 5 }  )  	
		playPuzzle[turret] = turret
		turret.type = type

		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/halfWall.png", 
		                            { size = imageWidth, rotation = rotation }, 
									{ calculator = myCC, colliderName = "blank", isSensor = false, bodyType = "static" }  )
		turret.myWall = tmp  	

		aimTurret(turret,true)
		timer.performWithDelay( 60, function() fireTurret( turret ) end )

	elseif(  type == "lightning" ) then

		tmp = display.newSprite( sheet, sequence )
		group:insert(tmp)
		tmp.x = x
		tmp.y = y
		tmp.rotation = rotation
		tmp:scale( imageWidth/tmp.contentWidth, imageWidth/tmp.contentHeight )
		tmp:play()

		local collisionFilter = myCC:getCollisionFilter( type )
		local params = { isSensor = true, filter=collisionFilter, radius = imageWidth/2 - 5, }
		physics.addBody( tmp, params )

		toggleLightning( tmp, true )



	else
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		                             { size = imageWidth, rotation = rotation }, 
									 { calculator = myCC, colliderName = type, isSensor = false, bodyType = "static", bounce = 0.3 }  )  	
	end
	
	if( type == "mover" ) then
		transitionMover( tmp, true )
	elseif( type == "drop" ) then
		doDrop( tmp, true )
	end	

	if(tmp) then
		tmp.type = type		
		playPuzzle[tmp] = tmp
	end

	return tmp
end

-- ==
-- createLevel() - EFM
-- ==

createLevel = function()
	print("---------------------\nEntering createLevel()")

	
	local piece
	
	-- purge level if it exists
	-- 

	if( isDisplayObject( thePlayer) and isDisplayObject( playPuzzle[thePlayer] ) ) then
		print("Purge")
	end
	local purgeCount = 0
	for k,v in pairs( playPuzzle ) do
		if( isDisplayObject( thePlayer) and v == thePlayer ) then
			-- Don't make the player again.
		else
			purgeCount = purgeCount + 1
			if( isDisplayObject( v ) ) then
				if(v.type and v.type ~= "aimingTurret") then
					v:removeSelf()
				end
			end
			playPuzzle[k] = nil
		end

		playPuzzle = {}
		playPuzzle[thePlayer] = thePlayer
	end
	if(purgeCount > 0 ) then print("Purged: ", purgeCount) end

	--if( createdLevel ) then return end 	

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]
		if(tmp.type ~= "blank") then
			if( isDisplayObject( thePlayer) and tmp.type == "player" ) then
			else
				piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type, tmp.curCount, myCC)	
				count = count + 1		
			end
		end
	end

	createdLevel = true

	print("Total blocks == " .. count )

end

-- ==
--	joystickListener() - This function interprets all joystick inputs into rotation, thrusting, and firing
-- ==
joystickListener = function( self, event )
	--table.dump(event)

	local phase = event.phase

	if( not gameRunning ) then return false end

	local deadZone = 10
	local maxLen = 110

	local tmpMag 
	local tmpAlpha = 0.2 

	local v = ssk.math2d.sub( event.xStart, event.yStart, event.x, event.y, true ) 
	local len = ssk.math2d.length( v )
	local angle = ssk.math2d.vector2Angle( v )
	
	if( len <= deadZone ) then
		tmpMag = 0
	elseif( len > maxLen ) then
		tmpMag = 1
	else
		tmpMag = len/( maxLen - deadZone )
	end

	print( event.xStart, event.yStart, event.x, event.y, " :", tmpMag, len, deadZone, maxLen ) 

	thePlayer.angularVelocity = 0

	if( phase == "began" ) then
		thePlayer.isFiring = true

		thePlayer.rotation = angle

		if(tmpMag > 0) then
			thePlayer.thrustForce = thrustForce * tmpMag
		else
			thePlayer.thrustForce = 0
		end
	
	elseif( phase == "moved" ) then

		thePlayer.rotation = angle
		if(tmpMag > 0) then
			thePlayer.thrustForce = thrustForce * tmpMag
		else
			thePlayer.thrustForce = 0
		end
	
	elseif( phase == "ended" or phase == "cancelled" ) then
		thePlayer.isFiring = false

		thePlayer.thrustForce = 0
	
	end

	return true
end


joystickListener_old = function( event )
	--table.dump(event)
	--local labelNames = {"vx", "vy", "nx", "ny", "percent", "phase", "state", "angle", "direction" }

	if( not gameRunning ) then return false end
	
	local phase = event.phase
	local state = event.state
	local angle = event.angle
	local percent = event.percent/100

	--print(state, percent)

	thePlayer.angularVelocity = 0

	if( phase == "began" ) then
		thePlayer.isFiring = true

		thePlayer.rotation = angle

		if(state == "on") then
			thePlayer.thrustForce = thrustForce * percent
		else
			thePlayer.thrustForce = 0
		end
	
	elseif( phase == "moved" ) then
		thePlayer.rotation = angle

		if(state == "on") then
			thePlayer.thrustForce = thrustForce * percent
		else
			thePlayer.thrustForce = 0
		end
	
	elseif( phase == "ended" or phase == "cancelled" ) then
		thePlayer.isFiring = false

		thePlayer.thrustForce = 0
	
	end

	return true
end

initCam = function( )

	local trackObj  = thePlayer
	local cameraObj = layers.world

	local ctlX, ctlY = trackObj:contentToLocal(cameraObj.x, cameraObj.y)
	local dx,dy = ctlX + centerX, ctlY + centerY

	print("Camera initialization: ", ctlX, ctlY, dx, dy)
	cameraObj.x = cameraObj.x + dx
	cameraObj.y = cameraObj.y + dy

	cameraObj.trackingObj = trackObj		
	cameraObj._sX = trackObj.x
	cameraObj._sY = trackObj.y
	cameraObj._dX = 0
	cameraObj._dY = 0
end

updateCam = function( )
	--if(true) then return end
	if( not gameRunning ) then return end


	local trackObj  = thePlayer
	local cameraObj = layers.world

	local deadX = 0
	local deadY = 0

	cameraObj._dX = cameraObj._sX - cameraObj.trackingObj.x
	cameraObj._dY = cameraObj._sY - cameraObj.trackingObj.y

	local ctlX, ctlY = cameraObj.trackingObj:contentToLocal(cameraObj.parent.x, cameraObj.parent.y)
	local dx, dy = ctlX + centerX, ctlY + centerY

	if(deadX) then
		if( mAbs(dx) > deadX ) then
			if( dx > 0 ) then
				dx = dx - deadX
			elseif( dx < 0 ) then
				dx = dx + deadX
			end				
		else
			cameraObj._dX = 0
		end
	end

	if(deadY) then
		if( mAbs(dy) > deadY ) then
			if( dy > 0 ) then
				dy = dy - deadY
			elseif( dy < 0 ) then
				dy = dy + deadY
			end				
		else
			cameraObj._dY = 0
		end
	end

	-- Apply delta to content layers parent
	cameraObj.x = cameraObj.x + cameraObj._dX
	cameraObj.y = cameraObj.y + cameraObj._dY

	-- Clear deltas and record new latest position
	cameraObj._dX = 0
	cameraObj._dY = 0
	cameraObj._sX = cameraObj.trackingObj.x
	cameraObj._sY = cameraObj.trackingObj.y



end


-- ==
--	playerMover() - This function applies any current force settings to the player's ship.
-- ==
playerMover = function()
	--if(true) then return end
	if( not gameRunning ) then return end

	-- 1. Rotate the ship if 'rotForce' is set.
	--
	thePlayer.rotation = thePlayer.rotation + thePlayer.rotForce

	-- Object rotations can be set to values outside the range [0, 360), but this is bad
	-- practice, so if we overshoot these two values, we simply add or subtract 360 degrees
	-- to get back into an acceptable range.
	if( thePlayer.rotation < 0 ) then 
		thePlayer.rotation = thePlayer.rotation + 360 
	end
	if( thePlayer.rotation > 360 ) then 
		thePlayer.rotation = thePlayer.rotation - 360 
	end
	
	-- 2. Calculate the current force vector
	--
	local fx,fy = ssk.math2d.angle2Vector( thePlayer.rotation )
	if( thePlayer.isVisible == false ) then 
		thrustForce = 0
	end
	fx,fy = ssk.math2d.scale( fx, fy, thePlayer.thrustForce )

	-- 3. Apply Force (can be 0)
	--
	-- Tip: Forces must be re-applied every frame to have an continuous and additive effect.
	--
	thePlayer:applyForce( fx, fy, thePlayer.x, thePlayer.y )

	-- 4. Show/Hide Thruster
	--
--	if( thePlayer.isVisible and thePlayer.thrustForce > 0 ) then
--		thePlayer.thruster.isVisible = true
--	else
--		thePlayer.thruster.isVisible = false
--	end

	-- Track player exactly
	updateCam()
	
end

----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
