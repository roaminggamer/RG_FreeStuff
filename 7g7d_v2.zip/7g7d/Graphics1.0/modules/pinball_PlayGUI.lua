-- =============================================================
-- 
-- =============================================================

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- none.


----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
-- none.

local myCC = ssk.ccmgr:newCalculator()
myCC:addName( "player" )
myCC:addName( "paddle" )
myCC:addName( "bumper" )
myCC:addName( "wall" )
myCC:addName( "danger" )
myCC:addName( "goal" )

myCC:collidesWith( "player", "paddle", "wall", "bumper", "danger", "goal" )
myCC:dump()


----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Locals
local layers 
local backImage

local maxVel = 350
local maxVel2 = maxVel ^ 2 + 10
local sl = ssk.math2d.squarelength
local norm = ssk.math2d.normalize
local sc = ssk.math2d.scale


local playPuzzle = {}

local curLenMult = 1

local thePlayer
local nearestMagnet
local paddles = {}

-- Forward Declarations
local create 
local destroy

local ignoreCollisions = false

local createPiece
local createLevel

local onTouch

local onCollision 
local onBack
local onHelp


----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------
-- ==
-- create() - Create EFM
-- ==
create = function ( parentGroup )
	print("\n------------------------------------------")
	print("Creating level: " .. currentLevelNum )
	local parentGroup = parentGroup or display.currentStage

	physics.setGravity(0,5)

	imageWidth = 20
	halfPieceWidth = imageWidth/2


	currentPuzzle = table.load( options.currentGameDir .."/level" .. currentLevelNum .. ".txt" )
	if(not currentPuzzle) then currentPuzzle = {} end

	-- Create some rendering layers
	layers = ssk.display.quickLayers( parentGroup, "background", "content", "buttons", "overlay", "palette" )
	
	backImage = display.newImage( layers.background, "images/back.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		backImage.rotation = 90
	end

	backImage.x = w/2
	backImage.y = h/2

	local overlayImage
	overlayImage = display.newImage( layers.overlay, "images/interface/protoOverlay.png" )
	if(build_settings.orientation.default == "landscapeRight") then
		overlayImage.rotation = 90
	end

	overlayImage.x = w/2
	overlayImage.y = h/2

	ssk.buttons:presetPush( layers.buttons, "default", 10, 10, 20, 20, "X", onBack )
	ssk.buttons:presetPush( layers.buttons, "default", w-10, 10, 20, 20, "?", onHelp )

	transition.from( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )

	createLevel()

	ignoreCollisions = false
end

-- ==
-- destroy() - Destroy EFM
-- ==
destroy = function ( )
	print("\n------------------------------------------")
	print("Destroyoing level" )

	layers:removeSelf()
	layers = nil
	backImage = nil
	paddles = nil
	nearestMagnet = nil

	physics.setGravity(0,0)

end

-- ==
-- onBack() - EFM
-- ==
onBack = function( event ) 
	
	local closure = 
		function()
			destroy()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end

-- ==
-- onHelp() - EFM
-- ==
onHelp = function( event ) 
	
	local closure = 
		function()
			destroy()
			ifc_Help.create()
			--ssk.debug.monitorMem()
		end
	transition.to( layers, {alpha = 0, time = sceneCrossFadeTime, onComplete = closure } )	
end


-- ==
-- EFM() - EFM
-- ==
onCollision = function( self, event )
	local other = event.other
	local type  = other.type
	
	if( event.phase == "began" ) then
		print(event.phase, type)		
		if( type == "goal" and not ignoreCollisions) then
			ignoreCollisions = true			

			ssk.gem:post( "PLAY_EFFECT" , { effectName = "win1" } )

			currentLevelNum = currentLevelNum + 1
			print("*****  In goal code", currentLevelNum, existingLevels)
			if( currentLevelNum > existingLevels ) then
				currentLevelNum = 1
			end
			timer.performWithDelay(10, 
				function() 
					destroy()
					create ()
				end )			
		elseif( type == "danger" and not ignoreCollisions) then
			ignoreCollisions = true			
				
			print("*****  In danger code", currentLevelNum, existingLevels)
			ssk.gem:post( "PLAY_EFFECT" , { effectName = "bad" } )

			timer.performWithDelay(10, 
				function() 
					destroy()
					create ()
				end )			
		end
	end
	return true
end

createPiece = function ( group, x, y, rotation, type )
	--print("creating: ", type)
	local tmp 

	if(type == "smallBumper" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/bumper.png", 
		{ size = imageWidth * 0.8 }, 
		{ radius = imageWidth/2 * 0.8, bodyType = "static", bounce = 2.0,
		  calculator = myCC, colliderName = "bumper" }  )

	elseif(type == "mediumBumper" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/bumper.png", 
		{ size = imageWidth * 1.4 }, 
		{ radius = imageWidth/2 * 1.4, bodyType = "static", bounce = 2.0,
		  calculator = myCC, colliderName = "bumper" }  )

	elseif(type == "largeBumper" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/bumper.png", 
		{ size = imageWidth * 2.0 }, 
		{ radius = imageWidth/2 * 2.0, bodyType = "static", bounce = 2.0,
		  calculator = myCC, colliderName = "bumper" }  )

	elseif(type == "rightPaddle" ) then	
		local height = imageWidth -- /3 * 2
		local width = 5.6 * height

		local hh = height/2
		local hw = width/2

		local shape = {  0,  -hh, 
						 hw,  -hh+4, 
						 hw,  hh-4, 
						 0,   hh }
--[[
		local shape = {  0,  -(hh-5), 
						 5,  -hh, 
						(hw-10),  -(hh-5), 
						hw,   -(hh-5), 
						hw,    (hh-5), 
						(hw-10),   (hh-5), 
						 5,   hh, 
						 0,   (hh-5) }
--]]
		local paddle = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/paddle.png", 
		                                     { w = width, h = height, rotation = 180 }, 
											 { density = 2, bodyType = "dynamic", bounce = 1, shape = shape,
		                                     calculator = myCC, colliderName = "paddle", density = 2, isBullet = true } )
		paddle.isBullet = true
		local pivot = ssk.display.circle( group, x, y, { radius = 5 }, 
		                                 { density = 1, bodyType = "static", bounce = 0, radius = 1,
		                                   calculator = myCC, colliderName = "paddle" } )
		pivot.isVisible = false

		pivot.myJoint = physics.newJoint( "pivot", pivot, paddle, pivot.x, pivot.y )
		pivot.myJoint.isLimitEnabled = true
		pivot.myJoint:setRotationLimits( -30, 15 )

		tmp = paddle
		playPuzzle[pivot] = pivot		

	elseif(type == "leftPaddle" ) then	
		local height = imageWidth -- /3 * 2
		local width = 5.6 * height

		local hh = height/2
		local hw = width/2

		local shape = {  0,  -hh, 
						 hw,  -hh+4, 
						 hw,  hh-4, 
						 0,   hh }
		--[[
		local shape = {  0,  -(hh-5), 
						 5,  -hh, 
						(hw-10),  -(hh-5), 
						hw,   -(hh-5), 
						hw,    (hh-5), 
						(hw-10),   (hh-5), 
						 5,   hh, 
						 0,   (hh-5) }
		--]]
		local paddle = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/paddle.png", 
		                                      { w = width, h = height }, 
											  { density = 2, bodyType = "dynamic", bounce = 1, shape = shape,
		                                      calculator = myCC, colliderName = "paddle", density = 2, isBullet = true } )
		paddle.isBullet = true
		local pivot = ssk.display.circle( group, x, y, { radius = 5 }, 
		                                  { density = 1, bodyType = "static", bounce = 0, radius = 1,
		                                     calculator = myCC, colliderName = "paddle" } )
		pivot.isVisible = false

		pivot.myJoint = physics.newJoint( "pivot", pivot, paddle, pivot.x, pivot.y )
		pivot.myJoint.isLimitEnabled = true
		pivot.myJoint:setRotationLimits( -15, 30 )

		tmp = paddle
		playPuzzle[pivot] = pivot		


	elseif(type == "player" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		{ size = imageWidth }, 
		{ radius = imageWidth/2+1, bodyType = "dynamic", calculator = myCC, colliderName = "player", density = 1, isBullet = true }  )
		tmp.isBullet = true
		tmp.timer = function( self )

			if( not isDisplayObject( tmp ) ) then return end
			local vx,vy = tmp:getLinearVelocity()

			local len2 = sl( vx, vy )

			if(len2 > maxVel2) then
				local v = norm( vx,vy, true )
				v = sc(v,maxVel)
				tmp:setLinearVelocity(v.x, v.y)
				--print(v.x,v.y)
			end
		end

		timer.performWithDelay( 30, tmp, 0 )


		thePlayer = tmp
		tmp.collision = onCollision
		tmp:addEventListener( "collision", tmp )
	
	elseif(type == "wall" ) then	
		local hh = (imageWidth-4)/2
		local shape = {  -hh, -hh, 
		                 hh, -hh,
						 hh, hh,
						 -hh, hh}

		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		{ size = imageWidth  }, 
		{ bodyType = "static", bounce = 0.8, calculator = myCC, colliderName = "wall", shape = shape }  )

	elseif(type == "danger" ) then	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		{ size = imageWidth  }, 
		{ bodyType = "static", isSensor = true, calculator = myCC, colliderName = "danger" }  )

	else	
		tmp = ssk.display.imageRect( group, x, y, "images/" .. options.currentGameDir .. "/" .. type .. ".png", 
		{ size = imageWidth  }, 
		{ bodyType = "static", calculator = myCC, colliderName = type }  )
	
	end


	if(tmp and (type == "leftPaddle" or type == "rightPaddle" ) ) then
		print("Add paddle...")
		paddles[tmp] = tmp
	end

	if(tmp and (type == "smallBumper" or type == "mediumBumper" or type == "largeBumper" ) ) then

		tmp.preCollision = function( self, event )
			--print( "Precollision", event.phase )
			--table.dump( event )
			if( self.ignoreCollisions ) then 
				return true 
			end

			local other = event.other
			self.ignoreCollisions = true
			local function reset( obj )
				obj.ignoreCollisions = false
				obj.bounce = 2
			end
			transition.to( self, { xScale = 1.2, yScale = 1.2, time = 50 } )
			transition.to( self, { xScale = 1, yScale = 1, delay = 55, time = 40, onComplete = reset } )
			local bv = ssk.math2d.sub(other,self)
			bv = ssk.math2d.normalize( bv )
			bv = ssk.math2d.scale(bv,5)

			ssk.gem:post( "PLAY_EFFECT" , { effectName = self.type } )
	
			timer.performWithDelay(1, function() self.bounce = 0.5 end )	

			--timer.performWithDelay(1, function() other:applyLinearImpulse( bv.x, bv.y ) end )	

			return true 
		end
		--tmp:addEventListener( "collision", tmp )
		tmp:addEventListener( "preCollision", tmp )

	end


	if(tmp) then
		tmp.type = type	
		playPuzzle[tmp] = tmp
	end

	return tmp
end

createLevel = function()

	local piece
	paddles = {}
	playPuzzle = {}

	local count = 0
	for i = 1, #currentPuzzle do
		local tmp = currentPuzzle[i]

			piece = createPiece( layers.content, tmp.x, tmp.y, tmp.rotation, tmp.type )	
			count = count + 1		

	end
	--print("Total blocks == " .. count )

	for k,v in pairs( playPuzzle ) do
		
		if( v.type == "smallBumper" or 
		    v.type == "mediumBumper" or 
			v.type == "largeBumper" or 
			v.type == "player" ) then
			v:toFront()
		end
	end

	for k,v in pairs( paddles ) do
		v:toFront()
	end

	-- 
	backImage.touch = onTouch
	backImage:addEventListener( "touch", backImage )

end

local function flipPaddle( paddle ) 
	if(paddle.flipping) then 
		return 
	end

	paddle.flipping = true

	if(paddle.type == "leftPaddle") then
		paddle:applyAngularImpulse( -600 )
	
		timer.performWithDelay( 200, 
			function()
				paddle:applyAngularImpulse( 300 )
			end )

	else
		paddle:applyAngularImpulse( 600 )
	
		timer.performWithDelay( 200, 
			function()
				paddle:applyAngularImpulse( -400 )
			end )
	end

	timer.performWithDelay( 300, 
		function()
			paddle.flipping = false
		end )


end

onTouch = function( self, event )
	print("Ontouch", event.phase)
	if( event.phase == "began" ) then
		for k,v in pairs(paddles) do
			flipPaddle(v)
		end
	end

	return true

end


----------------------------------------------------------------------
-- 5. The Module
----------------------------------------------------------------------
local public = {}
public.create  = create
public.destroy = destroy

return public
