_G.build_settings = {
   orientation = {
--      default = "portrait",
      default = "landscapeRight",
      supported = {
--         "portrait", "portraitUpsideDown",
         "landscapeRight", "landscapeLeft",
      },
   },
   iphone = {
      plist = {
         UIAppFonts = { "Harrowprint.ttf", "SF Alien Encounters.ttf" },
         UIStatusBarHidden=true,
      },
   },
   androidPermissions = {
      "android.permission.INTERNET",
   },
}
