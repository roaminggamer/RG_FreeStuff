#!/bin/bash
rm -f ../build.settings
cp ./build.settings.landscapeRight ../build.settings

