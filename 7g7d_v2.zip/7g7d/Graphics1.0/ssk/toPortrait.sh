#!/bin/bash
rm -f ../build.settings
cp ./build.settings.portrait ..//build.settings
