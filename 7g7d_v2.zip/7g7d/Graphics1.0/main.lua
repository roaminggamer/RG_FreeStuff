-- =============================================================
-- main.lua
-- =============================================================
--
-- Register a dummy handler 'FIRST' if we are using the simulator
--
-- Tip: If you don't do this early, you'll get pop-ups in the simulator (and on devices)
--      This is great for device debugging, but I personally prefer the console output
--      when using the console
--
if( system.getInfo( "environment" ) == "simulator" ) then
	local function myUnhandledErrorListener( event )
		return true
	end
	Runtime:addEventListener("unhandledError", myUnhandledErrorListener)
end

----------------------------------------------------------------------
--	1. Requires
----------------------------------------------------------------------
-- Load SSK Globals & Libraries
--
require "ssk.globals"
require "ssk.loadSSK"

-- Load Button, Label, and Sound Presets
--
require "config.rg_standardButtons.presets"
require "config.rg_basicButtons.presets"

_G.presets = {}
presets.yarm = require "config.yarm.presets"
presets.sgreen = require "config.sgreen.presets"
presets.gflip = require "config.gflip.presets"
presets.schmup = require "config.schmup.presets"
presets.pinball = require "config.pinball.presets"
presets.follower = require "config.follower.presets"

require "config.rg_testButtons.presets"

-- Read in the 'build.settings' copy
require("build_settings")

_G.ifc_Splash      = require "modules.ifc_Splash"
_G.ifc_MainMenu    = require "modules.ifc_MainMenu"
_G.ifc_Options     = require "modules.ifc_Options"
_G.ifc_Credits     = require "modules.ifc_Credits"

_G.ifc_Help     = require "modules.ifc_Help"

_G.ifc_SelectLevel = require "modules.ifc_SelectLevel"

_G.playGUI = {}
_G.editGUI = {}
playGUI.yarm = require "modules.yarm_PlayGUI"
editGUI.yarm = require "modules.yarm_EditGUI"

playGUI.sgreen = require "modules.sgreen_PlayGUI"
editGUI.sgreen = require "modules.sgreen_EditGUI"

playGUI.gflip = require "modules.gflip_PlayGUI"
editGUI.gflip = require "modules.gflip_EditGUI"

playGUI.schmup = require "modules.schmup_PlayGUI"
editGUI.schmup = require "modules.schmup_EditGUI"

playGUI.pinball = require "modules.pinball_PlayGUI"
editGUI.pinball = require "modules.pinball_EditGUI"

playGUI.follower = require "modules.follower_PlayGUI"
editGUI.follower = require "modules.follower_EditGUI"

require( "sounds.sounds" )

local GGFile = require( "GGFile" )
local fileManager = GGFile:new()

----------------------------------------------------------------------
--	2. Initialization
----------------------------------------------------------------------
io.output():setvbuf("no") -- Don't use buffer for console messages
display.setStatusBar(display.HiddenStatusBar)  -- Hide that pesky bar

local physics = require("physics")
physics.start()
physics.setGravity(0,0)

if(options.debugEn) then
	--physics.setDrawMode( "hybrid" )
end
physics.setContinuous( true )
physics.setPositionIterations( 8 )
physics.setVelocityIterations( 4 )
--physics.setTimeStep(1/90)


_G.editorEnabled = true -- EFM

ssk.gem:post(  "EFFECTS_VOLUME_CHANGE" ) -- Fake volume change to update the effects volume
ssk.gem:post(  "MUSIC_VOLUME_CHANGE" )   -- Fake volume change to update the sound volume and start the soundtrack if neccesary

----------------------------------------------------------------------
-- 3. Declarations
----------------------------------------------------------------------
-- Additional Globls
_G.sceneCrossFadeTime = 0

_G.imageWidth = 32
_G.halfPieceWidth = imageWidth/2
_G.halfBoardRowCol = 8


_G.gameNames = { "#1 You Attract/Repel Me (10 hours)", 
	            "#2 Something Green (7 hours)", 
				"#3 Gravity Flipper (6 hours)", 
				"#4 Simple Schmup (11 hours)", 
				"#5 Pinball? (9 hours)",
				"#6 Line Follower (3 hours)", 
				"#7 Hangman 21 (incomplete)",}


_G.gameDirs = {}
gameDirs[gameNames[1]] =  "yarm"
gameDirs[gameNames[2]] =  "sgreen"
gameDirs[gameNames[3]] =  "gflip"
gameDirs[gameNames[4]] =  "schmup"
gameDirs[gameNames[5]] =  "pinball"
gameDirs[gameNames[6]] =  "follower"
gameDirs[gameNames[7]] =  "hangman21"


options.currentGameDir = options.currentGameDir or "yarm"

_G.currentPuzzle = {}

_G.currentMode = "play"

_G.currentLevelNum = 1

_G.premadeLevels = {}
premadeLevels.yarm = 0
premadeLevels.sgreen = 0
premadeLevels.gflip = 0
premadeLevels.schmup = 0
premadeLevels.pinball = 0
premadeLevels.follower = 0

_G.existingLevels = 0

for k,v in pairs( { "yarm", "sgreen", "gflip", "schmup", "pinball", "follower" } ) do

	fileManager:makeDirectory( "", v )
	for i = 1, 100 do
		if( io.exists(v .. "/levels/level" .. i .. ".txt", system.ResourceDirectory) and
			not io.exists(v .. "/level" .. i .. ".txt",system.DocumentsDirectory ) ) then
			print("Restoring level " .. i )			
			local tmp = table.load( v .. "/levels/level" .. i .. ".txt", system.ResourceDirectory)
			table.save( tmp, v .. "/level" .. i .. ".txt", system.DocumentsDirectory)
		else
			break
		end	
	end
end

----------------------------------------------------------------------
-- 4. Definitions
----------------------------------------------------------------------


----------------------------------------------------------------------
-- 5. Execution
----------------------------------------------------------------------
ifc_Splash.create()
--ifc_MainMenu.create()
--ifc_Help.create()
--ifc_Options.create()
--ifc_Credits.create()
--ifc_PlayGUI.create()
--ifc_SelectLevel.create()
--ifc_EditGUI.create()


