
local tmp = display.newText( "Icon Sampler - iOS", 0, 0, system.nativeFont, 20)
tmp.x = 160
tmp.y = 240
