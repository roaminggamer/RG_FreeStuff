Balloons from here:

http://clipart.nicubunu.ro/